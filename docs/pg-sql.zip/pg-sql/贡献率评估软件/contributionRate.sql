-- ----------------------------
-- Table structure for yw_toses_contribution_rate_calculated_value
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_contribution_rate_calculated_value`;
CREATE TABLE `yw_toses_contribution_rate_calculated_value`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `COMPETE_SCENE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MISSION_TASK_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INDICATOR_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CALCULATED_VALUE` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCENE_SCENARIO_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCENE_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '样本id',
  `BENCHMARK_SCENE_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '基础想定下的样本id',
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `SUM_B` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '结果值基础，综合值',
  `SUM_C` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '结果值基础，对比值',
  `TYPE` tinyint(4) NULL DEFAULT NULL COMMENT '贡献率类型（1-提升度的体系贡献率算法，2-需求的体系贡献率算法，3-加权综合体系贡献率算法）',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_contribution_rate_result
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_contribution_rate_result`;
CREATE TABLE `yw_toses_contribution_rate_result`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `COMPETE_SCENE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MISSION_TASK_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCENE_SCENARIO_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INDICATOR_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INDICATOR_RESULT` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `STANDARD_LABEL_VALUE` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `STANDARD_LABEL_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(6) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_contribution_weight
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_contribution_weight`;
CREATE TABLE `yw_toses_contribution_weight`  (
  `ID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '主键',
  `SID` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '方案ID',
  `WEIGHT` decimal(64, 3) NULL DEFAULT NULL COMMENT '权重',
  `CONTRIBUTION_RATE_TYPE` tinyint(255) NULL DEFAULT NULL COMMENT '贡献率类型',
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '创建时间',
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '更新时间',
  `CREATE_USER_ID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '创建人id',
  `UPDATE_USER_ID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '更新人id',
  `DELETE_FLAG` tinyint(4) NULL DEFAULT 0 COMMENT '删除标志：0 未删除 1 已删除',
  `DELETE_USER_ID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '删除人id',
  `DELETE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '贡献率结果权重信息' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_indicator
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_indicator`;
CREATE TABLE `yw_toses_indicator`  (
  `ID` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PID` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DESCRIBES` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `LEVEL` int(11) NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `CREATOR` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `SID` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `APPRANCE_ID` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TREE_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SORTNO` int(11) NULL DEFAULT NULL,
  `IS_USED_CALCOR_TEMPLATE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ALG_PARAM` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DIMENSION` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MAX_VALUE` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MIN_VALUE` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CONNOTATION` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `METHOD` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INDICATOR_SCORE` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `RELATION_INDICATORS` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `DIRECTORY_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TABLE_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INDICATOR_TYPE` varchar(2) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '指标类型  1 效益 0 成本',
  `VALUE` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INDICATOR_SOURCE` tinyint(4) NULL DEFAULT NULL COMMENT '指标来源 1：来源与任务 2：手动新建',
  `INDICATOR_SOURCE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '指标来源ID',
  PRIMARY KEY (`ID`) USING BTREE,
  UNIQUE INDEX `UNIQUE_YE_TOSES_INDICTOR`(`ID`, `PID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;


-- ----------------------------
-- Table structure for yw_toses_indicator_values
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_indicator_values`;
CREATE TABLE `yw_toses_indicator_values`  (
  `ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `SID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `INDICATOR_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `SCENE_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NORMALIZED_VALUE` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UN_NORMALIZED_VALUE` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `STANDARD_LABEL_VALUE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `STANDARD_LABEL_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `NATURE_VALUE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `DPLUS` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '正理想解值',
  `DMINUS` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '负理想解值',
  `PCL_VALUE` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '主成分分析值',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;