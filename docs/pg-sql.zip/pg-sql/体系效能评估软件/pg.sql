/*
 Navicat Premium Data Transfer

 Source Server         : 200
 Source Server Type    : MySQL
 Source Server Version : 50744
 Source Host           : 10.10.3.200:3306
 Source Schema         : pg_b2601j

 Target Server Type    : MySQL
 Target Server Version : 50744
 File Encoding         : 65001

 Date: 19/10/2026 14:35:43
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for cd_analysis_model
-- ----------------------------
DROP TABLE IF EXISTS `cd_analysis_model`;
CREATE TABLE `cd_analysis_model`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '模型名称',
  `DESCRIPTION` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '模型描述',
  `MODEL_TYPE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '模型类型',
  `CREATE_TIME` timestamp(6) NULL DEFAULT NULL COMMENT '创建时间',
  `UPDATE_TIME` timestamp(6) NULL DEFAULT NULL COMMENT '更新时间',
  `FILE_PATH` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '模型存储路径',
  `FILENAME` varchar(150) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '文件名',
  `SUB_FOLDER_NAME` varchar(150) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '子文件夹',
  `CLASS_NAME` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '类名名',
  `METHOD_NAME` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '方法名（多个逗号分隔）',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cd_custom_data_classification
-- ----------------------------
DROP TABLE IF EXISTS `cd_custom_data_classification`;
CREATE TABLE `cd_custom_data_classification`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '主键id',
  `CLASSIFICATION_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '分类名称',
  `CLASSIFICATION_DESC` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '分类描述',
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin COMMENT = '自定义数据分类' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cd_data_analysis
-- ----------------------------
DROP TABLE IF EXISTS `cd_data_analysis`;
CREATE TABLE `cd_data_analysis`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `HOST` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT 'ip地址',
  `USERNAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '用户账号',
  `PASSWORD` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '密码',
  `TASKNAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TYPE` int(11) NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(6) NULL DEFAULT NULL COMMENT '创建时间',
  `SID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DB_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '数据库名称',
  `DB_TYPE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '数据库类型',
  `PORT` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '端口',
  `ANALYSIS_MODEL_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ANALYSIS_TYPE` int(11) NULL DEFAULT NULL,
  `NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TASK_RUN_STATUS` int(11) NULL DEFAULT NULL,
  `INTERVAL_IN_SECONDS` int(11) NULL DEFAULT NULL,
  `UPDATE_POLICY` int(11) NULL DEFAULT NULL,
  `TASK_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cd_data_convert_script
-- ----------------------------
DROP TABLE IF EXISTS `cd_data_convert_script`;
CREATE TABLE `cd_data_convert_script`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '名称',
  `DESCRIPTION` text CHARACTER SET utf8 COLLATE utf8_bin NULL COMMENT '描述',
  `SCRIPT_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '脚本名称',
  `SCRIPT_PATH` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '脚本路径',
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '创建时间',
  `UPDATE_TIME` timestamp(6) NULL DEFAULT NULL COMMENT '更新时间',
  `DESCRIBE` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  UNIQUE INDEX `ID`(`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cd_data_directory
-- ----------------------------
DROP TABLE IF EXISTS `cd_data_directory`;
CREATE TABLE `cd_data_directory`  (
  `ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '目录名称',
  `PARENT_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '父目录id',
  `LEAF_NODE_FLAG` tinyint(4) NULL DEFAULT NULL COMMENT '叶子节点标识',
  `MARK` varchar(1024) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '扩展',
  `MARK_TYPE` int(11) NULL DEFAULT NULL COMMENT '扩展类型',
  `BUSINESS_KEY` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '业务标识',
  `DIRECTORY_TYPE` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '目录数据类型，用于标识当前目录节点存储的是什么类型的数据，例如当前节点存储的word数据，标识为word；当前节点存储的是视频数据，标识为video',
  `USER_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '用户ID',
  `ROUTING_PATH` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '路由地址',
  `COMPONENT` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SORT` int(11) NULL DEFAULT NULL COMMENT '排序字段',
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cd_data_record
-- ----------------------------
DROP TABLE IF EXISTS `cd_data_record`;
CREATE TABLE `cd_data_record`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '记录ID',
  `CREATE_TIME` timestamp(6) NULL DEFAULT NULL COMMENT '创建时间',
  `TABLE_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '表名',
  `OPERATION` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '操作',
  `UNI_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '唯一标识ID',
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin COMMENT = '数据清洗操作记录表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cd_data_table_classify
-- ----------------------------
DROP TABLE IF EXISTS `cd_data_table_classify`;
CREATE TABLE `cd_data_table_classify`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `CLASSIFY_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DATA_SRC_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(6) NULL DEFAULT NULL,
  `INCLUDE_TASKS` tinyint(4) NULL DEFAULT NULL,
  `PID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cd_data_table_manager
-- ----------------------------
DROP TABLE IF EXISTS `cd_data_table_manager`;
CREATE TABLE `cd_data_table_manager`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `TABLE_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '任务名称',
  `DATA_SRC_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '数据源id',
  `TABLE_CLASSIFY_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '分类id',
  `CREATE_TIME` timestamp(6) NULL DEFAULT NULL COMMENT '创建时间',
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  INDEX `TABLEMANAGERNAME`(`TABLE_NAME`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cd_datasrc
-- ----------------------------
DROP TABLE IF EXISTS `cd_datasrc`;
CREATE TABLE `cd_datasrc`  (
  `ID` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '数据源名称',
  `TYPE` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '数据源类型',
  `DB_USER` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '账号',
  `PASS` varchar(192) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '密码',
  `IP` varchar(765) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT 'ip地址',
  `DBNAME` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '数据库名称',
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '创建时间',
  `CREATOR` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '创建者',
  `FILE_NAME` varchar(765) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '附件名称',
  `PORT` varchar(60) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '端口',
  `TASK_TYPE` int(11) NULL DEFAULT NULL COMMENT '任务类型',
  `TASK_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '任务表名称',
  `DATABASE_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '数据库名称',
  `INCLUDE_TASKS` tinyint(4) NULL DEFAULT NULL COMMENT '是否关联任务数据库 1关联任务数据表 2无任务数据表',
  `ANALYSIS_TYPE` tinyint(4) NULL DEFAULT NULL COMMENT '解析类型 1从数据库导入 2从文件导入',
  `ANALYSIS_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '远程数据源id',
  `UPDATE_TIME` timestamp(6) NULL DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cd_filter_attribute
-- ----------------------------
DROP TABLE IF EXISTS `cd_filter_attribute`;
CREATE TABLE `cd_filter_attribute`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SOURCE_CHINESE_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SOURCE_ENGLISH_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DESCRIPTION` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cd_filter_attritube_relevance
-- ----------------------------
DROP TABLE IF EXISTS `cd_filter_attritube_relevance`;
CREATE TABLE `cd_filter_attritube_relevance`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SOURCE_CNAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SOURCE_ENAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DESCRIPTION` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INTERFACE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ATTRI_CONDITION` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ATTRI_VALUE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cd_filter_config
-- ----------------------------
DROP TABLE IF EXISTS `cd_filter_config`;
CREATE TABLE `cd_filter_config`  (
  `ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT 'ID',
  `GROUPING_COLUMN` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '分组列',
  `FOREIGN_KEY_COLUMN` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '外键列',
  `CALCULATION_COLUMN` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '计算列',
  `COLUMN_VALUE` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '列值',
  `CALCULATION_SYMBOL` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '计算符号',
  `FILTER_TYPE` tinyint(4) NULL DEFAULT NULL COMMENT '筛选类型',
  `CUSTOM_ID` int(11) NULL DEFAULT NULL COMMENT '自定义ID',
  `SORT_NO` int(11) NULL DEFAULT NULL COMMENT '排序',
  `RESULT_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '结果名称',
  `CALC_PARAM` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '计算参数',
  `LEFT_CUSTOM_ID` int(11) NULL DEFAULT NULL COMMENT '左自定义ID',
  `RIGHT_CUSTOM_ID` int(11) NULL DEFAULT NULL COMMENT '右自定义ID',
  `AGGREGATE_SYMBOL` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '聚合函数二次计算符号',
  `AGGREGATE_VALUE` decimal(10, 3) NULL DEFAULT NULL COMMENT '聚合函数二次计算值',
  `PROCESS_RESULT` text CHARACTER SET utf8 COLLATE utf8_bin NULL COMMENT '处理结果',
  `COLUMN_OPTIONS` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '列选项',
  `CONDITION_TEXT` text CHARACTER SET utf8 COLLATE utf8_bin NULL COMMENT '条件文本',
  `LASH_VELOCITY` text CHARACTER SET utf8 COLLATE utf8_bin NULL COMMENT '最大速度',
  `MAX_DISTANCE` text CHARACTER SET utf8 COLLATE utf8_bin NULL COMMENT '最大距离',
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cd_gather_logs
-- ----------------------------
DROP TABLE IF EXISTS `cd_gather_logs`;
CREATE TABLE `cd_gather_logs`  (
  `ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `GATHER_TIME` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `GATHER_SCHEME_NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `GATHER_MODEL` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `STORAGE_DIRECTORY` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TOTAL_NUMBER` int(11) NULL DEFAULT NULL,
  `TYPE` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `F1` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cd_gather_params_template
-- ----------------------------
DROP TABLE IF EXISTS `cd_gather_params_template`;
CREATE TABLE `cd_gather_params_template`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `PARAM_TYPE` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PARAM_CNAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PARAM_ENAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `HTTP_URL` varchar(512) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `HTTP_METHOD` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cd_gather_scheme
-- ----------------------------
DROP TABLE IF EXISTS `cd_gather_scheme`;
CREATE TABLE `cd_gather_scheme`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '方案名称',
  `STORAGE_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '存储名称',
  `DATA_SRC_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '数据源id',
  `DATA_SRC_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '数据源名称',
  `ROUND_TYPE` int(11) NULL DEFAULT NULL COMMENT '轮次类型：2：单次试验，1：多次试验',
  `ROUND_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '轮次标识',
  `GATHER_STRATEGY` int(11) NULL DEFAULT NULL COMMENT '采集策略：1：执行一次，2：定时',
  `UPDATE_STRATEGY` int(11) NULL DEFAULT NULL COMMENT '更新策略：1：全量，2：增量',
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '创建时间',
  `STATE` int(11) NULL DEFAULT NULL COMMENT '状态 0是关闭，1是激活',
  `TASK_COUNT` bigint(20) NULL DEFAULT NULL COMMENT '执行次数统计,默认就是零',
  `EXPRESSION` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '表达式',
  `OUTER_PLUG_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '方案外部激活插件',
  `EXECUTE_STATE` int(11) NULL DEFAULT NULL COMMENT '执行状态 0:无状态,1:执行中,2:执行结束',
  `USER_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '用户id',
  `PG_SCHEME_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '评估方案id',
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cd_gather_task
-- ----------------------------
DROP TABLE IF EXISTS `cd_gather_task`;
CREATE TABLE `cd_gather_task`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `CRON_EXPRESSION` varchar(765) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '定时任务cron表达式',
  `METHOD_NAME` varchar(765) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '要执行方法名称',
  `TYPE` int(11) NULL DEFAULT NULL COMMENT '采集类型：1：数据库解析，2：文件解析，3：接口解析,4:接口获取',
  `DESCRIPTION` varchar(765) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '任务描述',
  `BEAN_CLASS` varchar(765) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '任务执行时调用哪个类的方法 包名+类名',
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '创建时间',
  `UPDATE_TIME` timestamp(6) NULL DEFAULT NULL COMMENT '更新时间',
  `JOB_STATUS` int(11) NULL DEFAULT 1 COMMENT '任务状态：0：开始，1：暂停, 2:执行失败',
  `JOB_GROUP` varchar(765) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '任务分组',
  `JOB_NAME` varchar(765) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '任务名称',
  `DATA_ANALYZE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '链接源id',
  `DATA_SRC_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '存储源id',
  `DATABASE_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '数据库名称',
  `TABLE_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '表名称',
  `COVER_DATA` int(11) NULL DEFAULT NULL COMMENT '是否覆盖数据：1：是，2：否',
  `INCLUDE_TASKS` int(11) NULL DEFAULT NULL COMMENT '是否关联任务表：1：是，2：不关联',
  `COUNT` int(11) NULL DEFAULT 0 COMMENT '任务执行数量',
  `INTERFACE_PULLING_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '关联的接口导入表id',
  `GATHER_SCHEME_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '采集方案id',
  `TABLE_NAMES` text CHARACTER SET utf8 COLLATE utf8_bin NULL COMMENT '数据库采集任务表',
  `DIRECTORY_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '采集任务子目录名称',
  `ANALYSIS_MODEL_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '解析插件id',
  `ANALYSIS_MODEL_METHOD_NAME` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '解析插件方法名称',
  `GATHER_STRATEGY` int(11) NULL DEFAULT NULL COMMENT '采集策略：1：执行一次，2：定时',
  `GATHER_PARAMS_IDS` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '采集参数id,逗号分割',
  `GATHER_PARAM_URL` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '采集参数数据获取地址',
  `GATHER_PARAM_REQUEST_METHOD` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '接口请求方式，POST,GET',
  `GATHER_PARAMS_MSG` varchar(5000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '参数信息',
  `AUTO_CREATE_TYPE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '自动创建，手动创建',
  `EXECUTE_STATE` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `BASE_SCENARIO_TYPE` int(11) NULL DEFAULT NULL,
  `EXECUTE_ERROR_MSG` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '任务执行失败信息',
  `EXECUTE_TIME` bigint(20) NULL DEFAULT NULL COMMENT '执行时间',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cd_import_table_record
-- ----------------------------
DROP TABLE IF EXISTS `cd_import_table_record`;
CREATE TABLE `cd_import_table_record`  (
  `ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `FROM_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '\"来源id（数据库、接口、文件存储时返回的id）',
  `FROM_TYPE` int(11) NULL DEFAULT NULL COMMENT '来源类型（未知:UNKNOWN,DATABASE:1,API:2,FILE:3）',
  `TABLE_NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '数据导入时建表的表名',
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '记录时间',
  `DIRECTORY_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '所属目录id',
  `TABLE_NAME_ALIAS` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '表别名',
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cd_round_record
-- ----------------------------
DROP TABLE IF EXISTS `cd_round_record`;
CREATE TABLE `cd_round_record`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT '采集轮次id',
  `NAME` varchar(512) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '轮次名称',
  `TASK_ID` varchar(512) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '轮次id',
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '创建时间',
  `TABLE_NAMES` text CHARACTER SET utf8 COLLATE utf8_bin NULL COMMENT '表名称集合',
  `DATA_SRC_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '数据源id',
  `DIRECTORY_NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ROUND_FIELD` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '轮次字段',
  `PARAM` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '轮次参数',
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin COMMENT = '采集轮次记录表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cd_source_interface_propelling
-- ----------------------------
DROP TABLE IF EXISTS `cd_source_interface_propelling`;
CREATE TABLE `cd_source_interface_propelling`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `CREATE_TIME` timestamp(6) NULL DEFAULT NULL COMMENT '创建时间',
  `UPDATE_TIME` timestamp(6) NULL DEFAULT NULL COMMENT '更新时间',
  `ORDER_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '源系统名称',
  `ORDER_TABLE_CNAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '源数据库表中文名称',
  `ORDER_TABLE_ENAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '源数据库表英文名称',
  `UPDATE_POLICY` int(11) NULL DEFAULT NULL COMMENT '数据更新策略，0：全量  1：增量',
  `DATABASE_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '数据库名称',
  `DIRECTORY_ID` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '目录ID',
  `INTERFACE_URL` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '数据推送接口地址',
  `DATA_SRC_ID` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '数据源ID',
  `COLUMN_STR` varchar(512) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '表字段',
  `GATHER_SCHEME_ID` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '采集方案ID',
  `TASK_ID` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '采集任务ID',
  `TASK_COUNT` int(11) NULL DEFAULT 0 COMMENT '推送次数',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cd_source_interface_propelling_filed
-- ----------------------------
DROP TABLE IF EXISTS `cd_source_interface_propelling_filed`;
CREATE TABLE `cd_source_interface_propelling_filed`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(6) NULL DEFAULT NULL COMMENT '创建时间',
  `UPDATE_TIME` timestamp(6) NULL DEFAULT NULL COMMENT '更新时间',
  `JOGGLE_PROPELLING_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '接口记录表主键',
  `SOURCE_FILED_CNAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '源字段中文名称',
  `SOURCE_FILED_ENAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '源字段英文名称',
  `SOURCE_FILED_TYPE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '源字段类型',
  `ALIAS_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '字段别名',
  `DATA_CONREVERSION_RULE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '字段转换规则'
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cd_source_interface_pulling
-- ----------------------------
DROP TABLE IF EXISTS `cd_source_interface_pulling`;
CREATE TABLE `cd_source_interface_pulling`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(6) NULL DEFAULT NULL COMMENT '创建时间',
  `UPDATE_TIME` timestamp(6) NULL DEFAULT NULL COMMENT '更新时间',
  `INTERFACE_ADDRESS` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '接口完整地址，包括ip、端口、路径',
  `INTERFACE_TYPE` int(11) NULL DEFAULT NULL COMMENT '接口类型  0：HTTP,1:Web Service,3:RPC',
  `INTERFACE_METHOD` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '接口请求方式，POST,GET',
  `UPDATE_POLICY` int(11) NULL DEFAULT NULL COMMENT '数据更新策略，0：全量  1：增量',
  `ORDER_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '源系统名称',
  `ORDER_TABLE_CNAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '源数据库表中文名称',
  `ORDER_TABLE_ENAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '源数据库表英文名称',
  `INTERFACE_RUN_STATUS` int(11) NULL DEFAULT NULL COMMENT '接口运行状态  0：正常，1：暂停',
  `INTERFACE_COLLECTION_FREQUENCY` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '接口采集频率',
  `INTERFACE_COLLECTION_TASK_TYPE` int(11) NULL DEFAULT NULL COMMENT '接口采集任务类型',
  `DATABASE_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '数据库名称',
  `PAGE_KEY` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '页码key',
  `PAGE_VALUE` int(11) NULL DEFAULT NULL COMMENT '页码值',
  `LIMIT_KEY` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '条数key',
  `LIMIT_VALUE` int(11) NULL DEFAULT NULL COMMENT '条数值',
  `DIRECTORY_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '目录ID 用户选择目录的ID',
  `SOURCE_JSON` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `OUTER_PLUG_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '方案外部激活插件',
  `INTERFACE_INPUT_PARAM` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cd_source_interface_pulling_filed
-- ----------------------------
DROP TABLE IF EXISTS `cd_source_interface_pulling_filed`;
CREATE TABLE `cd_source_interface_pulling_filed`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(6) NULL DEFAULT NULL COMMENT '创建时间',
  `UPDATE_TIME` timestamp(6) NULL DEFAULT NULL COMMENT '更新时间',
  `JOGGLE_PULLING_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '接口记录表主键',
  `SOURCE_FILED_CNAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '源字段中文名称',
  `SOURCE_FILED_ENAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '源字段英文名称',
  `SOURCE_FILED_TYPE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '源字段类型',
  `ALIAS_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '字段别名',
  `DATA_CONREVERSION_RULE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '字段转换规则'
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cd_table_being_parsed
-- ----------------------------
DROP TABLE IF EXISTS `cd_table_being_parsed`;
CREATE TABLE `cd_table_being_parsed`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TABLE_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '表名称',
  `LIMIT_NUM` int(11) NULL DEFAULT NULL COMMENT '分页查询数量',
  `VERSION` int(11) NULL DEFAULT NULL COMMENT '版本',
  `IS_OVER` tinyint(4) NULL DEFAULT NULL,
  `CLASSIFY_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ANALYSIS_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DATA_SRC_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '数据源id',
  `SID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cd_table_chname
-- ----------------------------
DROP TABLE IF EXISTS `cd_table_chname`;
CREATE TABLE `cd_table_chname`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `TABLE_NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '表名称',
  `CH_NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '中文名称',
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '创建时间',
  `TASK_TYPE` int(11) NULL DEFAULT NULL COMMENT '任务类型',
  `FIELD_NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '字段英文名',
  `FLAG` int(11) NULL DEFAULT NULL COMMENT '类型 1为表, 2为字段',
  `DATA_SRC_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '数据源id',
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cd_table_info
-- ----------------------------
DROP TABLE IF EXISTS `cd_table_info`;
CREATE TABLE `cd_table_info`  (
  `ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `CREATE_FLAG` int(11) NULL DEFAULT NULL COMMENT '0:导入\r\n 1：自定义',
  `DATA_SRC_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '数据源id',
  `TABLE_NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '表名称',
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cd_toses_log
-- ----------------------------
DROP TABLE IF EXISTS `cd_toses_log`;
CREATE TABLE `cd_toses_log`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `USER_ID` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `USER_NAME` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `OPERATING_TIME` timestamp(0) NULL DEFAULT NULL,
  `OPERATE` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `LOG_TYPE` int(11) NULL DEFAULT NULL,
  `BUSINESS_TYPE` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCHEMA_EVALUATE_TYPE` int(11) NULL DEFAULT NULL,
  `ANALYSIS_TYPE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INDICATOR_TYPE` int(11) NULL DEFAULT NULL,
  `CREATOR` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `CREATOR_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCHEMA_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for collection_data_json_parse
-- ----------------------------
DROP TABLE IF EXISTS `collection_data_json_parse`;
CREATE TABLE `collection_data_json_parse`  (
  `ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `PID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PROJECT` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CONTENT` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `RESULT` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MAX` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MIN` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TASK_ID` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for flyway_schema_history
-- ----------------------------
DROP TABLE IF EXISTS `flyway_schema_history`;
CREATE TABLE `flyway_schema_history`  (
  `installed_rank` int(11) NOT NULL,
  `version` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `description` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `script` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `checksum` int(11) NULL DEFAULT NULL,
  `installed_by` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `installed_on` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `execution_time` int(11) NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`installed_rank`) USING BTREE,
  INDEX `flyway_schema_history_s_idx`(`success`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for fz_parse_template
-- ----------------------------
DROP TABLE IF EXISTS `fz_parse_template`;
CREATE TABLE `fz_parse_template`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `PROJECT_KEY` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CONTENT_KEY` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `RESULT_KEY` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MAX_KEY` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MIN_KEY` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TASK_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `JSON` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TABLE_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for fz_task
-- ----------------------------
DROP TABLE IF EXISTS `fz_task`;
CREATE TABLE `fz_task`  (
  `ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `DESCRIBE` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TASK_NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hangtian_snapshot_ff17dc032d874f0d804535c3b8f06a37
-- ----------------------------
DROP TABLE IF EXISTS `hangtian_snapshot_ff17dc032d874f0d804535c3b8f06a37`;
CREATE TABLE `hangtian_snapshot_ff17dc032d874f0d804535c3b8f06a37`  (
  `R2` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `R3` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TASK_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `R1` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for permission
-- ----------------------------
DROP TABLE IF EXISTS `permission`;
CREATE TABLE `permission`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `PARENT_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(384) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `PERMISSION` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `TYPE` int(11) NULL DEFAULT NULL,
  `PER_CODE` varchar(384) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `LABEL` int(11) NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '创建时间',
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`ID`) USING BTREE,
  UNIQUE INDEX `PER_CODE`(`PER_CODE`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for table_1
-- ----------------------------
DROP TABLE IF EXISTS `table_1`;
CREATE TABLE `table_1`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DESC` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `FLAG` int(11) NULL DEFAULT NULL,
  `CREATER_TIME` timestamp(0) NULL DEFAULT NULL,
  `SID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for test_flyway_table
-- ----------------------------
DROP TABLE IF EXISTS `test_flyway_table`;
CREATE TABLE `test_flyway_table`  (
  `id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `age` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for upload_file
-- ----------------------------
DROP TABLE IF EXISTS `upload_file`;
CREATE TABLE `upload_file`  (
  `ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `MD5` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PATH` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SIZE` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `STATUS` int(11) NULL DEFAULT NULL,
  `SUFFIX` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for wjpg_equ_equsystem
-- ----------------------------
DROP TABLE IF EXISTS `wjpg_equ_equsystem`;
CREATE TABLE `wjpg_equ_equsystem`  (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `EQUID` int(11) NULL DEFAULT NULL,
  `EQUSYSID` int(11) NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 57 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for wjpg_equ_param
-- ----------------------------
DROP TABLE IF EXISTS `wjpg_equ_param`;
CREATE TABLE `wjpg_equ_param`  (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CH_PARAM` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `EN_PARAM` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `EQU_ID` int(11) NULL DEFAULT NULL,
  `PARAM_VALUE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PARAM_TYPE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '创建时间',
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 28 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for wjpg_equ_sys_param
-- ----------------------------
DROP TABLE IF EXISTS `wjpg_equ_sys_param`;
CREATE TABLE `wjpg_equ_sys_param`  (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `EQU_SYS_ID` int(11) NULL DEFAULT NULL,
  `CH_PARAM` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `EN_PARAM` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PARAM_VALUE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PARAM_TYPE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '创建时间',
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 25 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for wjpg_equipment
-- ----------------------------
DROP TABLE IF EXISTS `wjpg_equipment`;
CREATE TABLE `wjpg_equipment`  (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `EQU_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CATEGORY` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DESCS` varchar(5000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `KEY_PARAM` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `PARAM` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '创建时间',
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 101 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for wjpg_equipment_system
-- ----------------------------
DROP TABLE IF EXISTS `wjpg_equipment_system`;
CREATE TABLE `wjpg_equipment_system`  (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `EQU_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DESCS` varchar(5000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `COMPOSITION` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `STATISTICAL_INFO` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '创建时间',
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for wjpg_task_condition
-- ----------------------------
DROP TABLE IF EXISTS `wjpg_task_condition`;
CREATE TABLE `wjpg_task_condition`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TYPE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DESCRIPTION` varchar(5000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `VALUE_TYPE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `VALUE_TYPE_DATA` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_jx_task_log
-- ----------------------------
DROP TABLE IF EXISTS `yw_jx_task_log`;
CREATE TABLE `yw_jx_task_log`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `TASK_ID` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TASK_NAME` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TASK_PROJECT` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `EQUIP_NAME` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TABLE_NAME` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `RESULT` int(11) NULL DEFAULT NULL,
  `CREATED_TIME` timestamp(0) NULL DEFAULT NULL,
  `CREATED_STAMP` bigint(20) NULL DEFAULT NULL,
  `ERROR_MESSAGE` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_jx_task_table
-- ----------------------------
DROP TABLE IF EXISTS `yw_jx_task_table`;
CREATE TABLE `yw_jx_task_table`  (
  `TASK_PROJECT` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TABLE_NAME` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `EQUIP_NAME` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `TASK_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TASK_NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_message_notice
-- ----------------------------
DROP TABLE IF EXISTS `yw_message_notice`;
CREATE TABLE `yw_message_notice`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `TITLE` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CONTENT` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `STATUS` int(11) NULL DEFAULT 0,
  `NOTICE_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_sys_dict
-- ----------------------------
DROP TABLE IF EXISTS `yw_sys_dict`;
CREATE TABLE `yw_sys_dict`  (
  `OBJ_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '主键',
  `PARENT_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '父ID',
  `DICT_CODE` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '字典码',
  `DICT_NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '字典名称',
  `DICT_KEY` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '字典键',
  `DICT_VALUE` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '字典值',
  `DICT_SORT` int(10) NULL DEFAULT NULL COMMENT '排序',
  `IS_ENABLED` int(10) NULL DEFAULT NULL COMMENT '是否启用,配置二选一的情况（0：否；1：是）',
  `DICT_REMARK` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '备注',
  `EXT_FIELD` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '拓展/备用字段',
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '创建时间',
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`OBJ_ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '字典表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_sys_file
-- ----------------------------
DROP TABLE IF EXISTS `yw_sys_file`;
CREATE TABLE `yw_sys_file`  (
  `ID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '文件id',
  `NAME` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '文件名',
  `PATH` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '相对路径',
  `FOLDER_ID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '文件分类',
  `UPLOAD_DATE` datetime(0) NULL DEFAULT NULL COMMENT '上传时间',
  `MD5` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '文件md5',
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_sys_file_folder
-- ----------------------------
DROP TABLE IF EXISTS `yw_sys_file_folder`;
CREATE TABLE `yw_sys_file_folder`  (
  `ID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '路径id',
  `PATH` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '文件夹相对路径',
  `NAME` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '文件夹名称',
  `IS_DEFAULT` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '1为默认路径',
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_sys_home_page
-- ----------------------------
DROP TABLE IF EXISTS `yw_sys_home_page`;
CREATE TABLE `yw_sys_home_page`  (
  `HOME_PAGE_NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '首页名称',
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `HOME_PAGE_BUSINESS` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '首页业务标识',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_sys_log_business
-- ----------------------------
DROP TABLE IF EXISTS `yw_sys_log_business`;
CREATE TABLE `yw_sys_log_business`  (
  `OBJ_ID` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT '日志ID',
  `LOG_TYPE` tinyint(4) NULL DEFAULT NULL COMMENT '日志类别(1.系统日志、2.业务日志)',
  `OPERATION_TYPE` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '操作类别（OperationType.class）',
  `LOG_MESSAGE` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL COMMENT '日志消息',
  `EXECUTE_CODE` int(10) NULL DEFAULT NULL COMMENT '执行方法返回消息code',
  `EXECUTE_MESSAGE` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL COMMENT '执行方法返回消息',
  `EXECUTE_TIME` bigint(20) NULL DEFAULT NULL COMMENT '执行耗时（毫秒）',
  `SERVICE_HOST` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '服务器名',
  `REMOTE_IP` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '请求IP',
  `USER_AGENT` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '用户代理',
  `REQUEST_URI` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '请求地址',
  `METHOD_CLASS` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '方法类',
  `METHOD_NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '方法名',
  `REQUEST_PARAMS` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL COMMENT '请求参数',
  `REQUEST_ID` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '请求ID',
  `UNIT` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '所属单位',
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '创建时间',
  `CREATE_USER_ID` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL COMMENT '创建用户ID',
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`OBJ_ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_sys_menu
-- ----------------------------
DROP TABLE IF EXISTS `yw_sys_menu`;
CREATE TABLE `yw_sys_menu`  (
  `ID` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `MENU_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `PARENT_ID` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT '0',
  `ORDER_NUM` smallint(6) NULL DEFAULT 0,
  `PATH` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `COMPONENT` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT 'MENU',
  `QUERY` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `VISIBLE` tinyint(4) NULL DEFAULT 0,
  `STATUS` tinyint(4) NULL DEFAULT 0,
  `PERMS` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `REMARK` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MENU_LEVEL` smallint(6) NULL DEFAULT NULL,
  `MENU_ICON` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `MENU_OPERATE` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `METHOD` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SOURCE_ID` int(11) NULL DEFAULT NULL,
  `HOME_PAGE_FLAG` int(11) NULL DEFAULT NULL,
  `MENU_TYPE` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_sys_menu_operate
-- ----------------------------
DROP TABLE IF EXISTS `yw_sys_menu_operate`;
CREATE TABLE `yw_sys_menu_operate`  (
  `ID` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `OPERATE_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `PARENT_ID` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT '0',
  `ORDER_NUM` smallint(6) NULL DEFAULT 0,
  `OPERATE_PATH` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `VISIBLE` tinyint(4) NULL DEFAULT 0,
  `STATUS` tinyint(4) NULL DEFAULT 0,
  `PERMS` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `REMARK` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `OPERATE_ICON` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `MENU_OPERATE` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;



-- ----------------------------
-- Table structure for yw_toese_evaluate_calcor
-- ----------------------------
DROP TABLE IF EXISTS `yw_toese_evaluate_calcor`;
CREATE TABLE `yw_toese_evaluate_calcor`  (
  `ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CALCOR_CODE` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DESCRIBE` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UNIT_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UNIT_NAME` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `AUTHOR_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `AUTHOR` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `IMAGE` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `METHOD` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ADDRESS` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TYPE` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DEVELOPMENT_TIME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toese_outlier_detection
-- ----------------------------
DROP TABLE IF EXISTS `yw_toese_outlier_detection`;
CREATE TABLE `yw_toese_outlier_detection`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `DATA_SRC_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DB_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `COL_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MIN_VALUE` double NULL DEFAULT NULL,
  `MAX_VALUE` double NULL DEFAULT NULL,
  `FILL_VALUE` double NULL DEFAULT NULL,
  `TABLE_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_adaptability
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_adaptability`;
CREATE TABLE `yw_toses_adaptability`  (
  `ID` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `BUSINESS_ID` char(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '业务id',
  `ADAPTABILITY_TYPE` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '类型',
  `DATA_JSON` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '数据内容',
  `CALCULATION_RESULT` double NULL DEFAULT NULL COMMENT '计算结果',
  `GRADE` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '等级',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_algorithm_configure
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_algorithm_configure`;
CREATE TABLE `yw_toses_algorithm_configure`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `EQU_ID` int(11) NULL DEFAULT NULL,
  `SID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `FLAG` int(11) NULL DEFAULT NULL,
  `EXECUTION_TIME` double NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(6) NULL DEFAULT NULL,
  `A_MATRIX` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `D_MATRIX` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `C_MATRIX` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `SCENE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_algorithm_param_config
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_algorithm_param_config`;
CREATE TABLE `yw_toses_algorithm_param_config`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `INDICATOR_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CALC_MODULE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ALG_PARAM` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_algorithm_result
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_algorithm_result`;
CREATE TABLE `yw_toses_algorithm_result`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `A_MATRIX` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `D_MATRIX` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `C_MATRIX` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `SCENE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_analyse_components
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_analyse_components`;
CREATE TABLE `yw_toses_analyse_components`  (
  `ID` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(96) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CATEGORY` varchar(96) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DESCRIBES` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `DATA_TYPE` int(11) NULL DEFAULT NULL,
  `TABLE_NAME` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CHART_TYPE` varchar(96) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `XAXES` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `YAXES` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `IMAGE` blob NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `CREATOR` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `AGG_FUNCTION` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DSID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DB_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `GROUP_BY` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ANALYSIS_TYPE` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TASK_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  UNIQUE INDEX `UNIQUE_YW_TOSES_ANALYSE_COMPONENTS`(`NAME`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_analyse_outer
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_analyse_outer`;
CREATE TABLE `yw_toses_analyse_outer`  (
  `ID` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `OUTER_CNAME` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `OUTER_URL` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `LIB_URL` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CLASS_NAME` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `METHOD_NAME` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PARAM` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `REQUEST_METHOD` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `RUN_TIME` timestamp(6) NULL DEFAULT NULL,
  `RUN_STATUS` int(11) NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(6) NULL DEFAULT NULL,
  `CREATOR` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ERROR_MSG` varchar(256) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_analyse_view_components
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_analyse_view_components`;
CREATE TABLE `yw_toses_analyse_view_components`  (
  `VID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `COMPONENT_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `SORTNO` int(11) NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`VID`, `COMPONENT_ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_analyse_views
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_analyse_views`;
CREATE TABLE `yw_toses_analyse_views`  (
  `ID` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CANVAS_ID` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DESTINATION` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `CONCLUSION` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `CREATOR` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `BACKGROUND` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `WIDTH` int(11) NULL DEFAULT NULL,
  `HEIGHT` int(11) NULL DEFAULT NULL,
  `JSON` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `SID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TYPE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CONTRAST_JSON` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_author_information
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_author_information`;
CREATE TABLE `yw_toses_author_information`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `AUTHOR_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `AUTHOR_DESC` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UNIT_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_calc_module
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_calc_module`;
CREATE TABLE `yw_toses_calc_module`  (
  `ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `SID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `NAME` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INDICATOR_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `JSON` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `DSIDS` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `CREATE_TIME` timestamp(6) NULL DEFAULT NULL,
  `DEFAULT_CAL_MODULE` tinyint(4) NULL DEFAULT NULL,
  `CALC_TYPE` tinyint(4) NULL DEFAULT NULL,
  `ALG_PARAM` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `METHOD_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_calc_module_template
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_calc_module_template`;
CREATE TABLE `yw_toses_calc_module_template`  (
  `ID` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `TASK_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INDICATOR_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `JSON` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `TREE_NAME` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `SID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CALC_TYPE` tinyint(4) NULL DEFAULT NULL,
  `METHOD_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DEFINED_TYPE` tinyint(4) NULL DEFAULT 0,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_calcor
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_calcor`;
CREATE TABLE `yw_toses_calcor`  (
  `ID` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `PID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `NAME` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CALCOR_LIB_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INDICATOR_ID` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CALC_MODULE_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SHOW_VALUE` tinyint(4) NULL DEFAULT NULL,
  `OUTOR` tinyint(4) NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `CREATOR` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `COL_NAME` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DEFAULT_VALUE` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `USE_DEFAULT` tinyint(4) NULL DEFAULT NULL,
  `INS` varchar(765) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `OUS` varchar(765) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `VALUE_TYPE` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ALIAS_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PARAM` varchar(2555) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SORTNO` int(11) NULL DEFAULT NULL,
  `TASK_TYPE` int(11) NULL DEFAULT NULL,
  `USE_NATURE` tinyint(4) NULL DEFAULT NULL,
  `OUT_PLUG_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_calcor_cate
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_calcor_cate`;
CREATE TABLE `yw_toses_calcor_cate`  (
  `ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SORTNO` int(11) NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_calcor_inputparam
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_calcor_inputparam`;
CREATE TABLE `yw_toses_calcor_inputparam`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TYPE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `EVALUATE_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_calcor_lib
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_calcor_lib`;
CREATE TABLE `yw_toses_calcor_lib`  (
  `ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CODE` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ICON` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `CID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SORTNO` int(11) NULL DEFAULT NULL,
  `SHOWS` tinyint(4) NULL DEFAULT NULL,
  `DESCRIBES` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `EDIT` tinyint(4) NULL DEFAULT NULL,
  `INPUTS` int(11) NULL DEFAULT NULL,
  `OUTS` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_calcor_relevatn_schema
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_calcor_relevatn_schema`;
CREATE TABLE `yw_toses_calcor_relevatn_schema`  (
  `ID` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `SCHEMA_ID` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CALCAOR_ID` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_calcor_template
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_calcor_template`;
CREATE TABLE `yw_toses_calcor_template`  (
  `ID` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `PID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TASK_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CALCOR_LIB_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INDICATOR_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CALC_MODULE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SHOW_VALUE` tinyint(4) NULL DEFAULT NULL,
  `OUTOR` tinyint(4) NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `CREATOR` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `COL_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DEFAULT_VALUE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `USE_DEFAULT` tinyint(4) NULL DEFAULT NULL,
  `INS` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `OUS` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `VALUE_TYPE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ALIAS_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PARAM` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_calcor_values
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_calcor_values`;
CREATE TABLE `yw_toses_calcor_values`  (
  `ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `SCENE_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `CALCOR_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `INDICATOR_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `VALUE` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_cfg_task_condition
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_cfg_task_condition`;
CREATE TABLE `yw_toses_cfg_task_condition`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `TASK_TYPE` int(11) NULL DEFAULT NULL,
  `TASK_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TASK_DESC` varchar(5000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TASK_CONDITION` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `CREATE_TIME` timestamp(6) NULL DEFAULT NULL,
  `TASK_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `EQU_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DATA_SRC_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_comp_status_relation
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_comp_status_relation`;
CREATE TABLE `yw_toses_comp_status_relation`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `STATE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `COMP_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `STATUS` double NULL DEFAULT NULL,
  `SID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(6) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_compete_scene
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_compete_scene`;
CREATE TABLE `yw_toses_compete_scene`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TASK_COUNT` int(11) NULL DEFAULT NULL,
  `EQUIPMENT_COUNT` int(11) NULL DEFAULT NULL,
  `DESCS` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `SID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TASK_IDS` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `FIGHTER_TIME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ENEMY` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `FIGHTER_AREA` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TASK_MODEL` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `COL_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `COL_CNAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SOURCE_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_compete_scene_details
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_compete_scene_details`;
CREATE TABLE `yw_toses_compete_scene_details`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT '主键',
  `COMPETE_SCENE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '场景ID',
  `OPERATION_PURPOSE` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '作战目的',
  `OPPONENT_FEATURES` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '对手特征',
  `TERRAIN_TYPE` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '地形类型',
  `WEATHER` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '天气',
  `VISIBILITY` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '能见度',
  `WIND_SPEED` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '风速',
  `OUR_SIDE_TROOPS` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '我方兵力配置',
  `ENEMY_TROOPS` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '敌方兵力配置',
  `CREATE_USER_ID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建用户ID',
  `UPDATE_USER_ID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '修改用户ID',
  `DELETE_USER_ID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '删除人ID',
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '创建时间',
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '更新时间',
  `DELETE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '删除时间',
  `DELETE_FLAG` int(1) NULL DEFAULT 0 COMMENT '逻辑删除（默认：1：已删除、0：未删除）',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '场景详情信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_component_info
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_component_info`;
CREATE TABLE `yw_toses_component_info`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `SID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ALG_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `COMP_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `FAILURE_RATE` double NULL DEFAULT NULL,
  `REPAIR_RATE` double NULL DEFAULT NULL,
  `INDICATOR_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(6) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_contribution_rate_algorithm
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_contribution_rate_algorithm`;
CREATE TABLE `yw_toses_contribution_rate_algorithm`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `COMPETE_SCENE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MISSION_TASK_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCENE_SCENARIO_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CALC_MODULE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INDICATOR_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCENE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCENE_OWNER` tinyint(4) NULL DEFAULT NULL,
  `OVER_FLAG` smallint(6) NULL DEFAULT 0,
  `GATHER_PARAMS_IDS` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `AUTO_CREATE_TYPE` int(11) NULL DEFAULT NULL,
  `BASE_SCENARIO_TYPE` int(11) NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;


-- ----------------------------
-- Table structure for yw_toses_custom_data
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_custom_data`;
CREATE TABLE `yw_toses_custom_data`  (
  `ID` int(11) NOT NULL,
  `CUSTOM_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `EXECUTE_SQL` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DATA_SRC` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CUSTOM_DESC` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `CUSTOM_TYPE` tinyint(4) NULL DEFAULT NULL,
  `JSON_STR` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `CUSTOM_RESULT` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `EXECUTE_TYPE` tinyint(4) NULL DEFAULT NULL,
  `PENDING_RESULT` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `CLASSIFICATION_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `STATUS` int(11) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `CREATE_DATE` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  UNIQUE INDEX `CUSTOM_NAME`(`CUSTOM_NAME`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_data_record
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_data_record`;
CREATE TABLE `yw_toses_data_record`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `TABLE_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `OPERATION` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UNI_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_directory_tree
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_directory_tree`;
CREATE TABLE `yw_toses_directory_tree`  (
  `ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PATH` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TYPE` int(11) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_equipment_component
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_equipment_component`;
CREATE TABLE `yw_toses_equipment_component`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `EQU_ID` int(11) NULL DEFAULT NULL,
  `NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ATTRIBUTES` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `ORIGINAL_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CATEGORY` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `EQUIPMENT_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_evaluate_alg
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_evaluate_alg`;
CREATE TABLE `yw_toses_evaluate_alg`  (
  `ID` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CODE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SORTNO` int(11) NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `INDICATOR_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  INDEX `YW_TOSES_EVALUATE_ALG_UNIQUE_SID`(`SID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_evaluate_calcor
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_evaluate_calcor`;
CREATE TABLE `yw_toses_evaluate_calcor`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CALCOR_CODE` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `REMAKE` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UNIT_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UNIT_NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `AUTHOR_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `AUTHOR` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `DEVELOPMENT_TIME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `IMAGE` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `METHOD` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ADDRESS` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TYPE` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ENTITY_TYPE` int(11) NOT NULL DEFAULT 0,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `INVOKE_TYPE` int(11) NULL DEFAULT NULL COMMENT '调用类型：1 外部算子 2 python脚本 3 so动态链接库',
  `SCRIPT_PATH` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '脚本路径'
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_experiment_precept
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_experiment_precept`;
CREATE TABLE `yw_toses_experiment_precept`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INDICATOR_SYSTEM` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `STATE` int(11) NULL DEFAULT NULL,
  `INDICATOR_MODEID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DESCS` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCHEMA_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_factor
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_factor`;
CREATE TABLE `yw_toses_factor`  (
  `ID` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `SCENE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `FACTOR_CODE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `FACTOR_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `FACTOR_VALUE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  UNIQUE INDEX `UNIQUE_YW_TOSES_FACTOR`(`ID`, `SCENE_ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_gantt
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_gantt`;
CREATE TABLE `yw_toses_gantt`  (
  `ID` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `SERIAL_NUM` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `START_ALG` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `END_ALG` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INDICATOR_NAME` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `REAL_START_COL` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  UNIQUE INDEX `UNIQUE_YW_TOSES_GANTT`(`INDICATOR_NAME`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_indicator
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_indicator`;
CREATE TABLE `yw_toses_indicator`  (
  `ID` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PID` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DESCRIBES` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `LEVEL` int(11) NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `CREATOR` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `SID` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `APPRANCE_ID` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TREE_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SORTNO` int(11) NULL DEFAULT NULL,
  `IS_USED_CALCOR_TEMPLATE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ALG_PARAM` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DIMENSION` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MAX_VALUE` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MIN_VALUE` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CONNOTATION` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `METHOD` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INDICATOR_SCORE` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `RELATION_INDICATORS` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `DIRECTORY_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TABLE_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INDICATOR_TYPE` varchar(2) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '指标类型  1 效益 0 成本',
  `VALUE` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INDICATOR_SOURCE` tinyint(4) NULL DEFAULT NULL COMMENT '指标来源 1：来源与任务 2：手动新建',
  `INDICATOR_SOURCE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '指标来源ID',
  PRIMARY KEY (`ID`) USING BTREE,
  UNIQUE INDEX `UNIQUE_YE_TOSES_INDICTOR`(`ID`, `PID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_indicator_calculation_parameter
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_indicator_calculation_parameter`;
CREATE TABLE `yw_toses_indicator_calculation_parameter`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `SCHEMA_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INDICATOR_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PARAMETER_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SOURCE` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DIMENSION` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INSTRUCTIONS` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PARAM_KEY` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SOURCE_TYPE` int(11) NULL DEFAULT NULL,
  `WEAPON_ID_LIST` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PAYLOAD_ID_LIST` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_indicator_cata
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_indicator_cata`;
CREATE TABLE `yw_toses_indicator_cata`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SORTNO` int(11) NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `DESCS` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_indicator_choose_values
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_indicator_choose_values`;
CREATE TABLE `yw_toses_indicator_choose_values`  (
  `ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `SID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `INDICATOR_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `SCENE_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `VALUE` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_indicator_combine_credibility
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_indicator_combine_credibility`;
CREATE TABLE `yw_toses_indicator_combine_credibility`  (
  `ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `SCHEMA_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `INDICATOR_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `MATCH_RATE` double NULL DEFAULT NULL COMMENT '满足度计算结果',
  `COMBINE_CREDIBILITY_PARAM` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '条件信度参数json',
  `COMBINE_CREDIBILITY_NUMBER` int(11) NULL DEFAULT NULL COMMENT '规则数量',
  `INDICATOR_NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `SCENE_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_indicator_criteria
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_indicator_criteria`;
CREATE TABLE `yw_toses_indicator_criteria`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCENE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TASK_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INDICATOR_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MAX_VALUE` double NULL DEFAULT NULL,
  `MIN_VALUE` double NULL DEFAULT NULL,
  `TYPE` int(11) NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `SOURCE_INDICATOR_STANDARD` varchar(125) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `FUNC` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '评估矩阵准则输出值',
  `CREATE_DATE` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_DATE` timestamp(0) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_indicator_parameter_association
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_indicator_parameter_association`;
CREATE TABLE `yw_toses_indicator_parameter_association`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `INDICATOR` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PARAM_VALUE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_indicator_standard
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_indicator_standard`;
CREATE TABLE `yw_toses_indicator_standard`  (
  `ID` varchar(36) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `INDICATOR_ID` varchar(36) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `LABEL_ID` varchar(36) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MIN` varchar(36) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MAX` varchar(36) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MIN_SYMBOL` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MAX_SYMBOL` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCRIPT_PATH` varchar(250) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `STATUS` tinyint(4) NULL DEFAULT NULL,
  `FUNC` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INDICATOR_STAN_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `OPEN_FLAG` tinyint(4) NULL DEFAULT 0,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_indicator_standard_values
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_indicator_standard_values`;
CREATE TABLE `yw_toses_indicator_standard_values`  (
  `SID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `INDICATOR_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `SCENE_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `LABEL_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `LABEL_VALUE` double NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_indicator_tree
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_indicator_tree`;
CREATE TABLE `yw_toses_indicator_tree`  (
  `ID` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DESCRIBES` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `JSON` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `CREATOR` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `SID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ALG_PARAM` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MODEL_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INDICATOR_TREE_TYPE` int(11) NULL DEFAULT 1,
  `CREATE_DATE` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_DATE` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_indicator_value_info
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_indicator_value_info`;
CREATE TABLE `yw_toses_indicator_value_info`  (
  `ID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `SCHEMA_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `INDICATOR_NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '指标名称',
  `VALUE_UNIT` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '量纲',
  `INDICATOR_VALUE` double NULL DEFAULT NULL COMMENT '实际值',
  `CREDIBILITY_RATE` double NULL DEFAULT NULL COMMENT '实际值可信度',
  `IDEAL_VALUE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '理想值',
  `MIN_VALUE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '最低值',
  `INDICATOR_TYPE` int(11) NULL DEFAULT NULL COMMENT '属性',
  `INDICATOR_LEVEL` int(11) NULL DEFAULT NULL COMMENT '指标层级',
  `INDICATOR_ID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '指标id',
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `SCENE_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '样本id',
  `BEST_VALUE` decimal(10, 2) NULL DEFAULT NULL COMMENT '最佳值',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_indicator_values
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_indicator_values`;
CREATE TABLE `yw_toses_indicator_values`  (
  `ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `SID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `INDICATOR_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `SCENE_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NORMALIZED_VALUE` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UN_NORMALIZED_VALUE` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `STANDARD_LABEL_VALUE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `STANDARD_LABEL_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `NATURE_VALUE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `DPLUS` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '正理想解值',
  `DMINUS` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '负理想解值',
  `PCL_VALUE` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '主成分分析值',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_indicator_weight
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_indicator_weight`;
CREATE TABLE `yw_toses_indicator_weight`  (
  `ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `SID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INDICATOR_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `WEIGHT_MODEL_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `WEIGHT` double NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`, `WEIGHT_MODEL_ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_inner_plug
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_inner_plug`;
CREATE TABLE `yw_toses_inner_plug`  (
  `ID` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `INNER_REQ_PLUG_NAME` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `THIRD_URL` varchar(256) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `REQUEST_METHOD` varchar(10) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(6) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(6) NULL DEFAULT NULL,
  `CLASS_NAME` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `FILE_PATH` varchar(256) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `FILE_NAME` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PLUG_TYPE` int(11) NULL DEFAULT 1,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_issued_task
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_issued_task`;
CREATE TABLE `yw_toses_issued_task`  (
  `ID` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TASK_DESCRIBE` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MODEL` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `EXPERIMENT_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `IS_NEW` tinyint(4) NULL DEFAULT NULL,
  `EVALUATION_TASK` int(11) NULL DEFAULT NULL,
  `EVALUATION_SUB` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_linear_interpolation
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_linear_interpolation`;
CREATE TABLE `yw_toses_linear_interpolation`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `DATE_HOURS` double NULL DEFAULT NULL,
  `PHASE_DIFFERENCE` double NULL DEFAULT NULL,
  `SPEED` double NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_mainnavigate_tree_result
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_mainnavigate_tree_result`;
CREATE TABLE `yw_toses_mainnavigate_tree_result`  (
  `ID` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(36) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SORTNO` int(11) NULL DEFAULT NULL,
  `SID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCENE_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_mission_task
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_mission_task`;
CREATE TABLE `yw_toses_mission_task`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DESCS` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `FLAG` int(11) NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `SID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `BACK_GROUND` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SOURCE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `COMPETE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TASK_TYPE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TASK_GOAL` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_mission_task_details
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_mission_task_details`;
CREATE TABLE `yw_toses_mission_task_details`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT '主键',
  `MISSION_TASK_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '任务ID',
  `CORRELATION_TASK_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '关联任务ID',
  `CORRELATION_TYPE` tinyint(4) NULL DEFAULT NULL COMMENT '关联类型（1-前后逻辑关系、2-依赖关系、3-协同关系、4-自定义关系）',
  `RELATIONSHIP_DESCRIPTION` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '关系描述',
  `EVALUATION_INDICATORS` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '任务完成度评价指标（json）',
  `CREATE_USER_ID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建用户ID',
  `UPDATE_USER_ID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '修改用户ID',
  `DELETE_USER_ID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '删除人ID',
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '创建时间',
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '更新时间',
  `DELETE_TIME` timestamp(0) NULL DEFAULT NULL COMMENT '删除时间',
  `DELETE_FLAG` int(1) NULL DEFAULT 0 COMMENT '逻辑删除（默认：1：已删除、0：未删除）',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '任务详情表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_model_indicator
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_model_indicator`;
CREATE TABLE `yw_toses_model_indicator`  (
  `ID` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TREE_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TYPE` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PID` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DESCRIBES` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `LEVEL` int(11) NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `CREATOR` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `SID` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `APPRANCE_ID` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DIMENSION` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MAX_VALUE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MIN_VALUE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CONNOTATION` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `METHOD` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `RELATION_INDICATORS` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `SOURCE_INDICATOR` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '原始指标id',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_model_indicator_alone
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_model_indicator_alone`;
CREATE TABLE `yw_toses_model_indicator_alone`  (
  `ID` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TYPE` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DESCRIBES` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `CREATE_TIME` timestamp(6) NULL DEFAULT NULL,
  `CREATOR` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(6) NULL DEFAULT NULL,
  `DIMENSION` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MAX_VALUE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MIN_VALUE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CONNOTATION` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `METHOD` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `JSON` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `CID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `APPRANCE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_DATE` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_DATE` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_model_indicator_alone_cata
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_model_indicator_alone_cata`;
CREATE TABLE `yw_toses_model_indicator_alone_cata`  (
  `ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SORTNO` char(10) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(6) NULL DEFAULT NULL,
  `DESC` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `CREATE_DATE` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_DATE` timestamp(0) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_model_indicator_cata
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_model_indicator_cata`;
CREATE TABLE `yw_toses_model_indicator_cata`  (
  `ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SORTNO` int(11) NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(6) NULL DEFAULT NULL,
  `DESC` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  UNIQUE INDEX `ID`(`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_model_indicator_tree
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_model_indicator_tree`;
CREATE TABLE `yw_toses_model_indicator_tree`  (
  `ID` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DESCRIBES` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `JSON` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `CREATOR` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `CID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DEFAULT_CALC_MODULE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INDICATOR_TREE_TYPE` int(11) NULL DEFAULT 1,
  `MODEL_CONTENT` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL COMMENT '权重，算法内容',
  `SOURCE_INDICATOR` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL COMMENT '原始指标id',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_model_standard
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_model_standard`;
CREATE TABLE `yw_toses_model_standard`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DESCS` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TYPE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_model_standard_labels
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_model_standard_labels`;
CREATE TABLE `yw_toses_model_standard_labels`  (
  `ID` varchar(36) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(36) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SORTNO` int(11) NULL DEFAULT NULL,
  `VALUE` varchar(36) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CODE` varchar(36) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DESCRIBES` varchar(36) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MAX` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MIN` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MIN_SYMBOL` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MAX_SYMBOL` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCRIPT_PATH` varchar(250) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `FUNC` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `STATUS` int(11) NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_oper_exc_log
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_oper_exc_log`;
CREATE TABLE `yw_toses_oper_exc_log`  (
  `ID` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `URL` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `IP` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `USER_ID` varchar(36) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `USER_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `OPER_METHOD` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `EXC_NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `EXC_MESSAGE` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `OPER_DATE` timestamp(0) NULL DEFAULT NULL,
  `REQ_PARAM` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_outer_plug
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_outer_plug`;
CREATE TABLE `yw_toses_outer_plug`  (
  `ID` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `OUTER_CNAME` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `OUTER_URL` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `LIB_URL` varchar(256) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CLASS_NAME` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `METHOD_NAME` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PARAM` varchar(2048) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `REQUEST_METHOD` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `RUN_TIME` timestamp(6) NULL DEFAULT NULL,
  `RUN_STATUS` int(11) NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(6) NULL DEFAULT NULL,
  `CREATOR` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ERROR_MSG` varchar(256) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PLUG_TYPE` int(11) NULL DEFAULT 1,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_parts_state
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_parts_state`;
CREATE TABLE `yw_toses_parts_state`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `STATE_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(6) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_pieplot
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_pieplot`;
CREATE TABLE `yw_toses_pieplot`  (
  `ID` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `SERIAL_NUM` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MAX_ALG` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MIN_ALG` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `AVG_ALG` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INDICATOR_NAME` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  UNIQUE INDEX `UNIQUE_YW_TOSES_PIEPLOT`(`INDICATOR_NAME`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;



-- ----------------------------
-- Table structure for yw_toses_role_menu
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_role_menu`;
CREATE TABLE `yw_toses_role_menu`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `ROLE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MENU_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_scenario_sides
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_scenario_sides`;
CREATE TABLE `yw_toses_scenario_sides`  (
  `ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `BRIEFING` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `FORCE_TYPE` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `COLOR` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ALLIANCE_SIDES` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `NEUTRAL_SIDES` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `FOE_SIDES` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `FORCES` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `EQUIP_FROM` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_scene
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_scene`;
CREATE TABLE `yw_toses_scene`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATOR` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SORTNO` int(11) NULL DEFAULT NULL,
  `DESCRIBES` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `FILTER_COL` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `FILTER_VALUE` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `FILTER_COMMON` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `EXPERIMENT_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ISSUED_TASK_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SAMPLE_TASK_ID` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SUMMARY` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCENE_TYPE` tinyint(4) NULL DEFAULT NULL,
  `TREE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCENE_DATA_TYPE` tinyint(4) NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `TARGET_CORT` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '目标毁伤',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_scene_revelvant_equipment
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_scene_revelvant_equipment`;
CREATE TABLE `yw_toses_scene_revelvant_equipment`  (
  `ID` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `SCENE_ID` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `EQUIPMENT_NAME` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `EQUIPMENT_ID` int(11) NULL DEFAULT NULL,
  `CATEGORY` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_scene_scenario
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_scene_scenario`;
CREATE TABLE `yw_toses_scene_scenario`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `SCENE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCENARIO_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `EQUIPMENT_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `EQUIPMENT_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `COMPETE_SCENE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DESCS` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ATTRIBUTE_PROPERTY` tinyint(4) NULL DEFAULT NULL,
  `EQUIPMENT_NUM` int(11) NULL DEFAULT NULL,
  `OUR_TROOP_DEPLOYMENT` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `OTHER_TROOP_DEPLOYMENT` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ALLIANCE_DEPLOYMENT` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `OUR_NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `FOE_SIDES` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ALLIANCE_SIDEIDS` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `NEUTRAL_SIDEIDS` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `START_TIME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DURATION` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `AREA` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ADD_TYPE` tinyint(4) NULL DEFAULT NULL,
  `SIDE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `EQUIPMENT_CATEGORY` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `IDE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SOURCE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TASK_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SUBTYPE` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PARENT_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TYPE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SAMPLE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCENE_SCENARIO_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MODEL_ID` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `COMPONENT_ID` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT '0',
  `BASE_SCENARIO_TYPE` int(11) NULL DEFAULT NULL,
  `BASESCENARIO_TYPE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CS` int(11) NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `SCENE_SC_TYPE` tinyint(4) NULL DEFAULT NULL COMMENT '想定类型 1 是基础 2 是对比',
  `SCENARIO_BACKGROUND` varchar(512) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '想定背景',
  `SCENARIO_ATTEMPT` varchar(512) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '想定企图',
  `SCENARIO_SITUATION` varchar(512) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '想定态势图片路径(jpg/png)',
  `SCENARIO_FILE` varchar(512) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '想定文件',
  `OUR_SIDE_TROOPS` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL COMMENT '选配装备',
  `EXPERIMENTAL_FACTOR` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL COMMENT '试验因子',
  PRIMARY KEY (`ID`) USING BTREE,
  INDEX `CS`(`CS`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_scene_scenario_file
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_scene_scenario_file`;
CREATE TABLE `yw_toses_scene_scenario_file`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CONTENT` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `DESCRIPT` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `EQUIPMENT_NAME` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCENE_JSON` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `SCENE_SCENARIO_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TASK_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `P1` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `P2` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SOURCE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCENE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SOURCE_JSON` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `SUBTYPE` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TYPE` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PARENT_NAME` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SAMPLE_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_scene_sides_info
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_scene_sides_info`;
CREATE TABLE `yw_toses_scene_sides_info`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `SCENE_SCENARIO_ID` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCHEME_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CATEGORY` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `OWNING_EQUIPMENT` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `EQUIPMENT_OR_COMPONENT` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PARAM` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PARAM_VALUE` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TYPE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DESCRIBE` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DIMENSION` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SIDE_NAME` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCENE_SCENARIO_NAME` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `WEAPON_ID` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PAYLOAD_ID` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `REMARK` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_scene_table
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_scene_table`;
CREATE TABLE `yw_toses_scene_table`  (
  `ID` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `DSID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DB_NAME` varchar(150) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TABLE_NAME` varchar(150) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ALIAS_ID` varchar(96) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DESCRIBES` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `FILTER_COL` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `FILTER_VALUE` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SORTNO` int(11) NULL DEFAULT NULL,
  `COL_NAMES` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INCLUDE_TASKS` tinyint(4) NULL DEFAULT NULL,
  `INDICATOR_TREE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DATA_TABLE_TYPE` smallint(6) NULL DEFAULT NULL,
  `YW_TOSES_DATA_DIRECTORY` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CORRESPONDING_COLNAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCENE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `IS_CAL_FLAG` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INDICATOR_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_scene_table_template
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_scene_table_template`;
CREATE TABLE `yw_toses_scene_table_template`  (
  `ID` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DESCRIBES` char(100) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_USER` char(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_USER` char(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INCLUDE_TASKS` tinyint(4) NULL DEFAULT NULL,
  `DEFINED_TYPE` tinyint(4) NULL DEFAULT 0,
  `CALC_MODULE_TEMPLATE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_scene_table_template_data
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_scene_table_template_data`;
CREATE TABLE `yw_toses_scene_table_template_data`  (
  `ID` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `DSID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DB_NAME` varchar(150) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TABLE_NAME` varchar(150) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ALIAS_ID` varchar(96) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SORTNO` int(11) NULL DEFAULT NULL,
  `COL_NAMES` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INCLUDE_TASKS` tinyint(4) NULL DEFAULT NULL,
  `TEMPLATE_ID` char(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DESCRIBES` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_schema
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_schema`;
CREATE TABLE `yw_toses_schema`  (
  `ID` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CODE` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ASSESS_OBJECT` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `ASSESS_TARGET` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `DESCRIBES` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `CREATOR` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `TASK_SOURCE` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `EQUIPMENT_OVERVIEW` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `EQUIPMENT_KEY` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DSIDS` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `TASK_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `VERSION` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `IS_MANUAL_CREATE` tinyint(4) NULL DEFAULT NULL,
  `EXPERIMENT_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MODEL` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TASK_DESCRIBE` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ISSUED_TASK_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `EQUIPMENT_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `EQUIPMENT_SYS_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `EVALUATION_METHOD` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `EVALUATION_OBJECT` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SAMPLE` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `EVALUATION_DATE` timestamp(6) NULL DEFAULT NULL,
  `EVALUATION_TYPE` int(11) NULL DEFAULT NULL,
  `BACKGROUND` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `SCHEMA_CATA` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCHEMA_CHECK` int(11) NULL DEFAULT NULL,
  `SUMMARY` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `SCHEMA_EVALUATION_TYPE` int(11) NULL DEFAULT 1 COMMENT 'pg类型（1：能力，2：效能，3：贡献率）',
  `DATA_DIRECTORY_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT '',
  `DATA_DIRECTORY_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT '',
  `USER_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UNIT` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `F1` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '方案拓展字段',
  `F2` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '方案拓展字段',
  `F3` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '方案拓展字段',
  `F4` text CHARACTER SET utf8 COLLATE utf8_bin NULL COMMENT '方案拓展字段',
  `STATE` varchar(2) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT '评估状态1:待开始 2:已完成',
  `project_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_DATE` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_DATE` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  UNIQUE INDEX `UNIQUE_YW_TOSES_SCHEMA`(`NAME`, `TASK_ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_schema_cata
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_schema_cata`;
CREATE TABLE `yw_toses_schema_cata`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `CATA_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_schema_scene_table_alias
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_schema_scene_table_alias`;
CREATE TABLE `yw_toses_schema_scene_table_alias`  (
  `ID` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `SID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `ALIAS` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DESCRIBES` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `SORTNO` int(11) NULL DEFAULT NULL,
  `DSID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE,
  UNIQUE INDEX `UNIQUE_YW_TOSES_SCHEMA_ALIAS`(`SID`, `ALIAS`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_script_method
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_script_method`;
CREATE TABLE `yw_toses_script_method`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `SCRIPT_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCRIPT_DESC` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCRIPT_INPUT` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `CREATE_TIME` timestamp(6) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(6) NULL DEFAULT NULL,
  `WHETHER_EDIT` int(11) NULL DEFAULT NULL,
  `SCRIPT_PATH` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CALCOR_OR_MODEL` int(10) NULL DEFAULT NULL COMMENT '1 算子脚本 2 模型脚本',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_sides_direc
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_sides_direc`;
CREATE TABLE `yw_toses_sides_direc`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PARENT_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCHEMA_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCENE_SCENARIO_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SIDE_TYPE` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SIDE_NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TYPE` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `WEAPON_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PAYLOAD_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_sides_param
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_sides_param`;
CREATE TABLE `yw_toses_sides_param`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PARENT_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SIDES_PARAMETER` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SIDES_VALUES` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCENE_SCENARIO_ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DIMENSION` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `WEAPON_ID` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `PAYLOAD_ID` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `REMARK` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_standard
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_standard`;
CREATE TABLE `yw_toses_standard`  (
  `ID` varchar(36) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(36) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CID` varchar(36) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INDICATOR_TREE_ID` varchar(36) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SORTNO` int(11) NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_standard_cata
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_standard_cata`;
CREATE TABLE `yw_toses_standard_cata`  (
  `ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SORTNO` int(11) NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_standard_labels
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_standard_labels`;
CREATE TABLE `yw_toses_standard_labels`  (
  `ID` varchar(36) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `NAME` varchar(36) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SORTNO` int(11) NULL DEFAULT NULL,
  `VALUE` varchar(36) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CODE` varchar(36) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DESCRIBES` varchar(36) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `FLAG` int(11) NULL DEFAULT NULL,
  `SCRIPT_PATH` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_standard_value
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_standard_value`;
CREATE TABLE `yw_toses_standard_value`  (
  `ID` varchar(36) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `ST_ID` varchar(36) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INDICATOR_ID` varchar(36) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `LABEL_ID` varchar(36) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MIN` varchar(36) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MAX` varchar(36) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_task
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_task`;
CREATE TABLE `yw_toses_task`  (
  `ID` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `TASK_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TASK_DESCRIBE` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SORTNO` int(11) NULL DEFAULT NULL,
  `TASK_SOURCE` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `START_DATE` timestamp(0) NULL DEFAULT NULL,
  `END_DATE` timestamp(0) NULL DEFAULT NULL,
  `EXPERIMENT_ID` varchar(36) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MODEL` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_DATE` timestamp(0) NULL DEFAULT NULL,
  `IS_MANUAL_CREATE` tinyint(4) NULL DEFAULT NULL,
  `EVALUATION_TASK` int(11) NULL DEFAULT NULL,
  `EVALUATION_SUB` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_task_result
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_task_result`;
CREATE TABLE `yw_toses_task_result`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `TASK_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `COMPETE_SCENE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INDICATOR_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `VALUE` double NULL DEFAULT NULL,
  `SCENE_SCENARIO_ID` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_task_scene
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_task_scene`;
CREATE TABLE `yw_toses_task_scene`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `TASK_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCENE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_task_scene_relevance
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_task_scene_relevance`;
CREATE TABLE `yw_toses_task_scene_relevance`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `TASK_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCENE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_temp
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_temp`;
CREATE TABLE `yw_toses_temp`  (
  `ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `TYPE` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `JSON` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `REATE_TIME` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `BEAN_VALUE` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `METHOD_NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `HOME_PAGE_FLAG` int(11) NULL DEFAULT NULL,
  `SHOW_TYPE` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CATEGORY` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `DATA_TYPE` int(11) NULL DEFAULT NULL,
  `DATA_NAME` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MOCK_TYPE` int(11) NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_third_interface
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_third_interface`;
CREATE TABLE `yw_toses_third_interface`  (
  `ID` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `THIRD_CNAME` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `THIRD_URL` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `REQUEST_METHOD` varchar(10) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(6) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(6) NULL DEFAULT NULL,
  `CLASS_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `FILE_PATH` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_unit_information
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_unit_information`;
CREATE TABLE `yw_toses_unit_information`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `UNIT_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UNIT_DESC` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_user_data_relationship
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_user_data_relationship`;
CREATE TABLE `yw_toses_user_data_relationship`  (
  `ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `USER_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TABLE_NAME` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `TABLE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for yw_toses_weight_model
-- ----------------------------
DROP TABLE IF EXISTS `yw_toses_weight_model`;
CREATE TABLE `yw_toses_weight_model`  (
  `ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `SID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `INDICATOR_ID` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `NAME` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CODE` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `CREATOR` varchar(108) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp(0) NULL DEFAULT NULL,
  `ALGORITHM_JSON` longtext CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `CALC_MODULE_ID` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `SCORE_NUMBER` int(11) NULL DEFAULT NULL,
  `MIN` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `MAX` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `CREATE_DATE` timestamp(0) NULL DEFAULT NULL,
  `UPDATE_DATE` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- View structure for navigation_view
-- ----------------------------
DROP VIEW IF EXISTS `navigation_view`;
CREATE ALGORITHM = UNDEFINED DEFINER = `root`@`%` SQL SECURITY DEFINER VIEW `navigation_view` AS select `t1`.`ID` AS `NODEID`,'0' AS `PID`,`t1`.`TASK_NAME` AS `NAME`,'TASK' AS `TYPE`,'0' AS `SORT`,'' AS `CODE`,'' AS `SID`,'' AS `DEFAULT_CAL_MODULE` from `yw_toses_task` `t1` union all select `t2`.`ID` AS `NODEID`,`t2`.`TASK_ID` AS `PID`,`t2`.`NAME` AS `NAME`,'SCHEMA' AS `TYPE`,'0' AS `SORT`,'' AS `CODE`,`t2`.`ID` AS `SID`,'' AS `DEFAULT_CAL_MODULE` from `yw_toses_schema` `t2` union all select `t3`.`ID` AS `ID`,concat('NODE_INDICATOR',`t3`.`SID`) AS `PID`,`t3`.`NAME` AS `NAME`,'INDICATOR_TREE' AS `TYPE`,`t3`.`CREATOR` AS `SORT`,'' AS `CODE`,`t3`.`SID` AS `SID`,'' AS `DEFAULT_CAL_MODULE` from `yw_toses_indicator_tree` `t3` union all select `t3`.`ID` AS `NODEID`,(case when (`t3`.`PID` = '0') then `t3`.`TREE_ID` else `t3`.`PID` end) AS `PID`,`t3`.`NAME` AS `NAME`,'INDICATOR' AS `TYPE`,`t3`.`SORTNO` AS `SORT`,'' AS `CODE`,`t3`.`SID` AS `SID`,'' AS `DEFAULT_CAL_MODULE` from `yw_toses_indicator` `t3` union all select `t5`.`ID` AS `NODEID`,`t5`.`SID` AS `PID`,`t51`.`ALIAS` AS `NAME`,'SCENE_TABLE' AS `TYPE`,'0' AS `SORT`,'' AS `CODE`,'' AS `SID`,'' AS `DEFAULT_CAL_MODULE` from (`yw_toses_scene_table` `t5` left join `yw_toses_schema_scene_table_alias` `t51` on((`t5`.`ALIAS_ID` = `t51`.`ID`))) union all select `ytea`.`ID` AS `NODEID`,`ytea`.`INDICATOR_ID` AS `PID`,`ytea`.`NAME` AS `NAME`,'EVALUATE_ALG' AS `TYPE`,'-2' AS `SORT`,`ytea`.`CODE` AS `CODE`,`ytea`.`SID` AS `SID`,'' AS `DEFAULT_CAL_MODULE` from `yw_toses_evaluate_alg` `ytea` union all select concat('MAPPING_MATRIX_',`tcsss`.`ID`) AS `NODEID`,concat('NODE_MAPPING_MATRIX',`tcsss`.`SID`) AS `PID`,`tcsss`.`NAME` AS `NAME`,'CIRCUMSTANCES' AS `TYPE`,'0' AS `SORT`,'' AS `CODE`,`tcsss`.`SID` AS `SID`,'' AS `DEFAULT_CAL_MODULE` from `yw_toses_compete_scene` `tcsss`;

-- ----------------------------
-- View structure for navigation_view_v2
-- ----------------------------
DROP VIEW IF EXISTS `navigation_view_v2`;
CREATE ALGORITHM = UNDEFINED DEFINER = `root`@`%` SQL SECURITY DEFINER VIEW `navigation_view_v2` AS select `t1`.`ID` AS `NODEID`,'0' AS `PID`,`t1`.`TASK_NAME` AS `NAME`,'TASK' AS `TYPE`,'0' AS `SORT`,'' AS `CODE`,'' AS `SID`,'' AS `DEFAULT_CAL_MODULE` from `yw_toses_task` `t1` union all select `t2`.`ID` AS `NODEID`,`t2`.`TASK_ID` AS `PID`,`t2`.`NAME` AS `NAME`,'SCHEMA' AS `TYPE`,'0' AS `SORT`,'' AS `CODE`,`t2`.`ID` AS `SID`,'' AS `DEFAULT_CAL_MODULE` from `yw_toses_schema` `t2` union all select concat('NODE_INDICATOR',`t3`.`TREE_ID`) AS `NODEID`,concat('NODE_INDICATOR',`t3`.`SID`) AS `PID`,`t3`.`NAME` AS `NAME`,'INDICATOR_v2' AS `TYPE`,`t3`.`SORTNO` AS `SORT`,'' AS `CODE`,`t3`.`SID` AS `SID`,'' AS `DEFAULT_CAL_MODULE` from `yw_toses_indicator` `t3` where (`t3`.`PID` = '0') union all select `t3`.`ID` AS `ID`,(case when (`t3`.`INDICATOR_TREE_TYPE` = 1) then concat('ABILITY_EVALUTION_MODEL',`t3`.`SID`) else concat('PERFORMANCE_EVALUTION_MODEL',`t3`.`SID`) end) AS `PID`,`t3`.`NAME` AS `NAME`,'INDICATOR_TREE' AS `TYPE`,`t3`.`CREATOR` AS `SORT`,'' AS `CODE`,`t3`.`SID` AS `SID`,'' AS `DEFAULT_CAL_MODULE` from `yw_toses_indicator_tree` `t3` union all select `t3`.`ID` AS `NODEID`,(case when (`t3`.`PID` = '0') then `t3`.`TREE_ID` else `t3`.`PID` end) AS `PID`,`t3`.`NAME` AS `NAME`,'INDICATOR' AS `TYPE`,`t3`.`SORTNO` AS `SORT`,'' AS `CODE`,`t3`.`SID` AS `SID`,'' AS `DEFAULT_CAL_MODULE` from `yw_toses_indicator` `t3` union all select `t4`.`ID` AS `NODEID`,concat('NODE_DATA',`t4`.`SID`) AS `PID`,`t4`.`NAME` AS `NAME`,'SCENE' AS `TYPE`,`t4`.`SORTNO` AS `SORT`,'' AS `CODE`,`t4`.`SID` AS `SID`,'' AS `DEFAULT_CAL_MODULE` from `yw_toses_scene` `t4` union all select `t5`.`ID` AS `NODEID`,`t5`.`SID` AS `PID`,`t51`.`ALIAS` AS `NAME`,'SCENE_TABLE' AS `TYPE`,'0' AS `SORT`,'' AS `CODE`,'' AS `SID`,'' AS `DEFAULT_CAL_MODULE` from (`yw_toses_scene_table` `t5` left join `yw_toses_schema_scene_table_alias` `t51` on((`t5`.`ALIAS_ID` = `t51`.`ID`))) union all select concat('SCENE_',`yts`.`ID`) AS `NODEID`,concat('NODE_RESULT',`yts`.`SID`) AS `PID`,`yts`.`NAME` AS `NAME`,'RESULT_CATE' AS `TYPE`,`yts`.`SORTNO` AS `SORT`,'' AS `CODE`,`yts`.`SID` AS `SID`,'' AS `DEFAULT_CAL_MODULE` from `yw_toses_scene` `yts` union all select `ytea`.`ID` AS `NODEID`,`ytea`.`INDICATOR_ID` AS `PID`,`ytea`.`NAME` AS `NAME`,'EVALUATE_ALG' AS `TYPE`,'-2' AS `SORT`,`ytea`.`CODE` AS `CODE`,`ytea`.`SID` AS `SID`,'' AS `DEFAULT_CAL_MODULE` from `yw_toses_evaluate_alg` `ytea` union all select concat('MAPPING_MATRIX_',`tcsss`.`ID`) AS `NODEID`,concat('NODE_MAPPING_MATRIX',`tcsss`.`SID`) AS `PID`,`tcsss`.`NAME` AS `NAME`,'CIRCUMSTANCES' AS `TYPE`,'0' AS `SORT`,'' AS `CODE`,`tcsss`.`SID` AS `SID`,'' AS `DEFAULT_CAL_MODULE` from `yw_toses_compete_scene` `tcsss`;

SET FOREIGN_KEY_CHECKS = 1;
