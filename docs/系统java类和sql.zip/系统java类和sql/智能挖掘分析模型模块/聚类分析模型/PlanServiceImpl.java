package com.yw.fusionanaly.module.plan.service.impl;


import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSONObject;
import com.yw.fusionanaly.common.exception.ApiException;
import com.yw.fusionanaly.common.result.PageResult;
import com.yw.fusionanaly.common.result.ResultUtil;
import com.yw.fusionanaly.common.result.YwResult;
import com.yw.fusionanaly.common.util.ListToMapUtil;
import com.yw.fusionanaly.common.util.LocalDateTimeTool;
import com.yw.fusionanaly.common.util.MongodbStringUtil;
import com.yw.fusionanaly.database.collection.FuseComb;
import com.yw.fusionanaly.database.collection.Plan;
import com.yw.fusionanaly.database.collection.PlanSample;
import com.yw.fusionanaly.module.analysis.model.response.AbstractResultAnalysisVO;
import com.yw.fusionanaly.module.analysis.service.ResultAnalysisService;
import com.yw.fusionanaly.module.disposeFuse.dao.DisposeFuseDao;
import com.yw.fusionanaly.module.plan.algorithm.AlgorithmFactory;
import com.yw.fusionanaly.module.plan.algorithm.AlgorithmStrategy;
import com.yw.fusionanaly.module.plan.cache.PlanExecuteStatusCacheService;
import com.yw.fusionanaly.module.plan.dao.PlanMongoDbDao;
import com.yw.fusionanaly.module.plan.exportdoc.handler.ExportDoc;
import com.yw.fusionanaly.module.plan.exportdoc.handler.ExportWordStrategyFactory;
import com.yw.fusionanaly.module.plan.exportdoc.model.BaseExportModel;
import com.yw.fusionanaly.module.plan.observer.event.ExecutePlanEvent;
import com.yw.fusionanaly.module.plan.observer.eventbus.EventBusCenter;
import com.yw.fusionanaly.module.plan.request.*;
import com.yw.fusionanaly.module.plan.response.*;
import com.yw.fusionanaly.module.plan.service.PlanSampleService;
import com.yw.fusionanaly.module.plan.service.PlanService;
import com.yw.fusionanaly.module.plan.type.ExportDocType;
import com.yw.fusionanaly.module.plan.type.PlanMethodsType;
import com.yw.fusionanaly.module.plan.type.PlanSampleMethodType;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.TimeoutException;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.yw.fusionanaly.module.plan.type.PlanExecuteStatusType.*;
import static com.yw.fusionanaly.module.plan.type.PlanSampleMethodType.*;
import static com.yw.fusionanaly.module.plan.type.VariableType.*;


/**
 * 数据挖掘方案管理实现类
 *
 * @author hww
 * @date 2021/08/27 14:43
 **/
@Service
public class PlanServiceImpl implements PlanService {

    @Value("${python.runType}")
    private String pythonRunType;

    @Autowired
    private PlanMongoDbDao planDao;

    @Autowired
    private PlanSampleService planSampleService;

    @Autowired
    private DisposeFuseDao disposeFuseDao;

    @Autowired
    private AlgorithmFactory factory;

    @Autowired
    private PlanExecuteStatusCacheService cacheService;

    @Autowired
    private EventBusCenter eventBusCenter;

    @Autowired
    private ResultAnalysisService resultAnalysisService;

    @Override
    public void createPlan(PlanCreateRequest plan) {
        Plan plan1 = new Plan();
        BeanUtils.copyProperties(plan, plan1);
        plan1.setCreateTime(LocalDateTimeTool.dateToDateTimeStr(new Date()));
        plan1.setUpdateTime(LocalDateTimeTool.dateToDateTimeStr(new Date()));
        planDao.save(plan1);
    }

    @Override
    public List<PlanTreeResponse> getPlanTree() {
        List<Plan> plans = planDao.queryList(new Plan());
        List<PlanSample> planSamples = planSampleService.getAllPlanSample();
        List<PlanTreeResponse> planTreeResponses = plans.stream().map(p -> {
            PlanTreeResponse planTreeResponse = new PlanTreeResponse();
            BeanUtils.copyProperties(p, planTreeResponse);
            List<PlanSample> samples = planSamples.stream().filter(s -> s.getPlanId().equals(p.getId())).collect(Collectors.toList());
            planTreeResponse.setPlanSampleList(samples);
            return planTreeResponse;
        }).collect(Collectors.toList());
        return planTreeResponses;
    }

    @Override
    public PageResult<Plan> getPlanByPage(String name, Integer pageSize, Integer pageNum) {
        Plan plan = new Plan();
        if (pageSize == 0 && pageNum == 0) {
            PageResult<Plan> result = new PageResult<>();
            List<Plan> plans = planDao.queryList(plan);
            result.setList(plans);
            result.setTotal((long) plans.size());
            return result;
        }
        if (StrUtil.isNotEmpty(name)) {
            String n = MongodbStringUtil.escapeQueryChars(name);
            plan.setName(n);
            return planDao.getPage(plan, pageNum, pageSize);
        }
        return planDao.getPage(plan, pageNum, pageSize);
    }

    @Override
    public Plan getPlanById(String id) {
        Plan plan = new Plan().setId(id);
        return planDao.queryOne(plan);
    }

    @Override
    public Plan getPlanByName(String name) {
        Plan plan = new Plan().setName(name);
        return planDao.queryOne(plan);
    }

    @Override
    public void updatePlan(PlanUpdateRequest plan) {
        Plan p = new Plan();
        BeanUtils.copyProperties(plan, p);
        p.setUpdateTime(LocalDateTimeTool.dateToDateTimeStr(new Date()));
        Plan srcPlan = getPlanById(p.getId());
        planDao.updateFirst(srcPlan, p);
        List<PlanMethodsType> srcMethods = p.getMethod();
        if(Objects.equals(plan.getBasicDatasetId(),srcPlan.getBasicDatasetId())){
            List<PlanMethodsType> targetMethod = srcPlan.getMethod();
            srcMethods.removeAll(targetMethod);
            for (PlanMethodsType planMethodsType : srcMethods) {
                List<PlanSampleMethodType> planSampleMethodTypes = PlanMethodsType.toPlanSampleRegressionType(planMethodsType);
                for (PlanSampleMethodType planSampleMethodType : planSampleMethodTypes) {
                    planSampleService.deletePlanSampleBySampleType(planSampleMethodType, srcPlan.getId());
                }
            }
        }else {
            //组合变更，删除所有样本
            for (PlanMethodsType planMethodsType : srcMethods) {
                List<PlanSampleMethodType> planSampleMethodTypes = PlanMethodsType.toPlanSampleRegressionType(planMethodsType);
                for (PlanSampleMethodType planSampleMethodType : planSampleMethodTypes) {
                    planSampleService.deletePlanSampleBySampleType(planSampleMethodType, srcPlan.getId());
                }
            }
        }

    }

    @Override
    public void deletePlan(Plan plan) {
        planDao.delete(plan);
    }

    @Override
    public void deletePlanById(String id) {
        //findOne

        Plan plan = getPlanById(id);
        //delete
        if (null == plan) {
            throw new ApiException("该方案不存在");
        }
        deletePlan(plan);
        //删除方案下所有样本
        List<PlanSample> samples = planSampleService.getPlanSampleByPlanId(id);
        if (CollUtil.isNotEmpty(samples)) {
            planSampleService.deletePlanSample(plan.getId());
        }
    }


    @Override
    public void executePlan(PlanTaskStartRequest request) {
        String planId = request.getPlanId();
        List<String> sampleIds = request.getSampleIds();


        if (CollUtil.isEmpty(sampleIds)) {
            List<PlanSample> planSampleByPlanId = planSampleService.getPlanSampleByPlanId(planId);
            sampleIds = planSampleByPlanId.stream().map(PlanSample::getId).collect(Collectors.toList());
        }
        if (CollUtil.isNotEmpty(sampleIds)) {
            for (String sampleId : sampleIds) {
                String cacheId = planId + sampleId;
                ExecutePlanEvent executePlanEvent = ExecutePlanEvent.builder().planId(planId).sampleId(sampleId).cacheId(cacheId).build();
                eventBusCenter.postAsync(executePlanEvent);
            }
        }

    }

    @Override
    public void exportDoc(HttpServletRequest request, HttpServletResponse response, PlanExportRequest planExportRequest) throws IOException {
        try {
            Integer exportType = planExportRequest.getExportType();//获取导出类别
            String planId = planExportRequest.getPlanId();//获取方案Id
            String sampleId = planExportRequest.getSampleId();//获取样本id

            // 结果页面的图片描述 - 图片base64编码
            Map<String,String> fileAndPicBase64InfoMaps = planExportRequest.getFileAndPicBase64InfoMaps();//获取echart导出的图片base64

            PlanSample sample = planSampleService.getPlanSampleByPlanIdAndId(planId, sampleId);//根据方案id和样本id获取方案样本
            AbstractResultAnalysisVO resultAnalysisVO = resultAnalysisService.getResultBySampleId(sampleId);
            sample.setResultAll(resultAnalysisVO);
            if (null == sample) {
                return;
            }
            AlgorithmStrategy algorithm = factory.getAlgorithm(sample);//根据样本获取执行方法

            // 取出sample.result，解析成dto
            BaseExportModel model = algorithm.parseResult(sample, planExportRequest);//根据样本和导出请求  解析python执行结果 *注* 这里相当于把页面的值已经取出来了

            // 获取每个方法对应的导出类
            PlanSampleMethodType type = sample.getType();
            ExportDocType exportWordType = toExportWordType(type);//获取计划样本回归类型
            ExportDoc exportWord = ExportWordStrategyFactory.get(exportWordType);

            // 导出文件名
            String exportName = LocalDateTimeTool.getCurrentDateStr();//当天日期
            exportWord.export(response, model, sample, fileAndPicBase64InfoMaps, exportName, type.getDocName(), exportType);//响应，模型参数，样板，图片，当天日期，Word模型的名称，导出类别
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void cancelPlan(PlanTaskStopRequest request) throws IOException, InterruptedException, TimeoutException {
        String planId = request.getPlanId();
        List<String> sampleIds = request.getSampleIds();
        for (String sampleId : sampleIds) {
            cacheService.set(sampleId, CANCELING);
            PlanStatusResponse planStatusResponse = new PlanStatusResponse().setPlanId(planId).setSampleId(sampleId).setStatus(CANCELING);
            cacheService.set(planId + sampleId, planStatusResponse);
        }
        for (String sampleId : sampleIds) {
            String cacheId = planId + sampleId;
            PlanStatusResponse status = (PlanStatusResponse) cacheService.get(cacheId);
            //运行状态才可以取消
            if (null != status) {
                if (status.getStatus() == RUNNING) {
                    PlanSample s = planSampleService.getPlanSampleByPlanIdAndId(planId, sampleId);

                    if (s != null) {
                        AlgorithmStrategy algorithm = factory.getAlgorithm(s);
                        if (Objects.equals(pythonRunType, "remote")) {
                            algorithm.cancelRemote(planId, sampleId);
                        } else {
                            algorithm.cancelLocal(planId, sampleId);
                        }
                    }
                }
            }
        }
    }

    @Override
    public YwResult getPlanStatus(PlanTaskSearchRequest request) {
        //todo 待优化
        String planId = request.getPlanId();
        List<PlanSample> samples = planSampleService.getPlanSampleByPlanId(planId);
        List<PlanStatusResponse> statusResponseList = new ArrayList<>();
        for (PlanSample sample : samples) {
            String sampleId = sample.getId();
            PlanMethodsType planMethodsType = toPlanMethodsType(sample.getType());
            String cacheId = planId + sampleId;
            PlanStatusResponse status = (PlanStatusResponse) cacheService.get(cacheId);
            if (status == null) {
                PlanStatusResponse planStatusResponse = new PlanStatusResponse().setPlanId(planId).setSampleId(sampleId).setStatus(NOTSTART)
                        .setType(planMethodsType);
                statusResponseList.add(planStatusResponse);
                continue;
            }
            statusResponseList.add(status);
        }
        List<PlanStatusResponse> collect = statusResponseList.stream().filter(item -> !Objects.equals(item.getStatus(), NOTSTART)).collect(Collectors.toList());
        Function<PlanStatusResponse, PlanMethodsType> key = response -> response.getType();
        Function<PlanStatusResponse, PlanSampleStatusResponse> value = response -> {
            PlanSampleStatusResponse planSampleStatusResponse = new PlanSampleStatusResponse();
            planSampleStatusResponse.setSampleId(response.getSampleId()).setStatus(response.getStatus())
                    .setMsg(response.getMsg());
            return planSampleStatusResponse;
        };
        JSONObject jsonObject = new JSONObject();
        Map<PlanMethodsType, Set<PlanSampleStatusResponse>> map = ListToMapUtil.oneToManyMap(collect, key, value);
        jsonObject.put("list", map);
        Boolean allSamplesFinished = collect.stream().allMatch(item -> Objects.equals(item.getStatus(), SUCCESS) || Objects.equals(item.getStatus(), FAIL)
                || Objects.equals(item.getStatus(), CANCEL) || Objects.equals(item.getStatus(), CANCELING));
        if (map.size() > 0 && !allSamplesFinished) {
            jsonObject.put("startTimer", true);
        } else {
            jsonObject.put("startTimer", false);
        }
        return ResultUtil.success(jsonObject);
    }

    @Override
    public YwResult<Object> getPlanResult(String planId, String id) {
        PlanSample srcSample = planSampleService.getPlanSampleByPlanIdAndId(planId, id);
        if (srcSample == null) {
            return ResultUtil.fail();
        }
        if (srcSample.getResult() == null) {
            return ResultUtil.fail();
        }
        String result = (String) srcSample.getResult();

        return ResultUtil.success(result);
    }

    @Override
    public YwResult getValidationset(GetValidationsetRequest request) {
        String planId = request.getPlanId();
        String sampleId = request.getSampleId();
        PlanSample sample = planSampleService.getPlanSampleByPlanIdAndId(planId, sampleId);
        if (!Objects.equals(sample, null)) {
            ValidatesetResponse response = new ValidatesetResponse();
            response.setSampleId(sample.getId());
            response.setSampleName(sample.getName());
            List<PlanSampleExecuteRequest> params = sample.getParams();
            //是否已经配置验证集
            boolean isSetValidate = params.stream().filter(p -> p.getType() == VALIDATESET)
                    .anyMatch(t -> {
                        boolean b = false;
                        if (null != t.getData()) {
                            b = t.getData().size() > 0 ? true : false;
                        }
                        if (null != t.getStrData()) {
                            b = t.getData().size() > 0 ? true : false;
                        }
                        return b;
                    });
            List<PlanSampleExecuteRequest> validateset;
            if (isSetValidate) {
                validateset = params.stream().filter(p -> p.getType() == VALIDATESET).collect(Collectors.toList());
            } else {
                validateset = params.stream().filter(t -> INDEPENDENT == t.getType() || NORMAL == t.getType()).collect(Collectors.toList());
            }
            List<ValidatesetRequest> requests = validateset.stream().map(p -> {
                ValidatesetRequest validatesetRequest = new ValidatesetRequest();
                validatesetRequest.setName(p.getName());
                validatesetRequest.setDesc(p.getDesc());
                validatesetRequest.setData(p.getData());
                validatesetRequest.setStrData(p.getStrData());
                return validatesetRequest;
            }).collect(Collectors.toList());
            response.setValidatesetRequests(requests);
            return ResultUtil.success(response);
        }
        return ResultUtil.fail("该样本不存在！");
    }

    @Override
    public YwResult getDependentset(GetValidationsetRequest request) {
        String planId = request.getPlanId();
        String sampleId = request.getSampleId();
        PlanSample sample = planSampleService.getPlanSampleByPlanIdAndId(planId, sampleId);
        DependentRangeResponse r = new DependentRangeResponse();
        if (!Objects.equals(sample, null)) {
            r.setStart(sample.getStart());
            r.setEnd(sample.getEnd());
        }
        return ResultUtil.success(r);
    }

    @Override
    public void configValidateSet(ValidateionsetRequest request) {
        String planId = request.getPlanId();
        String sampleId = request.getSampleId();
        List<ValidatesetRequest> validatesetRequests = request.getValidatesetRequests();
        PlanSample sample = planSampleService.getPlanSampleByPlanIdAndId(planId, sampleId);
        String listStr = JSONObject.toJSONString(sample);
        PlanSample srcSample = JSONObject.parseObject(listStr, PlanSample.class);
        List<PlanSampleExecuteRequest> params = sample.getParams();
        int size = params.size();
        params.stream().forEach(t -> {
            if(size > 1){
                if (t.getType() == VALIDATESET) {
                    validatesetRequests.forEach(v -> {
                        if (v.getName().equals(t.getName()) && v.getDesc().equals(t.getDesc())) {
                            if (sample.getType() == ASSOCIATIONMINING_ANALYSIS_APRIORI || sample.getType() == ASSOCIATIONMINING_ANALYSIS_GROWTH) {
                                t.setStrData(v.getStrData());
                            } else {
                                t.setData(v.getData());
                            }
                        }
                    });
                }
            }else if(size == 1 && t.getType() == NORMAL){
                validatesetRequests.forEach(v -> {
                    if (v.getName().equals(t.getName()) && v.getDesc().equals(t.getDesc())) {
                        if (sample.getType() == ASSOCIATIONMINING_ANALYSIS_APRIORI || sample.getType() == ASSOCIATIONMINING_ANALYSIS_GROWTH) {
                            t.setStrData(v.getStrData());
                        } else {
                            t.setData(v.getData());
                        }
                    }
                });
            }

        });
        planSampleService.updateOne(srcSample, sample);
    }

    @Override
    public void configDependentRange(DependentRangeConfigRequest request) {
        Integer start = request.getStart();
        Integer end = request.getEnd();
        String planId = request.getPlanId();
        PlanMethodsType type = request.getType();
        List<PlanSample> samples = planSampleService.getPlanSampleByPlanIdAndType(planId, type);
        if (CollUtil.isNotEmpty(samples)) {
            for (PlanSample sample : samples) {
                String listStr = JSONObject.toJSONString(sample);
                PlanSample srcSample = JSONObject.parseObject(listStr, PlanSample.class);
                sample.setStart(start);
                sample.setEnd(end);
                planSampleService.updateOne(srcSample, sample);
            }
        }
    }

    @Override
    public boolean checkPlanFuseDataUsable(String planId) {
        Plan plan = planDao.queryById(planId);
        FuseComb fuseComb = disposeFuseDao.getFuseCombById(Integer.parseInt(plan.getBasicDatasetId()));
        return fuseComb.getPretreatment() == 7;
    }


}
