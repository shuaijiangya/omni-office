package com.yw.module.analysis.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.text.StrBuilder;
import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.ReflectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.Header;
import cn.hutool.http.HttpResponse;
import cn.hutool.http.HttpUtil;
import cn.hutool.json.JSONUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.yw.common.utils.ArithUtil;
import com.yw.common.utils.HttpUtils;
import com.yw.framework.backMgr.dbTableGenerator.domain.dto.TableColsDTO;
import com.yw.framework.backMgr.dbTableGenerator.service.impl.DataBaseHandler;
import com.yw.framework.backMgr.dict.domain.entity.DictEntity;
import com.yw.framework.backMgr.dict.service.DictService;
import com.yw.framework.common.defines.exception.custom.BusinessException;
import com.yw.framework.common.util.StringUtils;
import com.yw.gather.dbinfomgr.IDatasrcService;
import com.yw.gather.dbinfomgr.entity.DatasrcEntity;
import com.yw.module.analysis.FPTree.Apriori;
import com.yw.module.analysis.FPTree.FPTree;
import com.yw.module.analysis.domain.dto.ExploratoryAnalysisDTO;
import com.yw.module.analysis.domain.dto.ExploratoryDependentDTO;
import com.yw.module.analysis.domain.dto.ExploreCurveDTO;
import com.yw.module.analysis.domain.dto.OptimalIntervalExploreDTO;
import com.yw.module.analysis.domain.entity.*;
import com.yw.module.analysis.domain.request.LineAnalysisRequest;
import com.yw.module.analysis.domain.request.MiningModelConfigReq;
import com.yw.module.analysis.domain.request.TrainedModelAnalysisReq;
import com.yw.module.analysis.domain.response.*;
import com.yw.module.analysis.domain.vo.*;
import com.yw.module.analysis.mapper.MiningResultMapper;
import com.yw.module.analysis.service.*;
import com.yw.module.analysis.strategy.AbstractResultAnalysis;
import com.yw.module.analysis.strategy.ResultAnalysisStrategy;
import com.yw.module.analysis.utils.*;
import com.yw.module.calculation.domain.enums.PlanSampleMethodModelType;
import com.yw.module.calculation.domain.enums.PlanSampleMethodType;
import com.yw.module.calculation.domain.enums.VariableType;
import com.yw.module.calculation.domain.req.PlanSampleExecuteRequest;
import com.yw.module.calculation.domain.resp.PlanSample;
import com.yw.module.calculation.domain.vo.AbstractResultAnalysisVO;
import com.yw.module.calculation.parser.AbstractParser;
import com.yw.module.datasource.domain.dto.FindCommonDataDTO;
import com.yw.module.datasource.domain.dto.ScenePrevColValueDTO;
import com.yw.module.indicator.domain.entity.IndicatorEntity;
import com.yw.module.indicator.domain.entity.IndicatorValuesEntity;
import com.yw.module.indicator.service.IIndicatorService;
import com.yw.module.indicator.service.IIndicatorTreeService;
import com.yw.module.indicator.service.ITIndicatorValueService;
import com.yw.module.indicator.service.IndicatorCalculationParameterService;
import com.yw.module.plan.domain.entity.SceneEntity;
import com.yw.module.plan.service.ISceneService;
import com.yw.module.plan.service.ISceneTableService;
import com.yw.sys.api.Pair;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.util.*;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class StaticsticalAnalysisServiceImpl implements StaticsticalAnalysisService {

    private final IIndicatorService indicatorService;
    private final ITIndicatorValueService indicatorValueService;
    private final ResultAnalysisStrategy strategy;
    private final ISceneService iSceneService;
    @Value("${pg-general.module.python-file.executor}")
    protected String pythonServerUrl;

    @Autowired
    private MiningModelConfigService miningModelConfigService;

    @Autowired
    private MiningResultMapper miningResultMapper;

    @Autowired
    private ISceneService sceneService;

    @Autowired
    private DictService dictService;

    @Autowired
    private ISceneTableService sceneTableService;

    @Autowired
    private IndicatorCalculationParameterService indicatorCalculationParameterService;

    @Autowired
    private ITrendForecastService trendForecastService;
    @Autowired
    private IIndicatorService iIndicatorService;

    @Autowired
    private IIndicatorTreeService indicatorTreeService;

    /**
     * 数据库操作
     */
    @Autowired
    private DataBaseHandler dataBaseHandler;

    @Autowired
    private IDatasrcService datasrcService;


    @Value("${pythonFile.executor}")
    private String pythonServer;

    static final DecimalFormat dfm = new DecimalFormat("#.##");

    /**
     * 关联挖掘配置参数（通过词典表存储）
     */
    private final List<String> miningThresholdKeys = Arrays.asList("supportThreshold", "confidenceThreshold", "improveThreshold", "miningModel");


    private List<PlanSampleExecuteRequest> getVariableByIndicatorId(String sid, List<String> independent, PlanSampleMethodType methodType, VariableType variableType) {
//        if (CollUtil.isEmpty(independent)) {
//            return null;
//        }

//        Set<String> indicatorIdList = CollUtil.unionDistinct(independent, dependent);

        LambdaQueryWrapper<IndicatorValuesEntity> indicatorValuesEntityLambdaQueryWrapper = Wrappers.lambdaQuery(IndicatorValuesEntity.class);
        indicatorValuesEntityLambdaQueryWrapper.eq(IndicatorValuesEntity::getSid, sid);
        if (CollUtil.isNotEmpty(independent)) {
            indicatorValuesEntityLambdaQueryWrapper.in(IndicatorValuesEntity::getIndicatorId, independent);
        }
        List<IndicatorValuesEntity> valuesList = indicatorValueService.list(indicatorValuesEntityLambdaQueryWrapper);

        Map<String, List<IndicatorValuesEntity>> valueListPerIndicatorId = valuesList.stream().collect(Collectors.groupingBy(IndicatorValuesEntity::getIndicatorId));

        LambdaQueryWrapper<IndicatorEntity> indicatorEntityLambdaQueryWrapper = Wrappers.lambdaQuery(IndicatorEntity.class);
        if (CollUtil.isNotEmpty(independent)) {
            indicatorEntityLambdaQueryWrapper.in(IndicatorEntity::getId, independent);
        }
        Map<String, List<IndicatorEntity>> indicatorPerIndicatorId = indicatorService.list(indicatorEntityLambdaQueryWrapper).stream().collect(Collectors.groupingBy(IndicatorEntity::getId));

        return valueListPerIndicatorId.entrySet().stream().map(entry -> {
            PlanSampleExecuteRequest request = new PlanSampleExecuteRequest();
            request.setName(entry.getKey());
            request.setDesc(indicatorPerIndicatorId.get(entry.getKey()).get(0).getName());
            request.setType(variableType);
            request.setMethodType(methodType);
            request.setData(entry.getValue().stream()
                    // 轮次数据排序，保障指标间轮次数据顺序一致
                    .sorted(Comparator.comparing(IndicatorValuesEntity::getSceneId)).map(item -> Double.valueOf(item.getNormalizedValue())).collect(Collectors.toList()));
            request.setStrData(entry.getValue().stream()
                    .sorted(Comparator.comparing(IndicatorValuesEntity::getSceneId))
                    .map(IndicatorValuesEntity::getStandardLabelName)
                    .collect(Collectors.toList()).toArray(new String[]{}));
            return request;
        }).collect(Collectors.toList());
    }

    private String execute(PlanSampleMethodType methodType, Map<String, List<Object>> independentValues, Map<String, List<Object>> dependentValues) {
        AbstractResultAnalysis analysis = strategy.getExecuteByType(methodType);
        JSONObject resultJson = null;
        try {
            String result = analysis.execute(independentValues, dependentValues);
            resultJson = JSON.parseObject(result);
            if (!"SUCCESS".equals(resultJson.getString("status"))) {
                throw new BusinessException(resultJson.getString("errorInfo"));
            }
        } catch (Exception e) {
            throw new BusinessException("数据不支持算法分析：" + methodType.getDesc());
        }


        return resultJson.getString("data");
    }

    private PlanSample analysis(PlanSample planSample) {
        AbstractParser parser = strategy.getParser(planSample);
        AbstractResultAnalysisVO vo = strategy.analysis(parser, planSample);
        planSample.setResultAll(vo);
        return planSample;
    }

    @Override
    public List<StaticsticalPgVO> analysis(String scenarioId, String sceneId, String indicatorIds) {
        List<String> indicatorIdList = Arrays.asList(indicatorIds.split(","));
        List<IndicatorEntity> indicatorEntityList = indicatorService.findByBacthId(indicatorIdList);
        List<IndicatorValuesEntity> indicatorValuesEntityList = indicatorValueService.findByIndicatorIdIn(indicatorIdList);
        Map<String, List<IndicatorValuesEntity>> collectPerIndicatorId = indicatorValuesEntityList.stream().collect(Collectors.groupingBy(IndicatorValuesEntity::getIndicatorId));

        List<StaticsticalPgVO> resultList = new ArrayList<>();
        for (IndicatorEntity indicatorEntity : indicatorEntityList) {
            List<IndicatorValuesEntity> indicatorValues = collectPerIndicatorId.get(indicatorEntity.getId());
            List<Double> values = indicatorValues.stream().map(v -> Double.valueOf(v.getNormalizedValue())).collect(Collectors.toList());

            Double sum = values.stream().reduce(0d, Double::sum);
            values.sort(Comparator.naturalOrder());
            // 均值
            double avg = sum / values.size();
            // 最大值
            Double max = values.get(values.size() - 1);
            // 最小值
            Double min = values.get(0);
            // 方差
            Double variance = values.stream().map(val -> Math.pow(val - avg, 2)).reduce(0d, Double::sum) / values.size();
            // 标准差
            double standard = Math.sqrt(variance);
            // 中位数
            double median = values.size() % 2 == 0 ? (values.get(values.size() / 2 - 1) + values.get(values.size() / 2)) / 2 : values.get(values.size() / 2);
            // 众数
            Map<Double, Integer> map = new HashMap<>();
            values.forEach(v -> {
                map.merge(v, 1, Integer::sum);
            });
            double mode = map.entrySet().stream().max(Map.Entry.comparingByValue()).get().getKey();

            StaticsticalPgVO result = StaticsticalPgVO.valueOf(indicatorEntity.getId(), indicatorEntity.getName(), avg, max, min, variance, standard, median, mode);
            resultList.add(result);
        }

        return resultList;
    }

    /**
     * 线性回归分析
     *
     * @param trendForecastId
     * @param sid             方案id
     * @param scenarioId      想定id
     * @param sceneId         样本id
     * @param independent     自变量指标id
     * @param dependent       因变量指标id
     * @param type            算法类型
     * @param modelConfig     算法模型配置
     * @return
     */
    @Override
    public PlanSample lineAnalysis(String dataSrcId, String tableName, String trendForecastId, String sid, String scenarioId, String sceneId, List<String> independent, List<String> dependent, String type, LineAnalysisRequest.ModelConfig modelConfig) {
        if (PlanSampleMethodType.AUTOREGRESSION.getName().equals(type) && modelConfig == null) {
            modelConfig = new LineAnalysisRequest.ModelConfig();
            modelConfig.setAnalysisSize(3);
        }
        if (PlanSampleMethodType.AUTOREGRESSION.getName().equals(type) && modelConfig != null) {
            if (modelConfig.getAnalysisSize() == null) {
                modelConfig.setAnalysisSize(3);
            }
            if (modelConfig.getAnalysisSize() == 0) {
                throw new BusinessException("自回归预测数量不能为0");
            }
        }
        PlanSample planSample = getPlanSample(dataSrcId, tableName, sid, independent, dependent, type, modelConfig);

        List<PlanSampleExecuteRequest> params = planSample.getParams();
        TrendForecastEntity trendForecastEntity = new TrendForecastEntity();
        trendForecastEntity.setIndependent(JSON.toJSONString(independent));
        trendForecastEntity.setId(trendForecastId);
        trendForecastEntity.setDependent(JSON.toJSONString(dependent));
        trendForecastEntity.setResult(JSON.toJSONString(independent));
        // 模型配置信息 作用与BP神经网络算法
        trendForecastEntity.setSampleMethodType(type);
        trendForecastEntity.setSid(sid);
        TrendForecastEntity one = null;
        if (StringUtils.isNotEmpty(trendForecastId)) {
            one = trendForecastService.getById(trendForecastId);
        }
        if (!Objects.isNull(one)) {
            planSample.setUserInsertData(one.getUserInsertData());
        }
        PlanSample analysis = analysis(planSample);
        if (!Objects.isNull(one)) {
            analysis.setUserInsertData(one.getUserInsertData());
            trendForecastEntity.setUserInsertData(one.getUserInsertData());
        }
        //如果是自回归，保留历史趋势结果添加到新的预测中
        if (PlanSampleMethodType.AUTOREGRESSION.getName().equals(type)) {
            if (Objects.isNull(one)) {
                one = trendForecastService.getOne(new LambdaQueryWrapper<TrendForecastEntity>()
                        .eq(TrendForecastEntity::getSid, sid)
                        .eq(TrendForecastEntity::getSampleMethodType, type)
                        .orderByDesc(TrendForecastEntity::getCreateTime)
                        .last("limit 1"));
            }
            //判断历史自回归存在并属于同一个变量
            if (one != null && one.getIndependent().equals(JSON.toJSONString(independent))) {
                trendForecastEntity.setId(one.getId());
                PlanSample oldPlanSample = JSON.parseObject(one.getResult(), PlanSample.class);
                List<Double> oldData = oldPlanSample.getParams().get(0).getData();
                List<Double> newData = analysis.getParams().get(0).getData();
                if (oldData.size() < newData.size()) {
                    JSONObject jsonObject = JSON.parseObject(oldPlanSample.getResult().toString());
                    //自回归预测结果，（三条）
                    JSONArray validationsetPredictedValue = jsonObject.getJSONArray("validationsetPredictedValue");
                    //结果中添加新的字段，记录历史趋势分析结果
                    JSONArray oldPredictedValue = jsonObject.getJSONArray("oldPredictedValue");
                    if (oldPredictedValue == null) {
                        oldPredictedValue = new JSONArray();
                    }
                    //两次趋势预测结果有重叠，只记录非重叠结果作为历史结果
                    if (newData.size() - oldData.size() < modelConfig.getAnalysisSize()) {
                        int num = newData.size() - oldData.size();
                        for (int i = 0; i < num; i++) {
                            JSONObject object = validationsetPredictedValue.getJSONObject(i);
                            oldPredictedValue.add(object);
                        }
                        JSONObject lastResult = JSON.parseObject(analysis.getResult().toString());
                        lastResult.put("oldPredictedValue", oldPredictedValue);
                        analysis.setResult(lastResult);
                    } else {
                        //记录上次所有结果
                        for (int i = 0; i < modelConfig.getAnalysisSize(); i++) {
                            oldPredictedValue.add(validationsetPredictedValue.getJSONObject(i));
                        }
                        //新数据中未被预测的部分直接添加
                        for (int i = 0; i < newData.size() - oldData.size() - modelConfig.getAnalysisSize(); i++) {
                            JSONObject object = new JSONObject();
                            object.put("lower", null);
                            object.put("upper", null);
                            object.put("value", newData.get(oldData.size() + modelConfig.getAnalysisSize() + i));
                        }
                    }

                }

            }
        }
        trendForecastEntity.setModelConfig(JSON.toJSONString(modelConfig));
        trendForecastEntity.setResult(JSON.toJSONString(analysis));
        trendForecastEntity.setCreateTime(LocalDateTime.now());
        trendForecastEntity.setDataSrcId(dataSrcId);
        trendForecastEntity.setTableName(tableName);
        trendForecastService.saveOrUpdate(trendForecastEntity);
        analysis.setTrendForecastId(trendForecastEntity.getId());
        return analysis;
    }

    private PlanSample getPlanSample(String dataSrcId, String tableName, String sid, List<String> independent, List<String> dependent, String type, LineAnalysisRequest.ModelConfig modelConfig) {
        PlanSampleMethodType methodType = PlanSampleMethodType.valueOf(type);
        List<PlanSampleExecuteRequest> variableList = null;
        //通过选择的表数据进行训练
        if (dataSrcId != null && tableName != null) {
            variableList = getTableData(dataSrcId, tableName, sid, independent, dependent, PlanSampleMethodType.valueOf(type));
        } else {
            if (methodType == PlanSampleMethodType.AUTOREGRESSION) {
                variableList = getVariableBySimData(sid, independent, VariableType.INDEPENDENT, methodType);

            } else if (methodType == PlanSampleMethodType.EXPLORATORY_ANALYSIS) {
                variableList = getVariableByIndicatorId(sid, independent, PlanSampleMethodType.valueOf(type), VariableType.INDEPENDENT);
            } else {
                variableList = getVariableByIndicatorId(sid, dependent, PlanSampleMethodType.valueOf(type), VariableType.DEPENDENT);
                variableList.addAll(getVariableBySimData(sid, independent, VariableType.INDEPENDENT, methodType));
            }
        }

        if (CollUtil.isEmpty(variableList)) {
            return null;
        }
        Map<String, List<Object>> independentValues = new HashMap<>();
        Map<String, List<Object>> dependentValues = new HashMap<>();
        for (PlanSampleExecuteRequest variable : variableList) {
            if (VariableType.INDEPENDENT.equals(variable.getType())) {
                independentValues.put(variable.getName(), (List) variable.getData());
            } else if (VariableType.DEPENDENT.equals(variable.getType())) {
                dependentValues.put(variable.getName(), (List) variable.getData());
            }
        }
        if (PlanSampleMethodType.APSO_BPLearn == methodType) {
            // 提供bp 所需要的模型参数
            dependentValues.put("BP", Lists.newArrayList(modelConfig == null ? new LineAnalysisRequest.ModelConfig() : modelConfig));
        }
        if (PlanSampleMethodType.AUTOREGRESSION == methodType) {
            // 提供bp 所需要的模型参数
            dependentValues.put("AUTO", Lists.newArrayList(modelConfig == null ? new LineAnalysisRequest.ModelConfig() : modelConfig));
        }

        String resultData = execute(methodType, independentValues, dependentValues);
        for (PlanSampleExecuteRequest planSampleExecuteRequest : variableList) {
            if ("AUTOREGRESSION".equals(type)) {
                planSampleExecuteRequest.setType(VariableType.NORMAL);
                break;
            }
        }
        return PlanSample.builder().result(resultData).params(variableList).type(methodType).build();
    }

    private List<PlanSampleExecuteRequest> getTableData(String dataSrcId, String tableName, String sid, List<String> independent, List<String> dependent, PlanSampleMethodType methodType) {
        DatasrcEntity datasrcEntity = datasrcService.getById(dataSrcId);
        List<TableColsDTO> tableCols = dataBaseHandler.findTableCols(tableName, datasrcEntity.createDblinkDto().createDbLinkBo());

        List<String> columnNameList = new ArrayList<>();
        List<String> indicatorName = new ArrayList<>();
        Map<String, String> paramMap = new HashMap<>();
        Map<String, String> indicatorMap = new HashMap<>();
        //判断数据表是否包含指标字段
        for (String indicatorId : dependent) {
            IndicatorEntity indicatorEntity = indicatorService.getById(indicatorId);
            boolean flag = false;
            for (TableColsDTO tableCol : tableCols) {
                if (tableCol.getColCode().equals(indicatorEntity.getName())) {
                    flag = true;
                    break;
                }
            }
            if (!flag) {
                throw new BusinessException("效能指标：”" + indicatorEntity.getName() + "“在数据库表中不存在");
            }
            columnNameList.add(indicatorEntity.getName());
            indicatorName.add(indicatorEntity.getName());
            indicatorMap.put(indicatorEntity.getName(), indicatorId);
        }
        //判断数据表是否包含参数字段
        for (String param : independent) {
            boolean flag = false;
            for (TableColsDTO tableCol : tableCols) {
                if (tableCol.getColCode().equals(param.split("#")[1])) {
                    flag = true;
                    break;
                }
            }
            if (!flag) {
                throw new BusinessException("参数：”" + param.split("#")[1] + "“在数据库表中不存在");
            }
            columnNameList.add(param.split("#")[1]);
            paramMap.put(param.split("#")[1], param);
        }

        //查询每一列数据，构建样本
        List<Map<String, Object>> dataList = dataBaseHandler.findDataList(columnNameList, tableName, datasrcEntity.createDblinkDto().createDbLinkBo());
        List<PlanSampleExecuteRequest> requestList = new ArrayList<>();
        for (String columnName : columnNameList) {
            PlanSampleExecuteRequest request = new PlanSampleExecuteRequest();
            if (indicatorName.contains(columnName)) {
                request.setName(indicatorMap.get(columnName));
                request.setType(VariableType.DEPENDENT);
            } else {
                request.setName(paramMap.get(columnName));
                request.setType(VariableType.INDEPENDENT);
            }
            request.setDesc(columnName);
            request.setMethodType(methodType);

            List<Double> datas = new ArrayList<>();
            for (Map<String, Object> map : dataList) {
                Object o = map.get(columnName);
                datas.add(Double.parseDouble(o.toString()));
            }

            request.setData(datas);
            requestList.add(request);
        }

        return requestList;
    }

    /**
     * 探索性分析，入参为指标参数
     */
    private PlanSample getPlanSampleV2(String sid, List<String> independent, List<String> dependent, String type) {
        PlanSampleMethodType methodType = PlanSampleMethodType.valueOf(type);
        List<PlanSampleExecuteRequest> variableList = null;
        if (methodType == PlanSampleMethodType.AUTOREGRESSION) {
            variableList = getVariableBySimData(sid, independent, VariableType.INDEPENDENT, methodType);
        } else if (methodType == PlanSampleMethodType.EXPLORATORY_ANALYSIS) {
//            variableList = getVariableByIndicatorId(sid, independent, type, VariableType.INDEPENDENT);
            variableList = getVariableBySimData(sid, independent, VariableType.INDEPENDENT, methodType);
        } else {
            variableList = getVariableByIndicatorId(sid, dependent, PlanSampleMethodType.valueOf(type), VariableType.DEPENDENT);
            variableList.addAll(getVariableBySimData(sid, independent, VariableType.INDEPENDENT, methodType));
        }
        if (CollUtil.isEmpty(variableList)) {
            return null;
        }
        Map<String, List<Object>> independentValues = new HashMap<>();
        Map<String, List<Object>> dependentValues = new HashMap<>();
        for (PlanSampleExecuteRequest variable : variableList) {
            if (VariableType.INDEPENDENT.equals(variable.getType())) {
                independentValues.put(variable.getName(), (List) variable.getData());
            } else if (VariableType.DEPENDENT.equals(variable.getType())) {
                dependentValues.put(variable.getName(), (List) variable.getData());
            }
        }

        String resultData = execute(methodType, independentValues, dependentValues);
        for (PlanSampleExecuteRequest planSampleExecuteRequest : variableList) {
            if ("AUTOREGRESSION".equals(type)) {
                planSampleExecuteRequest.setType(VariableType.NORMAL);
                break;
            }
        }
        return PlanSample.builder().result(resultData).params(variableList).type(methodType).build();
    }

    /**
     * 探索性分析，入参为指标结果数据
     */
    private PlanSample getPlanSampleV3(String indicatorName, List<Double> topValue, String type) {
        //获取计划样本回归类型
        PlanSampleMethodType methodType = PlanSampleMethodType.valueOf(type);
        PlanSampleExecuteRequest planSampleExecuteRequest = new PlanSampleExecuteRequest();
        //设置变量名
        planSampleExecuteRequest.setName(indicatorName);
        planSampleExecuteRequest.setDesc(indicatorName);
        planSampleExecuteRequest.setMethodType(methodType);
        planSampleExecuteRequest.setData(topValue);
        //入参
        Map<String, List<Object>> independentValues = new HashMap<>();
        independentValues.put(indicatorName, (List) topValue);
        //执行算法
        String resultData = execute(methodType, independentValues, Maps.newHashMap());
        return PlanSample.builder().result(resultData).params(Collections.singletonList(planSampleExecuteRequest)).type(methodType).build();
    }

    /**
     * 从仿真数据中获取选择的关键数据和计算参数
     *
     * @param sid          方案id
     * @param independent  选择的关键指标和计算参数
     * @param variableType 参数类型
     * @return 数据
     */
    private List<PlanSampleExecuteRequest> getVariableBySimData(String sid, List<String> independent, VariableType variableType, PlanSampleMethodType methodType) {
        FindCommonDataDTO findCommonDataDTO = new FindCommonDataDTO();
        findCommonDataDTO.setSid(sid);
        Map<String, List<String>> tableNameAndColumnsMap = Maps.newHashMap();
        // 构建查询需要的数据
        for (String s : independent) {
            if (!s.contains("#")) {
                continue;
            }
            String[] split = s.split("#");
            String tableName = split[0];
            String column = split[1];
            if (!tableNameAndColumnsMap.containsKey(tableName)) {
                tableNameAndColumnsMap.put(tableName, Lists.newArrayList());
            }
            tableNameAndColumnsMap.get(tableName).add(column);
        }
        // 构建算法所需要的数据
        List<PlanSampleExecuteRequest> planSampleExecuteRequests = new ArrayList<>();
        for (String tableName : tableNameAndColumnsMap.keySet()) {
            findCommonDataDTO.setTableName(tableName);
            List<ScenePrevColValueDTO> allSimSceneDataByTableName = iSceneService.findAllSimSceneDataByTableName(tableName,
                    Sets.newHashSet(tableNameAndColumnsMap.get(tableName)), sid, null);
            for (ScenePrevColValueDTO scenePrevColValueDTO : allSimSceneDataByTableName) {
                List<Object> value = (List<Object>) scenePrevColValueDTO.getValue();
                PlanSampleExecuteRequest request = new PlanSampleExecuteRequest();
                request.setName(tableName + "#" + scenePrevColValueDTO.getColName());
                request.setDesc(scenePrevColValueDTO.getColName());
                request.setType(variableType);
                request.setMethodType(methodType);
                request.setData(value.stream().filter(s -> !Objects.isNull(s)).map(s -> Double.parseDouble(s.toString())).collect(Collectors.toList()));
                planSampleExecuteRequests.add(request);
            }
        }

        return planSampleExecuteRequests;
    }

    @Override
    public PlanSample exportAnalysis(String sid, String scenarioId, String sceneId,
                                     List<String> treeIds, List<String> independent) {
        //根据指标树id查询指标id
//        List<String> independent = Lists.newArrayList();
//        if (CollUtil.isNotEmpty(treeIds)) {
//            for (String treeId : treeIds) {
//                List<IndicatorEntity> treeList = indicatorService.findByTreeId(treeId);
//                List<String> treeIdValues = treeList.stream().map(IndicatorEntity::getId).collect(Collectors.toList());
//                independent.addAll(treeIdValues);
//            }
//        }
        return lineAnalysis(null, null, null, sid, scenarioId, sceneId, independent, Collections.emptyList(), PlanSampleMethodType.EXPLORATORY_ANALYSIS.name(), null);
    }

    @Override
    public MiningResultResp associationAnalysis(String sid, MiningParamResp miningThresholdConfig) {
        MiningModelConfigEntity miningModelConfigEntity = miningModelConfigService.getOne(new LambdaQueryWrapper<MiningModelConfigEntity>().eq(MiningModelConfigEntity::getSid, sid));

        if (miningModelConfigEntity == null) {
            throw new BusinessException("请先进行“关联关系挖掘模型构建”");
        }

        String indicatorInterval = miningModelConfigEntity.getIndicatorInterval();
        String indicatorParamInterval = miningModelConfigEntity.getIndicatorParamInterval();
        if (indicatorInterval == null && indicatorParamInterval == null) {
            throw new BusinessException("请先进行“关联关系挖掘模型构建”");
        }

        //挖掘样本数据
        List<List<String>> miningDataList = new ArrayList<>();
        int sampleSize = 0;

        List<String> indicatorIds = new ArrayList<>();
        List<String> indicatorParamIds = new ArrayList<>();
        sampleSize = buildMiningDataList(indicatorIds, miningDataList, indicatorInterval, indicatorParamIds, indicatorParamInterval, sampleSize, sid);


        MiningResultResp miningResult = null;
        Map<String, String> indicatorNameMap = new HashMap<>();
        Map<String, String> indicatorParamMap = new HashMap<>();
        getIndicatorAndParamNameMap(indicatorIds, indicatorParamIds, indicatorNameMap, indicatorParamMap);

        //默认使用APRIORI算法，或者指标和参数数量超过25个，强制使用APRIORI算法
        if (indicatorIds.size() + indicatorParamIds.size() > 25 || StringUtils.isEmpty(miningThresholdConfig.getMiningModel()) || PlanSampleMethodType.ASSOCIATIONMINING_ANALYSIS_APRIORI.getName().equals(miningThresholdConfig.getMiningModel())) {
            List<Set<String>> miningSetData = new ArrayList<>();
            for (List<String> strings : miningDataList) {
                miningSetData.add(new HashSet<>(strings));
            }

            //System.out.println(miningSetData);
            Apriori apriori = new Apriori(miningSetData, miningThresholdConfig.getSupportThreshold(), miningThresholdConfig.getConfidenceThreshold(), miningThresholdConfig.getImproveThreshold());

            // 生成频繁项集
            Map<Set<String>, Integer> frequentItemsets = apriori.generateFrequentItemsets();
            // 生成关联规则
            List<Apriori.Rule> rules = apriori.generateAssociationRules(frequentItemsets);
            miningResult = getAprioriMiningResult(indicatorNameMap, indicatorParamMap, rules, sampleSize, sid);
        } else {
            List<StrongAssociationRule> strongAssociationRules = relationAnalysisFPGrowth(miningDataList, sampleSize, miningThresholdConfig.getSupportThreshold(), miningThresholdConfig.getConfidenceThreshold());
            strongAssociationRules = strongAssociationRules.stream().filter(t -> t.getCondition().size() < 3 && t.getImprove() >= miningThresholdConfig.getImproveThreshold()).collect(Collectors.toList());
            miningResult = getMiningResult(indicatorNameMap, indicatorParamMap, strongAssociationRules, sampleSize, sid);
        }

        //三项集只保留前100条
        List<MiningResultResp.ItemSet> threeItemSets = miningResult.getThreeItemSets();
        threeItemSets.sort(Comparator
                .comparing(MiningResultResp.ItemSet::getSupport, Comparator.reverseOrder())
                .thenComparing(MiningResultResp.ItemSet::getConfidence, Comparator.reverseOrder())
                .thenComparing(MiningResultResp.ItemSet::getImprove, Comparator.reverseOrder()));
        threeItemSets = threeItemSets.subList(0, Math.min(threeItemSets.size(), 1000));
        miningResult.setThreeItemSets(threeItemSets);

        MiningResultEntity miningResultEntity = new MiningResultEntity();
        miningResultEntity.setSid(sid);
        miningResultEntity.setId(IdUtil.simpleUUID());
        miningResultEntity.setResult(JSON.toJSONString(miningResult));

        miningResultMapper.delete(new LambdaQueryWrapper<MiningResultEntity>().eq(MiningResultEntity::getSid, sid));
        miningResultMapper.insert(miningResultEntity);
        return miningResult;
    }

    @Override
    public MiningResultResp getHistoryResult(String sid) {
        MiningResultEntity miningResultEntity = miningResultMapper.selectOne(new LambdaQueryWrapper<MiningResultEntity>().eq(MiningResultEntity::getSid, sid).last("limit 1"));
        MiningResultResp miningResultResp = null;
        if (miningResultEntity == null || StringUtils.isEmpty(miningResultEntity.getResult())) {
            miningResultResp = this.associationAnalysis(sid, this.getMiningThresholdConfig());
        } else {
            miningResultResp = JSON.parseObject(miningResultEntity.getResult(), MiningResultResp.class);
        }
        return miningResultResp;
    }

    /**
     * 获取指标和参数的唯一标识和名称映射
     *
     * @param indicatorIds
     * @param indicatorParams
     */
    private void getIndicatorAndParamNameMap(List<String> indicatorIds, List<String> indicatorParams, Map<String, String> indicatorNameMap, Map<String, String> indicatorParamMap) {
        if (CollectionUtil.isNotEmpty(indicatorIds)) {
            List<IndicatorEntity> list = indicatorService.list(new LambdaQueryWrapper<IndicatorEntity>().in(IndicatorEntity::getId, indicatorIds));
            for (IndicatorEntity indicatorEntity : list) {
                indicatorNameMap.put(indicatorEntity.getId(), indicatorEntity.getName());
            }
        }

        for (String indicatorParam : indicatorParams) {
            String[] split = indicatorParam.split("#");
            indicatorParamMap.put("param#" + indicatorParam, split[1]);
        }
    }

    /**
     * 解析获取挖掘结果
     *
     * @param indicatorNameMap
     * @param indicatorParamMap
     * @param rules
     * @param size
     * @param sid
     * @return
     */
    private MiningResultResp getAprioriMiningResult(Map<String, String> indicatorNameMap, Map<String, String> indicatorParamMap, List<Apriori.Rule> rules, int size, String sid) {

        MiningResultResp miningResultResp = new MiningResultResp();
        List<MiningResultResp.ItemSet> twoItemSets = new ArrayList<>();
        List<MiningResultResp.ItemSet> threeItemSets = new ArrayList<>();
        for (Apriori.Rule rule : rules) {
            if (rule.consequent.size() > 1) {
                continue;
            }
            MiningResultResp.ItemSet itemSet = new MiningResultResp.ItemSet();
            itemSet.setSupport(Double.parseDouble(dfm.format(rule.support)));
            itemSet.setConfidence(Double.parseDouble(dfm.format(rule.confidence)));
            itemSet.setImprove(Double.parseDouble(dfm.format(rule.improve)));

            StringBuilder explain = new StringBuilder("前置项（");
            //项集中的指标id替换成指标名称
            List<String> condition = new ArrayList<>();
            for (String s : rule.antecedent) {
                String[] split = s.split(":");
                itemSet.getIds().add(split[0]);

                if (split[0].startsWith("param")) {
                    condition.add(indicatorParamMap.get(split[0]) + ":" + split[1]);
                    explain.append("指标计算参数：").append(indicatorParamMap.get(split[0])).append("、");
                } else {
                    condition.add(indicatorNameMap.get(split[0]) + ":" + split[1]);
                    explain.append("指标：").append(indicatorNameMap.get(split[0])).append("、");
                }
            }
            explain.deleteCharAt(explain.length() - 1);
            explain.append(")\n后置项（");
            for (String result : rule.consequent) {
                String[] split = result.split(":");

                //关联原始数据，进行曲线拟合
                if (split[0].startsWith("param")) {
                    result = indicatorParamMap.get(split[0]) + ":" + split[1];
                    explain.append("指标计算参数：").append(indicatorParamMap.get(split[0]));
                } else {
                    result = indicatorNameMap.get(split[0]) + ":" + split[1];
                    explain.append("指标：").append(indicatorNameMap.get(split[0]));
                }
                itemSet.getIds().add(split[0]);
                itemSet.setRelationship(String.join("、",condition) + "->" + result);
            }

            itemSet.setExplain(explain.toString());
            if (rule.antecedent.size() == 1) {
                twoItemSets.add(itemSet);
            } else {
                threeItemSets.add(itemSet);
            }
        }
        miningResultResp.setTwoItemSets(twoItemSets);
        miningResultResp.setThreeItemSets(threeItemSets);


        return miningResultResp;
    }

    /**
     * 构建挖掘样本
     *
     * @param indicatorIds
     * @param miningDataList
     * @param indicatorInterval
     * @param indicatorParamIds
     * @param indicatorParamInterval
     * @param sampleSize
     * @param sid
     */
    private int buildMiningDataList(List<String> indicatorIds, List<List<String>> miningDataList
            , String indicatorInterval, List<String> indicatorParamIds, String indicatorParamInterval, int sampleSize, String sid) {
        //指标数据
        if (StringUtils.isNotEmpty(indicatorInterval) && indicatorInterval.length() > 2) {
            //获取配置的所有指标和区间个数信息
            Map<String, Integer> indicatorIntervalNumMap = getConfigIntervalNum(indicatorInterval, indicatorIds);

            List<Map<String, Object>> sampleIndicatorData = getSampleIndicatorData(indicatorIds);

            //区间等分
            List<IndicatorInterval> indicatorMaxMinValue = getIndicatorMaxMinValue(indicatorIds);
            for (IndicatorInterval interval : indicatorMaxMinValue) {
                Integer num = indicatorIntervalNumMap.get(interval.getId());
                List<IndicatorInterval.Interval> intervalList = getIntervals(interval, num);
                interval.setIntervals(intervalList);
            }

            //指标值进行区间替换
            valueToInterval(sampleIndicatorData, indicatorMaxMinValue);

            sampleSize = sampleIndicatorData.size();
            for (Map<String, Object> indicatorSampleDatum : sampleIndicatorData) {
                List<String> miningData = new ArrayList<>();
                for (String s : indicatorSampleDatum.keySet()) {
                    if (!"num".equals(s)) {
                        miningData.add(s + ":" + indicatorSampleDatum.get(s));
                    }
                }
                miningDataList.add(miningData);
            }
        }

        //指标计算参数数据
        if (StringUtils.isNotEmpty(indicatorParamInterval) && indicatorParamInterval.length() > 2) {
            //获取配置的所有指标计算参数和区间个数信息
            Map<String, Integer> indicatorParamIntervalNumMap = getConfigIntervalNum(indicatorParamInterval, indicatorParamIds);

            //List<IndicatorCalculationParameter> indicatorParameterList = indicatorCalculationParameterService.list(new LambdaQueryWrapper<IndicatorCalculationParameter>().in(IndicatorCalculationParameter::getId, indicatorParamIds));
            List<Map<String, Object>> paramDataList = getIndicatorParamSampleData(indicatorParamIds, sid);

            //区间等分
            List<IndicatorInterval> indicatorParamMaxMinValue = getIndicatorParamMaxMinValue(indicatorParamIds, sid);
            for (IndicatorInterval interval : indicatorParamMaxMinValue) {
                Integer num = indicatorParamIntervalNumMap.get(interval.getId());
                List<IndicatorInterval.Interval> intervalList = getIntervals(interval, num);
                interval.setIntervals(intervalList);
            }

            //指标参数值进行区间替换
            valueToInterval(paramDataList, indicatorParamMaxMinValue);

            if (sampleSize == 0) {
                sampleSize = paramDataList.size();
            }
            for (int i = 0; i < sampleSize; i++) {
                Map<String, Object> indicatorSampleDatum = paramDataList.get(i);
                List<String> miningData = new ArrayList<>();
                if (i < miningDataList.size()) {
                    miningData = miningDataList.get(i);
                } else {
                    miningDataList.add(miningData);
                }
                for (String s : indicatorSampleDatum.keySet()) {
                    if (!"num".equals(s)) {
                        miningData.add("param#" + s + ":" + indicatorSampleDatum.get(s));
                    }
                }
            }
        }
        return sampleSize;
    }

    /**
     * 获取指标/参数配置区间数量
     *
     * @param configInterval 配置信息
     * @param ids            指标/参数 ids
     * @return
     */
    private Map<String, Integer> getConfigIntervalNum(String configInterval, List<String> ids) {
        JSONArray objects = JSON.parseArray(configInterval);
        Map<String, Integer> indicatorIntervalNumMap = new HashMap<>();
        for (int i = 0; i < objects.size(); i++) {
            ids.add(objects.getJSONObject(i).get("id").toString());
            indicatorIntervalNumMap.put(objects.getJSONObject(i).get("id").toString(), Integer.parseInt(objects.getJSONObject(i).get("intervalNum").toString()));
        }
        return indicatorIntervalNumMap;
    }

    /**
     * 数值替换对于区间
     *
     * @param sampleIndicatorData  数据
     * @param indicatorMaxMinValue 区间
     */
    private void valueToInterval(List<Map<String, Object>> sampleIndicatorData, List<IndicatorInterval> indicatorMaxMinValue) {
        for (Map<String, Object> indicatorSampleDatum : sampleIndicatorData) {
            for (IndicatorInterval interval : indicatorMaxMinValue) {
                if (indicatorSampleDatum.get(interval.getId()) == null) {
                    throw new BusinessException("模型构建的数据存在空数据，请检查后重试");
                }
                double v = Double.parseDouble(indicatorSampleDatum.get(interval.getId()).toString());
                List<IndicatorInterval.Interval> intervals = interval.getIntervals();
                for (int i = 0; i < intervals.size(); i++) {
                    IndicatorInterval.Interval intervalPart = intervals.get(i);
                    if (i == intervals.size() - 1) {
                        if (Double.compare(v, intervalPart.getLeftValue()) >= 0 && Double.compare(v, intervalPart.getRightValue()) <= 0) {
                            indicatorSampleDatum.put(interval.getId(), "[" + intervalPart.getLeftValue() + "," + intervalPart.getRightValue() + "]");
                            break;
                        }
                    } else {
                        if (Double.compare(v, intervalPart.getLeftValue()) >= 0 && Double.compare(v, intervalPart.getRightValue()) < 0) {
                            indicatorSampleDatum.put(interval.getId(), "[" + intervalPart.getLeftValue() + "," + intervalPart.getRightValue() + ")");
                            break;
                        }
                    }
                }
            }
        }
    }

    /**
     * 构建二项集，三项集结果列表
     *
     * @param strongAssociationRules
     * @param size
     * @return
     */
    private MiningResultResp getMiningResult(Map<String, String> indicatorNameMap, Map<String, String> indicatorParamMap, List<StrongAssociationRule> strongAssociationRules, int size, String sid) {

        /*if (CollectionUtil.isNotEmpty(indicatorParamIds)) {
            List<IndicatorCalculationParameter> indicatorParameterList = indicatorCalculationParameterService.list(new LambdaQueryWrapper<IndicatorCalculationParameter>().in(IndicatorCalculationParameter::getId, indicatorParamIds));
            for (IndicatorCalculationParameter calculationParameter : indicatorParameterList) {
                indicatorParamMap.put("param#" + calculationParameter.getId(), calculationParameter);
            }
        }*/

        MiningResultResp miningResultResp = new MiningResultResp();
        List<MiningResultResp.ItemSet> twoItemSets = new ArrayList<>();
        List<MiningResultResp.ItemSet> threeItemSets = new ArrayList<>();
        for (StrongAssociationRule rule : strongAssociationRules) {
            MiningResultResp.ItemSet itemSet = new MiningResultResp.ItemSet();
            itemSet.setSupport(Double.parseDouble(dfm.format(1.0 * rule.support / size)));
            itemSet.setConfidence(Double.parseDouble(dfm.format(rule.confidence)));
            itemSet.setImprove(Double.parseDouble(dfm.format(rule.improve)));

            StringBuilder explain = new StringBuilder("前置项（");
            //项集中的指标id替换成指标名称
            List<String> condition = new ArrayList<>();
            for (int i = 0; i < rule.condition.size(); i++) {
                String s = rule.condition.get(i);
                String[] split = s.split(":");
                itemSet.getIds().add(split[0]);

                if (split[0].startsWith("param")) {
                    condition.add(indicatorParamMap.get(split[0]) + ":" + split[1]);
                    explain.append("指标计算参数：").append(indicatorParamMap.get(split[0])).append("、");
                } else {
                    condition.add(indicatorNameMap.get(split[0]) + ":" + split[1]);
                    explain.append("指标：").append(indicatorNameMap.get(split[0])).append("、");
                }
            }
            explain.deleteCharAt(explain.length() - 1);
            explain.append(")\n后置项（");
            String result = "";
            String[] split = rule.result.split(":");

            //关联原始数据，进行曲线拟合
            if (split[0].startsWith("param")) {
                result = indicatorParamMap.get(split[0]) + ":" + split[1];
                explain.append("指标计算参数：").append(indicatorParamMap.get(split[0]));
            } else {
                result = indicatorNameMap.get(split[0]) + ":" + split[1];
                explain.append("指标：").append(indicatorNameMap.get(split[0]));
            }

            itemSet.getIds().add(split[0]);
            itemSet.setRelationship(String.join("、",condition) + "->" + result);
            itemSet.setExplain(explain.toString());
            if (rule.condition.size() == 1) {
                twoItemSets.add(itemSet);
            } else {
                threeItemSets.add(itemSet);
            }
        }
        miningResultResp.setTwoItemSets(twoItemSets);
        miningResultResp.setThreeItemSets(threeItemSets);
        return miningResultResp;
    }

    /**
     * 指标值区间等分
     *
     * @param interval 区间最大最小值
     * @param num      区间个数
     * @return
     */
    @NotNull
    private static List<IndicatorInterval.Interval> getIntervals(IndicatorInterval interval, Integer num) {
        Double minValue = interval.getMinValue();
        Double maxValue = interval.getMaxValue();
        double partValue = (maxValue - minValue) / num;

        List<IndicatorInterval.Interval> intervalList = new ArrayList<>();
        for (int i = 0; i < num; i++) {
            IndicatorInterval.Interval intervalPart = new IndicatorInterval.Interval();
            if (i == 0) {
                intervalPart.setLeftValue(new BigDecimal(minValue).setScale(3, RoundingMode.DOWN).doubleValue());
            } else {
                intervalPart.setLeftValue(new BigDecimal(minValue).setScale(3, RoundingMode.HALF_UP).doubleValue());
            }
            if (i == num - 1) {
                intervalPart.setRightValue(new BigDecimal(maxValue).setScale(3, RoundingMode.UP).doubleValue());
            } else {
                intervalPart.setRightValue(new BigDecimal(minValue + partValue).setScale(3, RoundingMode.HALF_UP).doubleValue());
            }
            minValue += partValue;
            intervalList.add(intervalPart);
        }
        return intervalList;
    }

    @Override
    public JSONObject getSampleData(MiningModelConfigReq req) {
        List<MiningModelConfigReq.IntervalConfig> indicatorIntervalConfig = req.getIndicatorIntervalConfig();
        List<MiningModelConfigReq.IntervalConfig> indicatorParamIntervalConfig = req.getIndicatorParamIntervalConfig();
        if (CollectionUtil.isEmpty(indicatorIntervalConfig) && CollectionUtil.isEmpty(indicatorParamIntervalConfig)) {
            throw new BusinessException("指标或指标计算参数配置不能为空");
        }

        List<String> indicatorIds = indicatorIntervalConfig.stream().map(t -> t.getId()).collect(Collectors.toList());


        //构建表头数据信息
        List<TableStructureMsg> tableStructureMsgs = new ArrayList<>();
        TableStructureMsg tableStructureMsg = new TableStructureMsg();
        tableStructureMsg.setProp("num");
        tableStructureMsg.setLabel("序号");
        tableStructureMsgs.add(tableStructureMsg);

        List<Map<String, Object>> dataList = new ArrayList<>();
        JSONObject map = new JSONObject();
        //指标数据
        if (CollectionUtil.isNotEmpty(indicatorIntervalConfig)) {
            List<IndicatorEntity> indicatorEntityList = indicatorService.list(new LambdaQueryWrapper<IndicatorEntity>().in(IndicatorEntity::getId, indicatorIds));
            for (IndicatorEntity indicatorEntity : indicatorEntityList) {
                TableStructureMsg tableStructureMsg2 = new TableStructureMsg();
                tableStructureMsg2.setProp(indicatorEntity.getId());
                tableStructureMsg2.setLabel(indicatorEntity.getName());
                tableStructureMsgs.add(tableStructureMsg2);
            }
            dataList = getSampleIndicatorData(indicatorIds);
        }

        //指标参数数据
        if (CollectionUtil.isNotEmpty(indicatorParamIntervalConfig)) {
            List<String> indicatorParamIds = indicatorParamIntervalConfig.stream().map(t -> t.getId()).collect(Collectors.toList());
            for (String indicatorParam : indicatorParamIds) {
                String[] split = indicatorParam.split("#");
                TableStructureMsg tableStructureMsg2 = new TableStructureMsg();
                tableStructureMsg2.setProp(indicatorParam);
                tableStructureMsg2.setLabel(split[1]);
                tableStructureMsgs.add(tableStructureMsg2);
            }

            List<Map<String, Object>> paramDataList = getIndicatorParamSampleData(indicatorParamIds, req.getSid());
            if (CollectionUtil.isEmpty(paramDataList)) {
                throw new BusinessException("指标参数数据不存在，请检查指标关联仿真数据是否正确并且存在数据");
            }
            if (CollectionUtil.isEmpty(dataList)) {
                dataList = paramDataList;
            } else {
                for (int i = 0; i < dataList.size(); i++) {
                    dataList.get(i).putAll(paramDataList.get(i));
                }
            }
        }
        map.put("tableHeader", tableStructureMsgs);
        /*if (page.getTotal() > num) {
            map.put("total", num);
        } else {
            map.put("total", page.getTotal());
        }*/
        map.put("tableData", dataList);


        MiningModelConfigEntity miningModelConfigEntity = miningModelConfigService.getOne(new LambdaQueryWrapper<MiningModelConfigEntity>().eq(MiningModelConfigEntity::getSid, req.getSid()));
        if (miningModelConfigEntity == null) {
            miningModelConfigEntity = new MiningModelConfigEntity();
        }
        miningModelConfigEntity.setSid(req.getSid());
        miningModelConfigEntity.setMiningModel(req.getMiningModel());
        miningModelConfigEntity.setIndicatorParamInterval(JSON.toJSONString(req.getIndicatorParamIntervalConfig()));
        miningModelConfigEntity.setIndicatorInterval(JSON.toJSONString(req.getIndicatorIntervalConfig()));
        miningModelConfigService.saveOrUpdate(miningModelConfigEntity);

        return map;
    }

    @Override
    public MiningResultLineGraphResp associationAnalysisLineGraph(List<String> ids, String sid) {

        MiningResultLineGraphResp miningResultLineGraphResp = new MiningResultLineGraphResp();

        for (int i = 0; i < ids.size(); i++) {
            String id = ids.get(i);
            //关联原始数据，进行曲线拟合
            String name = "";
            List<Double> v = new ArrayList<>();
            if (id.startsWith("param")) {
                String[] split = id.split("#");

                if (StringUtils.isNotEmpty(split[1])) {
                    List<ScenePrevColValueDTO> scenePrevColValueDTOList = sceneService.findAllSimSceneDataByTableName(split[1],
                            Sets.newHashSet(split[2]), sid, null);
                    ScenePrevColValueDTO scenePrevColValueDTO = scenePrevColValueDTOList.get(0);


                    Object valueObj = scenePrevColValueDTO.getValue();
                    List<Double> valueList = new ArrayList<>();
                    if (valueObj instanceof List) {
                        for (Object o : (List) valueObj) {
                            valueList.add(Double.parseDouble(o.toString()));
                        }
                    }

                    name = split[2];
                    v = valueList;
                }
            } else {
                List<IndicatorValuesEntity> indicatorValuesEntityList = indicatorValueService.list(new LambdaQueryWrapper<IndicatorValuesEntity>()
                        .eq(IndicatorValuesEntity::getIndicatorId, id));
                List<Double> axis = indicatorValuesEntityList.stream().map(t -> Double.parseDouble(t.getNormalizedValue())).collect(Collectors.toList());
                IndicatorEntity indicatorEntity = indicatorService.getById(id);
                name = indicatorEntity.getName();
                v = axis;
            }
            if (i == 0) {
                miningResultLineGraphResp.setAxis1(v);
                miningResultLineGraphResp.setAxisName1(name);
            } else if (i == 1) {
                miningResultLineGraphResp.setAxis2(v);
                miningResultLineGraphResp.setAxisName2(name);
            } else {
                miningResultLineGraphResp.setAxis3(v);
                miningResultLineGraphResp.setAxisName3(name);
            }
        }
        // sort排序
        List<MiningResultLineGraphSortResp> miningResultLineGraphSortResps = new ArrayList<>();
        List<Double> axis1 = miningResultLineGraphResp.getAxis1();
        List<Double> axis2 = miningResultLineGraphResp.getAxis2();
        List<Double> axis3 = miningResultLineGraphResp.getAxis3();
        if (CollUtil.isNotEmpty(axis1)) {
            List<Double> axis1New = Lists.newArrayList();
            List<Double> axis2New = Lists.newArrayList();
            List<Double> axis3New = Lists.newArrayList();
            for (int i = 0; i < axis1.size(); i++) {
                MiningResultLineGraphSortResp miningResultLineGraphSortResp = new MiningResultLineGraphSortResp();
                miningResultLineGraphSortResp.setAxis1(axis1.get(i));
                if (CollUtil.isNotEmpty(axis2)) {
                    miningResultLineGraphSortResp.setAxis2(axis2.get(i));
                }
                if (CollUtil.isNotEmpty(axis3)) {
                    miningResultLineGraphSortResp.setAxis3(axis3.get(i));
                }
                miningResultLineGraphSortResps.add(miningResultLineGraphSortResp);
            }

            miningResultLineGraphSortResps.sort(Comparator.comparing(MiningResultLineGraphSortResp::getAxis1));
            for (MiningResultLineGraphSortResp miningResultLineGraphSortResp : miningResultLineGraphSortResps) {
                axis1New.add(miningResultLineGraphSortResp.getAxis1());
                if (!Objects.isNull(miningResultLineGraphSortResp.getAxis2())) {
                    axis2New.add(miningResultLineGraphSortResp.getAxis2());
                }
                if (!Objects.isNull(miningResultLineGraphSortResp.getAxis2())) {
                    axis3New.add(miningResultLineGraphSortResp.getAxis3());
                }
            }
            miningResultLineGraphResp.setAxis1(axis1New);
            miningResultLineGraphResp.setAxis2(axis2New);
            miningResultLineGraphResp.setAxis3(axis3New);
        }
        return miningResultLineGraphResp;
    }

    /**
     * 探索性分析service
     */
    @Autowired
    private ExploratoryAnalysisService exploratoryAnalysisService;

    /**
     * 一元线性回归分析结果Service
     */
    @Autowired
    private SimpleLinearService simpleLinearService;

    /**
     * 系统边界条件，探索性分析
     */
    /*@Override
    @Transactional(rollbackFor = Exception.class)
    public String boundaryExportAnalysis(ExploratoryAnalysisDTO exploratoryAnalysisDTO) {
        List<ExploratoryAnalysisEntity> exploratoryAnalysisEntityList = Lists.newArrayList();
        List<SimpleLinearEntity> simpleLinearEntityList = Lists.newArrayList();
        //获取探索性分析结果
        List<ExploratoryDependentDTO> dependentDTOList = exploratoryAnalysisDTO.getDependentDTOList();
        //sid
        String sid = exploratoryAnalysisDTO.getSid();
        //根据sid查询指标
        List<IndicatorEntity> indicatorEntityList = indicatorService.list(new LambdaQueryWrapper<IndicatorEntity>().eq(IndicatorEntity::getSid, sid));
        if (CollUtil.isEmpty(indicatorEntityList)) {
            throw new BusinessException("未查询到指标信息");
        }
        //获取指标id name map
        Map<String, String> indicatorIdNameMap = indicatorEntityList.stream().collect(Collectors.toMap(IndicatorEntity::getId, IndicatorEntity::getName));
        for (ExploratoryDependentDTO exploratoryDependentDTO : dependentDTOList) {
            Double dependentMin = exploratoryDependentDTO.getDependentMin();
            Double dependentMax = exploratoryDependentDTO.getDependentMax();
            //效能指标
            String dependent = exploratoryDependentDTO.getDependent();
            //效能指标名称
            String dependentName = indicatorIdNameMap.get(dependent);
            //关键因素
            List<String> independent = exploratoryDependentDTO.getIndependent();
            //探索分析结论
            StrBuilder conclusion = new StrBuilder();
            conclusion.append("影响").append(dependentName).append("的关键因素有").append(independent.stream().map(t -> t.split("-")[1]).collect(Collectors.joining(","))).append("，").append(dependentName).append("变化范围为").append(String.valueOf(dependentMin)).append("-").append(String.valueOf(dependentMax)).append("，");
            //数据分布分析结论
            StrBuilder dataConclusion = new StrBuilder();
            dataConclusion.append("影响").append(dependentName).append("的关键因素有").append(independent.stream().map(t -> t.split("-")[1]).collect(Collectors.joining(","))).append("，");
            for (String ind : independent) {
                //一元线性回规
                PlanSample planSample = getPlanSample(null, null, sid, Collections.singletonList(ind), Collections.singletonList(dependent), PlanSampleMethodType.SIMPLE_LINEAR.name(), null);
                //探索性分析
                PlanSample planSampleV2 = getPlanSampleV2(sid, Collections.singletonList(ind), Lists.newArrayList(), PlanSampleMethodType.EXPLORATORY_ANALYSIS.name());
                //补充异常值
                dataConclusion.append("探索的关键因素为").append(ind.split("-")[1]).append("，");
                List<Double> dataAbnormal = handlingOutliers(dependent, ind, planSample, planSampleV2, simpleLinearEntityList, dependentMin, dependentMax, dataConclusion);
                conclusion.append("探索的关键因素为").append(ind).append("该关键因素超出边界条件的数据有").append(JSONUtil.toJsonStr(dataAbnormal)).append("，");
            }
            conclusion.append("这些关键因素数据会导致指标异常情况的发生。");
            //保存探索性分析折线结果
            exploratoryAnalysisEntityList.add(ExploratoryAnalysisEntity.builder()
                    .sid(sid)
                    .dependentId(dependent)
                    .dependentMin(dependentMin)
                    .dependentMax(dependentMax)
                    .exploratoryAnalysisConclusion(conclusion.toString())
                    .build());
        }
        //清空旧数据
        List<ExploratoryAnalysisEntity> exploratoryAnalysisEntities = exploratoryAnalysisService.list(new LambdaQueryWrapper<ExploratoryAnalysisEntity>().eq(ExploratoryAnalysisEntity::getSid, sid));
        if (CollUtil.isNotEmpty(exploratoryAnalysisEntities)) {
            List<String> dependentIds = exploratoryAnalysisEntities.stream().map(ExploratoryAnalysisEntity::getDependentId).collect(Collectors.toList());
            exploratoryAnalysisService.remove(new LambdaQueryWrapper<ExploratoryAnalysisEntity>().eq(ExploratoryAnalysisEntity::getSid, sid));
            simpleLinearService.remove(new LambdaQueryWrapper<SimpleLinearEntity>().in(SimpleLinearEntity::getDependentId, dependentIds));
        }
        //存储结果
        exploratoryAnalysisService.saveBatch(exploratoryAnalysisEntityList);
        if (CollUtil.isNotEmpty(simpleLinearEntityList)) {
            simpleLinearService.saveBatch(simpleLinearEntityList);
        }
        return "计算成功";
    }*/

    /**
     * 系统边界条件，探索性分析
     */
    @Override
    public String boundaryExportAnalysisV2(ExploratoryAnalysisDTO exploratoryAnalysisDTO) {
        List<ExploratoryAnalysisEntity> exploratoryAnalysisEntityList = Lists.newArrayList();
        List<SimpleLinearEntity> simpleLinearEntityList = Lists.newArrayList();
        //装备名
        //String equName = exploratoryAnalysisDTO.getEquName();
        //获取探索性分析结果
        List<ExploratoryDependentDTO> dependentDTOList = exploratoryAnalysisDTO.getDependentDTOList();
        //sid
        String sid = exploratoryAnalysisDTO.getSid();
        //根据sid查询指标
        List<IndicatorEntity> indicatorEntityList = indicatorService.list(new LambdaQueryWrapper<IndicatorEntity>().eq(IndicatorEntity::getSid, sid));
        if (CollUtil.isEmpty(indicatorEntityList)) {
            throw new BusinessException("未查询到指标信息");
        }
        //获取指标id name map
        Map<String, String> indicatorIdNameMap = indicatorEntityList.stream().collect(Collectors.toMap(IndicatorEntity::getId, IndicatorEntity::getName));
        for (ExploratoryDependentDTO exploratoryDependentDTO : dependentDTOList) {
            List<ExploratoryDependentDTO.Independent> independentList = exploratoryDependentDTO.getIndependentList();

            //关键因素
            String dependent = exploratoryDependentDTO.getDependent();
            String dependentName = dependent.split("#")[1];

            //探索分析结论
            StringBuilder all = new StringBuilder();

            //效能指标
            for (ExploratoryDependentDTO.Independent independent1 : independentList) {
                String ind = independent1.getIndependent();
                Double independentMin = independent1.getIndependentMin();
                Double independentMax = independent1.getIndependentMax();

                StrBuilder conclusion = new StrBuilder();
                //一元线性回规
                //获取探索曲线 这里会进行第一次的数据过滤
                ExploreCurveDTO exploreCurve = getExploreCurve(sid, dependent, ind, independentMin, independentMax);
                //探索性分析
                PlanSample intervalDataPlanSample = new PlanSample();
                if (exploreCurve.getIntervalValue().size() >= 5) {
                    intervalDataPlanSample = getPlanSampleV3(dependentName, exploreCurve.getIntervalValue(), PlanSampleMethodType.EXPLORATORY_ANALYSIS.name());
                }
                //对探索性分析算法得出的结果做修正
                BoxPlotUtil.BoxPlotData boxPlotData = fixData(intervalDataPlanSample, exploreCurve, 0);
                // 数据分布分析界面的数据
                //再次调用探索性分析 效能指标的数据
                PlanSample allDataPlanSample = getPlanSampleV3(indicatorIdNameMap.get(ind), exploreCurve.getYList(), PlanSampleMethodType.EXPLORATORY_ANALYSIS.name());
                // 关键因素的探索性以及分布数据
                PlanSample keyFactorSampleResult = getPlanSampleV3(dependentName, exploreCurve.getXList(), PlanSampleMethodType.EXPLORATORY_ANALYSIS.name());
                //对探索性分析算法得出的结果做修正
                fixDataException(allDataPlanSample, exploreCurve, exploratoryDependentDTO, boxPlotData, 0);
                BoxPlotUtil.BoxPlotData keyFactorBoxPlotData = fixData(keyFactorSampleResult, exploreCurve, 1);

                fixDataException(keyFactorSampleResult, exploreCurve, exploratoryDependentDTO, keyFactorBoxPlotData, 1);
                List<SimpleLinearEntity> outParam = Lists.newArrayList();
                List<String> list = saveSimpleLinear(dependentName, indicatorIdNameMap.get(ind), independentMin, independentMax,
                        simpleLinearEntityList, exploreCurve, intervalDataPlanSample, allDataPlanSample, keyFactorSampleResult, dependent,
                        ind, conclusion.toString(), outParam, boxPlotData, keyFactorBoxPlotData);
                if (CollUtil.isEmpty(list)) {
                    conclusion.append("当前分析数据不符合效能指标要求，请重新设置指标变化范围。");
                } else {
                    List<Pair<Double, Double>> pointers = Lists.newArrayList();
                    for (int i = 0; i < list.size(); i++) {
                        String pointer = list.get(i);
                        String[] pointerSplit = pointer.replaceAll("\\[", "").replaceAll("]", "").split(",");
                        pointers.add(new Pair<>(Double.parseDouble(pointerSplit[0]), Double.parseDouble(pointerSplit[1])));
                    }
                    conclusion
                            .append("结合边界条件探索曲线，在该场景下").append(dependentName)
                            .append("设置为")
                            .append(printfPointers(pointers))
                            .append("时，均能保证")
                            .append(indicatorIdNameMap.get(ind)).append("达到")
                            .append("[").append(independentMin).append(",").append(independentMax).append("]")
                            .append("从而使得该任务顺利完成。").append("因此").append(dependentName).append("的边界条件为")
                            .append(printfPointers(pointers)).append("。");
                    conclusion.append("根据指标各组边界箱型图观察，");
                    appendIntersectionConclusion(pointers,exploreCurve, conclusion, dependentName);
                }
                //保存曲线，箱型图结果
                all.append(conclusion.toString()).append(independentList.get(independentList.size() - 1).equals(ind) ? "" : "\n");
                outParam.get(0).setOverallConclusion(conclusion.toString());
            }
            //保存探索性分析折线结果
            exploratoryAnalysisEntityList.add(ExploratoryAnalysisEntity.builder()
                    .sid(sid)
                    .dependentId(dependent)
                    .exploratoryAnalysisConclusion(all.toString())
                    .build());
        }
        //清空旧数据
        List<ExploratoryAnalysisEntity> exploratoryAnalysisEntities = exploratoryAnalysisService.list(new LambdaQueryWrapper<ExploratoryAnalysisEntity>().eq(ExploratoryAnalysisEntity::getSid, sid));
        if (CollUtil.isNotEmpty(exploratoryAnalysisEntities)) {
            List<String> dependentIds = exploratoryAnalysisEntities.stream().map(ExploratoryAnalysisEntity::getDependentId).collect(Collectors.toList());
            exploratoryAnalysisService.remove(new LambdaQueryWrapper<ExploratoryAnalysisEntity>().eq(ExploratoryAnalysisEntity::getSid, sid));
            simpleLinearService.remove(new LambdaQueryWrapper<SimpleLinearEntity>().in(SimpleLinearEntity::getDependentId, dependentIds));
        }
        //存储结果
        exploratoryAnalysisService.saveBatch(exploratoryAnalysisEntityList);
        if (CollUtil.isNotEmpty(simpleLinearEntityList)) {
            simpleLinearService.saveBatch(simpleLinearEntityList);
        }
        return "计算成功";
    }

    /**
     * 补充交点结论
     *
     * @param exploreCurve       数据
     * @param conclusion         结论
     */
    private void appendIntersectionConclusion(List<Pair<Double, Double>> pointers,ExploreCurveDTO exploreCurve, StrBuilder conclusion, String indicatorName) {
        List<Double> xList = Lists.newArrayList();
        xList.addAll(exploreCurve.getIntervalValue());

        for (Pair<Double, Double> pointer : pointers) {
            xList = xList.stream().filter(t->t>=pointer.getKey()&&t<=pointer.getValue()).collect(Collectors.toList());
        }

        // 根据最大最小过滤数据求众数或者中位数
        xList.sort(Comparator.comparing(s -> s));
        // 获取众数 均值 中位数 entrySet().stream().max(Map.Entry.comparingByValue())
        //Map<Double, Long> modeMap = xList.stream().collect(Collectors.groupingBy(d -> d, Collectors.counting()));
        Double mode = 0.0;
        int n = xList.size();
        if (n == 0) {
            mode = 0.0;
        } else {
            if (n % 2 == 1) {
                mode = xList.get(n / 2);
            } else {
                mode = (xList.get(n / 2 - 1) + xList.get(n / 2)) / 2.0;
            }
        }

        //中位数等于均值为正态分布，大于为负偏态分布
        Double avg = xList.stream().mapToDouble(Double::doubleValue).average().orElse(0);
        mode = ArithUtil.round(mode, 4);
        conclusion.append(indicatorName).append("数据呈现")
                .append(mode.equals(avg) ? "正态分布" : mode > avg ? "负偏态分布" :  "正偏态分布" ).append("。为了保证任务顺利完成概率最大，建议将").append(indicatorName).append("设置为").append(mode).append("。");
    }

    /**
     * 打印x的区间范围
     *
     * @param pointers x区间范围
     * @return [], []
     */
    private String printfPointers(List<Pair<Double, Double>> pointers) {
        StringBuilder sb = new StringBuilder();
        for (Pair<Double, Double> pointer : pointers) {
            sb.append("[").append(pointer.getKey()).append(",").append(pointer.getValue()).append("]").append("、");
        }
        return sb.substring(0, sb.length() - 1);
    }


    private void fixDataException(PlanSample planSampleV3RemoveExceptionValue, ExploreCurveDTO exploreCurve,
                                  ExploratoryDependentDTO exploratoryDependentDTO, BoxPlotUtil.BoxPlotData boxData,
                                  int keyFactorFlag) {
        List<Double[]> originalPoints = exploreCurve.getOriginalPoints();
        List<Double[]> filterPoinsts = new ArrayList<>();
        List<Double> exceptionVals = new ArrayList<>();
        //过滤箱型图上下限范围外的值
        for (Double[] originalPoint : originalPoints) {
            double originalValue = keyFactorFlag == 1 ? originalPoint[0] : originalPoint[1];
            if (originalValue < boxData.upperBound && originalValue > boxData.lowerBound) {
                filterPoinsts.add(originalPoint);
            } else {
                exceptionVals.add(keyFactorFlag == 1 ? originalPoint[0] : originalPoint[1]);
            }
        }
        List<LOWESS.Point> points = LOWESSUtil.generatePointData(filterPoinsts);
        // 提取y值
        List<Double> yValues = BoxPlotUtil.extractYValues(points, keyFactorFlag);
        // 计算箱型图数据
        BoxPlotUtil.BoxPlotData boxPlotData = null;
        if (CollUtil.isEmpty(yValues)) {
            boxPlotData = new BoxPlotUtil.BoxPlotData(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, new ArrayList<>());
        } else {
            boxPlotData = BoxPlotUtil.calculateBoxPlot(yValues);
        }
        Map map = JSONUtil.toBean(planSampleV3RemoveExceptionValue.getResult().toString(), Map.class);
        Map<String, Object> mapResult = (Map<String, Object>) ((List<Object>) map.get("list")).get(0);
        mapResult.put("std", new BigDecimal(String.valueOf(mapResult.get("std"))).setScale(4, java.math.RoundingMode.HALF_UP));
        mapResult.put("var", new BigDecimal(String.valueOf(mapResult.get("var"))).setScale(4, java.math.RoundingMode.HALF_UP));
        mapResult.put("mean", new BigDecimal(String.valueOf(mapResult.get("mean"))).setScale(4, java.math.RoundingMode.HALF_UP));
        mapResult.put("max", new BigDecimal(String.valueOf(mapResult.get("max"))).setScale(4, java.math.RoundingMode.HALF_UP));
        mapResult.put("min", new BigDecimal(String.valueOf(mapResult.get("min"))).setScale(4, java.math.RoundingMode.HALF_UP));
        mapResult.put("argmax", new BigDecimal(String.valueOf(mapResult.get("argmax"))).setScale(4, java.math.RoundingMode.HALF_UP));


        //上四分位数
        mapResult.put("rHalf", boxPlotData.q3);
        //上四分位数
        mapResult.put("lHalf", boxPlotData.q1);
        //中位数
        mapResult.put("median", boxPlotData.median);
        //上下限
        JSONArray array = new JSONArray();
        array.add(boxPlotData.lowerBound);
        array.add(boxPlotData.upperBound);
        mapResult.put("rang_list", array);
        //异常值
        JSONArray exceptionArr = new JSONArray();
        for (Double exceptionVal : exceptionVals) {
            exceptionArr.add(exceptionVal);
        }
        mapResult.put("error_list", exceptionArr);
        JSONArray list = new JSONArray();
        list.add(mapResult);
        map.put("list", list);
        planSampleV3RemoveExceptionValue.setResult(JSON.toJSONString(map));
    }

    /**
     * 对探索性分析的结果做修正
     *
     * @param planSampleV3
     * @param exploreCurve
     */
    private BoxPlotUtil.BoxPlotData fixData(PlanSample planSampleV3, ExploreCurveDTO exploreCurve, int keyFactorFlag) {
        List<Double[]> originalPoints = exploreCurve.getOriginalPoints();
        List<LOWESS.Point> points = LOWESSUtil.generatePointData(originalPoints);
        // 提取y值
        List<Double> yValues = BoxPlotUtil.extractYValues(points, keyFactorFlag);
        // 计算箱型图数据
        BoxPlotUtil.BoxPlotData boxPlotData = null;
        if (CollUtil.isEmpty(yValues)) {
            boxPlotData = new BoxPlotUtil.BoxPlotData(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, new ArrayList<>());
        } else {
            boxPlotData = BoxPlotUtil.calculateBoxPlot(yValues);
        }
//        Map map = JSONUtil.toBean(planSampleV3.getResult().toString(), Map.class);
//        Map<String, Object> mapResult = (Map<String, Object>) ((List<Object>) map.get("list")).get(0);
//        mapResult.put("std", new BigDecimal(String.valueOf(mapResult.get("std"))).setScale(4, java.math.RoundingMode.HALF_UP));
//        mapResult.put("var", new BigDecimal(String.valueOf(mapResult.get("var"))).setScale(4, java.math.RoundingMode.HALF_UP));
//        mapResult.put("mean", new BigDecimal(String.valueOf(mapResult.get("mean"))).setScale(4, java.math.RoundingMode.HALF_UP));
//
//        //上四分位数
//        mapResult.put("rHalf", new BigDecimal(String.valueOf(mapResult.get("rHalf"))).setScale(4, java.math.RoundingMode.HALF_UP));
//        //上四分位数
//        mapResult.put("lHalf", boxPlotData.q1);
//        //中位数
//        mapResult.put("median", boxPlotData.median);
//        //上下限
//        JSONArray array = new JSONArray();
//        array.add(boxPlotData.lowerBound);
//        array.add(boxPlotData.upperBound);
//        mapResult.put("rang_list", array);
//        JSONArray list = new JSONArray();
//        list.add(mapResult);
//        map.put("list", list);
//        planSampleV3.setResult(JSON.toJSONString(map));
        return boxPlotData;
    }

    /**
     * 得到最大y对应的x
     *
     * @param exploreCurve
     * @return
     */
    private Double getMaxYOfX(ExploreCurveDTO exploreCurve) {
        List<Double[]> list = exploreCurve.getExamplePoints();
        Double x = 0.0;
        Double maxY = Double.MIN_VALUE;
        for (Double[] doubles : list) {
            if (doubles[1] > maxY) {
                maxY = doubles[1];
                x = doubles[0];
            }
        }
        return x;
    }

    /**
     * 保存曲线，箱型图结果
     */
    private List<String> saveSimpleLinear(String dependentName, String indicatorName, Double independentMin, Double independentMax,
                                          List<SimpleLinearEntity> simpleLinearEntityList, ExploreCurveDTO exploreCurve, PlanSample intervalDataPlanSample,
                                          PlanSample allDataPlanSample, PlanSample keyFactorSampleResult, String dependent, String ind,
                                          String overallConclusion, List<SimpleLinearEntity> entityList, BoxPlotUtil.BoxPlotData boxData,
                                          BoxPlotUtil.BoxPlotData keyFactorBoxPlotData) {
        if (ObjectUtil.isNull(allDataPlanSample)) {
            return new ArrayList<>();
        }
        //异常分析结论
        StrBuilder factorStatisticsConclusion = new StrBuilder();
        //数据探索结论
        StringBuilder dataConclusion = new StringBuilder();
        //获取未去异常值结果

        List<Double[]> filterPoinsts = new ArrayList<>();
        List<Double[]> keyFactorFilterPoinsts = new ArrayList<>();
        List<Double> filterYList = new ArrayList<>();
        List<Double> filterXList = new ArrayList<>();
        //过滤箱型图上下限范围外的值
        for (Double[] originalPoint : exploreCurve.getOriginalPoints()) {
            if (originalPoint[1] <= boxData.upperBound && originalPoint[1] >= boxData.lowerBound) {
                filterPoinsts.add(originalPoint);
                filterYList.add(originalPoint[1]);
            }
            if (originalPoint[0] <= keyFactorBoxPlotData.upperBound && originalPoint[0] >= keyFactorBoxPlotData.lowerBound) {
                keyFactorFilterPoinsts.add(originalPoint);
                filterXList.add(originalPoint[0]);
            }
        }
        // 获取数据分布情况结论
        String indicatorDistribution = obtainConclusionsFromDataDistribution(indicatorName, exploreCurve.getYList(), exploreCurve.getOriginalPoints(), filterPoinsts, 0);
        String keyFactorDistribution = obtainConclusionsFromDataDistribution(dependentName, exploreCurve.getXList(), exploreCurve.getOriginalPoints(), keyFactorFilterPoinsts, 1);
        //标准差
        //TODO 直接将mape的数据和标准差放在一起，不增加字段了，避免发包问题
        List<List<String>> standartAndMapeList = Lists.newArrayList();
        List<String> standard = Lists.newArrayList();
        //方差
        List<String> variance = Lists.newArrayList();
        //mape
        List<String> mape = Lists.newArrayList();
        standartAndMapeList.add(standard);
        standartAndMapeList.add(mape);
        //数量
        List<List<Integer>> number = Lists.newArrayList();

        List<Integer> stdNumber = Lists.newArrayList();
        List<Integer> varianceNumber = Lists.newArrayList();
        List<Integer> mapeNumber = Lists.newArrayList();
        //计算标准差，方差
//        MathUtil.calculateStatistics(exploreCurve.getTopValue(), standard, variance, number);
        List<LOWESS.Point> examplePoints = LOWESSUtil.generatePointData(exploreCurve.getExamplePoints());
        List<LOWESS.Point> originalPoints = LOWESSUtil.generatePointData(exploreCurve.getOriginalPoints());
        IntervalStatisticsUtil.StatisticsResult result =
                IntervalStatisticsUtil.calculateIntervalStatistics(examplePoints, originalPoints, independentMin, independentMax, exploreCurve.getModel());
        List<Double> stdDevRanges = result.stdDevRanges;
        List<Double> varianceRanges = result.varianceRanges;
        List<Double> mapeRanges = result.mapeRanges;
        List<Integer> stdDevCounts = result.stdDevCounts;
        List<Integer> varianceCounts = result.varianceCounts;
        List<Integer> mapeCounts = result.mapeCounts;

        int maxCountStd = 0;
        for (int i = 0; i < stdDevRanges.size() - 1; i++) {
            if (maxCountStd < stdDevCounts.get(i)) {
                maxCountStd = i;
            }
            standard.add(String.format("[%.2f-%.2f)",
                    stdDevRanges.get(i), stdDevRanges.get(i + 1)));
            stdNumber.add(stdDevCounts.get(i));
        }
        int maxCountvariance = 0;
        for (int i = 0; i < varianceRanges.size() - 1; i++) {
            if (maxCountvariance < stdDevCounts.get(i)) {
                maxCountvariance = i;
            }
            variance.add(String.format("[%.2f-%.2f)",
                    varianceRanges.get(i), varianceRanges.get(i + 1)));
            varianceNumber.add(varianceCounts.get(i));
        }
        int maxCountmape = 0;
        for (int i = 0; i < mapeRanges.size() - 1; i++) {
            if (maxCountmape < mapeCounts.get(i)) {
                maxCountmape = i;
            }
            mape.add(String.format("[%.2f-%.2f)",
                    mapeRanges.get(i), mapeRanges.get(i + 1)));
            mapeNumber.add(mapeCounts.get(i));
        }
        number.add(stdNumber);
        number.add(varianceNumber);
        number.add(mapeNumber);
        //数据探索结论
        if (CollUtil.isNotEmpty(variance) && CollUtil.isNotEmpty(standard) && CollUtil.isNotEmpty(mape)) {
            //集中程度
            String concentrationDegree = getConcentrationDegree(varianceRanges, stdDevRanges);
            //曲线局部拟合性
            String localProperty = getLocalProperty(mape.get(maxCountmape));

            dataConclusion.append("方差和标准差分布直方图，补充了对曲线局部拟合情况的分析，由左图可知，各区间方差主要分布在")
                    .append(variance.get(maxCountvariance))
                    .append("标准差分布在").append(standard.get(maxCountStd))
                    .append("其分布的集中程度").append(concentrationDegree)
                    .append("平均绝对百分比误差分布在").append(mape.get(maxCountmape))
                    .append("曲线局部拟合性").append(localProperty)
                    .append("装备参数的设定区间").append("较差".equals(localProperty) ? "不具备参考性" : "具备参考性");
        } else {
            dataConclusion.append("当前分析数据不符合效能指标要求，请重新设置指标变化范围。");
        }

        exploreCurve.setFilterYList(filterYList);
        exploreCurve.setFilterXList(filterXList);
        PlanSample noExceptionIntervalDataPlanSample = getPlanSampleV3(indicatorName, exploreCurve.getFilterYList(), PlanSampleMethodType.EXPLORATORY_ANALYSIS.name());
        PlanSample keyFactorNoExceptionIntervalDataPlanSample = getPlanSampleV3(dependentName, exploreCurve.getFilterXList(), PlanSampleMethodType.EXPLORATORY_ANALYSIS.name());
        SimpleLinearEntity entity = SimpleLinearEntity.builder()
                //因变量ID
                .dependentId(dependent)
                //自变量
                .independent(ind)
                //一元线性回归分析结果
                .simpleLinearResult(JSONUtil.toJsonStr(exploreCurve))
                //探索性分析结果
                .exploratoryAnalysisResult(JSONUtil.toJsonStr(intervalDataPlanSample))
                //(区间数据)探索性分析结果以及去掉异常值结果
                .intervalExploratoryAnalysisResult(JSONUtil.toJsonStr(allDataPlanSample))
                .keyFactorIntervalExploratoryAnalysisResult(JSONUtil.toJsonStr(keyFactorSampleResult))
                .noExceptionValueResult(JSONUtil.toJsonStr(noExceptionIntervalDataPlanSample))
                .keyFactorNoExceptionValueResult(JSONUtil.toJsonStr(keyFactorNoExceptionIntervalDataPlanSample))
                //因素统计结论 效能指标
                .factorStatisticsConclusion(indicatorDistribution)
                // 关键因素
                .keyFactorStatisticsConclusion(keyFactorDistribution)
                //数据分布分析结论
                .dataConclusion(dataConclusion.toString())
                //标准差
                .standard(JSONUtil.toJsonStr(standartAndMapeList))
                //方差
                .variance(JSONUtil.toJsonStr(variance))
                //数量
                .number(JSONUtil.toJsonStr(number))
                // 总体结论
                .overallConclusion(overallConclusion)
                .independentMax(independentMax)
                .independentMin(independentMin)
                .createTime(LocalDateTime.now())
                .build();

        //设置数据集中程度区间分布
        setIntervalDistribution(entity, exploreCurve.getYList(), true, 0);
        //设置数据集中程度区间分布(剔除异常值)
        setIntervalDistribution(entity, exploreCurve.getFilterYList(), false, 0);

        //设置关键指标数据集中程度区间分布
        setIntervalDistribution(entity, exploreCurve.getXList(), true, 1);
        //设置关键指标数据集中程度区间分布(剔除异常值)
        setIntervalDistribution(entity, exploreCurve.getFilterXList(), false, 1);
        //保存结果
        simpleLinearEntityList.add(entity);
        entityList.add(entity);
        return result.getRangeList();
    }

    public static String buildParams(Integer method, List<Double> sourceData) {
        JSONObject object = new JSONObject();
        object.put("method", method);
        JSONObject data = new JSONObject();
        object.put("data", sourceData);
        return JSON.toJSONString(object, SerializerFeature.DisableCircularReferenceDetect);
    }

    /**
     * 获取数据分布分析模块的结论
     *
     * @param sourceData     原始数据
     * @param originalPoints 数据分布点
     * @param filterPoinsts  过滤完之后的数据
     */
    private String obtainConclusionsFromDataDistribution(String name, List<Double> sourceData, List<Double[]> originalPoints, List<Double[]> filterPoinsts, int keyFactorFlag) {
        StringBuilder factorStatisticsConclusion = new StringBuilder();
        String params = buildParams(1007, sourceData);
        String sendPost = HttpUtils.sendPost(pythonServerUrl, params);
        try {
            JSONObject jsonObject = JSON.parseObject(sendPost);
            String data = jsonObject.getString("data");
            factorStatisticsConclusion
                    .append("通过对").append(name).append("的箱型图、直方图和KDE曲线分析，可得出以下结论")
                    .append(data).append("3.");
        } catch (Exception e) {
            log.error("无法生成通过箱形图以及直方图得出结论，异常信息: {}", e.getMessage());
        }
        // 生成两组测试数据
        List<LOWESS.Point> points1 = LOWESSUtil.generatePointData(filterPoinsts);
        List<LOWESS.Point> points2 = LOWESSUtil.generatePointData(originalPoints);

        // 计算箱型图数据
        BoxPlotUtil.BoxPlotData boxPlotData1 = BoxPlotUtil.calculateBoxPlot(
                BoxPlotUtil.extractYValues(points1, keyFactorFlag));
        BoxPlotUtil.BoxPlotData boxPlotData2 = BoxPlotUtil.calculateBoxPlot(
                BoxPlotUtil.extractYValues(points2, keyFactorFlag));

        // 进行t检验
        BoxPlotUtil.TTestResult tTestResult = BoxPlotUtil.performTTest(boxPlotData1, boxPlotData2);
        boolean rCheckResult = tTestResult.isSignificant;
        if (rCheckResult) {
            factorStatisticsConclusion.append("在异常值检测上，发现").append(sourceData.size() - filterPoinsts.size())
                    //.append("个异常值，剔除异常值后，数据分布差异不大，建议直接剔除异常值。")
                    .append("个异常值。")
                    .append("异常值剔除前后，数据分布差异大，建议结合实际情况进行处理。")
                    .append("①若异常值分散，且数量较少，建议首先核对数据源是否存在错误，若数据错误直接删除，否则考虑外部因素对系统产生影响；")
                    .append("②若异常值分布集中，建议优先考虑外部因素对系统产生的影响，结合外部原因，分析数据变化规律，此时异常值需要保留；")
                    .append("③若异常值较多，建议先剔除其中的由于数据错误导致的计算误差，之后根据剩余异常值情况，结合①、②进行考量。");
        } else {
            //factorStatisticsConclusion.append("异常值剔除前后，数据分布差异不大，建议直接剔除异常值");
            factorStatisticsConclusion.append("在异常值检测上，发现").append(sourceData.size() - filterPoinsts.size())
                    .append("个异常值，剔除异常值后，数据分布差异不大，建议直接剔除异常值。")
                   ;
        }
        return factorStatisticsConclusion.toString();
    }

    /**
     * 设置数据集中程度区间分布
     *
     * @param entity
     * @param yList
     */
    private void setIntervalDistribution(SimpleLinearEntity entity, List<Double> yList, boolean exceptionFlag, int keyFactorFlag) {
        List<String> intervalDistribution = new ArrayList<>();
        List<Integer> intervalDistributionNum = new ArrayList<>();

        double max = yList.get(0);
        double min = yList.get(0);
        for (Double v : yList) {
            if (v > max) {
                max = v;
            }
            if (min > v) {
                min = v;
            }
        }
        int minInt = (int) Math.floor(min);
        int maxInt = (int) Math.ceil(max);
        int interval = (int) Math.ceil((max - min) / 10);
        int num = 0;
        if (interval != 0) {
            for (int i = minInt; i <= maxInt; i = i + interval) {
                int sum = 0;
                for (Double v : yList) {
                    if (v >= i && v < i + interval) {
                        sum++;
                    }
                }
                String intervalString = "";
                if (num == 0) {
                    intervalString = "[";
                } else {
                    intervalString = "(";
                }
                intervalString += i + "," + (i + interval) + ")";
                intervalDistribution.add(intervalString);
                intervalDistributionNum.add(sum);

                num++;
            }
        } else {
            String intervalString = "[" + minInt + "," + maxInt + "]";
            intervalDistribution.add(intervalString);
            intervalDistributionNum.add(yList.size());
        }

        if (exceptionFlag && keyFactorFlag == 0) {
            entity.setIntervalDistribution(JSON.toJSONString(intervalDistribution));
            entity.setIntervalDistributionNum(JSON.toJSONString(intervalDistributionNum));
        }
        if (!exceptionFlag && keyFactorFlag == 0) {
            entity.setNoExceptionIntervalDistribution(JSON.toJSONString(intervalDistribution));
            entity.setNoExceptionIntervalDistributionNum(JSON.toJSONString(intervalDistributionNum));
        }
        if (exceptionFlag && keyFactorFlag == 1) {
            entity.setKeyFactorIntervalDistribution(JSON.toJSONString(intervalDistribution));
            entity.setKeyFactorIntervalDistributionNum(JSON.toJSONString(intervalDistributionNum));
        }
        if (!exceptionFlag && keyFactorFlag == 1) {
            entity.setKeyFactorNoExceptionIntervalDistribution(JSON.toJSONString(intervalDistribution));
            entity.setKeyFactorNoExceptionIntervalDistributionNum(JSON.toJSONString(intervalDistributionNum));
        }
    }

    /**
     * 曲线局部拟合性
     */
    private String getLocalProperty(String mape) {
        double[] bounds = parseInterval(mape);
        return bounds[1] <= 10 ? "良好" : bounds[1] <= 20 ? "一般" : "较差";
    }

    /**
     * 获取区间中的值
     *
     * @param mape 区间
     */
    private double[] parseInterval(String mape) {
        //去掉首尾空格
        String content = mape.substring(1, mape.length() - 1).trim();
        //分隔
        String[] parts = content.split("-");
        if (parts.length != 2) {
            throw new BusinessException("区间范围有误");
        }
        return new double[]{Double.parseDouble(parts[0].trim()), Double.parseDouble(parts[1].trim())};
    }

    /**
     * 获取集中程度
     *
     * @param varianceList 方差
     * @param standardList 标准差
     */
    private String getConcentrationDegree(List<Double> varianceList, List<Double> standardList) {
        String concentrationDegree = "较低";
        //方差值小于50
        for (Double variance : varianceList) {
            if (variance > 50) {
                return concentrationDegree;
            }
        }
        //标准差值小于1
        for (Double standard : standardList) {
            if (standard > 1) {
                return concentrationDegree;
            }
        }
        return "较高";
    }

    /**
     * 移除异常值，并返回异常值
     *
     * @
     */
    private List<Double> removeExceptionValue(PlanSample planSampleV3, List<Double> topValue, Boolean isNormalDistribution) {
        List<Double> exceptionValue = Lists.newArrayList();
        if (ObjectUtil.isNull(planSampleV3) || ObjectUtil.isNull(planSampleV3.getResult())) {
            return exceptionValue;
        }
        Map map = JSONUtil.toBean(planSampleV3.getResult().toString(), Map.class);
        Map<String, Object> mapResult = (Map<String, Object>) ((List<Object>) map.get("list")).get(0);
        //获取前25%平均值
        double average = topValue.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
        //获取最小值
        double min = Double.parseDouble(mapResult.get("min").toString());
        //获取最大值
        double max = Double.parseDouble(mapResult.get("max").toString());
        //获取中为数
        double median = Double.parseDouble(mapResult.get("median").toString());
        //判断分布情况
        if (Math.abs(average - median) / average > 0.3) {
            isNormalDistribution = false;
        }
        Iterator<Double> iterator = topValue.iterator();
        //移除异常值
        while (iterator.hasNext()) {
            Double value = iterator.next();
            if (ObjectUtil.isNull(value)) {
                continue;
            }
            if (value < min || value > max) {
                exceptionValue.add(value);
                iterator.remove();
            }
        }
        //保存异常值
        mapResult.put("error_list", exceptionValue);
        planSampleV3.setResult(JSONUtil.toJsonStr(map));
        return exceptionValue;
    }

    /**
     * 获取探索曲线
     */
    private ExploreCurveDTO getExploreCurve(String sid, String dependent, String ind, Double independentMin, Double independentMax) {
        ExploreCurveDTO exploreCurveDTO = new ExploreCurveDTO();
        //获取指标值
        List<PlanSampleExecuteRequest> variableByIndicatorId = getVariableByIndicatorId(sid, Collections.singletonList(ind), PlanSampleMethodType.NONE, VariableType.NORMAL);
        //获取参数值
        List<PlanSampleExecuteRequest> variableBySimData = getVariableBySimData(sid, Collections.singletonList(dependent), VariableType.NORMAL, PlanSampleMethodType.NONE);
        if (CollUtil.isNotEmpty(variableByIndicatorId) && CollUtil.isNotEmpty(variableBySimData)) {
            //指标值
            List<Double> yList = variableByIndicatorId.get(0).getData();
            //参数值
            List<Double> xList = variableBySimData.get(0).getData();
            if (CollUtil.isEmpty(yList) || CollUtil.isEmpty(xList)) {
                return exploreCurveDTO;
            }
            //获取x,y
            double[][] points = MathUtil.ListToArr(yList, xList);
            //获取方程
            Model model = MathUtil.approximateEquation(points);
            if (model == null) {
                IndicatorEntity indicatorEntity = indicatorService.getById(ind);
                throw new BusinessException("“" + dependent.split("#")[1] + "-" + indicatorEntity.getName() + "“数据不符合要求，无法生产拟合曲线");
            }
            exploreCurveDTO.setExploreCurveEquation(ObjectUtil.isNull(model) ? "" : model.toString());
            //设置原始点
            exploreCurveDTO.setOriginalPoints(points);
            //生成示例点
            List<Double[]> examplePoints = model.generateSamplePoints(points, 20);
            exploreCurveDTO.setExamplePoints(examplePoints);
            exploreCurveDTO.setModel(model);
            //获取前25%的值，并获取临界值，前25% 区间
            MathUtil.analyzePoints(points, exploreCurveDTO);

            MathUtil.setIntervalValue(points, exploreCurveDTO, independentMin, independentMax);

            exploreCurveDTO.setXList(xList);
            exploreCurveDTO.setYList(yList);
        }
        return exploreCurveDTO;
    }


    private List<Double> handlingOutliers(String dependent, String ind, PlanSample planSample, PlanSample planSampleV2, List<SimpleLinearEntity> simpleLinearEntityList, Double dependentMin, Double dependentMax, StrBuilder dataConclusion) {
        List<Double> dataAbnormal = Lists.newArrayList();
        if (ObjectUtil.isNotNull(planSample) && ObjectUtil.isNotNull(planSample.getResult())
                && CollUtil.isNotEmpty(planSample.getParams())
                && ObjectUtil.isNotNull(planSampleV2) && ObjectUtil.isNotNull(planSampleV2.getResult())) {
            //一元回归方程
            Object equation = JSONUtil.toBean(planSample.getResult().toString(), Map.class).get("regressionEquation");
            //获取效能指标结果
            List<Double> data = Lists.newArrayList();
            for (PlanSampleExecuteRequest param : planSample.getParams()) {
                //获取关键因素数据
                if (ind.equals(param.getName())) {
                    data.addAll(param.getData());
                    break;
                }
            }
            //获取异常值（不在变化范围内的值）
            if (ObjectUtil.isNotNull(equation)) {
//                String expression = equation.toString().split("=")[1].trim();
                Function<Double, Double> function = parseEquation(equation.toString());
//              double y = Double.parseDouble(ScriptUtil.eval(expression, new SimpleBindings(Map.of("x", datum))).toString());
                for (Double datum : data) {
                    double y = function.apply(datum);
                    if (ObjectUtil.isNotNull(dependentMin) && y < dependentMin) {
                        dataAbnormal.add(datum);
                    }
                    if (ObjectUtil.isNotNull(dependentMax) && y > dependentMax) {
                        dataAbnormal.add(datum);
                    }
                }

            }
            //补充异常值
            Map map = JSONUtil.toBean(planSampleV2.getResult().toString(), Map.class);
            Map<String, Object> mapResult = (Map<String, Object>) ((List<Object>) map.get("list")).get(0);
            mapResult.put("error_list", dataAbnormal);
            //获取方差
            Object var = mapResult.get("var");
            //获取标准差
            Object std = mapResult.get("std");
            planSampleV2.setResult(JSONUtil.toJsonStr(map));
            //处理结论
            dataConclusion.append("该关键因素的实际分布区间从仿真软件获取，为").append("xxx-xxx").append("，通过计算得出方差为").append(var).append("，标准差为").append(std).append("分布集中程度")
                    .append(Double.parseDouble(std.toString()) > 5 ? "高" : "低");


            //保存一元线性回归分析结果
            simpleLinearEntityList.add(SimpleLinearEntity.builder()
                    .dependentId(dependent)
                    .independent(ind)
                    .simpleLinearResult(JSONUtil.toJsonStr(planSample))
                    .exploratoryAnalysisResult(JSONUtil.toJsonStr(planSampleV2))
                    .dataConclusion(dataConclusion.toString())
                    .build());
        }
        return dataAbnormal;
    }

    /**
     * 根据表达式计算Y
     *
     * @param expression 表达式
     */
    private Function<Double, Double> parseEquation(String expression) {
        //去除所有空格
        String cleanedEquation = StrUtil.removeAll(expression, " ");
        //使用正则表达式提取系数a,b
        String regex = "^y=([+-]?\\d*\\.?\\d+)x([+-]\\d*\\.?\\d+)$";
        Matcher matcher = Pattern.compile(regex).matcher(cleanedEquation);
        if (!matcher.find()) {
            throw new BusinessException("方程格式不正确" + cleanedEquation);
        }

        double a = Double.parseDouble(matcher.group(1));
        double b = Double.parseDouble(matcher.group(2));

        //返回计算函数
        return x -> a * x + b;
    }

    /**
     * 系统边界条件，探索性分析 结果查询
     */
    @Override
    public List<ExploratoryAnalysisVO> exportAnalysisResult(String sid) {
        List<ExploratoryAnalysisVO> exploratoryAnalysisVOS = Lists.newArrayList();
        //根据sid查询分析项信息
        List<ExploratoryAnalysisEntity> exploratoryAnalysisEntities = exploratoryAnalysisService.list(new LambdaQueryWrapper<ExploratoryAnalysisEntity>().eq(ExploratoryAnalysisEntity::getSid, sid));
        if (CollUtil.isEmpty(exploratoryAnalysisEntities)) {
            return exploratoryAnalysisVOS;
        }
        List<String> dependentIds = exploratoryAnalysisEntities.stream().map(ExploratoryAnalysisEntity::getDependentId).collect(Collectors.toList());
        //根据sid查询探索性分析结果
        List<SimpleLinearEntity> simpleLinearEntityList = simpleLinearService.list(new LambdaQueryWrapper<SimpleLinearEntity>().in(SimpleLinearEntity::getDependentId, dependentIds));
        //根据因变量分组
        Map<String, List<SimpleLinearEntity>> simpleLinearMap = simpleLinearEntityList.stream().collect(Collectors.groupingBy(SimpleLinearEntity::getDependentId));
        //探索性分析结果
        for (ExploratoryAnalysisEntity exploratoryAnalysisEntity : exploratoryAnalysisEntities) {
            //折线图结果
            List<SimpleLinearVO> simpleLinearVOList = Lists.newArrayList();
            ExploratoryAnalysisVO exploratoryAnalysisVO = BeanUtil.toBean(exploratoryAnalysisEntity, ExploratoryAnalysisVO.class);
            //处理探索性分析结果
            if (CollUtil.isNotEmpty(simpleLinearMap.get(exploratoryAnalysisEntity.getDependentId()))) {
                //根据因变量id 获取对应的探索性分析结果
                for (SimpleLinearEntity simpleLinearEntity : simpleLinearMap.get(exploratoryAnalysisEntity.getDependentId())) {
                    SimpleLinearVO sl = new SimpleLinearVO();
                    sl.setIndependent(simpleLinearEntity.getIndependent());
                    sl.setDependentId(simpleLinearEntity.getDependentId());
                    //处理探索性分析结果
                    PlanSample planSampleEx = JSONUtil.toBean(simpleLinearEntity.getExploratoryAnalysisResult(), PlanSample.class);
                    planSampleEx.setType(PlanSampleMethodType.EXPLORATORY_ANALYSIS);
                    for (PlanSampleExecuteRequest param : planSampleEx.getParams()) {
                        param.setType(VariableType.INDEPENDENT);
                    }
                    sl.setExploratoryAnalysisResult(analysis(planSampleEx));
                    //处理一元线性回归分析结果
                    PlanSample planSampleSi = JSONUtil.toBean(simpleLinearEntity.getSimpleLinearResult(), PlanSample.class);
                    planSampleSi.setType(PlanSampleMethodType.SIMPLE_LINEAR);
                    for (PlanSampleExecuteRequest param : planSampleSi.getParams()) {
                        if (param.getName().equals(simpleLinearEntity.getDependentId())) {
                            param.setType(VariableType.DEPENDENT);
                        } else {
                            param.setType(VariableType.INDEPENDENT);
                        }
                    }
                    sl.setSimpleLinearResult(analysis(planSampleSi));
                    simpleLinearVOList.add(sl);
                }
            }
            exploratoryAnalysisVO.setSimpleLinearVOList(simpleLinearVOList);
            exploratoryAnalysisVOS.add(exploratoryAnalysisVO);
        }
        return exploratoryAnalysisVOS;
    }

    /**
     * 关键因素结果查询
     */
    @Override
    public List<SimpleLinearVO> elementsResult(String sid) {
        List<SimpleLinearVO> simpleLinearVOS = Lists.newArrayList();
        //根据sid查询分析项信息
        List<ExploratoryAnalysisEntity> exploratoryAnalysisEntities = exploratoryAnalysisService.list(new LambdaQueryWrapper<ExploratoryAnalysisEntity>().eq(ExploratoryAnalysisEntity::getSid, sid));
        if (CollUtil.isEmpty(exploratoryAnalysisEntities)) {
            return simpleLinearVOS;
        }
        List<String> dependentIds = exploratoryAnalysisEntities.stream().map(ExploratoryAnalysisEntity::getDependentId).collect(Collectors.toList());
        //根据sid查询探索性分析结果
        List<SimpleLinearEntity> simpleLinearEntityList = simpleLinearService.list(new LambdaQueryWrapper<SimpleLinearEntity>().in(SimpleLinearEntity::getDependentId, dependentIds));
        Map<String, PlanSample> independentNameMap = Maps.newHashMap();
        for (SimpleLinearEntity simpleLinearEntity : simpleLinearEntityList) {
            //创建探索性分析VO对象
            SimpleLinearVO simpleLinearVO = new SimpleLinearVO();
            //转为结果对象
            PlanSample planSample = JSONUtil.toBean(simpleLinearEntity.getExploratoryAnalysisResult(), PlanSample.class);
            planSample.setType(PlanSampleMethodType.EXPLORATORY_ANALYSIS);
            for (PlanSampleExecuteRequest param : planSample.getParams()) {
                param.setType(VariableType.INDEPENDENT);
            }
            //判断是否已存在相同关键因素
            if (independentNameMap.containsKey(simpleLinearEntity.getIndependent())) {
                //获取已有的相同关键因素
                PlanSample planSampleOne = independentNameMap.get(simpleLinearEntity.getIndependent());
                //获取异常值
                Map mapOne = JSONUtil.toBean(planSampleOne.getResult().toString(), Map.class);
                Map<String, Object> mapResult = (Map<String, Object>) ((List<Object>) mapOne.get("list")).get(0);
                List<Double> dataAbnormalOne = (List<Double>) mapResult.get("error_list");
                Map map = JSONUtil.toBean(planSample.getResult().toString(), Map.class);
                List<Double> dataAbnormal = (List<Double>) ((Map<String, Object>) ((List<Object>) map.get("list")).get(0)).get("error_list");
                //相同关键因素异常值累加
                dataAbnormalOne.addAll(dataAbnormal);
                planSampleOne.setResult(JSONUtil.toJsonStr(mapOne));
                continue;
            }
            independentNameMap.put(simpleLinearEntity.getIndependent(), analysis(planSample));
            //添加结果返回
            simpleLinearVO.setIndependent(simpleLinearEntity.getIndependent());
            simpleLinearVO.setDependentId(simpleLinearEntity.getDependentId());
            simpleLinearVO.setDataConclusion(simpleLinearEntity.getDataConclusion());
            simpleLinearVO.setExploratoryAnalysisResult(analysis(planSample));
            simpleLinearVOS.add(simpleLinearVO);
        }
        return simpleLinearVOS;
    }

    @Override
    public MiningParamResp getMiningThresholdConfig() {
        /**
         * 获取（支持度，置信度，提升度）挖掘阈值配置
         * @return
         */
        List<DictEntity> list = dictService.list(new LambdaQueryWrapper<DictEntity>().in(DictEntity::getDictCode, miningThresholdKeys));
        if (CollectionUtil.isEmpty(list)) {
            return new MiningParamResp(0.6, 0.3, 1.2, PlanSampleMethodType.ASSOCIATIONMINING_ANALYSIS_APRIORI.getName());
        }
        MiningParamResp miningParamResp = new MiningParamResp();
        for (DictEntity dictEntity : list) {
            ReflectUtil.setFieldValue(miningParamResp, dictEntity.getDictCode(), dictEntity.getDictValue());
        }
        return miningParamResp;

    }

    @Override
    public String associationAnalysisConclusion(String sid) {
        MiningModelConfigEntity miningModelConfigEntity = miningModelConfigService.getOne(new LambdaQueryWrapper<MiningModelConfigEntity>().eq(MiningModelConfigEntity::getSid, sid));
        if (miningModelConfigEntity == null) {
            return "无";
        }

        MiningResultResp miningResultResp = this.getHistoryResult(sid);
        List<MiningResultResp.ItemSet> twoItemSets = miningResultResp.getTwoItemSets();
        List<MiningResultResp.ItemSet> threeItemSets = miningResultResp.getThreeItemSets();

        twoItemSets.sort(Comparator
                .comparing(MiningResultResp.ItemSet::getSupport, Comparator.reverseOrder())
                .thenComparing(MiningResultResp.ItemSet::getConfidence, Comparator.reverseOrder())
                .thenComparing(MiningResultResp.ItemSet::getImprove, Comparator.reverseOrder()));
        threeItemSets.sort(Comparator
                .comparing(MiningResultResp.ItemSet::getSupport, Comparator.reverseOrder())
                .thenComparing(MiningResultResp.ItemSet::getConfidence, Comparator.reverseOrder())
                .thenComparing(MiningResultResp.ItemSet::getImprove, Comparator.reverseOrder()));

        StringBuilder sb = new StringBuilder();
        if (PlanSampleMethodType.ASSOCIATIONMINING_ANALYSIS_APRIORI.getName().equals(miningModelConfigEntity.getMiningModel())) {
            sb.append("使用Apriori算法模型进行关联关系挖掘");
        } else {
            sb.append("使用FP-Growth算法模型进行关联关系挖掘");
        }

        List<String> ids = new ArrayList<>();
        String twoItemResult = "";
        for (MiningResultResp.ItemSet twoItemSet : twoItemSets) {
            List<String> ids1 = twoItemSet.getIds();
            if (ids1.get(0).startsWith("param") || ids1.get(1).startsWith("param")) {
                continue;
            }
            ids = ids1;
            twoItemResult = twoItemSet.getRelationship();
            break;
        }
        if (CollectionUtil.isEmpty(ids)) {
            return "无";
        }
        List<IndicatorEntity> list = iIndicatorService.list(new LambdaQueryWrapper<IndicatorEntity>().in(IndicatorEntity::getId, ids));
        if (CollectionUtil.isEmpty(list)) {
            return "无";
        }
        sb.append("，二项集中");
        String[] split = twoItemResult.split("->");
        split[0] = split[0].substring(1, split[0].length() - 1);
        sb.append(split[0])
                .append("与")
                .append(split[1])
                .append("关联关系最强，当");
        String[] s0 = split[0].split(":");
        String[] s1 = split[1].split(":");
        sb.append(s0[0])
                .append("指标取值落在")
                .append(s0[1]).append("时，")
                .append(s1[0]).append("取值落在")
                .append(s1[1])
                .append("可能性较高，因此，如果需要提高").append(s1[0]).append("的性能，可通过改善").append(s0[0]).append("的性能。");


        String threeItemResult = "";
        for (MiningResultResp.ItemSet three : threeItemSets) {
            List<String> ids1 = three.getIds();
            if (ids1.get(0).startsWith("param") || ids1.get(1).startsWith("param") || ids1.get(2).startsWith("param")) {
                continue;
            }
            threeItemResult = three.getRelationship();
            break;
        }
        if (StrUtil.isBlank(threeItemResult)) {
            return sb.toString();
        }
        String[] threeSplit = threeItemResult.split("->");
        threeSplit[0] = threeSplit[0].substring(1, threeSplit[0].length() - 1);
        String[] threeS0 = threeSplit[0].split("、")[0].split(":");
        String[] threeS1 = threeSplit[0].split("、")[0].split(":");
        String[] threeS2 = threeSplit[1].split(":");
        sb.append("在三项集中")
                .append(threeSplit[0])
                .append("和").append(threeSplit[1])
                .append("关联关系最强，因此当")
                .append(threeS0[0])
                .append("取值在")
                .append(threeS0[1])
                .append("且").append(threeS1[0]).append("取值在").append(threeS1[1])
                .append("时，")
                .append(threeS2[0])
                .append("取值落在")
                .append(threeS2[1])
                .append("概率较高。因此，如果需要提高")
                .append(threeS2[0])
                .append("的性能，可通过改善").append(threeS0[0]).append("和").append(threeS1[0]).append("指标的性能。");
        //"在评估的所有关键指标中，"+list.get(0).getName()+"与"+list.get(1).getName()+"存在较强的关联关系。"
        return sb.toString();
    }

    @Override
    public GreyRelationAnalysisResultResp greyCorrelationAnalysis(String sid) {
        MiningModelConfigEntity miningModelConfigEntity = miningModelConfigService.getOne(new LambdaQueryWrapper<MiningModelConfigEntity>().eq(MiningModelConfigEntity::getSid, sid));
        if (miningModelConfigEntity == null || miningModelConfigEntity.getIndicatorInterval() == null) {
            return new GreyRelationAnalysisResultResp();
        }
        //获取关联挖掘配置的指标id
        List<String> indicatorIds = new ArrayList<>();
        getConfigIntervalNum(miningModelConfigEntity.getIndicatorInterval(), indicatorIds);

        //获取评估指标结果
        List<IndicatorValuesEntity> valuesList = indicatorValueService.list(new LambdaQueryWrapper<IndicatorValuesEntity>()
                .in(IndicatorValuesEntity::getIndicatorId, indicatorIds));
        if (CollectionUtil.isEmpty(valuesList)) {
            throw new BusinessException("指标结果未计算或指标结果为空");
        }

        Map<String, List<Double>> examDict = new LinkedHashMap<>();
        //每个指标的多轮次评估结果
        Map<String, List<IndicatorValuesEntity>> indicatorRoundValue = valuesList.stream().collect(Collectors.groupingBy(IndicatorValuesEntity::getIndicatorId));

        for (Map.Entry<String, List<IndicatorValuesEntity>> entry : indicatorRoundValue.entrySet()) {
            List<Double> data = entry.getValue().stream().map(t -> Double.parseDouble(t.getNormalizedValue())).collect(Collectors.toList());
            examDict.put(entry.getKey(), data);
        }

        //构建指标计算参数数据
        List<String> indicatorParamIds = new ArrayList<>();
        getConfigIntervalNum(miningModelConfigEntity.getIndicatorParamInterval(), indicatorParamIds);
        List<Map<String, Object>> indicatorParamSampleData = getIndicatorParamSampleData(indicatorParamIds, sid);
        for (String indicatorParamId : indicatorParamIds) {
            List<Double> data = new ArrayList<>();
            for (Map<String, Object> map : indicatorParamSampleData) {
                Object o = map.get(indicatorParamId);
                if (o == null) {
                    log.error("指标计算参数数据为空!!!");
                    o = 0;
                }
                try {
                    data.add(Double.parseDouble(o.toString()));
                } catch (NumberFormatException e) {
                    throw new BusinessException("指标计算参数数据不是数值，请检查");
                }
            }
            examDict.put(indicatorParamId, data);
        }


        indicatorIds.addAll(indicatorParamIds);
        JSONObject object = new JSONObject();
        object.put("method", 41);
        JSONObject data = new JSONObject();
        object.put("data", data);
        data.put("examDict", examDict);
        data.put("examDf", indicatorIds);
        String result = HttpUtils.sendPost(pythonServerUrl, JSON.toJSONString(object));

        GreyRelationAnalysisResultResp greyRelationAnalysisResultResp = parsingGreyRelationAnalysisResult(result, indicatorIds, indicatorParamIds);


        return greyRelationAnalysisResultResp;
    }

    /**
     * 解析灰色关联分析结果，封装
     *
     * @param json
     * @return
     */
    private GreyRelationAnalysisResultResp parsingGreyRelationAnalysisResult(String json, List<String> indicatorIds, List<String> indicatorParamIds) {
        //解析python返回结果
        JSONObject resultData = null;
        try {
            resultData = JSON.parseObject(json).getJSONObject("data");
        } catch (Exception e) {
            throw new BusinessException("数据不满足灰色关联分析！");
        }
        JSONArray deleteIds = resultData.getJSONArray("deleteId");
        JSONArray resultList = resultData.getJSONArray("resultList");
        if (Objects.isNull(deleteIds) || Objects.isNull(resultList)) {
            throw new RuntimeException("暂无计算结果");
        }

        GreyRelationAnalysisResultResp greyRelationAnalysisResultResp = new GreyRelationAnalysisResultResp();
        List<GreyRelationAnalysisResultResp.Header> headers = new ArrayList<>();
        List<Map<String, Object>> mapDataList = new ArrayList<>();
        greyRelationAnalysisResultResp.setData(mapDataList);
        greyRelationAnalysisResultResp.setHeaders(headers);
        GreyRelationAnalysisResultResp.Header first = new GreyRelationAnalysisResultResp.Header();
        first.setLabel("指标名称");
        first.setProp("1");
        headers.add(first);
        Map<String, String> indicatorNameMap = new HashMap<>();

        List<IndicatorEntity> indicatorEntityList = indicatorService.list(new LambdaQueryWrapper<IndicatorEntity>()
                .in(IndicatorEntity::getId, indicatorIds));
        for (IndicatorEntity indicatorEntity : indicatorEntityList) {
            //过滤python计算去除的指标列
            if (deleteIds.contains(indicatorEntity.getId())) {
                continue;
            }
            //构建矩阵表头
            GreyRelationAnalysisResultResp.Header header = new GreyRelationAnalysisResultResp.Header();
            header.setLabel(indicatorEntity.getName());
            header.setProp(indicatorEntity.getId());
            headers.add(header);
            indicatorNameMap.put(indicatorEntity.getId(), indicatorEntity.getName());
        }
        for (String indicatorParamId : indicatorParamIds) {
            //过滤python计算去除的指标列
            if (deleteIds.contains(indicatorParamId)) {
                continue;
            }
            //构建矩阵表头
            GreyRelationAnalysisResultResp.Header header = new GreyRelationAnalysisResultResp.Header();
            String[] split = indicatorParamId.split("#");
            header.setLabel(split[1]);
            header.setProp(indicatorParamId);
            headers.add(header);
            indicatorNameMap.put(indicatorParamId, split[1]);
        }

        GreyRelationAnalysisResultResp.Header header = new GreyRelationAnalysisResultResp.Header();
        header.setLabel("关联关系最强指标名称");
        header.setProp("name");
        header.setFixedDisplay(true);
        headers.add(header);

        for (int i = 0; i < resultList.size(); i++) {
            JSONObject jsonObject = resultList.getJSONObject(i);
            //源指标id
            String source = jsonObject.getString("source");
            //相关联其他指标id
            String target = jsonObject.getString("target");
            String[] split = target.split(",");
            //关联结果值
            JSONArray result = jsonObject.getJSONArray("result");

            //构建矩阵数据
            Map<String, Object> map = new LinkedHashMap<>();
            for (GreyRelationAnalysisResultResp.Header header1 : headers) {
                if (header1.getProp().equals(source)) {
                    map.put("1", header1.getLabel());
                }
            }
            mapDataList.add(map);
            map.put(source, null);
            int maxIndex = 0;
            BigDecimal maxValue = new BigDecimal(-1);
            for (int j = 0; j < split.length; j++) {
                if (result.get(j) instanceof BigDecimal) {
                    BigDecimal bigDecimal = result.getBigDecimal(j);
                    bigDecimal = bigDecimal.setScale(3, RoundingMode.HALF_UP);
                    map.put(split[j], bigDecimal);
                    //获取最强关联指标
                    if (bigDecimal.compareTo(maxValue) > 0) {
                        maxValue = bigDecimal;
                        maxIndex = j;
                    }
                }
            }
            map.put("name", indicatorNameMap.get(split[maxIndex]) + ":" + maxValue);
        }
        return greyRelationAnalysisResultResp;
    }

    /**
     * 最优取值区间探索
     *
     * @param optimalIntervalExploreDTO 最优取值区间探索DTO
     */
    @Override
    public OptimalIntervalExploreVO optimalIntervalExplore(OptimalIntervalExploreDTO optimalIntervalExploreDTO) {
        //返回结果
        OptimalIntervalExploreVO optimalIntervalExploreVO = new OptimalIntervalExploreVO();
        //数据效验
        if (StrUtil.isBlank(optimalIntervalExploreDTO.getSid()) || CollUtil.isEmpty(optimalIntervalExploreDTO.getIndependent()) || StrUtil.isBlank(optimalIntervalExploreDTO.getDependent())) {
            return optimalIntervalExploreVO;
        }
        //python算法入参
        Map<String, Object> parameters = Maps.newHashMap();
        //data
        Map<String, Object> data = Maps.newHashMap();
        parameters.put("data", data);
        parameters.put("method", PlanSampleMethodType.DT.getCode());
        //构建入参
        String paramStr = buildParameters(optimalIntervalExploreDTO, data);
        //获取返回结果
        try {
            //调用python算法
            HttpResponse execute = HttpUtil.createPost(pythonServerUrl)
                    .header(Header.CONTENT_TYPE, "application/json")
                    .body(JSON.toJSONString(parameters))
                    .execute();
            String body = execute.body();
            //解析结果为json
            JSONObject parse = JSON.parseObject(body);
            if ("SUCCESS".equals(parse.getString("status"))) {
                //解析结果
                analysisResult(optimalIntervalExploreVO, parse.getJSONObject("data"));
            }
        } catch (Exception e) {
            throw new BusinessException("python算法调用失败");
        }
        // 补充 结论
        optimalIntervalExploreVO.setConsole("当前使用数据中,【" + paramStr + "】的效能值不存在满足区间【" + optimalIntervalExploreDTO.getMinEff() + "," + optimalIntervalExploreDTO.getMaxEff() + "】的数据");
        return optimalIntervalExploreVO;
    }

    @Override
    public List<String> greyRelationAnalysisConclusion(String sid) {
        List<String> conclusionList = new ArrayList<>();

        GreyRelationAnalysisResultResp greyRelationAnalysisResultResp = greyCorrelationAnalysis(sid);
        List<GreyRelationAnalysisResultResp.Header> headers = greyRelationAnalysisResultResp.getHeaders();
        if (headers == null) {
            return new ArrayList<>();
        }
        Map<String, String> indicatorNameMap = new HashMap<>();
        for (GreyRelationAnalysisResultResp.Header header : headers) {
            indicatorNameMap.put(header.getProp(), header.getLabel());
        }

        List<Map<String, Object>> dataList = greyRelationAnalysisResultResp.getData();

        if (CollectionUtil.isEmpty(dataList)) {
            return new ArrayList<>();
        }
        String conclusion = "通过灰色关联分析，已经探索出各因素之间的关联程度，如下所示:";
        conclusionList.add(conclusion);

        int i = 1;
        for (Map<String, Object> map : dataList) {
            conclusion = "";
            Map<String, Double> data = new HashMap<>();
            for (Map.Entry<String, Object> entry : map.entrySet()) {
                if (entry.getValue() != null) {
                    try {
                        data.put(entry.getKey(), Double.parseDouble(entry.getValue().toString()));
                    } catch (NumberFormatException e) {
                        //e.printStackTrace();
                    }
                }
            }

            LinkedHashMap<String, Double> collect = data.entrySet().stream().sorted(new Comparator<Map.Entry<String, Double>>() {
                @Override
                public int compare(Map.Entry<String, Double> o1, Map.Entry<String, Double> o2) {
                    return Double.compare(o2.getValue(), o1.getValue());
                }
            })
                    .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (v1, v2) -> v1, LinkedHashMap::new));
            conclusion = conclusion + i + ".影响【" + map.get("1") + "】的主要影响因子是【";

            int j = 1;
            String nameValue = "";
            String name = "";
            for (Map.Entry<String, Double> mp : collect.entrySet()) {
                if (j > 3) {
                    break;
                }
                if (j == 1) {
                    conclusion += indicatorNameMap.get(mp.getKey()) + "(" + mp.getValue() + ")】";
                } else {
                    if (j != 2) {
                        nameValue += ",";
                        name += ",";
                    }
                    nameValue += indicatorNameMap.get(mp.getKey()) + "(" + mp.getValue() + ")";
                    name += indicatorNameMap.get(mp.getKey());
                }
                j++;
            }
            conclusion += "，次要因子是【" + nameValue + "】" + "，因此提高【" + map.get("1") + "】效能可从【" + name + "】方面入手";
            conclusionList.add(conclusion);
            i++;
        }
        return conclusionList;
    }

    /**
     * 删除用户输入的数据
     *
     * @param request 请求体
     * @return
     */
    @Override
    public PlanSample deleteUserInsertData(TrainedModelAnalysisReq request) {
        TrendForecastEntity trendForecastEntity = trendForecastService.getById(request.getTrendForecastId());
        if (trendForecastEntity == null) {
            throw new BusinessException("模型未训练，请先训练模型");
        }

        if (StringUtils.isEmpty(trendForecastEntity.getUserInsertData())) {
            // 无需操作删除
            return new PlanSample();
        }
        JSONObject userInsertData = JSON.parseObject(trendForecastEntity.getUserInsertData());

        PlanSampleMethodType planSampleMethodType = PlanSampleMethodType.valueOf(trendForecastEntity.getSampleMethodType());
        String params = JSON.parseObject(trendForecastEntity.getResult()).getString("params");
        List<PlanSampleExecuteRequest> planSampleExecuteRequests = JSON.parseArray(params, PlanSampleExecuteRequest.class);
        PlanSample build = PlanSample.builder().result(JSON.parseObject(trendForecastEntity.getResult()).getString("result")).params(planSampleExecuteRequests).type(planSampleMethodType).build();
        PlanSample analysis = analysis(build);
        if (!userInsertData.containsKey("userInsertData")) {
            userInsertData.put("userInsertData", new JSONArray());
        }
        JSONArray rowDatas = userInsertData.getJSONArray("userInsertData");
        if (rowDatas.size() < request.getUserInsertDataId()) {
            // 错误的请求导致删除失败，但是可以进行容错处理
            return analysis;
        }
        JSONArray analysisValues = userInsertData.getJSONArray("analysisValues");
        rowDatas.remove(request.getUserInsertDataId() - 1);
        analysisValues.remove(request.getUserInsertDataId() - 1);
        // 重新定义主键为了删除做准备
        JSONArray ids = new JSONArray();
        for (int i = 0; i < rowDatas.size(); i++) {
            ids.add(i + 1);
        }
        userInsertData.put("ids", ids);
        trendForecastEntity.setUserInsertData(JSON.toJSONString(userInsertData));
        trendForecastService.saveOrUpdate(trendForecastEntity);
        analysis.setUserInsertData(JSON.toJSONString(userInsertData));
        return analysis;
    }

    @Override
    public PlanSample trainedModelAnalysis(TrainedModelAnalysisReq request) {

        TrendForecastEntity trendForecastEntity = trendForecastService.getById(request.getTrendForecastId());
        if (trendForecastEntity == null) {
            throw new BusinessException("模型未训练，请先训练模型");
        }
        PlanSampleMethodType planSampleMethodType = PlanSampleMethodType.valueOf(trendForecastEntity.getSampleMethodType());
        //多元逻辑回归、二元逻辑回归、BP神经网络走训练模型调py
        if (planSampleMethodType == PlanSampleMethodType.BINARY_LOGISTIC || planSampleMethodType == PlanSampleMethodType.MULTIVARIATE_LOGISTIC || planSampleMethodType == PlanSampleMethodType.APSO_BPLearn) {
            return runModelPy(request, trendForecastEntity);
        }

        List<Double> newDataList = request.getDataList();
        JSONObject userInsertData = new JSONObject();
        if (StringUtils.isNotEmpty(trendForecastEntity.getUserInsertData())) {
            userInsertData = JSON.parseObject(trendForecastEntity.getUserInsertData());
        }
        if (!userInsertData.containsKey("userInsertData")) {
            userInsertData.put("userInsertData", new JSONArray());
        }
        JSONArray rowDatas = userInsertData.getJSONArray("userInsertData");
        if (!userInsertData.containsKey("analysisValues")) {
            userInsertData.put("analysisValues", new JSONArray());
        }

        JSONArray analysisValues = userInsertData.getJSONArray("analysisValues");
        rowDatas.add(newDataList);
        // 获取回归方程计算值并返回结果
        String result = trendForecastEntity.getResult();
        JSONObject jsonObject = JSON.parseObject(result);
        JSONObject result1 = jsonObject.getJSONObject("result");
        Double b = planSampleMethodType == PlanSampleMethodType.BINARY_LOGISTIC ? result1.getDouble("coef") : result1.getDouble("b");
        JSONArray regressionCoefficient = planSampleMethodType == PlanSampleMethodType.BINARY_LOGISTIC ? result1.getJSONArray("coefficient") : result1.getJSONArray("regressionCoefficient");
        BigDecimal bigDecimal = new BigDecimal(0);
        for (int i = 0; i < regressionCoefficient.size(); i++) {
            Double value = regressionCoefficient.getJSONObject(i).getDouble("value");
            Double userInsertDataValue = newDataList.get(i);
            bigDecimal = bigDecimal.add(BigDecimal.valueOf(value).multiply(BigDecimal.valueOf(userInsertDataValue)));
        }

        double newAnalysisValue = Double.parseDouble(bigDecimal.add(BigDecimal.valueOf(b)).setScale(4, RoundingMode.HALF_UP).toString());
        if (planSampleMethodType == PlanSampleMethodType.BINARY_LOGISTIC) {
            newAnalysisValue = 1 / (1 + Math.exp(-(newAnalysisValue)));
        }
        analysisValues.add(newAnalysisValue);
        // 重新定义主键为了删除做准备
        JSONArray ids = new JSONArray();
        for (int i = 0; i < rowDatas.size(); i++) {
            ids.add(i + 1);
        }
        userInsertData.put("ids", ids);
        trendForecastEntity.setUserInsertData(JSON.toJSONString(userInsertData));
        trendForecastService.saveOrUpdate(trendForecastEntity);
        String params = jsonObject.getString("params");
        List<PlanSampleExecuteRequest> planSampleExecuteRequests = JSON.parseArray(params, PlanSampleExecuteRequest.class);
        PlanSample build = PlanSample.builder().result(jsonObject.get("result")).params(planSampleExecuteRequests).type(planSampleMethodType).build();
        PlanSample analysis = analysis(build);
        analysis.setUserInsertData(JSON.toJSONString(userInsertData));
        return analysis;

    }

    public PlanSample runModelPy(TrainedModelAnalysisReq request, TrendForecastEntity trendForecastEntity) {
        List<Double> newDataList = request.getDataList();
        JSONObject userInsertData = new JSONObject();
        if (StringUtils.isNotEmpty(trendForecastEntity.getUserInsertData())) {
            userInsertData = JSON.parseObject(trendForecastEntity.getUserInsertData());
        }
        if (!userInsertData.containsKey("userInsertData")) {
            userInsertData.put("userInsertData", new JSONArray());
        }
        JSONArray rowDatas = userInsertData.getJSONArray("userInsertData");
        if (!userInsertData.containsKey("analysisValues")) {
            userInsertData.put("analysisValues", new JSONArray());
        }

        JSONArray analysisValues = userInsertData.getJSONArray("analysisValues");
        rowDatas.add(newDataList);

        List<String> headerList = request.getHeaderList();
        List<Double> dataList = request.getDataList();
        Map<String, Object> py = new HashMap<>();
        Map<String, Object> data = new HashMap<>();
        PlanSampleMethodModelType methodModel = PlanSampleMethodModelType.getName(trendForecastEntity.getSampleMethodType());
        py.put("method", methodModel.getCode());
        py.put("data", data);

        Map<String, List<Double>> independent = new HashMap<>();
        //for (List<Double> doubles : dataList) {
        String modelIndependent = trendForecastEntity.getIndependent();
        List<String> headList = JSONArray.parseArray(modelIndependent, String.class);
        int num=0;
        for (String h2 : headerList) {
            for (String h1 : headList) {
                if (h1.contains(h2)){
                    num++;
                    break;
                }
            }
        }
        if (headList.size()!=headerList.size() && num!=headerList.size()){
            throw new BusinessException("模型未训练");
        }
        for (int i = 0; i < headerList.size(); i++) {
            String s =headerList.get(i);
            for (String h2 : headList) {
                if (h2.contains(s))s=h2;
            }
            List<Double> d = new ArrayList<>();
            if (independent.containsKey(s)) {
                d = independent.get(s);
            } else {
                independent.put(s, d);
            }
            d.add(dataList.get(i));
        }
        //}

        data.put("independent", independent);
        String resultString;
        try {
            //调python获取结果数据
            String s = JSON.toJSONString(py);
            //System.out.println(s);
            String post = HttpUtil.post(pythonServer, s);
            resultString = com.yw.common.utils.StringUtils.unicodeDecode(post);
            System.out.println(resultString);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException("python服务连接失败");
        }
        if (resultString.contains("<!DOCTYP")) {
            throw new BusinessException("数据不支持训练模型");
        }

        try {
            JSONObject jsonObject = JSONObject.parseObject(resultString);
            JSONArray jsonArray = jsonObject.getJSONArray("data");
            List<Double> datas = new ArrayList<>();
            for (Object o : jsonArray) {
                datas.add(new BigDecimal(o.toString()).setScale(4, RoundingMode.HALF_UP).doubleValue());
            }
            analysisValues.add(datas.get(0));
        } catch (Exception e) {
            throw new BusinessException("数据不支持训练模型");
        }

        // 重新定义主键为了删除做准备
        JSONArray ids = new JSONArray();
        for (int i = 0; i < rowDatas.size(); i++) {
            ids.add(i + 1);
        }
        userInsertData.put("ids", ids);
        trendForecastEntity.setUserInsertData(JSON.toJSONString(userInsertData));
        trendForecastService.saveOrUpdate(trendForecastEntity);

        // 返回结果
        String result = trendForecastEntity.getResult();
        JSONObject jsonObject = JSON.parseObject(result);
        String params = jsonObject.getString("params");
        List<PlanSampleExecuteRequest> planSampleExecuteRequests = JSON.parseArray(params, PlanSampleExecuteRequest.class);
        PlanSampleMethodType planSampleMethodType = PlanSampleMethodType.valueOf(trendForecastEntity.getSampleMethodType());
        PlanSample build = PlanSample.builder().result(jsonObject.get("result")).params(planSampleExecuteRequests).type(planSampleMethodType).build();
        PlanSample analysis = analysis(build);
        analysis.setUserInsertData(JSON.toJSONString(userInsertData));
        return analysis;
    }

    /**
     * 系统边界条件，探索性分析 结果查询
     */
    @Override
    public List<ExploratoryAnalysisVO> exportAnalysisResultV2(String sid) {
        List<ExploratoryAnalysisVO> exploratoryAnalysisVOS = Lists.newArrayList();
        //根据sid查询分析项信息
        List<ExploratoryAnalysisEntity> exploratoryAnalysisEntities = exploratoryAnalysisService.list(new LambdaQueryWrapper<ExploratoryAnalysisEntity>().eq(ExploratoryAnalysisEntity::getSid, sid));
        if (CollUtil.isEmpty(exploratoryAnalysisEntities)) {
            return exploratoryAnalysisVOS;
        }
        List<String> dependentIds = exploratoryAnalysisEntities.stream().map(ExploratoryAnalysisEntity::getDependentId).collect(Collectors.toList());
        //根据sid查询探索性分析结果
        List<SimpleLinearEntity> simpleLinearEntityList = simpleLinearService.list(new LambdaQueryWrapper<SimpleLinearEntity>().in(SimpleLinearEntity::getDependentId, dependentIds));
        //根据因变量分组
        Map<String, List<SimpleLinearEntity>> simpleLinearMap = simpleLinearEntityList.stream().collect(Collectors.groupingBy(SimpleLinearEntity::getDependentId));
        //探索性分析结果
        for (ExploratoryAnalysisEntity exploratoryAnalysisEntity : exploratoryAnalysisEntities) {
            //折线图结果
            List<SimpleLinearVO> simpleLinearVOList = Lists.newArrayList();
            ExploratoryAnalysisVO exploratoryAnalysisVO = BeanUtil.toBean(exploratoryAnalysisEntity, ExploratoryAnalysisVO.class);
            //处理探索性分析结果
            if (CollUtil.isNotEmpty(simpleLinearMap.get(exploratoryAnalysisEntity.getDependentId()))) {
                //根据因变量id 获取对应的探索性分析结果
                for (SimpleLinearEntity simpleLinearEntity : simpleLinearMap.get(exploratoryAnalysisEntity.getDependentId())) {
                    SimpleLinearVO sl = new SimpleLinearVO();
                    sl.setIndependentMin(simpleLinearEntity.getIndependentMin());
                    sl.setIndependentMax(simpleLinearEntity.getIndependentMax());
                    sl.setIndependent(simpleLinearEntity.getIndependent());
                    sl.setDependentId(simpleLinearEntity.getDependentId());
                    sl.setDataConclusion(simpleLinearEntity.getDataConclusion());
                    sl.setFactorStatisticsConclusion(simpleLinearEntity.getFactorStatisticsConclusion());
                    sl.setKeyFactorStatisticsConclusion(simpleLinearEntity.getKeyFactorStatisticsConclusion());
                    sl.setOverallConclusion(simpleLinearEntity.getOverallConclusion());
                    sl.setIntervalDistribution(JSONUtil.toList(JSONUtil.parseArray(simpleLinearEntity.getIntervalDistribution()), String.class));
                    sl.setKeyFactorIntervalDistribution(JSONUtil.toList(JSONUtil.parseArray(simpleLinearEntity.getKeyFactorIntervalDistribution()), String.class));
                    sl.setIntervalDistributionNum(JSONUtil.toList(JSONUtil.parseArray(simpleLinearEntity.getIntervalDistributionNum()), Integer.class));
                    sl.setKeyFactorIntervalDistributionNum(JSONUtil.toList(JSONUtil.parseArray(simpleLinearEntity.getKeyFactorIntervalDistributionNum()), Integer.class));
                    sl.setNoExceptionIntervalDistribution(JSONUtil.toList(JSONUtil.parseArray(simpleLinearEntity.getNoExceptionIntervalDistribution()), String.class));
                    sl.setKeyFactorNoExceptionIntervalDistribution(JSONUtil.toList(JSONUtil.parseArray(simpleLinearEntity.getKeyFactorNoExceptionIntervalDistribution()), String.class));
                    sl.setKeyFactorNoExceptionIntervalDistributionNum(JSONUtil.toList(JSONUtil.parseArray(simpleLinearEntity.getKeyFactorNoExceptionIntervalDistributionNum()), Integer.class));
                    sl.setNoExceptionIntervalDistributionNum(JSONUtil.toList(JSONUtil.parseArray(simpleLinearEntity.getNoExceptionIntervalDistributionNum()), Integer.class));
                    if (ObjectUtil.isNotNull(simpleLinearEntity.getSimpleLinearResult())) {
                        //探索曲线
                        sl.setExploreCurveDTO(JSONUtil.toBean(simpleLinearEntity.getSimpleLinearResult(), ExploreCurveDTO.class));
                    }
                    if (StrUtil.isNotBlank(simpleLinearEntity.getStandard())) {
                        //标准差
                        sl.setStandardList(JSONUtil.toList(JSONUtil.parseArray(simpleLinearEntity.getStandard()), String.class));
                    }
                    if (StrUtil.isNotBlank(simpleLinearEntity.getVariance())) {
                        //方差
                        sl.setVarianceList(JSONUtil.toList(JSONUtil.parseArray(simpleLinearEntity.getVariance()), String.class));
                    }
                    if (StrUtil.isNotBlank(simpleLinearEntity.getNumber())) {
                        //数据量个数
                        List<String> list = JSON.parseArray(simpleLinearEntity.getNumber(), String.class);
                        List<List<Integer>> numberList = new ArrayList<>();
                        for (String o : list) {
                            if (o.contains("[")) {
                                List<Integer> integerList = JSON.parseArray(o, Integer.class);
                                numberList.add(integerList);
                            }
                        }
                        sl.setNumberList(numberList);
                    }
                    //处理探索性分析结果
                    if (ObjectUtil.isNotNull(simpleLinearEntity.getExploratoryAnalysisResult())) {
                        PlanSample planSampleEx = JSONUtil.toBean(simpleLinearEntity.getExploratoryAnalysisResult(), PlanSample.class);
                        planSampleEx.setType(PlanSampleMethodType.EXPLORATORY_ANALYSIS);
                        if (!CollUtil.isEmpty(planSampleEx.getParams())) {
                            for (PlanSampleExecuteRequest param : planSampleEx.getParams()) {
                                param.setType(VariableType.INDEPENDENT);
                            }
                            sl.setExploratoryAnalysisResult(analysis(planSampleEx));
                        }
                    }
                    //处理探索性分析结果(区间数据)
                    if (ObjectUtil.isNotNull(simpleLinearEntity.getIntervalExploratoryAnalysisResult())) {
                        PlanSample planSampleEx = JSONUtil.toBean(simpleLinearEntity.getIntervalExploratoryAnalysisResult(), PlanSample.class);
                        planSampleEx.setType(PlanSampleMethodType.EXPLORATORY_ANALYSIS);
                        for (PlanSampleExecuteRequest param : planSampleEx.getParams()) {
                            param.setType(VariableType.INDEPENDENT);
                        }
                        sl.setIntervalExploratoryAnalysisResult(analysis(planSampleEx));
                    }
                    //去除异常探索分析结果
                    if (ObjectUtil.isNotNull(simpleLinearEntity.getNoExceptionValueResult())) {
                        PlanSample planSampleExNoException = JSONUtil.toBean(simpleLinearEntity.getNoExceptionValueResult(), PlanSample.class);
                        planSampleExNoException.setType(PlanSampleMethodType.EXPLORATORY_ANALYSIS);
                        for (PlanSampleExecuteRequest param : planSampleExNoException.getParams()) {
                            param.setType(VariableType.INDEPENDENT);
                        }
                        sl.setNoExceptionValueResult(analysis(planSampleExNoException));
                    }
                    //处理探索性分析结果(区间数据)
                    if (ObjectUtil.isNotNull(simpleLinearEntity.getKeyFactorIntervalExploratoryAnalysisResult())) {
                        PlanSample planSampleEx = JSONUtil.toBean(simpleLinearEntity.getKeyFactorIntervalExploratoryAnalysisResult(), PlanSample.class);
                        planSampleEx.setType(PlanSampleMethodType.EXPLORATORY_ANALYSIS);
                        for (PlanSampleExecuteRequest param : planSampleEx.getParams()) {
                            param.setType(VariableType.INDEPENDENT);
                        }
                        sl.setKeyFactorIntervalExploratoryAnalysisResult(analysis(planSampleEx));
                    }
                    //去除异常探索分析结果
                    if (ObjectUtil.isNotNull(simpleLinearEntity.getKeyFactorNoExceptionValueResult())) {
                        PlanSample planSampleExNoException = JSONUtil.toBean(simpleLinearEntity.getKeyFactorNoExceptionValueResult(), PlanSample.class);
                        planSampleExNoException.setType(PlanSampleMethodType.EXPLORATORY_ANALYSIS);
                        for (PlanSampleExecuteRequest param : planSampleExNoException.getParams()) {
                            param.setType(VariableType.INDEPENDENT);
                        }
                        sl.setKeyFactorNoExceptionValueResult(analysis(planSampleExNoException));
                    }
                    simpleLinearVOList.add(sl);
                }
            }
            exploratoryAnalysisVO.setSimpleLinearVOList(simpleLinearVOList);
            exploratoryAnalysisVOS.add(exploratoryAnalysisVO);
        }
        return exploratoryAnalysisVOS;
    }

    /**
     * 解析结果
     */
    private void analysisResult(OptimalIntervalExploreVO optimalIntervalExploreVO, JSONObject data) {
        //获取关键指标对效能指标影响程度VO
        List<Map<String, Object>> feature = JSONObject.parseObject(data.get("feature").toString(), new com.alibaba.fastjson.TypeReference<List<Map<String, Object>>>() {
        });
        if (CollUtil.isNotEmpty(feature)) {
            List<FeatureVO> featureVOS = Lists.newArrayList();
            for (Map<String, Object> entity : feature) {
                featureVOS.add(FeatureVO.builder().feature(entity.get("Feature").toString()).importance(Double.parseDouble(entity.get("Importance").toString())).build());
            }
            //设置关键指标对效能指标影响程度VO
            optimalIntervalExploreVO.setFeatureVOS(featureVOS);
        }
        //获取关键指标最优取值区间
        List<Map<String, Double>> optimal = JSONObject.parseObject(data.get("optimal").toString(), new com.alibaba.fastjson.TypeReference<List<Map<String, Double>>>() {
        });
        if (CollUtil.isNotEmpty(optimal) && optimal.size() == 3) {
            List<OptimalVO> optimalVOList = Lists.newArrayList();
            Map<String, OptimalVO> optimalVOHashMap = Maps.newHashMap();
            for (int i = 0; i < optimal.size(); i++) {
                for (Map.Entry<String, Double> entity : optimal.get(i).entrySet()) {
                    //判断指标名称是否存在
                    if (!optimalVOHashMap.containsKey(entity.getKey())) {
                        OptimalVO optimalVO = OptimalVO.builder().indicatorName(entity.getKey()).build();
                        optimalVOHashMap.put(entity.getKey(), optimalVO);
                        optimalVOList.add(optimalVO);
                    }
                    //获取对应名称的指标最优取值区间
                    OptimalVO optimalVO = optimalVOHashMap.get(entity.getKey());
                    switch (i) {
                        //最小值
                        case 0:
                            optimalVO.setMin(entity.getValue());
                            break;
                        //最大值
                        case 1:
                            optimalVO.setMax(entity.getValue());
                            break;
                        //折中值
                        case 2:
                            optimalVO.setCompromise(entity.getValue());
                            break;
                    }
                }
            }
            //设置关键指标最优取值区间
            optimalIntervalExploreVO.setOptimalVOS(optimalVOList);
        }
        //获取决策树VO
        DecisionTreeVO decisionTreeVO = JSONUtil.toBean(data.get("tree").toString(), DecisionTreeVO.class);
        //设置决策树VO
        optimalIntervalExploreVO.setDecisionTreeVO(decisionTreeVO);
    }

    /**
     * 构建算法入参
     */
    private String buildParameters(OptimalIntervalExploreDTO optimalIntervalExploreDTO, Map<String, Object> data) {
        //方案id
        String sid = optimalIntervalExploreDTO.getSid();
        //查询关键指标参数
        List<PlanSampleExecuteRequest> variableBySimData = getVariableBySimData(sid, optimalIntervalExploreDTO.getIndependent(), VariableType.INDEPENDENT, PlanSampleMethodType.DT);
        //查询关键因素参数
        List<PlanSampleExecuteRequest> variableByIndicatorId = getVariableByIndicatorId(sid, Lists.newArrayList(optimalIntervalExploreDTO.getDependent()), PlanSampleMethodType.DT, VariableType.DEPENDENT);
        if (CollUtil.isEmpty(variableBySimData) || CollUtil.isEmpty(variableByIndicatorId)) {
            return null;
        }
        LinkedHashMap<String, List<Double>> examDict = new LinkedHashMap<>();
        List<String> examDf = Lists.newArrayList();
        //关键指标
        for (PlanSampleExecuteRequest variableBySimDatum : variableBySimData) {
            //字段名
            examDf.add(variableBySimDatum.getDesc());
            //参数名 值
            examDict.put(variableBySimDatum.getDesc(), variableBySimDatum.getData());
        }
        //关键因素
        PlanSampleExecuteRequest planSampleExecuteRequest = variableByIndicatorId.get(0);
        examDf.add(planSampleExecuteRequest.getDesc());
        examDict.put(planSampleExecuteRequest.getDesc(), planSampleExecuteRequest.getData());
        //添加参数
        data.put("examDict", examDict);
        data.put("examDf", examDf);
        data.put("minEff", ObjectUtil.isNull(optimalIntervalExploreDTO.getMinEff()) ? 0.7 : optimalIntervalExploreDTO.getMinEff());
        data.put("maxEff", ObjectUtil.isNull(optimalIntervalExploreDTO.getMaxEff()) ? 0.9 : optimalIntervalExploreDTO.getMaxEff());
        return planSampleExecuteRequest.getDesc();
    }

    /**
     * 获取指标参数数据
     *
     * @param indicatorParams
     * @param sid
     * @return
     */
    private List<Map<String, Object>> getIndicatorParamSampleData(List<String> indicatorParams, String sid) {

        List<Map<String, Object>> paramDataList = new ArrayList<>();

        for (String indicatorParam : indicatorParams) {
            String[] split = indicatorParam.split("#");

            List<ScenePrevColValueDTO> scenePrevColValueDTOList = sceneService.findAllSimSceneDataByTableName(split[0], new HashSet<>(Collections.singleton(split[1])), sid, null);
            if (CollectionUtil.isNotEmpty(scenePrevColValueDTOList)) {
                ScenePrevColValueDTO scenePrevColValueDTO = scenePrevColValueDTOList.get(0);
                Object value = scenePrevColValueDTO.getValue();
                if (value instanceof List) {
                    List list = (List) value;
                    for (int j = 0; j < list.size(); j++) {
                        if (paramDataList.size() < list.size()) {
                            Map<String, Object> map = new HashMap<>();
                            map.put(indicatorParam, list.get(j));
                            paramDataList.add(map);
                        } else {
                            paramDataList.get(j).put(indicatorParam, list.get(j));
                        }
                    }
                }
            }
        }

        return paramDataList;
    }

    /**
     * 获取指标计算参数最大最小值
     *
     * @param indicatorParams
     */
    private List<IndicatorInterval> getIndicatorParamMaxMinValue(List<String> indicatorParams, String sid) {

        List<IndicatorInterval> indicatorIntervals = new ArrayList<>();

        if (CollectionUtil.isNotEmpty(indicatorParams)) {
            for (String indicatorParam : indicatorParams) {
                String[] split = indicatorParam.split("#");
                List<ScenePrevColValueDTO> scenePrevColValueDTOList = sceneService.findAllSimSceneDataByTableName(split[0],
                        new HashSet<>(Collections.singleton(split[1])), sid, null);
                if (CollUtil.isEmpty(scenePrevColValueDTOList)){
                    continue;
                }
                ScenePrevColValueDTO scenePrevColValueDTO = scenePrevColValueDTOList.get(0);
                Object value = scenePrevColValueDTO.getValue();
                if (value instanceof List) {
                    List list = (List) value;
                    IndicatorInterval indicatorInterval = new IndicatorInterval();
                    indicatorInterval.setId(indicatorParam);
                    double min = Double.MAX_VALUE;
                    double max = Double.MIN_VALUE;

                    for (int j = 0; j < list.size(); j++) {
                        if (ObjectUtil.isEmpty(list.get(j))) {
                            continue;
                        }
                        try {
                            min = Math.min(min, Double.parseDouble(list.get(j).toString()));
                            max = Math.max(max, Double.parseDouble(list.get(j).toString()));
                        } catch (NumberFormatException e) {
                            throw new BusinessException("挖掘模型构建选择的指标计算参数存在非关系列，请检查：" + split[1]);
                        }
                    }
                    indicatorInterval.setMinValue(min);
                    indicatorInterval.setMaxValue(max);
                    indicatorIntervals.add(indicatorInterval);
                }
            }
        }

        return indicatorIntervals;
    }

    /**
     * 获取指标最大最小值
     *
     * @param indicatorIds
     */
    private List<IndicatorInterval> getIndicatorMaxMinValue(List<String> indicatorIds) {
        List<IndicatorValuesEntity> valuesList = indicatorValueService.list(new LambdaQueryWrapper<IndicatorValuesEntity>()
                .in(IndicatorValuesEntity::getIndicatorId, indicatorIds));
        if (CollectionUtil.isEmpty(valuesList)) {
            throw new BusinessException("指标结果未计算或指标结果为空");
        }

        //每个指标轮次的评估结果
        Map<String, List<IndicatorValuesEntity>> indicatorRoundValue = valuesList.stream().collect(Collectors.groupingBy(IndicatorValuesEntity::getIndicatorId));

        //构建表格数据
        List<IndicatorInterval> indicatorIntervals = new ArrayList<>();
        for (Map.Entry<String, List<IndicatorValuesEntity>> entry : indicatorRoundValue.entrySet()) {
            IndicatorInterval indicatorInterval = new IndicatorInterval();
            indicatorInterval.setId(entry.getKey());
            double min = Double.MAX_VALUE;
            double max = Double.MIN_VALUE;
            for (IndicatorValuesEntity indicatorValuesEntity : entry.getValue()) {
                min = Math.min(min, Double.parseDouble(indicatorValuesEntity.getNormalizedValue()));
                max = Math.max(max, Double.parseDouble(indicatorValuesEntity.getNormalizedValue()));
            }
            indicatorInterval.setMinValue(min);
            indicatorInterval.setMaxValue(max);
            indicatorIntervals.add(indicatorInterval);
        }
        return indicatorIntervals;
    }

    /**
     * 获取样本指标数据
     *
     * @param indicatorIds
     */
    private List<Map<String, Object>> getSampleIndicatorData(List<String> indicatorIds) {
        List<IndicatorEntity> indicatorEntities = indicatorService.list(new LambdaQueryWrapper<IndicatorEntity>().in(IndicatorEntity::getId, indicatorIds));
        if (CollUtil.isEmpty(indicatorEntities)) {
            throw new BusinessException("指标数据为空");
        }
        IndicatorEntity indicatorEntity = indicatorEntities.get(0);
        List<SceneEntity> sceneEntities = sceneService.list(new LambdaQueryWrapper<SceneEntity>().eq(SceneEntity::getTreeId, indicatorEntity.getTreeId()));
        if (CollUtil.isEmpty(sceneEntities)) {
            throw new BusinessException("指标结果未计算或指标结果为空");
        }
        Set<String> sceneIds = sceneEntities.stream().map(SceneEntity::getId).collect(Collectors.toSet());
        List<IndicatorValuesEntity> valuesList = indicatorValueService.list(new LambdaQueryWrapper<IndicatorValuesEntity>()
                .in(IndicatorValuesEntity::getIndicatorId, indicatorIds)
                .in(IndicatorValuesEntity::getSceneId, sceneIds));
        if (CollectionUtil.isEmpty(valuesList)) {
            throw new BusinessException("指标结果未计算或指标结果为空");
        }

        //每个轮次的指标评估结果
        Map<String, List<IndicatorValuesEntity>> roundIndicatorValue = valuesList.stream().collect(Collectors.groupingBy(IndicatorValuesEntity::getSceneId));

        //构建表格数据
        int size = 1;
        List<Map<String, Object>> dataList = new ArrayList<>();
        for (Map.Entry<String, List<IndicatorValuesEntity>> entry : roundIndicatorValue.entrySet()) {
            //一条样本数据，包含多个指标值
            Map<String, Object> data = new HashMap<>();
            data.put("num", size++);
            for (IndicatorValuesEntity indicatorValuesEntity : entry.getValue()) {
                data.put(indicatorValuesEntity.getIndicatorId(), Double.parseDouble(indicatorValuesEntity.getNormalizedValue()));
            }
            dataList.add(data);
        }
        return dataList;
    }

    /**
     * 调用关联挖掘分析FP_Growth
     *
     * @param sampleSize 样本数
     * @return 关联挖掘python结果
     */
    private static List<StrongAssociationRule> relationAnalysisFPGrowth(List<List<String>> intervalDataList, int sampleSize, Double sup, Double confi) {
        FPTree fpTree = new FPTree();
        int minSup = (int) Math.ceil(sup * sampleSize);
        fpTree.setMinSuport(minSup);
        fpTree.setConfident(confi);

        //后置项集设置
        Set<String> decideAttr = new HashSet<>();
        for (List<String> strings : intervalDataList) {
            decideAttr.addAll(strings);
        }

        fpTree.setDecideAttr(decideAttr);
        long begin = System.currentTimeMillis();
        fpTree.buildFPTree(intervalDataList);
        long end = System.currentTimeMillis();
        System.out.println("buildFPTree use time " + (end - begin));

        List<StrongAssociationRule> rules = fpTree.getAssociateRule();

        /*System.out.println("条件\t\t\t\t\t结果\t\t\t支持度\t置信度");

        for (StrongAssociationRule rule : rules) {
            System.out.println(rule.condition + "->" + rule.result + "\t" + dfm.format(1.0 * rule.support / sampleSize)
                    + "\t" + dfm.format(rule.confidence));
        }*/
        return rules;
    }

//@Override
    /*public PlanSample associationAnalysis(String sid, String scenarioId, String sceneId, List<String> treeIds, Double confidenceThreshold, Double reliabilityThreshold, String type) {
        //根据指标树id查询指标id
        if (CollUtil.isEmpty(treeIds)) {
            return null;
        }
        List<String> independent = Lists.newArrayList();
        for (String treeId : treeIds) {
            List<IndicatorEntity> treeList = indicatorService.findByTreeId(treeId);
            List<String> treeIdValues = treeList.stream().map(IndicatorEntity::getId).collect(Collectors.toList());
            independent.addAll(treeIdValues);
        }

        List<PlanSampleExecuteRequest> variableList = getVariableByIndicatorId(sid, independent, type);
        if (CollUtil.isEmpty(variableList)) {
            return null;
        }

        PlanSampleMethodType methodType = PlanSampleMethodType.valueOf(type);

        Map<String, List<Object>> independentValues = new HashMap<>();
        AtomicInteger incrInt = new AtomicInteger();
        for (PlanSampleExecuteRequest variable : variableList) {
            if (VariableType.INDEPENDENT.equals(variable.getType())) {
                for (String strData : variable.getStrData()) {
                    if (StrUtil.hasBlank(strData) && "未设置评估准则".equals(strData)) {
                        continue;
                    }
                    independentValues.computeIfAbsent(strData, item -> new ArrayList<>()).add(variable.getDesc());
                }
            }
        }

        if (CollUtil.isEmpty(independentValues)) {
            return null;
        }

        String body = AbstractResultAnalysis.buildParams(methodType.getCode(), independentValues, null);
        JSONObject resultJson;
        try {
            String result = HttpUtils.sendPost(pythonServerUrl, body);
            resultJson = JSON.parseObject(result);
            if (!"SUCCESS".equals(resultJson.getString("status"))) {
                throw new BusinessException(resultJson.getString("errorInfo"));
            }
        } catch (Exception e) {
            throw new BusinessException("数据不支持算法分析：" + methodType.getDesc());
        }

        String resultData = resultJson.getString("data");

        PlanSample planSample = PlanSample.builder().result(resultData).params(variableList).type(methodType).build();
        return analysis(planSample);
    }*/


}
