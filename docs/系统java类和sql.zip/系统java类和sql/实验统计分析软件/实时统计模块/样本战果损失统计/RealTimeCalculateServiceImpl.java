package com.yw.module.datasource.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.yw.common.defines.listener.AutoGeneratorSceneApplication;
import com.yw.common.utils.UUIDGenerator;
import com.yw.framework.backMgr.dbTableGenerator.domain.bo.DbLinkBO;
import com.yw.framework.backMgr.dbTableGenerator.domain.bo.TableColsBO;
import com.yw.framework.backMgr.dbTableGenerator.domain.dto.ExerciseInfoDTO;
import com.yw.framework.backMgr.dbTableGenerator.domain.dto.TableColsDTO;
import com.yw.framework.backMgr.dbTableGenerator.service.impl.DataBaseHandler;
import com.yw.framework.common.defines.response.PageInfo;
import com.yw.framework.common.util.db.DbUtils;
import com.yw.framework.common.util.pool2.PoolUtil;
import com.yw.gather.dbinfomgr.IDatasrcService;
import com.yw.gather.dbinfomgr.entity.DatasrcEntity;
import com.yw.gather.gathertask.defines.CopyDataFromFileToDB;
import com.yw.gather.gathertask.defines.DataSourceExeclParam;
import com.yw.module.calculation.indicatorCalculation.point.DecimalPointRetention;
import com.yw.module.calculation.service.IEvaluationCalculationService;
import com.yw.module.datasource.domain.dto.RelatedSamplesDTO;
import com.yw.module.datasource.domain.enums.AfterDataCollectionType;
import com.yw.module.datasource.domain.enums.CustomizedDataCollectionType;
import com.yw.module.datasource.domain.vo.CalculateResultVO;
import com.yw.module.datasource.domain.vo.TargetClassifyVO;
import com.yw.module.datasource.service.AfterGeneralDataService;
import com.yw.module.datasource.service.RealTimeCalculateService;
import com.yw.module.indicator.domain.entity.IndicatorEntity;
import com.yw.module.indicator.domain.entity.IndicatorTreeEntity;
import com.yw.module.indicator.domain.entity.IndicatorValuesEntity;
import com.yw.module.indicator.service.IIndicatorService;
import com.yw.module.indicator.service.IIndicatorTreeService;
import com.yw.module.indicator.service.ITIndicatorValueService;
import com.yw.module.missionScene.domain.entity.ContributionRateAlgorithmEntity;
import com.yw.module.missionScene.domain.entity.SceneScenarioEntity;
import com.yw.module.missionScene.service.ContributionRateAlgorithmService;
import com.yw.module.missionScene.service.SceneScenarioService;
import com.yw.module.plan.domain.entity.SceneEntity;
import com.yw.module.plan.domain.entity.SceneTableEntity;
import com.yw.module.plan.domain.entity.SchemaAliasEntity;
import com.yw.module.plan.service.ISceneTableService;
import com.yw.module.plan.service.ISchemaSceneTableAliasService;
import com.yw.module.plan.service.impl.SceneServiceImpl;
import com.yw.module.tcpconnect.TcpConnectionManager;
import com.yw.module.tcpconnect.TcpDataListener;
import com.yw.module.tcpconnect.TcpDataParser;
import com.yw.module.tcpconnect.content.GeneralContent;
import com.yw.module.tcpconnect.content.RealTimeDataContent;
import com.yw.module.tcpconnect.hander.BuildTopHighPointListener;
import com.yw.module.tcpconnect.listener.GeneralListener;
import com.yw.module.tcpconnect.listener.RealTimeDataListener;
import com.yw.module.tcpconnect.parser.BuildTopHighPointParser;
import com.yw.module.tcpconnect.parser.GeneralParser;
import com.yw.module.tcpconnect.parser.RealTimeDataParser;
import com.yw.source.dataManagement.handler.DataBasesOperationHandler;
import com.yw.source.importDataDirectory.entity.DataDirectory;
import com.yw.source.importDataDirectory.entity.ImportTableRecord;
import com.yw.source.importDataDirectory.service.IDataDirectoryService;
import com.yw.source.importDataDirectory.service.IImportTableRecordService;
import io.netty.handler.codec.LineBasedFrameDecoder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URI;
import java.net.URISyntaxException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * @BelongProject ddd
 * @BelongPackage com.yw.module.datasource.service.impl
 * @Author HaiBo
 * @date 2025-02-2025/2/24  19:44
 * @description
 */
@Service
@Slf4j
public class RealTimeCalculateServiceImpl implements RealTimeCalculateService, ApplicationContextAware {

    @Resource
    private DataSourceProperties dataSourceProperties;

    @Autowired
    private DataBasesOperationHandler dataBasesOperationHandler;

    /**
     * 样本服务实现
     */
    @Autowired
    private SceneServiceImpl sceneService;

    @Autowired
    private SceneScenarioService sceneScenarioService;

    /**
     * 实现场景任务想定关联算法
     */
    @Autowired
    private ContributionRateAlgorithmService contributionRateAlgorithmService;

    /**
     * pg计算实现层接口
     */
    @Autowired
    private IEvaluationCalculationService evaluationCalculationService;

    /**
     * 指标项服务层
     */
    @Autowired
    private IIndicatorService indicatorService;

    /**
     * 指标树服务层
     */
    @Autowired
    private IIndicatorTreeService indicatorTreeService;

    /**
     * 数据写入
     */
    @Autowired
    private CopyDataFromFileToDB copyDataFromFileToDB;

    /**
     * 数据源
     */
    @Autowired
    private IDatasrcService datasrcService;

    /**
     * 目录service
     */
    @Autowired
    private IDataDirectoryService iDataDirectoryService;

    /**
     * 数据库操作
     */
    @Autowired
    private DataBaseHandler dataBaseHandler;

    /**
     * 样本表结构
     */
    @Autowired
    private ISceneTableService sceneTableService;

    @Autowired
    private ISchemaSceneTableAliasService iSchemaSceneTableAliasService;

    @Autowired
    private ITIndicatorValueService indicatorValueService;

    @Autowired
    private IImportTableRecordService iImportTableRecordService;

    @Resource
    private PoolUtil poolUtil;


    @Autowired
    private DecimalPointRetention decimalPointRetention;

    @Autowired
    private AfterGeneralDataService afterGeneralDataService;


    /**
     * ip
     */
    private String host;

    /**
     * 端口
     */
    private String port;

    /**
     * 数据库类型
     */
    private String dbType;

    /**
     * 数据库名称
     */
    private String dbName;

    /**
     * 数据源链接信息
     */
    private DatasrcEntity datasrcEntity;

    private ApplicationContext applicationContext;

    /**
     * 事后评估--不同场景想定对应的数据解析器
     */
    private Map<String, TcpDataParser> scenarioParserMap = new HashMap<>();
    private Map<String, TcpDataListener> scenarioListenerMap = new HashMap<>();

    public RealTimeCalculateServiceImpl() {
        scenarioParserMap.put("2b63b84dd48b4edb9b07ac169f2078a9", new BuildTopHighPointParser());
        scenarioListenerMap.put("2b63b84dd48b4edb9b07ac169f2078a9", new BuildTopHighPointListener(this));
        //TODO 添加其他场景想定
    }


    /**
     * 初始化实时访问数据 drc
     */
    @PostConstruct
    public void init() {
        // taskType 默认使用5 区别于自定以数据（3）
        DatasrcEntity one = datasrcService.getOne(new LambdaQueryWrapper<DatasrcEntity>().eq(DatasrcEntity::getTaskType, 5));
        if (one != null) {
            datasrcEntity = one;
            this.host = one.getId();
            this.port = one.getPort();
            this.dbType = one.getType();
            this.dbName = one.getDatabaseName();
            return;
        }
        String dbName = "a0a9c76f84778";
        try {
            // 填充新的数据源对象
            String s1 = buildNewDataSrc(dbName);
            // 获取实时仿真数据表名
            String realTimeTableName = CustomizedDataCollectionType.REAL_TIME_DATA.name;
            List<TableColsBO> objects = Lists.newArrayList();
            //初始化基础字段
            objects.add(TableColsBO.valueOf("ID", "VARCHAR", 1, 0));
            for (String s : CustomizedDataCollectionType.REAL_TIME_DATA.roundKey.split("/")) {
                objects.add(TableColsBO.valueOf(s, "VARCHAR", 0, 0));
            }
            //创建数据库表
            datasrcEntity.setDatabaseName(s1);
            dataBaseHandler.createDatabase(dbName, datasrcEntity.createDblinkDto().createDbLinkBo());
            datasrcEntity.setDatabaseName(dbName);
            dataBaseHandler.createTable(realTimeTableName, objects, datasrcEntity.createDblinkDto().createDbLinkBo());

            ImportTableRecord importTableRecord = new ImportTableRecord();
            importTableRecord.setTableName(realTimeTableName);
            importTableRecord.setDirectoryId(realTimeTableName);
            iImportTableRecordService.save(new ImportTableRecord());
        } catch (Exception e) {
            datasrcService.remove(new LambdaQueryWrapper<DatasrcEntity>().eq(DatasrcEntity::getTaskType, 5));
            iDataDirectoryService.remove(new LambdaQueryWrapper<DataDirectory>().like(DataDirectory::getMark, datasrcEntity.getId()));
        }
    }


    /**
     * tcp数据接收
     *
     * @param data 数据
     */
    @Override
    public void tcpReceive(List<Map<String, Object>> data) {
        if (CollUtil.isEmpty(data)) {
            return;
        }
        final String sceneScenarioRoundKey = "SCENESCENARIOID";
        List<Map<String, Object>> dataInsert = Lists.newArrayList();
        Set<String> sceneScenarioRoundKeyValue = Sets.newHashSet();
        for (Map<String, Object> datum : data) {
            if (datum == null) {
                continue;
            }
            datum.put("CREATE_TIME", LocalDateTime.now());
            //补充ID列
            if (!datum.containsKey("ID") && !datum.containsKey("id")) {
                datum.put("ID", IdUtil.fastSimpleUUID());
            }
            Map<String, Object> map = Maps.newHashMap();
            for (Map.Entry<String, Object> entry : datum.entrySet()) {
                map.put(entry.getKey().toUpperCase(), entry.getValue());
            }
            if (datum.containsKey(sceneScenarioRoundKey)) {
                sceneScenarioRoundKeyValue.add(datum.get(sceneScenarioRoundKey).toString());
            }
            dataInsert.add(map);
        }
        //获取数据表名
        String realTimeTableName = CustomizedDataCollectionType.REAL_TIME_DATA.name;
        //获取数据源链接对象
        DbLinkBO dbLinkBo = datasrcEntity.createDblinkDto().createDbLinkBo();
        //获取表列
        List<TableColsDTO> columnList = Lists.newArrayList();
        List<String> tableColumns = Lists.newArrayList();
        for (Map<String, Object> datum : dataInsert) {
            for (Map.Entry<String, Object> entry : datum.entrySet()) {
                String col = entry.getKey();
                if (!tableColumns.contains(col)) {
                    TableColsDTO colsDTO = new TableColsDTO();
                    colsDTO.setColCode(col);
                    colsDTO.setColType("VARCHAR");
                    colsDTO.setColLen(255);
                    columnList.add(colsDTO);
                    tableColumns.add(col);
                }
            }
        }
        //创建轮次
        roundHandler(CustomizedDataCollectionType.REAL_TIME_DATA.name, CustomizedDataCollectionType.REAL_TIME_DATA.roundKey, tableColumns, dataInsert, datasrcEntity.getId(), datasrcEntity.getDatabaseName());

        //累加数据
        dataBasesOperationHandler.saveV2("ID", dbLinkBo, 2, realTimeTableName, columnList, dataInsert, 2, 1);

        //执行计算，返回结果
        CompletableFuture.supplyAsync(() -> {
            // 查询出所关联的想定
            List<SceneScenarioEntity> list = sceneScenarioService.list(new LambdaQueryWrapper<SceneScenarioEntity>().in(SceneScenarioEntity::getSourceId, sceneScenarioRoundKeyValue));
            if (CollUtil.isEmpty(list)) {
                // 当前数据没有关联方可以不用计算 节约资源
                return null;
            }
            //判断是否有关联的样本数据结构
            List<SceneTableEntity> sceneTableEntityList = sceneTableService.list(new LambdaQueryWrapper<SceneTableEntity>()
                    .eq(SceneTableEntity::getDsid, datasrcEntity.getId())
                    .in(SceneTableEntity::getSid, list.stream().map(SceneScenarioEntity::getSid).collect(Collectors.toSet()))
                    .eq(SceneTableEntity::getTableName, CustomizedDataCollectionType.REAL_TIME_DATA.name.toLowerCase()));
            if (CollUtil.isNotEmpty(sceneTableEntityList)) {
                for (SceneTableEntity sceneTableEntity : sceneTableEntityList) {
                    //构建样本
                    applicationContext.publishEvent(new AutoGeneratorSceneApplication("autoGenerator", datasrcEntity.getId(), sceneTableEntity.getTableName(), sceneTableEntity.getSid(), sceneTableEntity.getIndicatorTreeId()));
                    try {
                        //等待样本构建成功
                        Thread.sleep(200);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    //计算(避免重复计算,该轮仿真计算过，不再计算)
                    try {
                        evaluationCalculationService.parallelCalculate(sceneTableEntity.getSid(), 3);
                    } catch (Exception e) {
                        log.error("实时计算失败，异常原因：{}", e.getMessage());
                    }
//                    //查询计算结果
//                    CalculateResultVO calculateResult = this.getCalculateResult(sceneTableEntity.getSid());
//                    //推数据给前端
//                    StompMessagePusher.pushStompMessage(WebSocketConstant.REAL_TIME_COMPUTING_MESSAGE+"/"+sceneTableEntity.getSid() , calculateResult);
                }
            }
            return null;
        }).thenAccept(result -> {
        }).exceptionally((e) -> {
            e.printStackTrace();
            return null;
        });
    }

    /**
     * tcp数据接收
     *
     * @param data 数据
     */
    @Override
    public void afterTcpReceive(List<Map<String, Object>> data) {
        if (CollUtil.isEmpty(data)) {
            return;
        }

        //获取数据表名
        String afterTableName = AfterDataCollectionType.BUILD_TOP_HIGH_POINT.name;
        DatasrcEntity datasrcEntity = datasrcService.getOne(new LambdaQueryWrapper<DatasrcEntity>().eq(DatasrcEntity::getTaskType, 6));
        //获取数据源链接对象
        DbLinkBO dbLinkBo = datasrcEntity.createDblinkDto().createDbLinkBo();

        List<Map<String, Object>> dataList = dataBaseHandler.findDataList(afterTableName, dbLinkBo);
        int fzid = dataList != null ? dataList.size() : 0;

        List<Map<String, Object>> dataInsert = Lists.newArrayList();
        for (Map<String, Object> datum : data) {
            if (datum == null) {
                continue;
            }
            //补充ID列
            if (!datum.containsKey("ID") && !datum.containsKey("id")) {
                datum.put("ID", IdUtil.fastSimpleUUID());
            }
            datum.put("FZID", ++fzid);
            Map<String, Object> map = Maps.newHashMap();
            for (Map.Entry<String, Object> entry : datum.entrySet()) {
                map.put(entry.getKey().toUpperCase(), entry.getValue());
            }
            dataInsert.add(map);
        }


        //获取表列
        List<TableColsDTO> columnList = Lists.newArrayList();
        List<String> tableColumns = Lists.newArrayList();
        for (Map<String, Object> datum : dataInsert) {
            for (Map.Entry<String, Object> entry : datum.entrySet()) {
                String col = entry.getKey();
                if (!tableColumns.contains(col)) {
                    TableColsDTO colsDTO = new TableColsDTO();
                    colsDTO.setColCode(col);
                    colsDTO.setColType("VARCHAR");
                    colsDTO.setColLen(255);
                    columnList.add(colsDTO);
                    tableColumns.add(col);
                }
            }
        }
        //创建轮次
        roundHandler(AfterDataCollectionType.BUILD_TOP_HIGH_POINT.name, AfterDataCollectionType.BUILD_TOP_HIGH_POINT.roundKey, tableColumns, dataInsert, datasrcEntity.getId(), datasrcEntity.getDatabaseName());

        //累加数据
        dataBasesOperationHandler.saveV2("ID", dbLinkBo, 2, afterTableName, columnList, dataInsert, 2, 1);

        //构建样本
        //applicationContext.publishEvent(new AutoGeneratorSceneApplication("autoGenerator", datasrcEntity.getId(), sceneTableEntity.getTableName(), sceneTableEntity.getSid(), sceneTableEntity.getIndicatorTreeId()));

    }

    /**
     * 获取实时仿真数据源对象
     */
    @Override
    public TargetClassifyVO getRealTimeSrc() {
        CustomizedDataCollectionType realTimeData = CustomizedDataCollectionType.REAL_TIME_DATA;
        return new TargetClassifyVO(datasrcEntity.getId(), realTimeData.roundKey, realTimeData.name, dbName, realTimeData.id);
    }

    /**
     * 关联样本
     *
     * @param relatedSamplesDTO 关联样本信息dto
     * @return 提示信息
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public String relatedSamples(RelatedSamplesDTO relatedSamplesDTO) {
        CustomizedDataCollectionType realTimeData = CustomizedDataCollectionType.REAL_TIME_DATA;
        String sid = relatedSamplesDTO.getSid();
        //根据数据源id查询所有字段列
        DbLinkBO dbLinkBo = datasrcEntity.createDblinkDto().createDbLinkBo();
        List<TableColsDTO> tableCols = dataBaseHandler.findTableCols(realTimeData.name, dbLinkBo);
        //查询是否有样本
        List<SceneTableEntity> sceneTableEntities = sceneTableService.list(new LambdaQueryWrapper<SceneTableEntity>().eq(SceneTableEntity::getSid, sid));
        if (CollUtil.isNotEmpty(sceneTableEntities)) {
            //清除原有的sendTable信息
            sceneTableService.remove(new LambdaQueryWrapper<SceneTableEntity>().eq(SceneTableEntity::getSid, sid));
            iSchemaSceneTableAliasService.remove(new LambdaQueryWrapper<SchemaAliasEntity>().eq(SchemaAliasEntity::getSid, sid));
            //获取样本id集合
            List<SceneEntity> sceneEntityList = sceneService.list(new LambdaQueryWrapper<SceneEntity>().eq(SceneEntity::getSid, sid));
            if (CollUtil.isNotEmpty(sceneEntityList)) {
                List<String> sceneEntityIds = sceneEntityList.stream().map(SceneEntity::getId).collect(Collectors.toList());
                //清除贡献率关联记录
//                contributionRateAlgorithmService.remove(new LambdaQueryWrapper<ContributionRateAlgorithmEntity>()
//                        .in(ContributionRateAlgorithmEntity::getSceneId, sceneEntityIds));
            }
            //清除原有样本
            sceneService.remove(new LambdaQueryWrapper<SceneEntity>().eq(SceneEntity::getSid, sid));
        }
        //构建sendTable
        buildSample(tableCols, sid, relatedSamplesDTO.getIndicatorsKey(), realTimeData);
        //构建样本
        applicationContext.publishEvent(new AutoGeneratorSceneApplication("autoGenerator", datasrcEntity.getId(), realTimeData.name, sid, null));
        return "样本关联成功";
    }

    /**
     * 查询实时计算结果
     *
     * @param sid 方案id
     */
    @Override
    public CalculateResultVO getCalculateResult(String sid, int allDataFlag) {
        CalculateResultVO calculateResultVO = new CalculateResultVO();
        //横坐标
        List<SceneEntity> sceneList = Lists.newArrayList();
        //纵坐标
        Map<String, List<String>> indicatorValue = Maps.newHashMap();

        //获取方案下所有实时指标
        IndicatorTreeEntity indicatorTreeEntity = indicatorTreeService.getOne(new LambdaQueryWrapper<IndicatorTreeEntity>()
                .eq(IndicatorTreeEntity::getSid, sid)
                .eq(IndicatorTreeEntity::getIndicatorTreeCategory, CustomizedDataCollectionType.REAL_TIME_DATA.id));
//        List<IndicatorEntity> indicatorEntityList = indicatorService.list(new LambdaQueryWrapper<IndicatorEntity>()
//                .eq(IndicatorEntity::getSid, sid)
//                .eq(IndicatorEntity::getTreeId, indicatorTreeEntity.getId()));
        List<IndicatorEntity> indicatorEntityList = indicatorService.getLeafIndicator(indicatorTreeEntity.getId());
        for (IndicatorEntity indicatorEntity : indicatorEntityList) {
            String indicatorNameId = indicatorEntity.getName() + "/" + indicatorEntity.getId();
            indicatorValue.put(indicatorNameId, Lists.newArrayList());
        }

        //计算的样本，（5条）
        List<SceneEntity> sceneEntityList = sceneService.selectCalculateScene(sid, allDataFlag);
//                list(new LambdaQueryWrapper<SceneEntity>()
//                .eq(SceneEntity::getSid, sid)
//                .orderByDesc(SceneEntity::getCreateTime)
//                .eq(SceneEntity::getSceneType, CustomizedDataCollectionType.REAL_TIME_DATA.id)
//                .last("limit 5"));

        if (CollUtil.isNotEmpty(sceneEntityList)) {
            //根据样本id查询指标计算结果
            List<String> sceneId = sceneEntityList.stream().map(SceneEntity::getId).collect(Collectors.toList());
            List<ContributionRateAlgorithmEntity> bySceneIds = contributionRateAlgorithmService.findBySceneIds(sceneId);
            List<String> relationSceneIds = Lists.newArrayList();
            if (CollUtil.isNotEmpty(bySceneIds)) {
                relationSceneIds.addAll(bySceneIds.stream().map(ContributionRateAlgorithmEntity::getSceneId).collect(Collectors.toList()));
            }
            List<IndicatorValuesEntity> indicatorValuesEntityList = indicatorValueService.list(new LambdaQueryWrapper<IndicatorValuesEntity>().in(IndicatorValuesEntity::getSceneId, sceneId));
            if (CollUtil.isNotEmpty(indicatorValuesEntityList) && CollUtil.isNotEmpty(indicatorEntityList)) {
                //获取指标 id 名称 map
                Map<String, String> indicatorIdNameMap = indicatorEntityList.stream().collect(Collectors.toMap(IndicatorEntity::getId, IndicatorEntity::getName));
                //根据样本id分类结果
                Map<String, List<IndicatorValuesEntity>> sceneIdIndicatorValuesMap = indicatorValuesEntityList.stream().collect(Collectors.groupingBy(IndicatorValuesEntity::getSceneId));
                for (SceneEntity sceneEntity : sceneEntityList) {
                    if (ObjectUtil.isNull(sceneIdIndicatorValuesMap.get(sceneEntity.getId()))) {
                        continue;
                    }
                    if (!relationSceneIds.contains(sceneEntity.getId())) {
                        continue;
                    }
                    sceneList.add(sceneEntity);
                    for (IndicatorValuesEntity indicatorValuesEntity : sceneIdIndicatorValuesMap.get(sceneEntity.getId())) {
                        String indicatorName = indicatorIdNameMap.get(indicatorValuesEntity.getIndicatorId());
                        String indicatorNameId = indicatorName + "/" + indicatorValuesEntity.getIndicatorId();
                        if (!indicatorValue.containsKey(indicatorNameId)) {
                            indicatorValue.put(indicatorNameId, Lists.newArrayList());
                        }
                        indicatorValue.get(indicatorNameId).add(new BigDecimal(indicatorValuesEntity.getNormalizedValue()).setScale(2, RoundingMode.HALF_UP).toString());
                    }
                }
            }
        }else {
            SceneEntity sceneEntity1 = new SceneEntity();
            sceneEntity1.setCreateTime(LocalDateTime.of(2026,6,20,12,10,15));
            SceneEntity sceneEntity2 = new SceneEntity();
            sceneEntity2.setCreateTime(LocalDateTime.of(2026,6,20,12,10,20));
            SceneEntity sceneEntity3 = new SceneEntity();
            sceneEntity3.setCreateTime(LocalDateTime.of(2026,6,20,12,10,25));
            SceneEntity sceneEntity4 = new SceneEntity();
            sceneEntity4.setCreateTime(LocalDateTime.of(2026,6,20,12,10,30));
            SceneEntity sceneEntity5 = new SceneEntity();
            sceneEntity5.setCreateTime(LocalDateTime.of(2026,6,20,12,10,35));
            sceneList.add(sceneEntity1);
            sceneList.add(sceneEntity2);
            sceneList.add(sceneEntity3);
            sceneList.add(sceneEntity4);
            sceneList.add(sceneEntity5);
            for (String key : indicatorValue.keySet()) {
                if (key.startsWith("人员伤亡b")){
                    indicatorValue.put(key, Arrays.asList("0.00", "0.00", "0.00", "0.00", "0.00"));
                }
                if (key.startsWith("人员伤亡r")){
                    indicatorValue.put(key, Arrays.asList("0.00", "0.00", "0.00", "0.00", "0.00"));
                }
                if (key.startsWith("兵力交换比b")){
                    indicatorValue.put(key, Arrays.asList("0.00", "0.00", "0.00", "0.00", "0.00"));
                }
                if (key.startsWith("兵力交换比r")){
                    indicatorValue.put(key, Arrays.asList("0.00", "0.00", "0.00", "0.00", "0.00"));
                }
                if (key.startsWith("弹药消耗量b")){
                    indicatorValue.put(key, Arrays.asList("0.00", "0.00", "0.00", "0.00", "0.00"));
                }
                if (key.startsWith("弹药消耗量r")){
                    indicatorValue.put(key, Arrays.asList("0.00", "0.00", "0.00", "0.00", "0.00"));
                }
                if (key.startsWith("装备战损b")){
                    indicatorValue.put(key, Arrays.asList("0.00", "0.00", "0.00", "0.00", "0.00"));
                }
                if (key.startsWith("装备战损r")){
                    indicatorValue.put(key, Arrays.asList("0.00", "0.00", "0.00", "0.00", "0.00"));
                }
            }
        }
        calculateResultVO.setSceneList(sceneList);
        calculateResultVO.setIndicatorValue(indicatorValue);

        //非全量查询下，再统计总量
        if (allDataFlag == 0 && CollUtil.isNotEmpty(sceneEntityList)) {
            // taskType 默认使用5 区别于自定以数据（3）
            DatasrcEntity datasrc = datasrcService.getOne(new LambdaQueryWrapper<DatasrcEntity>().eq(DatasrcEntity::getTaskType, 5));

            //查询当前方案想定
            List<SceneScenarioEntity> scenarioEntityList = sceneScenarioService.findSceneScenarioBySid(sid);
            List<ExerciseInfoDTO.RoundFilter> roundFilterList = new ArrayList<>();
            ExerciseInfoDTO.RoundFilter roundFilter = new ExerciseInfoDTO.RoundFilter();
            roundFilter.setRoundField("SCENESCENARIOID");
            roundFilter.setRoundData(scenarioEntityList.get(0).getSourceId());
            roundFilterList.add(roundFilter);
            //查询当前方案想定--实时数据
            List<Map<String, Object>> dataList = dataBaseHandler.findDataListRoundFilter(CustomizedDataCollectionType.REAL_TIME_DATA.name, datasrc.createDblinkDto().createDbLinkBo(), roundFilterList);
            dataList.sort((o1, o2) -> o2.get("CREATE_TIME").toString().compareTo(o1.get("CREATE_TIME").toString()));
            int blueTotalAmmoNum = 0;
            int redTotalAmmoNum = 0;
            //人员伤亡总量
            int blueTotalDeathMan = 0;
            int redTotalDeathMan = 0;
            //zb战损
            int blueTotalDeathEquipment = 0;
            int redTotalDeathEquipment = 0;
            for (int i = 0; i < dataList.size(); i++) {
                Map<String, Object> map = dataList.get(i);
                if (i > 0) {
                    DateTimeFormatter formatter = new DateTimeFormatterBuilder()
                            .appendPattern("yyyy-MM-dd HH:mm:ss")
                            .appendFraction(ChronoField.MILLI_OF_SECOND, 0, 7, true)
                            .toFormatter();
                    //DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSS");
                    LocalDateTime time1 = LocalDateTime.parse(map.get("CREATE_TIME").toString(), formatter);
                    LocalDateTime time2 = LocalDateTime.parse(dataList.get(i - 1).get("CREATE_TIME").toString(), formatter);
                    Duration between = Duration.between(time1, time2);
                    long seconds = between.getSeconds();
                    //当两条数据间隔超过30秒，说明当前这一次仿真已经统计结束（对应仿真实时数据推送的间隔5秒）
                    if (seconds > 30) {
                        break;
                    }
                }

                try {
                    blueTotalAmmoNum += Integer.parseInt(map.get("弹药消耗量BLUE").toString());
                    redTotalAmmoNum += Integer.parseInt(map.get("弹药消耗量RED").toString());
                    blueTotalDeathMan += Integer.parseInt(map.get("人员伤亡BLUE").toString());
                    redTotalDeathMan += Integer.parseInt(map.get("人员伤亡RED").toString());

                    blueTotalDeathEquipment += Integer.parseInt(map.get("装备战损BLUE").toString());
                    redTotalDeathEquipment += Integer.parseInt(map.get("装备战损RED").toString());
                } catch (NumberFormatException e) {
                    log.error(e.getMessage());
                }
            }
            calculateResultVO.setBlueTotalAmmoNum(blueTotalAmmoNum);
            calculateResultVO.setBlueTotalDeathMan(blueTotalDeathMan);
            calculateResultVO.setBlueTotalDeathEquipment(blueTotalDeathEquipment);
            if (redTotalDeathEquipment + redTotalDeathMan != 0) {
                double v = 1.0 * (blueTotalDeathMan + blueTotalDeathEquipment) / (redTotalDeathEquipment + redTotalDeathMan);
                calculateResultVO.setBlueTotalMilitaryExchangeRatio(new BigDecimal(v).setScale(2, RoundingMode.HALF_UP).doubleValue());
            } else {
                calculateResultVO.setBlueTotalMilitaryExchangeRatio(0);
            }


            calculateResultVO.setRedTotalAmmoNum(redTotalAmmoNum);
            calculateResultVO.setRedTotalDeathMan(redTotalDeathMan);
            calculateResultVO.setRedTotalDeathEquipment(redTotalDeathEquipment);
            if (blueTotalDeathMan + blueTotalDeathEquipment != 0) {
                double v = 1.0 * (redTotalDeathEquipment + redTotalDeathMan) / (blueTotalDeathMan + blueTotalDeathEquipment);
                calculateResultVO.setRedTotalMilitaryExchangeRatio(new BigDecimal(v).setScale(2, RoundingMode.HALF_UP).doubleValue());
            } else {
                calculateResultVO.setRedTotalMilitaryExchangeRatio(0);
            }
        }else {
            calculateResultVO.setBlueTotalAmmoNum(0);
            calculateResultVO.setBlueTotalDeathMan(0);
            calculateResultVO.setBlueTotalDeathEquipment(0);
            calculateResultVO.setBlueTotalMilitaryExchangeRatio(0);

            calculateResultVO.setRedTotalAmmoNum(0);
            calculateResultVO.setRedTotalDeathMan(0);
            calculateResultVO.setRedTotalDeathEquipment(0);
            calculateResultVO.setRedTotalMilitaryExchangeRatio(0);
        }

        return calculateResultVO;
    }

    @Value("${pg-general.module.tcp.ip}")
    private String ipTcp;

    @Value("${pg-general.module.tcp.port}")
    private int portTcp;

    @Autowired
    private TcpConnectionManager manager;

    /**
     * 连接TCP
     */
/*    @Override
    public String connectTcp(Integer onOff) {
        if(onOff == 0){
            manager.disconnect(portTcp);
            return "tcp连接已断开";
        }
        // 连接文本服务端（9091端口）
//        manager.connect(ipTcp, portTcp, pipeline ->
//                        pipeline.addLast(new LineBasedFrameDecoder(1024 * 1024)), // 仅保留行解码器
//                new ListDataParser(),
//                new ListDataListener(this));

        manager.realTimeConnect(ipTcp, portTcp, pipeline ->
                        pipeline.addLast(new LineBasedFrameDecoder(1024 * 1024)), // 仅保留行解码器
                new RealTimeDataParser(),
                new JsonStringDataListener(this));

        // 添加关闭钩子
        Runtime.getRuntime().addShutdownHook(new Thread(manager::shutdown));
        return "tcp连接成功";
    }*/
    @Override
    public String realTimeConnect(String ip, int port, Integer onOff) {
        if (onOff == 0) {
            if (!manager.isRealTimeConnect(port)) {
                return "已经断开连接，不用重复断开";
            }
            manager.disconnectRealTime(port);
            RealTimeDataContent.init();
            return "tcp连接已断开";
        }

        if (manager.isRealTimeConnect(port)) {
            return "已经连接，不要重复连接";
        }

//        long count = sceneService.count(new LambdaQueryWrapper<SceneEntity>().eq(SceneEntity::getSid, schemaId).eq(SceneEntity::getSceneType, 1));
//        RealTimeDataContent.fzid =  new AtomicInteger((int)count);


        new Thread(() -> {
            manager.realTimeConnect(ip, port, pipeline ->
                            pipeline.addLast(new LineBasedFrameDecoder(1024 * 1024)), // 仅保留行解码器
                    new RealTimeDataParser(),
                    new RealTimeDataListener(this));
        }).start();

        // 添加关闭钩子
        //Runtime.getRuntime().addShutdownHook(new Thread(manager::shutdown2));
        return "tcp连接成功";
    }

    @Override
    public String connectTcpForAfter(String ip, int port, Integer onOff,String directoryName) {
        if (onOff == 0) {
            if (!manager.isAfterConnect(port)) {
                return "已经断开连接，不用重复断开";
            }
            manager.disconnectAfter(port);
            return "tcp连接已断开";
        }

        if (manager.isAfterConnect(port)) {
            return "已经连接，不要重复连接";
        }

        //SceneScenarioEntity sceneScenarioEntity = sceneScenarioService.getOne(new LambdaQueryWrapper<SceneScenarioEntity>().eq(SceneScenarioEntity::getSid, sid));

        new Thread(() -> {
            manager.afterConnect(ip, port, pipeline ->
                            pipeline.addLast(new LineBasedFrameDecoder(1024 * 1024)), // 仅保留行解码器
                    new GeneralParser(),
                    new GeneralListener(afterGeneralDataService, directoryName));
        }).start();
        // 添加关闭钩子
        //Runtime.getRuntime().addShutdownHook(new Thread(manager::shutdown3));
        return "事后tcp已连接";
    }

    @Override
    public void clearRealTimeConnect() {
        manager.disconnectRealTime(null);
    }

    @Override
    public void clearAfterConnect() {
        manager.disconnectAfter(null);
    }

    @Override
    public String tcpConnect(String sid, String ip, int port, Integer onOff) {
        if (onOff == 0) {
            if (!manager.isConnect(port)) {
                return "已经断开连接，不用重复断开";
            }
            manager.disconnect(port);
            RealTimeDataContent.init();
            return "tcp连接已断开";
        }

        if (manager.isConnect(port)) {
            return "已经连接，不要重复连接";
        }

        long count = sceneService.count(new LambdaQueryWrapper<SceneEntity>().eq(SceneEntity::getSid, sid).eq(SceneEntity::getSceneType, 1));
        RealTimeDataContent.fzid = new AtomicInteger((int) count);


        SceneScenarioEntity sceneScenarioEntity = sceneScenarioService.getOne(new LambdaQueryWrapper<SceneScenarioEntity>().eq(SceneScenarioEntity::getSid, sid));

        new Thread(() -> {
            manager.connect(ip, port, pipeline ->
                            pipeline.addLast(new LineBasedFrameDecoder(1024 * 1024)), // 仅保留行解码器
                    new RealTimeDataParser(),
                    scenarioParserMap.get(sceneScenarioEntity.getSourceId()),
                    new RealTimeDataListener(this),
                    scenarioListenerMap.get(sceneScenarioEntity.getSourceId()));
        }).start();

        // 添加关闭钩子
        //Runtime.getRuntime().addShutdownHook(new Thread(manager::shutdown2));
        return "tcp连接成功";
    }

    @Override
    public String connectTcpSaveOriginalData(String ip, int port, Integer onOff, String directoryName) {
        if (onOff == 0) {
            if (!manager.isConnectOriginalData(port)) {
                return "已经断开连接，不用重复断开";
            }
            manager.disconnectOriginalData(port);
            GeneralContent.clear();
            RealTimeDataContent.init();
            return "tcp连接已断开";
        }

        if (manager.isConnectOriginalData(port)) {
            return "已经连接，不要重复连接";
        }

        //SceneScenarioEntity sceneScenarioEntity = sceneScenarioService.getOne(new LambdaQueryWrapper<SceneScenarioEntity>().eq(SceneScenarioEntity::getSid, sid));

        new Thread(() -> {
            manager.connectOriginalData(ip, port, pipeline ->
                            pipeline.addLast(new LineBasedFrameDecoder(1024 * 1024)), // 仅保留行解码器
                    new RealTimeDataParser(),
                    new GeneralParser(),
                    new RealTimeDataListener(this),
                    new GeneralListener(afterGeneralDataService, directoryName));
        }).start();

        // 添加关闭钩子
        //Runtime.getRuntime().addShutdownHook(new Thread(manager::shutdown2));
        return "tcp连接成功";
    }

    @Override
    public String realTimeConnectstate(String ip, int port, Integer onOff) {
        if (onOff == 0) {
//            if (!manager.isRealTimeConnect(port)) {
//                return "已经断开连接，不用重复断开";
//            }
//            manager.disconnectRealTime(port);
            RealTimeDataContent.init();
            return "tcp连接已断开";
        }

        if (manager.isRealTimeConnect(port)) {
            return "tcp连接成功";
        }

        return "tcp连接失败";
    }

    @Override
    public String connectTcpForAfterStatue(String sid, String ip, int port, Integer onOff, String directoryName) {
        if (onOff == 0) {
//            if (!manager.isAfterConnect(port)) {
//                return "连接失败，请重试";
//            }
//            manager.disconnectAfter(port);
            return "tcp连接已断开";
        }

        if (manager.isAfterConnect(port)) {
            return "tcp连接成功";
        }
        return "tcp连接失败";
    }


    /**
     * 统计分析效能评估结果结论
     */
    public List<String> efficiencyTrendConclusion(String sid) {
        IndicatorTreeEntity indicatorTreeEntity = indicatorTreeService.getOne(new LambdaQueryWrapper<IndicatorTreeEntity>()
                .eq(IndicatorTreeEntity::getSid, sid)
                .eq(IndicatorTreeEntity::getIndicatorTreeCategory, 1));
        List<IndicatorEntity> leafIndicatorList = indicatorService.getLeafIndicator(indicatorTreeEntity.getId());
        List<String> ids = leafIndicatorList.stream().map(t -> t.getId()).collect(Collectors.toList());

        List<SceneEntity> sceneEntityList = sceneService.list(new LambdaQueryWrapper<SceneEntity>().eq(SceneEntity::getSid, sid).eq(SceneEntity::getTreeId, indicatorTreeEntity.getId()));

        if (CollectionUtils.isEmpty(sceneEntityList)) {
            return new ArrayList<>(Collections.singleton("无"));
        }
        Set<String> sceneIds = sceneEntityList.stream().map(SceneEntity::getId).collect(Collectors.toSet());
        List<IndicatorValuesEntity> indicatorValuesEntityList = indicatorValueService.list(new LambdaQueryWrapper<IndicatorValuesEntity>()
                .in(IndicatorValuesEntity::getIndicatorId, ids)
                .in(IndicatorValuesEntity::getSceneId, sceneIds));
        if (CollectionUtils.isEmpty(indicatorValuesEntityList)) {
            return new ArrayList<>(Collections.singleton("无"));
        }
        Map<String, List<IndicatorValuesEntity>> indicatorValueMap = indicatorValuesEntityList.stream().collect(Collectors.groupingBy(IndicatorValuesEntity::getIndicatorId));

        double avgRedAmmoNum = 0;
        double avgBlueAmmoNum = 0;
        double maxBlueDeathPerson = 0;
        double maxBlueDeathEquipment = 0;
        double maxRedDeathPerson = 0;
        double maxRedDeathEquipment = 0;
        double maxRedExchangeRatio = 0;
        for (IndicatorEntity node : leafIndicatorList) {
            String id = node.getId();
            List<IndicatorValuesEntity> valueList = indicatorValueMap.get(id);
            indicatorValueMap.put(node.getName(), valueList);
            if (CollectionUtils.isEmpty(valueList)) {
                continue;
            }
            List<Double> data = valueList.stream().map(obj -> Double.parseDouble(obj.getNormalizedValue())).collect(Collectors.toList());

            if ("弹药消耗量red".equals(node.getName())) {
                //计算平均值
                avgRedAmmoNum = decimalPointRetention.setScale(BigDecimal.valueOf(data.stream().mapToDouble(Double::doubleValue).average().orElse(0.0)), 0.0);
            }
            if ("弹药消耗量blue".equals(node.getName())) {
                //计算平均值
                avgBlueAmmoNum = decimalPointRetention.setScale(BigDecimal.valueOf(data.stream().mapToDouble(Double::doubleValue).average().orElse(0.0)), 0.0);
            }
            if ("人员伤亡red".equals(node.getName())) {
                //计算最大值
                maxRedDeathPerson = decimalPointRetention.setScale(BigDecimal.valueOf(data.stream().mapToDouble(Double::doubleValue).max().orElse(0.0)), 0.0);
            }
            if ("人员伤亡blue".equals(node.getName())) {
                //计算最大值
                maxBlueDeathPerson = decimalPointRetention.setScale(BigDecimal.valueOf(data.stream().mapToDouble(Double::doubleValue).max().orElse(0.0)), 0.0);
            }
            if ("装备战损red".equals(node.getName())) {
                //计算最大值
                maxRedDeathEquipment = decimalPointRetention.setScale(BigDecimal.valueOf(data.stream().mapToDouble(Double::doubleValue).max().orElse(0.0)), 0.0);
            }
            if ("装备战损blue".equals(node.getName())) {
                //计算最大值
                maxBlueDeathEquipment = decimalPointRetention.setScale(BigDecimal.valueOf(data.stream().mapToDouble(Double::doubleValue).max().orElse(0.0)), 0.0);
            }
            if ("兵力交换比red".equals(node.getName())) {
                //计算最大值
                maxRedExchangeRatio = decimalPointRetention.setScale(BigDecimal.valueOf(data.stream().mapToDouble(Double::doubleValue).max().orElse(0.0)), 0.0);
            }

        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        List<String> conclusions = new ArrayList<>();
        String conclusion1 = "1. 红方平均弹药消耗量为" + avgRedAmmoNum;
        if (avgRedAmmoNum < avgBlueAmmoNum) {
            conclusion1 = conclusion1 + "，小于蓝方弹药消耗" + avgBlueAmmoNum + "，红方在资源利用上更占优势。";
        } else if (avgRedAmmoNum > avgBlueAmmoNum) {
            conclusion1 = conclusion1 + "，大于蓝方弹药消耗" + avgBlueAmmoNum + "，蓝方在资源利用上更占优势。";
        } else {
            conclusion1 = conclusion1 + "，等于蓝方弹药消耗" + avgBlueAmmoNum + "，双方在资源利用上势均力敌。";
        }
        List<IndicatorValuesEntity> valueRedDeathPersionList = indicatorValueMap.get("人员伤亡red");
//        String conclusion2 = "";
//        for (IndicatorValuesEntity indicatorValues : valueRedDeathPersionList) {
//            if (Double.compare(Double.parseDouble(indicatorValues.getNormalizedValue()), maxRedDeathPerson)==0){
//                if (indicatorValues.getCreateTime()==null){
//                    indicatorValues.setCreateTime(LocalDateTime.now());
//                }
//                conclusion2 = conclusion2 + "2. 在仿真开始后，在"+indicatorValues.getCreateTime().format(formatter)+"时，红方人员伤亡数量达到最大值"+maxRedDeathPerson;
//                break;
//            }
//        }
//        List<IndicatorValuesEntity> valueRedDeathEquipmentList = indicatorValueMap.get("装备战损red");
//        for (IndicatorValuesEntity indicatorValues : valueRedDeathEquipmentList) {
//            if (Double.compare(Double.parseDouble(indicatorValues.getNormalizedValue()), maxRedDeathEquipment)==0){
//                if (indicatorValues.getCreateTime()==null){
//                    indicatorValues.setCreateTime(LocalDateTime.now());
//                }
//                conclusion2 = conclusion2 + "；在"+indicatorValues.getCreateTime().format(formatter)+"时，红方装备战损数量最高为"+maxRedDeathEquipment;
//                break;
//            }
//        }
//        conclusion2 = conclusion2 +"建议重点关注仿真开始后上述两个时间节点，分析导致红方高人员伤亡和高装备战损的具体原因，优化作战方案及战术部署。";

        String conclusion3 = "2. ";
        List<IndicatorValuesEntity> valueBlueDeathPersonList = indicatorValueMap.get("人员伤亡blue");
        for (IndicatorValuesEntity indicatorValues : valueBlueDeathPersonList) {
            if (Double.compare(Double.parseDouble(indicatorValues.getNormalizedValue()), maxBlueDeathPerson) == 0) {
                if (indicatorValues.getCreateTime() == null) {
                    indicatorValues.setCreateTime(LocalDateTime.now());
                }
                conclusion3 = conclusion3 + "在仿真开始后，在" + indicatorValues.getCreateTime().format(formatter) + "时，蓝方人员伤亡数量达到最大值" + maxBlueDeathPerson;
                break;
            }
        }
        List<IndicatorValuesEntity> valueBlueDeathEquipmentList = indicatorValueMap.get("装备战损blue");
        if (valueBlueDeathEquipmentList == null) {
            conclusion3 = conclusion3 + "建议重点关注仿真开始后上述时间节点，分析导致蓝方高人员伤亡的具体原因，推荐将此时的战术布局作为参考。";
        } else {
            for (IndicatorValuesEntity indicatorValues : valueBlueDeathEquipmentList) {
                if (Double.compare(Double.parseDouble(indicatorValues.getNormalizedValue()), maxBlueDeathEquipment) == 0) {
                    if (indicatorValues.getCreateTime() == null) {
                        indicatorValues.setCreateTime(LocalDateTime.now());
                    }
                    conclusion3 = conclusion3 + "；在" + indicatorValues.getCreateTime().format(formatter) + "时，蓝方装备战损数量最高为" + maxBlueDeathEquipment;
                    break;
                }
            }
            conclusion3 = conclusion3 + "建议重点关注仿真开始后上述两个时间节点，分析导致蓝方高人员伤亡和高装备战损的具体原因，推荐将此时的战术布局作为参考。";
        }


        String conclusion4 = "3. ";
        List<IndicatorValuesEntity> valueRedExchangeRatioList = indicatorValueMap.get("兵力交换比red");
        for (IndicatorValuesEntity indicatorValues : valueRedExchangeRatioList) {
            if (Double.compare(Double.parseDouble(indicatorValues.getNormalizedValue()), maxRedExchangeRatio) == 0) {
                if (indicatorValues.getCreateTime() == null) {
                    indicatorValues.setCreateTime(LocalDateTime.now());
                }
                conclusion4 = conclusion4 + "在仿真开始后，在" + indicatorValues.getCreateTime().format(formatter) + "时红方的兵力交换比最大为" + maxRedExchangeRatio;
                conclusion4 = conclusion4 + "，说明在仿真" + indicatorValues.getCreateTime().format(formatter) + "，红方作战效益较好，可以将此次仿真的战术布局作为参考。";
                break;
            }
        }
        conclusions.add(conclusion1);
        //conclusions.add(conclusion2);
        conclusions.add(conclusion3);
        conclusions.add(conclusion4);

        return conclusions;
    }

    @Override
    public PageInfo<Map<String, Object>> realTimeEvent(String sid, Integer offSet, Integer limit) {

        // taskType 默认使用5 区别于自定以数据（3）
        DatasrcEntity datasrc = datasrcService.getOne(new LambdaQueryWrapper<DatasrcEntity>().eq(DatasrcEntity::getTaskType, 5));

        //查询当前方案想定
        List<SceneScenarioEntity> scenarioEntityList = sceneScenarioService.findSceneScenarioBySid(sid);
        List<ExerciseInfoDTO.RoundFilter> roundFilterList = new ArrayList<>();
        ExerciseInfoDTO.RoundFilter roundFilter = new ExerciseInfoDTO.RoundFilter();
        roundFilter.setRoundField("SCENESCENARIOID");
        roundFilter.setRoundData(scenarioEntityList.get(0).getSourceId());

        ExerciseInfoDTO.RoundFilter roundFilter2 = new ExerciseInfoDTO.RoundFilter();
        roundFilter2.setRoundField("FLAG");
        roundFilter2.setRoundData("0");
        roundFilterList.add(roundFilter);
        roundFilterList.add(roundFilter2);
        //查询当前方案想定--实时数据
        PageInfo<Map<String, Object>> dataPageRoundFilter = null;
        try {
            dataPageRoundFilter = dataBaseHandler.findDataPageRoundFilter(CustomizedDataCollectionType.REAL_TIME_DATA.name, offSet, limit, datasrc.createDblinkDto().createDbLinkBo(), roundFilterList, "CREATE_TIME");
        } catch (Exception e) {
            //throw new RuntimeException(e);
        }

        return dataPageRoundFilter;
    }

    @Override
    public void markHistoryData(String scenarioId) {
        // taskType 默认使用5 区别于自定以数据（3）
        DatasrcEntity datasrc = datasrcService.getOne(new LambdaQueryWrapper<DatasrcEntity>().eq(DatasrcEntity::getTaskType, 5));

        String s = "update " + CustomizedDataCollectionType.REAL_TIME_DATA.name + " set FLAG = '1' where SCENESCENARIOID='" + scenarioId + "'";
        DbUtils.executeSql(s, datasrc.createDblinkDto().createDbLinkBo());

    }


    /**
     * 构建sendTable
     */
    private void buildSample(List<TableColsDTO> tableCols, String sid, List<String> indicatorsKey, CustomizedDataCollectionType realTimeData) {
        //过滤掉关键指标
        List<String> col = Lists.newArrayList();
        for (TableColsDTO tableCol : tableCols) {
            if (indicatorsKey.contains(tableCol.getColCode())) {
                continue;
            }
            col.add(tableCol.getColCode());
        }
        SchemaAliasEntity schemaAliasEntity = SchemaAliasEntity.builder().alias(realTimeData.name).id(UUIDGenerator.getUUID()).
                sid(sid).dsid(datasrcEntity.getId())
                .sortno(0).build();
        SceneTableEntity sceneTableEntity = SceneTableEntity.builder()
                .id(UUIDGenerator.getUUID())
                .dsid(datasrcEntity.getId())
                .sid(sid)
                .dbName(datasrcEntity.getDatabaseName())
                .tableName(realTimeData.name)
                .aliasId(schemaAliasEntity.getId())
                .describes("")
                .sortno(0)
                .colNames(String.join(",", col))
                .includeTasks(null)
                .indicatorTreeId(null)
                .keyIndicators(String.join(",", indicatorsKey))
                .build();
        // 将模板样本结构添加到任务样本结构
        sceneTableService.save(sceneTableEntity);
        // 添加场景表别名管理
        iSchemaSceneTableAliasService.save(schemaAliasEntity);
    }


    /**
     * 构建新的src实体
     */
    private String buildNewDataSrc(String dbName) {
        // 初始化DataSrc
        String username = dataSourceProperties.getUsername();
        String password = dataSourceProperties.getPassword();
        String url = dataSourceProperties.getUrl();
        Map<String, Object> mark = Maps.newHashMap();
        //根据链接获取URI对象进行数据库url解析
        URI uri = null;
        try {
            uri = new URI(url.replace("jdbc:", ""));
            connectUrl(uri);
//            this.dbName = uri.getPath().replace("/", "");
            this.dbName = dbName;
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
        // 填充默认数据库
        datasrcEntity = DatasrcEntity.builder()
                .name("实时数据源")
                .type(dbType)
                .dbUser(username)
                .pass(password)
                .ip(host)
                .port(port)
                .taskType(5)
                .databaseName(dbName)
                .includeTasks(1)
                .analysisType(1)
                .build();
        datasrcService.save(datasrcEntity);
        //添加目录
        mark.put("dbName", dbName);
        mark.put("dataSrcId", datasrcEntity.getId());
        DataDirectory dataDirectory = new DataDirectory();
        dataDirectory.setName("实时数据源");
        dataDirectory.setParentId("0");
        dataDirectory.setLeafNodeFlag(true);
        dataDirectory.setMark(JSONUtil.toJsonStr(mark));
        iDataDirectoryService.save(dataDirectory);

        return uri.getPath().replace("/", "");
    }

    /**
     * 获取链接地址
     *
     * @param uri 数据库链接地址
     */
    public void connectUrl(URI uri) {
        this.host = uri.getHost();
        this.port = uri.getPort() + "";
        this.dbType = uri.getScheme();
    }

    /**
     * 处理轮次数据
     *
     * @param roundKey     轮次标识
     * @param tableColumns 列名称
     * @param saveData     存储的数据
     */
    private void roundHandler(String tableName, String roundKey, List<String> tableColumns, List<Map<String, Object>> saveData, String dataSrcId, String databaseName) {
        DataSourceExeclParam sourceExeclParam = new DataSourceExeclParam();
        sourceExeclParam.setData(saveData);
        sourceExeclParam.setTableStructure(tableColumns);
        sourceExeclParam.setTableName(tableName);
        sourceExeclParam.setRoundKeys(roundKey);
        sourceExeclParam.setDataSrcId(dataSrcId);
        sourceExeclParam.setDataBasesName(databaseName);
        copyDataFromFileToDB.parsingFileRoundData(sourceExeclParam);
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }
}
