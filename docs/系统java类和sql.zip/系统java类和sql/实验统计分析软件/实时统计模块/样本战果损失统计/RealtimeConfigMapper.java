package com.yw.module.datasource.mapper;

import com.yw.module.datasource.domain.entity.RealtimeConfigEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author zl
 * @since 2025-03-21
 */
@Mapper
public interface RealtimeConfigMapper extends BaseMapper<RealtimeConfigEntity> {

}
