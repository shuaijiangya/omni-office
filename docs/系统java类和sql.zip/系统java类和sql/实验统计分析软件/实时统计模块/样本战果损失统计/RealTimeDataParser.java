package com.yw.module.tcpconnect.parser;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.yw.common.utils.DateUtil;
import com.yw.module.tcpconnect.content.RealTimeDataContent;
import com.yw.module.tcpconnect.TcpDataParser;
import com.zn.utils.DateUtils;
import com.zn.utils.StringUtils;

import java.util.*;

/**
 * @BelongProject ddd
 * @BelongPackage com.yw.module.tcpconnect.parser
 * @Author zl
 * @date 2025/2/24
 * @description 数据解析
 */
public class RealTimeDataParser implements TcpDataParser<List<Map<String, Object>>> {

    @Override
    public List<Map<String, Object>> parseStringList(List<String> datas) throws Exception {
        List<JSONObject> jsonObjectList = new ArrayList<>();
        for (String data : datas) {
            jsonObjectList.add(JSON.parseObject(data));
        }
        //一组数据开始标志(以第一条想定id来判断)
        boolean startFlag = false;

        //想定id
        String scenarioID = null;
        //任务id
        String missionID = "";

        //红蓝方消耗弹药统计
        int blueAmmoNum = 0;
        int redAmmoNum = 0;

        //红蓝方人员死亡统计
        int bluePersonDeathNum = 0;
        int redPersonDeathNum = 0;

        //红蓝方装备战损统计
        int blueEquipmentDeathNum = 0;
        int redEquipmentDeathNum = 0;

        //红蓝方事件
        List<String> redEvent = new ArrayList<>();
        List<String> blueEvent = new ArrayList<>();

        //谁被谁击中 string: 被击中者#击中者
        Set<String> hitMsg = new HashSet<>();

        for (JSONObject map : jsonObjectList) {
            if (map==null){
                continue;
            }
            int msgType = map.getIntValue("msgType");

            //任务状态判断
            if (msgType == 3){
                int taskStatus = map.getIntValue("taskStatus");
                //仿真重新开始
                if (taskStatus==1){
                    init();
                    //丢弃历史数据
                    return null;
                }
            }

            //是否为数据开始标志
            if (27==msgType && StringUtils.isNotEmpty(map.getString("scenarioID"))){
                scenarioID = map.getString("scenarioID");
                missionID = map.getString("missionID");
                startFlag = true;
                RealTimeDataContent.scenarioID = scenarioID;
                continue;
            }

            //得到想定标示，并且数据类型为毁伤事件信息
            if (startFlag && 15 == msgType) {
                int eventType = map.getIntValue("eventType");

                //击中毁伤事件 || 击杀事件
                if (eventType == 1 || eventType == 3){
                    String eventName = "击中";
                    if (eventType==3){
                        eventName = "击杀";
                    }

                    //被命中目标
                    String targetName = map.getString("targetName");
                    //发射方
                    String shooterName = map.getString("shooterName");
                    String shotId = map.getString("shotID");
                    if (!hitMsg.contains(targetName+"#"+shooterName)){
                        //自爆
                        if ("0".equals(shotId)){
                            if (RealTimeDataContent.redObjectNames.contains(targetName)){
                                redEvent.add(targetName+"自爆");
                                redEquipmentDeathNum += 1;
                            }else {
                                blueEvent.add(targetName+"自爆");
                                blueEquipmentDeathNum += 1;
                            }
                        }else {
                            //按照被击中者区分红蓝方事件
                            if (RealTimeDataContent.redObjectNames.contains(targetName)){
                                if (com.yw.framework.common.util.StringUtils.isNotEmpty(shooterName)){
                                    redEvent.add(targetName+"被"+shooterName+eventName);
                                    if ("击杀".equals(eventName)){
                                        //死亡统计(跟生命值为0同时记录互补)
                                        if (!RealTimeDataContent.deathObjectNames.contains(targetName)){
                                            //记录死亡，以及死亡统计过的，之后不再统计
                                            RealTimeDataContent.deathObjectNames.add(targetName);
                                            if (RealTimeDataContent.personObjectNames.contains(targetName)){
                                                redPersonDeathNum += 1;
                                            }else {
                                                redEquipmentDeathNum += 1;
                                            }
                                        }
                                    }
                                }else {
                                    redEvent.add(targetName+"被"+"爆炸波及");
                                }
                            }else {
                                if (com.yw.framework.common.util.StringUtils.isNotEmpty(shooterName)){
                                    blueEvent.add(targetName+"被"+shooterName+eventName);
                                    if ("击杀".equals(eventName)){
                                        //死亡统计(跟生命值为0同时记录互补)
                                        if (!RealTimeDataContent.deathObjectNames.contains(targetName)){
                                            //记录死亡，以及死亡统计过的，之后不再统计
                                            RealTimeDataContent.deathObjectNames.add(targetName);
                                            if (RealTimeDataContent.personObjectNames.contains(targetName)){
                                                bluePersonDeathNum += 1;
                                            }else {
                                                blueEquipmentDeathNum += 1;
                                            }
                                        }
                                    }
                                }else {
                                    blueEvent.add(targetName+"被"+"爆炸波及");
                                }
                            }
                        }
                        hitMsg.add(targetName+"#"+shooterName);
                    }
                }
            }

            //得到想定标示，并且数据类型为实体信息
            if (startFlag && 31 == msgType){
                //JSONObject objectInfo = map.getJSONObject("objectInfo");
                String objectName = map.getString("objectName");
                //生命值，小于等于0代表死亡
                double lifeValue = map.getDoubleValue("lifeValue");
                //实体阵营 0红方 1蓝方
                int objectCamp = map.getIntValue("objectCamp");
                //实体类型 小于100为人员
                int objectType = map.getIntValue("objectType");

                //所有红方单位统计
                if (!RealTimeDataContent.redObjectNames.contains(objectName) && objectCamp == 0){
                    RealTimeDataContent.redObjectNames.add(objectName);
                }

                //所有人员单位统计,类型小于100代表人员
                if (!RealTimeDataContent.personObjectNames.contains(objectName) && objectType < 100){
                    RealTimeDataContent.personObjectNames.add(objectName);
                }

                //死亡统计（生命值小于等于0）
                if (!RealTimeDataContent.deathObjectNames.contains(objectName) && Double.compare(0, lifeValue)>=0){
                    JSONObject objectPosition = map.getJSONObject("objectPosition");
                    //经度
                    double lon = objectPosition.getDoubleValue("lon");
                    //纬度
                    double lat = objectPosition.getDoubleValue("lat");
                    //海拔高度
                    double altitude = objectPosition.getDoubleValue("altitude");
                    //记录死亡，以及死亡统计过的，之后不再统计
                    RealTimeDataContent.deathObjectNames.add(objectName);
                    if (objectCamp == 0){
                        //类型小于100代表人员
                        if (objectType < 100){
                            redPersonDeathNum += 1;
                            redEvent.add(objectName+"在经度:"+lon+"纬度:"+lat+"海拔高度:"+altitude+"死亡");
                        }else {
                            redEquipmentDeathNum += 1;
                            redEvent.add(objectName+"在经度:"+lon+"纬度:"+lat+"海拔高度:"+altitude+"战损");
                        }
                    }else {
                        if (objectType < 100){
                            bluePersonDeathNum += 1;
                            blueEvent.add(objectName+"在经度:"+lon+"纬度:"+lat+"海拔高度:"+altitude+"死亡");
                        }else {
                            blueEquipmentDeathNum += 1;
                            blueEvent.add(objectName+"在经度:"+lon+"纬度:"+lat+"海拔高度:"+altitude+"战损");
                        }
                    }
                    //System.out.println("人员出现伤亡----------------阵营"+objectCamp+"objectName："+map.get("objectName"));
                }

                //弹药信息
                String ammoInfo = map.getString("ammoInfo");

                if (StringUtils.isNotEmpty(ammoInfo)){
                    JSONArray ammoInfoArray = null;
                    try {
                        ammoInfoArray = JSON.parseArray(ammoInfo);
                        //当前实体装载弹药剩余统计
                        int objectAmmoNum = 0;
                        if (ammoInfoArray!=null){
                            for (int i = 0; i < ammoInfoArray.size(); i++) {
                                JSONObject jsonObject = ammoInfoArray.getJSONObject(i);
                                //弹药数量
                                int ammoNum = jsonObject.getIntValue("ammoNum");
                                objectAmmoNum+=ammoNum;
                            }
                            if (objectCamp == 0){
                                if (RealTimeDataContent.redEntityAmmoTotalNum.containsKey(objectName)){
                                    if (RealTimeDataContent.redEntityAmmoTotalNum.get(objectName) > objectAmmoNum){
                                        redAmmoNum += RealTimeDataContent.redEntityAmmoTotalNum.get(objectName) - objectAmmoNum;
                                        if (redAmmoNum>1000){
                                            System.out.println();
                                        }
                                    }
                                    RealTimeDataContent.redEntityAmmoTotalNum.put(objectName, objectAmmoNum);
                                }else {
                                    RealTimeDataContent.redEntityAmmoTotalNum.put(objectName, objectAmmoNum);
                                }
                            }else {
                                if (RealTimeDataContent.blueEntityAmmoTotalNum.containsKey(objectName)){
                                    if (RealTimeDataContent.blueEntityAmmoTotalNum.get(objectName) > objectAmmoNum){
                                        blueAmmoNum += RealTimeDataContent.blueEntityAmmoTotalNum.get(objectName) - objectAmmoNum;
                                    }
                                    RealTimeDataContent.blueEntityAmmoTotalNum.put(objectName, objectAmmoNum);
                                }else {
                                    RealTimeDataContent.blueEntityAmmoTotalNum.put(objectName, objectAmmoNum);
                                }
                            }
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }
            }
        }

        if (redAmmoNum>1000){
            System.out.println();
        }

        Map<String, Object> data = new HashMap<>();
        if (scenarioID==null){
            return null;
        }
        Date date = new Date();
        String s = DateUtil.dateToString(date, DateUtil.DATE_FULL_STR);
        data.put("SCENESCENARIOID", scenarioID);
        data.put("FZID", RealTimeDataContent.fzid.incrementAndGet());
        data.put("START_TIME", s);
        data.put("missionID", missionID);
        data.put("弹药消耗量RED", redAmmoNum);
        data.put("弹药消耗量BLUE", blueAmmoNum);
        data.put("人员伤亡RED", redPersonDeathNum);
        data.put("人员伤亡BLUE", bluePersonDeathNum);
        data.put("装备战损RED", redEquipmentDeathNum);
        data.put("装备战损BLUE", blueEquipmentDeathNum);
        //data.put("兵力交换比BLUE", blueEquipmentDeathNum);
        if ((bluePersonDeathNum+blueEquipmentDeathNum)==0){
            data.put("兵力交换比RED", 0);
        }else {
            data.put("兵力交换比RED", 1.0*(redPersonDeathNum+redEquipmentDeathNum)/(bluePersonDeathNum+blueEquipmentDeathNum));
        }
        if ((redPersonDeathNum+redEquipmentDeathNum)==0){
            data.put("兵力交换比BLUE", 0);
        }else {
            data.put("兵力交换比BLUE", 1.0*(bluePersonDeathNum+blueEquipmentDeathNum)/(redPersonDeathNum+redEquipmentDeathNum));
        }

        if (redAmmoNum>0){
            redEvent.add("弹药消耗了"+redAmmoNum);
        }
        if (blueAmmoNum>0){
            blueEvent.add("弹药消耗了"+blueAmmoNum);
        }
        Map<String, Object> event = new HashMap<>();
        event.put("time", s);
        event.put("blueEvent", blueEvent);
        event.put("redEvent", redEvent);
        data.put("EVENT", JSON.toJSONString(event));

        return Collections.singletonList(data);
    }

    private void init() {
        RealTimeDataContent.redEntityAmmoTotalNum.clear();
        RealTimeDataContent.blueEntityAmmoTotalNum.clear();
        RealTimeDataContent.deathObjectNames = new ArrayList<>();
        RealTimeDataContent.num = 0;
    }

    public static void main(String[] args) throws Exception {
        String t = "2025-04-25 08:30:00";

        String t2 = "2027-09-15 08:30:00";

        System.out.println(DateUtils.getTime(t) + "====" + DateUtils.getTime(t2) + "====" + (DateUtils.getTime(t2) - DateUtils.getTime(t)));
    }
}
