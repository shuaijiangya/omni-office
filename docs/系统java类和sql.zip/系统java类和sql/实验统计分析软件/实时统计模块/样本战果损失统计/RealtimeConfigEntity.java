package com.yw.module.datasource.domain.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.time.LocalDateTime;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * 实时评估图表配置
 * @author zl
 * @since 2025-03-21
 */
@Getter
@Setter
@TableName("wa_jue_realtime_config")
@ApiModel(value = "RealtimeConfig对象", description = "")
public class RealtimeConfigEntity {

    @TableId(value = "ID", type = IdType.ASSIGN_ID)
    private String id;

    @TableField("CHART_TYPE")
    private String chartType;

    @TableField("BLUE_INDICATOR")
    private String blueIndicator;

    @TableField("RED_INDICATOR")
    private String redIndicator;

    @TableField("SID")
    private String  sid;

    @ApiModelProperty("创建时间")
    @TableField(value = "CREATE_TIME", fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @ApiModelProperty("更新时间")
    @TableField(value = "UPDATE_TIME", fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;


}
