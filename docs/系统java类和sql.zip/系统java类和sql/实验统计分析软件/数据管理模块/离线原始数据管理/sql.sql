CREATE TABLE `cd_data_directory` (
  `ID` varchar(255) COLLATE utf8_bin NOT NULL,
  `NAME` varchar(255) COLLATE utf8_bin DEFAULT NULL COMMENT '目录名称',
  `PARENT_ID` varchar(255) COLLATE utf8_bin DEFAULT NULL COMMENT '父目录id',
  `LEAF_NODE_FLAG` tinyint(4) DEFAULT NULL COMMENT '叶子节点标识',
  `MARK` varchar(512) COLLATE utf8_bin DEFAULT NULL COMMENT '扩展',
  `MARK_TYPE` int(11) DEFAULT NULL COMMENT '扩展类型',
  `BUSINESS_KEY` varchar(128) COLLATE utf8_bin DEFAULT NULL COMMENT '业务标识',
  `DIRECTORY_TYPE` varchar(255) COLLATE utf8_bin DEFAULT NULL COMMENT '目录数据类型，用于标识当前目录节点存储的是什么类型的数据，例如当前节点存储的word数据，标识为word；当前节点存储的是视频数据，标识为video',
  `USER_ID` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '用户ID',
  `ROUTING_PATH` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '路由地址',
  `COMPONENT` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `SORT` int(11) DEFAULT NULL COMMENT '排序字段',
  `CREATE_TIME` timestamp NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp NULL DEFAULT NULL,
  `OPERATION_FLAG` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '是否可操作标识 1可以 0不可以',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=DYNAMIC;

CREATE TABLE `cd_datasrc` (
  `ID` char(32) COLLATE utf8_bin NOT NULL,
  `NAME` varchar(108) COLLATE utf8_bin DEFAULT NULL COMMENT '数据源名称',
  `TYPE` varchar(108) COLLATE utf8_bin DEFAULT NULL COMMENT '数据源类型',
  `DB_USER` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '账号',
  `PASS` varchar(192) COLLATE utf8_bin DEFAULT NULL COMMENT '密码',
  `IP` varchar(765) COLLATE utf8_bin DEFAULT NULL COMMENT 'ip地址',
  `DBNAME` varchar(108) COLLATE utf8_bin DEFAULT NULL COMMENT '数据库名称',
  `CREATE_TIME` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  `CREATOR` varchar(108) COLLATE utf8_bin DEFAULT NULL COMMENT '创建者',
  `FILE_NAME` varchar(765) COLLATE utf8_bin DEFAULT NULL COMMENT '附件名称',
  `PORT` varchar(60) COLLATE utf8_bin DEFAULT NULL COMMENT '端口',
  `TASK_TYPE` int(11) DEFAULT NULL COMMENT '任务类型',
  `TASK_NAME` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '任务表名称',
  `DATABASE_NAME` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '数据库名称',
  `INCLUDE_TASKS` tinyint(4) DEFAULT NULL COMMENT '是否关联任务数据库 1关联任务数据表 2无任务数据表',
  `ANALYSIS_TYPE` tinyint(4) DEFAULT NULL COMMENT '解析类型 1从数据库导入 2从文件导入',
  `ANALYSIS_ID` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '远程数据源id',
  `UPDATE_TIME` timestamp(6) NULL DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=DYNAMIC;

CREATE TABLE `cd_round_record` (
  `ID` varchar(50) COLLATE utf8_bin NOT NULL COMMENT '采集轮次id',
  `NAME` varchar(512) COLLATE utf8_bin DEFAULT NULL COMMENT '轮次名称',
  `TASK_ID` varchar(512) COLLATE utf8_bin DEFAULT NULL COMMENT '轮次id',
  `CREATE_TIME` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  `TABLE_NAMES` text COLLATE utf8_bin COMMENT '表名称集合',
  `DATA_SRC_ID` varchar(255) COLLATE utf8_bin DEFAULT NULL COMMENT '数据源id',
  `DIRECTORY_NAME` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `ROUND_FIELD` varchar(255) COLLATE utf8_bin DEFAULT NULL COMMENT '轮次字段',
  `PARAM` varchar(128) COLLATE utf8_bin DEFAULT NULL COMMENT '轮次参数',
  `UPDATE_TIME` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=DYNAMIC COMMENT='采集轮次记录表';

CREATE TABLE `cd_import_table_record` (
  `ID` varchar(255) COLLATE utf8_bin NOT NULL,
  `FROM_ID` varchar(255) COLLATE utf8_bin DEFAULT NULL COMMENT '"来源id（数据库、接口、文件存储时返回的id）',
  `FROM_TYPE` int(11) DEFAULT NULL COMMENT '来源类型（未知:UNKNOWN,DATABASE:1,API:2,FILE:3）',
  `TABLE_NAME` varchar(255) COLLATE utf8_bin DEFAULT NULL COMMENT '数据导入时建表的表名',
  `CREATE_TIME` timestamp NULL DEFAULT NULL COMMENT '记录时间',
  `DIRECTORY_ID` varchar(255) COLLATE utf8_bin DEFAULT NULL COMMENT '所属目录id',
  `TABLE_NAME_ALIAS` varchar(255) COLLATE utf8_bin DEFAULT NULL COMMENT '表别名',
  `UPDATE_TIME` timestamp NULL DEFAULT NULL,
  `OPERATION_FLAG` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '是否可操作标识 1可以 0不可以',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=DYNAMIC;

CREATE TABLE `cd_table_chname` (
  `ID` varchar(50) COLLATE utf8_bin NOT NULL,
  `TABLE_NAME` varchar(255) COLLATE utf8_bin DEFAULT NULL COMMENT '表名称',
  `CH_NAME` varchar(255) COLLATE utf8_bin DEFAULT NULL COMMENT '中文名称',
  `CREATE_TIME` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  `TASK_TYPE` int(11) DEFAULT NULL COMMENT '任务类型',
  `FIELD_NAME` varchar(255) COLLATE utf8_bin DEFAULT NULL COMMENT '字段英文名',
  `FLAG` int(11) DEFAULT NULL COMMENT '类型 1为表, 2为字段',
  `DATA_SRC_ID` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '数据源id',
  `UPDATE_TIME` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=DYNAMIC;