package com.yw.source.datagather.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.yw.framework.backMgr.dbTableGenerator.domain.dto.DbLinkDTO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;
import lombok.extern.slf4j.Slf4j;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**
 * @Author: 刘乐法
 * @Description: 数据源
 * @Date: 2020/11/17 11:01
 */
@Getter
@Setter
@ToString
@Entity
@Table(name = "yw_toses_datasrc")
@TableName("yw_toses_datasrc")
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ApiModel(value = "数据源实体")
@Slf4j
public class DatasrcEntity {

    @Id
//    @GeneratedValue(generator = "uuidGenerator")
//    @GenericGenerator(name = "uuidGenerator", strategy = "uuid") // UUID生成策略
    @Column(name = "id")
    private String id;

    /**
     * 名称
     **/
    @ApiModelProperty(value = "名称", name = "name")
    @Column(name = "name")
    private String name;

    /**
     * 数据源类型
     **/
    @ApiModelProperty(value = "数据源类型", name = "type")
    @Column(name = "type")
    private String type;

    /**
     * 用户名
     **/
    @ApiModelProperty(value = "用户名", name = "dbUser")
    @Column(name = "DB_USER")
    private String dbUser;

    /**
     * 密码
     **/
    @ApiModelProperty(value = "密码", name = "pass")
    @Column(name = "pass")
    private String pass;

    /**
     * 地址
     **/
    @ApiModelProperty(value = "地址", name = "ip")
    @Column(name = "ip")
    private String ip;

    /**
     * 创建时间
     **/
    @ApiModelProperty(value = "创建时间", name = "createDate")
    @Column(name = "create_date")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createDate;

    /**
     * 创建人
     **/
    @ApiModelProperty(value = "创建人", name = "creator")
    @Column(name = "creator")
    private String creator;

    /**
     * 附件地址
     **/
    @ApiModelProperty(value = "附件名称", name = "fileName")
    @Column(name = "file_name")
    private String fileName;

    /**
     * 附件地址
     **/
    @ApiModelProperty(value = "端口", name = "port")
    @Column(name = "port")
    private String port;

    @ApiModelProperty("任务类型")
    @Column(name = "TASK_TYPE")
    private Integer taskType;

    @ApiModelProperty("任务表名称")
    @Column(name = "TASK_NAME")
    private String taskName;

    @ApiModelProperty("数据库名称")
    @Column(name = "DATABASE_NAME")
    private String databaseName;

    @ApiModelProperty("是否关联任务数据库 1关联任务数据表 2无任务数据表")
    @Column(name = "INCLUDE_TASKS")
    private Integer includeTasks;

    @ApiModelProperty("解析类型 1从数据库导入 2从文件导入")
    @Column(name = "ANALYSIS_TYPE")
    private Integer analysisType;

    @ApiModelProperty("远程数据源id")
    @Column(name = "ANALYSIS_ID")
    private String analysisId;
    /**
     * 创建时间
     **/
    @ApiModelProperty(value = "修改时间", name = "updateDate")
    @Column(name = "update_date")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date updateDate;


    public DbLinkDTO createDblinkDto() {
        DbLinkDTO dbLinkDto = new DbLinkDTO();
        dbLinkDto.setIp(ip);
        dbLinkDto.setPass(pass);
        dbLinkDto.setIp(ip);
        dbLinkDto.setType(type);
        dbLinkDto.setPort(port);
        dbLinkDto.setUser(dbUser);
        dbLinkDto.setTaskType(taskType);
        dbLinkDto.setDbName(databaseName);
        return dbLinkDto;
    }
}
