package com.yw.source.datagather.localInfo.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.IdUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.support.ExcelTypeEnum;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.common.io.ByteStreams;
import com.mongodb.MongoClientSettings;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.mongodb.client.*;
import com.mongodb.connection.ClusterConnectionMode;
import com.mongodb.connection.ClusterType;
import com.yw.domain.dto.dataSource.*;
import com.yw.domain.entity.dataSource.*;
import com.yw.domain.entity.script.DataConvertScriptEntity;
import com.yw.domain.response.dataSource.AnalysisTableResponse;
import com.yw.domain.response.dataSource.DataSourceMainResponse;
import com.yw.domain.response.dataSource.DataSourceMainV2Response;
import com.yw.domain.vo.TaskInfoVO;
import com.yw.domain.vo.dataSource.TableClassifyListVO;
import com.yw.domain.vo.dataSource.TableManagerListVO;
import com.yw.exception.BusinessException;
import com.yw.framework.backMgr.dbTableGenerator.domain.bo.DbLinkBO;
import com.yw.framework.backMgr.dbTableGenerator.domain.dto.ExerciseInfoDTO;
import com.yw.framework.backMgr.dbTableGenerator.domain.dto.TableColsDTO;
import com.yw.framework.backMgr.dbTableGenerator.domain.vo.DbTableVO;
import com.yw.framework.backMgr.dbTableGenerator.service.impl.DataBaseHandler;
import com.yw.framework.backMgr.dbTableGenerator.service.impl.DmOperationServiceImpl;
import com.yw.framework.backMgr.dbTableGenerator.service.impl.MysqlOperationServiceImpl;
import com.yw.framework.defines.response.PageInfo;
import com.yw.source.common.constant.WebSocketConstant;
import com.yw.source.common.enums.DataAnalysisType;
import com.yw.source.common.enums.DataTableType;
import com.yw.source.datagather.entity.DatasrcEntity;
import com.yw.source.datagather.localInfo.service.DataSrcManagerService;
import com.yw.source.datagather.localInfo.service.TableClassifyService;
import com.yw.source.datagather.localInfo.service.TableManagerService;
import com.yw.source.datagather.mapper.DataConvertScriptMapper;
import com.yw.source.datagather.mapper.DataSrcManagerMapper;
import com.yw.source.datagather.mapper.DataTableClassifyMapper;
import com.yw.source.datagather.mapper.DataTableManagerMapper;
import com.yw.source.datagather.repository.ConvertColumnRepository;
import com.yw.source.datagather.repository.DataSrcManagerRepository;
import com.yw.source.datagather.repository.DataTableChNameRepository;
import com.yw.source.datagather.repository.IDatasrcRepository;
import com.yw.source.datagather.req.ExerciseInfoReq;
import com.yw.source.datagather.resp.DataSourceRoundDirectoryResp;
import com.yw.source.datagather.vo.AnalysisDateVO;
import com.yw.source.datagather.vo.TableInfoVO;
import com.yw.source.gatherSchedule.domain.entity.GatherRoundRecord;
import com.yw.source.gatherSchedule.service.IGatherRoundRecordService;
import com.yw.source.importDataDirectory.service.IDataDirectoryService;
import com.yw.source.utils.XmlJsonConvertUtil;
import com.yw.type.DataBaseType;
import com.yw.type.DataSourceRunType;
import com.yw.utils.*;
import com.zn.async.manager.ExecutorManager;
import com.zn.async.task.AsyncTask;
import com.zn.stomp.message.StompMessagePusher;
import dm.jdbc.driver.DmdbNClob;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ResourceUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;
import java.util.stream.Collectors;

/**
 * 数据源管理服务
 */
@Service
public class DataSrcManagerServiceImpl extends ServiceImpl<DataSrcManagerMapper, DataAnalysisEntity> implements DataSrcManagerService {


    protected final static Logger LOG = LoggerFactory.getLogger(DataSrcManagerServiceImpl.class);

    /**
     * 数据处理器
     */
    private final DataBaseHandler dataBaseHandler;
    /**
     * 中文名称
     */
    private final DataTableChNameRepository dataTableChNameRepository;
    /**
     * 数据管理对象
     */
    private final DataSrcManagerRepository dataSrcManagerRepository;
    /**
     * 转换规则
     */
    private final ConvertColumnRepository convertColumnRepository;
    /**
     * 本地源
     */
    private final IDatasrcRepository iDatasrcRepository;

    /**
     * 转换规则
     */
    @Autowired
    private DataConvertScriptMapper dataConvertScriptMapper;

    /**
     * 文件路径
     */
    @Value("${pythonFile.path}")
    private String pythonCovertLibUrl;

    /**
     * 轮次数据
     */
    @Autowired
    private IGatherRoundRecordService iGatherRoundRecordService;

    /**
     * 达梦数据服务
     */
    @Autowired
    private DmOperationServiceImpl dmOperationService;

    /**
     * 表分类
     */
    @Autowired
    private TableClassifyService tableClassifyService;

    /**
     * 表管理
     */
    @Autowired
    private TableManagerService tableManagerService;

    /**
     * 表分类持久层
     */
    @Autowired
    private DataTableClassifyMapper dataTableClassifyMapper;

    /**
     * 表管理持久层
     */
    @Autowired
    private DataTableManagerMapper dataTableManagerMapper;

    /**
     * 异步线程管理
     */
    @Autowired
    private ExecutorManager executorManager;

    /**
     * 数据目录服务
     */
    @Resource
    private IDataDirectoryService dataDirectoryService;

    /**
     * 采集轮次管理
     */
    @Autowired
    private IGatherRoundRecordService gatherRoundRecordService;

    /**
     * 解析的表
     */
    public static Set<String> PARSED_TABLE = Sets.newConcurrentHashSet();

    /**
     * 转换脚本使用参数
     */
    public int countSize;
    public int overSize;
    public boolean cancelConvert = false;
    /**
     * 数据转换规则使用锁
     */
    private final ReentrantLock lock = new ReentrantLock();

    public DataSrcManagerServiceImpl(DataBaseHandler dataBaseHandler, DataTableChNameRepository dataTableAliasRepository,
                                     ConvertColumnRepository convertColumnRepository, DataSrcManagerRepository dataSrcManagerRepository,
                                     IDatasrcRepository iDatasrcRepository) {
        this.dataBaseHandler = dataBaseHandler;
        this.dataTableChNameRepository = dataTableAliasRepository;
        this.dataSrcManagerRepository = dataSrcManagerRepository;
        this.convertColumnRepository = convertColumnRepository;
        this.iDatasrcRepository = iDatasrcRepository;
    }

    /**
     * 获取已经解析完成的表名称以及正在解析的表名称
     *
     * @return com.yw.source.datagather.vo.AnalysisDateVO
     * @Date 2021/12/20
     * @Param [dataSrcId]
     **/
    @Override
    public AnalysisDateVO showAnalysisTable(String dataSrcId, String classifyId, String tableName) {
        //获取当前类型的数据源
        Optional<DatasrcEntity> repositoryOne = iDatasrcRepository.findById(dataSrcId);
        if (!repositoryOne.isPresent()) {
            return new AnalysisDateVO();
        }
        DatasrcEntity entity = repositoryOne.get();

        List<TableChNameEntity> tableChNameLists = dataTableChNameRepository.findByDataSrcIdAndFlag(entity.getId(), 1);
        // key tablename value chname
        Map<String, String> tableChNameMaps = Maps.newHashMap();
        for (TableChNameEntity chname : tableChNameLists) {
            tableChNameMaps.put(chname.getTableName(), chname.getChName());
        }
        //任务表
        String taskName = entity.getTaskName();
        if (StringUtils.isEmpty(taskName)) {
            taskName = "";
        }
        //获取当前分类表信息
        List<TableManagerListVO> tableManagerListVOS = tableManagerService.showCollect(classifyId, tableName);
        //正在解析的表
        //去重复
        Map<String, TableManagerListVO> tableManagerMap = Maps.newHashMap();
        tableManagerListVOS.stream().forEach(dbName -> {
            String name = dbName.getTableName();
            tableManagerMap.put(name, dbName);
        });
        List<DbTableVO> vos = Lists.newArrayList();
        DbTableVO taskTable = null;
        for (Map.Entry<String, TableManagerListVO> tableMap : tableManagerMap.entrySet()) {
            String localTableName = tableMap.getKey();
            if (taskName.equals(localTableName)) {
                taskTable = DbTableVO.valueOf(localTableName, tableChNameMaps.get(localTableName), tableMap.getValue().getId());
                continue;
            }
            vos.add(DbTableVO.valueOf(localTableName, tableChNameMaps.get(localTableName), tableMap.getValue().getId()));
        }
        int resultFlag = DataSourceRunType.END.getId();

        //todo  判断是否存在正在解析/解析完成/

        //构造返回信息
        return AnalysisDateVO.valueOf(dataSrcId, "", taskTable, vos, resultFlag, "");
    }


    /**
     * 导出模板下载:txt,xml,excel三种类型
     *
     * @param fileType 文件类型
     */
    @Override
    public void downLoadFileModule(String fileType, HttpServletResponse response, HttpServletRequest request) {
        if (StringUtils.isEmpty(fileType)) {
            return;
        }
        switch (fileType) {
            case "txt":
                downLoadFileTXTModule(response, request);
                break;
            case "xml":
                downLoadFileXMLModule(response, request);
                break;
            case "excel":
                downLoadFileExcelModule(response);
                break;
            default:
                throw new BusinessException("暂未提供: " + fileType + "文件模板");
        }
    }

    /**
     * 查询远程源信息
     */
    @Override
    public DataAnalysisEntity selectById(String analysisId) {
        Optional<DataAnalysisEntity> dataAnalysisEntityOptional = dataSrcManagerRepository.findById(analysisId);
        return dataAnalysisEntityOptional.get();
    }

    /**
     * 获取正在解析的表
     */
    @Override
    public AnalysisTableResponse selectAnalysisTable() {
        return AnalysisTableResponse.valueOf(PARSED_TABLE, null, true);
    }

    /**
     * 有任务关联和无任务关联下所有的表
     *
     * @param dsid         数据源ID
     * @param includeTasks 是否包含任务
     */
    @Override                                        //数据源id       是否关联任务表标志
    public List<TableManagerListVO> selectIncludeTasksAllTables(String dsid, int includeTasks) {
        Optional<DatasrcEntity> datasrcEntity = iDatasrcRepository.findById(dsid);
        DatasrcEntity entity = datasrcEntity.get();
        List<TableManagerListVO> result = Lists.newArrayList();
        List<DataTableClassifyEntity> list;
        List<DataTableManagerEntity> tableManagers = Lists.newArrayList();
        //获取当前数据源下所有的表
        list = dataTableClassifyMapper.findByDataSrcId(dsid);
        if (DataTableType.getType(includeTasks) != DataTableType.NONE) {
            list = list.stream().filter(s -> s.getIncludeTasks() == includeTasks).collect(Collectors.toList());
            list.forEach(c -> tableManagers.addAll(dataTableManagerMapper.findByTableClassifyId(c.getId())));

        } else if (DataTableType.getType(includeTasks) == DataTableType.NONE) {
            list.forEach(c -> tableManagers.addAll(dataTableManagerMapper.findByTableClassifyId(c.getId())));
        }
        String taskName = entity.getTaskName();
        tableManagers.forEach(table -> {
            String tableName = table.getTableName();
            if (!StringUtils.isEmpty(taskName) && !tableName.equals(taskName)) {
                result.add(TableManagerListVO.valueOf(table.getId(), tableName, table.getTableClassifyId(), table.getChName()));
            }
        });
        return result;
    }

    /**
     * 设置数据源分类map
     *
     * @param paramList         数据源分类
     * @param includeTasks      是否包含任务分类
     * @param tableClassifyMaps 数据源分类map
     */
    private void setTableClassifyMap(List<TableClassifyListVO> paramList, int includeTasks,
                                     Map<String, Map<Integer, DataSourceMainResponse>> tableClassifyMaps) {
        for (TableClassifyListVO vo : paramList) {
            int classifyIncludeTasks = vo.getIncludeTasks();
            Map<Integer, DataSourceMainResponse> classifyListVos = tableClassifyMaps.get(vo.getDataSrcId());

            if (CollUtil.isEmpty(classifyListVos)) {
                classifyListVos = Maps.newHashMap();
                // 构造有无关联任务数据表信息
                if (DataTableType.getType(includeTasks) == DataTableType.NONE) {
                    classifyListVos.put(DataTableType.INCLUDE_TASK_DATA_SHEET.id, DataSourceMainResponse.valueOf(DataTableType.INCLUDE_TASK_DATA_SHEET.id + "", "有关联任务的数据表"));
                    classifyListVos.put(DataTableType.TASK_DATA_TABLE_NOT_INCLUDED.id, DataSourceMainResponse.valueOf(DataTableType.TASK_DATA_TABLE_NOT_INCLUDED.id + "", "无关联任务的数据表"));
                } else if (DataTableType.getType(includeTasks) == DataTableType.TASK_DATA_TABLE_NOT_INCLUDED) {
                    classifyListVos.put(DataTableType.TASK_DATA_TABLE_NOT_INCLUDED.id, DataSourceMainResponse.valueOf(DataTableType.TASK_DATA_TABLE_NOT_INCLUDED.id + "", "无关联任务的数据表"));
                } else {
                    classifyListVos.put(DataTableType.INCLUDE_TASK_DATA_SHEET.id, DataSourceMainResponse.valueOf(DataTableType.INCLUDE_TASK_DATA_SHEET.id + "", "有关联任务的数据表"));
                }
                tableClassifyMaps.put(vo.getDataSrcId(), classifyListVos);
            }
            DataSourceMainResponse sourceMainResponse = classifyListVos.get(classifyIncludeTasks);
            if (sourceMainResponse == null) {
                continue;
            }
            if (CollUtil.isEmpty(sourceMainResponse.childes)) {
                sourceMainResponse.childes = Lists.newArrayList();
            }
            sourceMainResponse.childes.add(DataSourceMainResponse.valueOf(vo.getId(), vo.getClassifyName()));
        }
    }

    /**
     * 删除指定表
     */
    @Transactional
    @Override
    public void deleteTable(DeleteTableDTO dto) {
        String dataSrcId = dto.getDataSrcId();
        List<String> tables = dto.getTables();

        Optional<DatasrcEntity> repositoryOne = iDatasrcRepository.findById(dataSrcId);
        DatasrcEntity entity = repositoryOne.get();
        DbLinkBO dbLinkBO = entity.createDblinkDto().createDbLinkBo();
        dataBaseHandler.deleteTable(tables, dbLinkBO);
        delSourceColumn(tables);
        tableManagerService.deleteByTableNames(tables, dataSrcId);
        for (String table : tables) {
            dataTableChNameRepository.deleteByTableNameAndDataSrcId(table, dataSrcId);
        }
    }

    /**
     * 数据源解析-主界面显示
     *
     * @param includeTasks 是否包含任务
     * @return
     */
    @Override
    public List<DataSourceMainV2Response> mainDisplayV2(int includeTasks) {
        List<DataSourceMainV2Response> responses = Lists.newArrayList();
        if (DataTableType.getType(includeTasks) == DataTableType.NONE) {
            return responses;
        }
        List<DatasrcEntity> iDatasrcRepositoryAll = iDatasrcRepository.findByIncludeTasksOrderByTaskTypeAscCreateDateDesc(includeTasks);
        for (DatasrcEntity datasrcEntity : iDatasrcRepositoryAll) {
            if (datasrcEntity.getTaskType() == DataAnalysisType.CUSTOM_DATA.getId()) {
                continue;
            }
            responses.add(DataSourceMainV2Response.valueOf(datasrcEntity.getId(), datasrcEntity.getName(),
                    datasrcEntity.getAnalysisType(), datasrcEntity.getAnalysisId(), datasrcEntity.getCreateDate(),
                    datasrcEntity.getUpdateDate(), datasrcEntity.getDatabaseName()));
        }
        return responses;
    }

    /**
     * 数据源解析-主界面显示
     *
     * @param includeTasks 是否包含任务
     */
    @Override
    public List<DataSourceMainResponse> mainDisplay(int includeTasks) {
        List<DataSourceMainResponse> result = Lists.newArrayList();

        List<DatasrcEntity> iDatasrcRepositoryAll = iDatasrcRepository.findAll();

        List<TableClassifyListVO> list = tableClassifyService.showCollect(null);

        // key datasrcId value:<有无关联任务标志,数据源分类信息>>
        Map<String, Map<Integer, DataSourceMainResponse>> tableClassifyMaps = Maps.newHashMap();

        //设置有无关联数据表
        setTableClassifyMap(list, includeTasks, tableClassifyMaps);

        for (DatasrcEntity entity : iDatasrcRepositoryAll) {
            if (entity.getTaskType() == DataAnalysisType.CUSTOM_DATA.getId()) {
                continue;
            }
            Map<Integer, DataSourceMainResponse> sourceMainResponseMap = tableClassifyMaps.get(entity.getId());
            List<DataSourceMainResponse> childes = Lists.newArrayList();
            if (CollUtil.isNotEmpty(sourceMainResponseMap)) {
                childes.addAll(sourceMainResponseMap.values());
            }
            result.add(DataSourceMainResponse.valueOf(entity.getId(), entity.getName(), childes));
        }
        return result;
    }

    /**
     * 下载txt文件模型
     */
    private void downLoadFileTXTModule(HttpServletResponse response, HttpServletRequest request) {
        JSONArray jsonArray = new JSONArray();
        List<Map<String, Object>> dataList = Lists.newArrayList();
        for (int i = 0; i < 3; i++) {
            Map<String, Object> resultMap = Maps.newLinkedHashMap();
            resultMap.put("TASK_ID", i);
            resultMap.put("ID", i);
            resultMap.put("tableField3", "[[30157,30092,30156,30091,30164,30165,31120,31112,31119,31111,30189,30190,36113],[30157,30092,30156,30091,30164,30165,31120,31112,31119,31111,30189,30190,36113]]");
            resultMap.put("tableField4", "[[30157,30092,30156,30091,30164,30165,31120,31112,31119,31111,30189,30190,36113],[30157,30092,30156,30091,30164,30165,31120,31112,31119,31111,30189,30190,36113]]");
            dataList.add(resultMap);
        }
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("tableName", "FZ_88");
        jsonObject.put("data", dataList);
        jsonArray.add(jsonObject);
        JsonFileUtil.createJsonFile(request, response, JSON.toJSONString(jsonArray), "TXTFileModule", ".txt");
    }

    /**
     * 下载xml文件模型
     */
    private void downLoadFileXMLModule(HttpServletResponse response, HttpServletRequest request) {
        try {
            List<ExportXmlDTO> list = Lists.newArrayList();
            ExportXmlDTO exportXmlDTO = new ExportXmlDTO();
            List<Map<String, Object>> dataList = Lists.newArrayList();
            for (int i = 1; i <= 3; i++) {
                Map<String, Object> resultMap = Maps.newLinkedHashMap();
                resultMap.put("ID", i);
                resultMap.put("NAME", i);
                resultMap.put("AGE", i);
                dataList.add(resultMap);
            }
            exportXmlDTO.setTableName("TABLE");
            exportXmlDTO.setData(dataList);
            list.add(exportXmlDTO);
            XmlJsonConvertUtil.exportXmlToFile(request, response, "XMLFileModule", XmlJsonConvertUtil.listToXml(list));
            LOG.info("成功导出XML文件格式数据");
        } catch (IOException e) {
            throw new BusinessException("导出xml异常！");
        }
    }

    /**
     * 下载excel文件模型
     */
    private void downLoadFileExcelModule(HttpServletResponse response) {
        ExcelWriter excelWriter = null;
        try {
            excelWriter = new ExcelWriter(getOutputStream("excelFileModule", response), ExcelTypeEnum.XLSX);
            String tableName = "FZ_88";
            List<List<String>> tableHeaders = new ArrayList<>();
            List<List<Object>> tableData = new ArrayList<>();
            for (int i = 0; i < 3; i++) {
                List<String> keys = new ArrayList<>();
                if (i == 0) {
                    keys.add("ID");
                } else if (i == 1) {
                    keys.add("TASK_ID");
                } else {
                    keys.add("VA" + i);
                }
                tableHeaders.add(keys);
            }

            for (int i = 1; i <= 10; i++) {
                List<Object> objects = new ArrayList<>();
                objects.add(i + "");
                objects.add(i + "");
                objects.add(i + "");

                tableData.add(objects);
            }

            WriteSheet writeSheet = buildSheetByHead(0, tableName, tableHeaders);
            excelWriter.write(tableData, writeSheet);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // 千万别忘记finish 会帮忙关闭流
            if (excelWriter != null) {
                excelWriter.finish();
            }
        }

    }


    /**
     * 获取所有数据源信息
     *
     * @return 数据源列表
     */
    @Override
    public List<DatasrcEntity> mainDisplayV3(int includeTasks) {
        return iDatasrcRepository.findAll();
    }

    /**
     * 渲染V4版本
     */
    @Override
    public List<DataSourceRoundDirectoryResp> mainDisplayV4() {
        List<DataSourceRoundDirectoryResp> dataSourceRoundDirectoryResps = new ArrayList<>();

        List<DatasrcEntity> datasrcEntityList = iDatasrcRepository.findAll();
        for (DatasrcEntity datasrcEntity : datasrcEntityList) {

            List<Map<String, Object>> directoryWithRecords = dataDirectoryService.getDirectoryWithRecords();


            DataSourceRoundDirectoryResp dataSourceRoundDirectoryResp = new DataSourceRoundDirectoryResp();
            BeanUtil.copyProperties(datasrcEntity, dataSourceRoundDirectoryResp);
            List<GatherRoundRecord> recordList = gatherRoundRecordService.queryList(datasrcEntity.getId());
            List<DataSourceRoundDirectoryResp.GatherRoundRecord> gatherRoundRecordList = new ArrayList<>();

            for (GatherRoundRecord gatherRoundRecord : recordList) {
                DataSourceRoundDirectoryResp.GatherRoundRecord roundRecord = new DataSourceRoundDirectoryResp.GatherRoundRecord();
                BeanUtil.copyProperties(gatherRoundRecord, roundRecord);
                roundRecord.setDirectoryWithRecords(directoryWithRecords);
                gatherRoundRecordList.add(roundRecord);
            }
            dataSourceRoundDirectoryResp.setGatherRoundRecordList(gatherRoundRecordList);


            dataSourceRoundDirectoryResps.add(dataSourceRoundDirectoryResp);
        }

        return dataSourceRoundDirectoryResps;
    }

    /**
     * 获取表定义字段
     */
    @Override
    public TableInfoVO tableNameDefineField2(ExerciseInfoReq req) {
        return null;
    }

    /**
     * 将上传文件读取到String
     *
     * @param file
     * @return
     */
    private String fileReadToString(MultipartFile file) {
        InputStream is = null;
        BufferedReader br = null;
        StringBuffer sb = null;
        try {
            is = file.getInputStream();
            br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            sb = new StringBuffer();
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
                sb.append("\n");
            }
            String s = sb.toString();
            return sb.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        } finally {
            try {
                br.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


    }

    /**
     * 演戏或仿真链接
     *
     * @return com.yw.source.datagather.vo.AnalysisDateVO
     * @Author lj
     * @Description 演戏或仿真链接
     * @Date 2021/12/20
     * @Param [dto]
     **/
    @Override
    public AnalysisDateVO analysisDate(ExerciseDateDTO dto) {
        int includeTasks = dto.getIncludeTasks();
        DataTableType dataTableType = DataTableType.getType(includeTasks);
        if (dataTableType.equals(DataTableType.NONE)) {
            LOG.error("The data parsing type is not adapted yet");
            throw new BusinessException("暂未适配该数据解析类型");
        }

        //根据解析类型获取待解析的数据源
        String analysisId = dto.getAnalysisId();
        DataAnalysisEntity dataAnalysisEntity = null;
        if (!StringUtils.isEmpty(analysisId)) {
//            Optional<DataAnalysisEntity> dataSrcMan = dataSrcManagerRepository.findById(analysisId);
            Optional<DataAnalysisEntity> dataSrcMan = Optional.ofNullable(this.getById(analysisId));
            if (dataSrcMan.isPresent()) {
                dataAnalysisEntity = dataSrcMan.get();
            }
        }
        if (dataAnalysisEntity != null) {
            //修改
            Date createDate = null;
            if (dataAnalysisEntity.getCreateTime() == null) {
                createDate = new Date();
            } else {
                createDate = dataAnalysisEntity.getCreateTime();
            }
            dataAnalysisEntity = DataAnalysisEntity.valueOf(analysisId, createDate, dto);
        } else {
            //添加
            analysisId = UUIDGenerator.getUUID();
            //唯一性校验, 根据 DbType IP地址 DbName 进行判断 存在进行更新
//            Optional<DataAnalysisEntity> optional = dataSrcManagerRepository.findOne(
//                    Example.of(DataAnalysisEntity.builder().
//                            dbName(dto.getDbName()).
//                            dbType(dto.getDbType()).
//                            host(dto.getHost()).build()));
            Optional<DataAnalysisEntity> optional = Optional.ofNullable(this.getOne(new QueryWrapper<DataAnalysisEntity>().eq("DB_NAME", dto.getDbName())
                    .eq("DB_TYPE", dto.getDbType()).eq("HOST", dto.getHost())));
            if (optional.isPresent()) {
                DataAnalysisEntity entity = optional.get();
                analysisId = entity.getId();
            }
            dataAnalysisEntity = DataAnalysisEntity.valueOf(analysisId, dto);
        }
//        dataSrcManagerRepository.saveAndFlush(dataAnalysisEntity);
        this.saveOrUpdate(dataAnalysisEntity);
        // 获取数据源任务表
//        String classifyId = dto.getClassifyId();

        String dataSrcTaskName = dto.getTaskName();
        String dbType = dto.getDbType();
        DataBaseType baseType = DataBaseType.getType(dbType);
        if (baseType == DataBaseType.NONE) {
            throw new BusinessException("咱无适配类型数据库");
        }
        String taskName = dto.getTaskName();
        AnalysisDateVO result = null;
        // 非关系型数据库操作
        if (baseType == DataBaseType.MONGODB) {
            if (StringUtils.isEmpty(dto.getAnalysisModelId())) {
                throw new BusinessException("请先设置解析模型");
            }
            // 非关系性数据库操作
            result = nonRelational(dataAnalysisEntity, taskName, dataTableType);
        } else {
            //DbLinkBO 关系型数据库操作
            result = relational(dataAnalysisEntity, taskName, dataTableType, dataSrcTaskName);
        }
        result.setAnalysisId(analysisId);
        return result;
    }

    /**
     * 校验任务表是否包含指定信息
     *
     * @param taskName 任务表名称
     * @param dbLinkBO 链接信息
     * @author l j
     */
    private void testingTaskTable(String taskName, DbLinkBO dbLinkBO) {
        List<String> fieldCols = Lists.newArrayList();

        List<TableColsDTO> dataList = dataBaseHandler.findTableCols(taskName, dbLinkBO);
        if (CollUtil.isEmpty(dataList)) {
            throw new BusinessException("任务表信息不完全,请重新设置任务表");
        }
        //获取任务表的字段信息
        for (TableColsDTO colsDTO : dataList) {
            fieldCols.add(colsDTO.getColCode());
        }
        //任务表是否存在ID以及TASK_NAME两个字段
        if (!fieldCols.contains("ID") && !fieldCols.contains("TASK_NAME")) {
            throw new BusinessException("指定任务表不存在ID以及TASK_NAME字段信息");
        }
    }

    /**
     * 关系型数据库校验
     **/
    private AnalysisDateVO relational(DataAnalysisEntity dataAnalysisEntity, String taskName, DataTableType dataTableType, String dataSrcTaskName) {
        AnalysisDateVO value = new AnalysisDateVO();

        DbLinkBO dbLinkBO = DbLinkBO.valueOf(dataAnalysisEntity.getDbType(), dataAnalysisEntity.getHost(), dataAnalysisEntity.getPort(),
                dataAnalysisEntity.getDbName(), dataAnalysisEntity.getPassword(), dataAnalysisEntity.getUsername());
        List<String> fieldCols = Lists.newArrayList();
        //用户指定任务表的结构
        if (dataTableType.equals(DataTableType.INCLUDE_TASK_DATA_SHEET)) {
            testingTaskTable(taskName, dbLinkBO);
        }
        //获取数据库表信息
        List<DbTableVO> vos = null;
        try {
            vos = dataBaseHandler.findTableName(dbLinkBO.getDbName(), dbLinkBO);
        } catch (Exception e) {
            throw new BusinessException("数据库连接失败,请检查数据库连接信息");
        }
        if (vos != null && !vos.isEmpty()) {
            if (dataTableType.equals(DataTableType.INCLUDE_TASK_DATA_SHEET)) {
                for (DbTableVO vo : vos) {
                    if (vo.getTableName().equals(taskName)) {
                        continue;
                    }
                    List<TableColsDTO> tableCols = dataBaseHandler.findTableCols(vo.getTableName(), dbLinkBO);
                    fieldCols = Lists.newArrayList();
                    for (TableColsDTO cols : tableCols) {
                        fieldCols.add(cols.getColCode());
                    }
                    if (!fieldCols.contains("TASK_ID")) {
                        throw new BusinessException("当前数据源有数据表没有关联任务表");
                    }
                }
            }
            value = AnalysisDateVO.valueOf(dataAnalysisEntity.getId(), vos, dataSrcTaskName, taskName);
        }
        return value;
    }

    /**
     * 非关系型数据库校验
     **/
    private AnalysisDateVO nonRelational(DataAnalysisEntity dataAnalysisEntity, String taskName, DataTableType dataTableType) {

        List<String> mongoTableNames = getMongoTable(dataAnalysisEntity.getHost(), Integer.parseInt(dataAnalysisEntity.getPort()),
                dataAnalysisEntity.getUsername(), dataAnalysisEntity.getDbName(), dataAnalysisEntity.getPassword());
        if (CollUtil.isEmpty(mongoTableNames)) {
            return new AnalysisDateVO();
        }
        if (dataTableType == DataTableType.INCLUDE_TASK_DATA_SHEET) {
            if (!mongoTableNames.contains(taskName)) {
                throw new BusinessException("指定任务表不存在ID以及TASK_NAME字段信息");
            }

            boolean flag = verificationTaskNameContain(dataAnalysisEntity.getHost(), Integer.parseInt(dataAnalysisEntity.getPort()),
                    dataAnalysisEntity.getUsername(), dataAnalysisEntity.getDbName(), taskName, dataAnalysisEntity.getPassword());
            if (!flag) {
                throw new BusinessException("指定任务表不存在ID以及TASK_NAME字段信息");
            }
        }
        return AnalysisDateVO.valueOf(dataAnalysisEntity.getId(), mongoTableNames, taskName);
    }


    /**
     * 获取表展示信息
     *
     * @param dbLinkBO 链接BO
     * @param dbName   表名称
     * @param offSet   其实页
     * @param limit    页大小
     * @return
     */
    public TableInfoVO getTableInfoVO(DbLinkBO dbLinkBO, String dbName, Integer offSet, Integer limit, String dataSrcId, List<ExerciseInfoDTO.RoundFilter> roundFilterList) {
        //获取表别名
        String chName = new String();
        Optional<TableChNameEntity> one = dataTableChNameRepository.findOne(Example.of(TableChNameEntity.builder().dataSrcId(dataSrcId).tableName(dbName).flag(1).build()));
        if (one.isPresent()) {
            chName = one.get().getChName();
        }
        //获取数据表字段
        List<TableColsDTO> fields = dataBaseHandler.findTableCols(dbName, dbLinkBO);
        List<TableColsDTO> tableFields = new ArrayList<>();
        if (roundFilterList != null && roundFilterList.size() > 0) {
            for (TableColsDTO field : fields) {
                for (ExerciseInfoDTO.RoundFilter roundFilter : roundFilterList) {
                    if (field.getColCode().equals(roundFilter.getRoundField())) {
                        tableFields.add(field);
                        break;
                    }
                }
            }

            for (TableColsDTO field : fields) {
                boolean isHave = false;
                for (ExerciseInfoDTO.RoundFilter roundFilter : roundFilterList) {
                    if (field.getColCode().equals(roundFilter.getRoundField())) {
                        isHave = true;
                        break;
                    }
                }
                if (!isHave) {
                    tableFields.add(field);
                }
            }
        } else {
            tableFields = fields;
        }

        PageInfo<Map<String, Object>> page = new PageInfo();
        //获取表数据 offSet == 0 不分页
        if (offSet == 0) {
            if (roundFilterList != null && roundFilterList.size() > 0) {
                List<Map<String, Object>> dataListRoundFilter = dataBaseHandler.findDataListRoundFilter(dbName, dbLinkBO, roundFilterList);
                page.setList(dataListRoundFilter);
                page.setTotal((long) dataListRoundFilter.size());
            } else {
                List<Map<String, Object>> dataList = dataBaseHandler.findDataList(dbName, dbLinkBO);
                page.setList(dataList);
                page.setTotal((long) dataList.size());
            }
        } else {
            if (roundFilterList != null && roundFilterList.size() > 0) {
                page = dataBaseHandler.findDataPageRoundFilter(dbName, offSet, limit, dbLinkBO, roundFilterList);
            } else {
                page = dataBaseHandler.findDataPage(dbName, offSet, limit, dbLinkBO);
            }
        }
        //获取表字段中文名
        List<TableChNameEntity> chNameEntityList = dataTableChNameRepository.findByTableNameAndDataSrcIdAndFlag(dbName, dataSrcId, 2);
        if (CollectionUtils.isEmpty(chNameEntityList)) {
            tableFields.stream().forEach(item -> {
                TableChNameEntity tableChNameEntity = new TableChNameEntity();
                tableChNameEntity.setChName(item.getDescribes());
                tableChNameEntity.setFieldName(item.getColCode());
                chNameEntityList.add(tableChNameEntity);
            });
        }

        //组装数据
        return TableInfoVO.valueOf(chName, tableFields, page.getList(), page.getTotal(), chNameEntityList);
    }

    /**
     * 获取转化信息
     */
    @Override
    public Map<String, String> getConvert() {
        Map<String, String> result = Maps.newHashMap();
        result.put("countSize", countSize + ""); // 需要转换的总条数
        result.put("overSize", overSize + ""); // 已经转换的总条数
        return result;
    }

    /**
     * 取消转换函数
     */
    @Override
    public void cancelConvert() {
        cancelConvert = true;
    }

    /**
     * 数据转换函数
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public int convertColumn(ColumnConvertDTO convertDTO) {
        cancelConvert = false;
        String tableName = convertDTO.getTableName();
        String dataSrcId = convertDTO.getDataSrcId();
        String columnName = convertDTO.getColumnName();
        String converName = convertDTO.getPyfileName();
        DataConvertScriptEntity dataConvertScriptEntity = dataConvertScriptMapper.selectByPrimaryId(new HashMap<String, Object>(1) {{
            put("NAME", converName);
        }});
        if (dataConvertScriptEntity == null) {
            throw new BusinessException("该转化规则不存在");
        }
        String pyfileName = dataConvertScriptEntity.getScriptName();

        //存储适配类型
        Optional<DatasrcEntity> entityOptional = iDatasrcRepository.findById(dataSrcId);
        if (!entityOptional.isPresent()) {
            LOG.error("暂未配置该数据解析类型");
        }
        DatasrcEntity entity = entityOptional.get();
        //DbLinkBO
        DbLinkBO dbLinkBO = entity.createDblinkDto().createDbLinkBo();
        //获取表别名
        String dbName = tableName;
        //获取数据表字段
        List<TableColsDTO> tableFields = dataBaseHandler.findTableCols(dbName, dbLinkBO);
        //获取主键所在字段,没有主键取第一个
        String pk = tableFields.stream().filter(item -> Objects.equals(item.getPk(), 1))
                .map(TableColsDTO::getColCode).findFirst().get();
        List<ConvertColumnDTO> convertColumnDTOS = Lists.newArrayList();
        Optional<ConvertColumnEntity> optionalConvertColumnEntity = convertColumnRepository
                .findOne(Example.of(ConvertColumnEntity.builder().tableName(tableName).dataSrcId(dataSrcId).columnName(columnName).build()));
        if (!optionalConvertColumnEntity.isPresent()) {
            List<Map<String, Object>> list = dataBaseHandler.findDataList(dbName, dbLinkBO);
            // 数据总条数

            List<Object> columnDatas = new ArrayList<>();
            List<Object> pkDatas = new ArrayList<>();
            list.stream().forEach(item -> {
                List<Object> columnData = item.entrySet().stream().filter(item2 -> Objects.equals(item2.getKey(), columnName))
                        .map(Map.Entry::getValue).collect(Collectors.toList());
                List<Object> pkData = item.entrySet().stream().filter(item2 -> Objects.equals(item2.getKey(), pk))
                        .map(Map.Entry::getValue).collect(Collectors.toList());
                columnDatas.addAll(columnData);
                pkDatas.addAll(pkData);
            });
            //如果先前该表的这个列未解析过，则解析原始数据
            if (columnDatas.size() == pkDatas.size()) {
                for (int i = 0; i < columnDatas.size(); i++) {
                    //K:主键值 V：待更新的值
                    String k = String.valueOf(pkDatas.get(i));

                    Object v = columnDatas.get(i);
                    if (v instanceof DmdbNClob) {
                        if (i == 5000) {
                            System.err.println("dangqian");
                        }
                        DmdbNClob clob = (DmdbNClob) v;
                        convertColumnDTOS.add(ConvertColumnDTO.valueOf(k.trim(), String.valueOf(clob.data)));
                    } else {

                        convertColumnDTOS.add(ConvertColumnDTO.valueOf(k.trim(), String.valueOf(v).trim()));
                    }
                }
            }

            ConvertColumnEntity convertColumnEntity = ConvertColumnEntity.valueof(dataSrcId, tableName, columnName, JSON.toJSONString(convertColumnDTOS), converName);
            convertColumnRepository.saveAndFlush(convertColumnEntity);
        } else {
            //如果先前该表的这个列已经解析过，则用数据库中的原始数据,并更新转化规则
            ConvertColumnEntity convertColumnEntity = optionalConvertColumnEntity.get();
            String convertData = convertColumnEntity.getConvertData();
            convertColumnDTOS = JSON.parseArray(convertData, ConvertColumnDTO.class);
            convertColumnRepository.delete(convertColumnEntity);
            ConvertColumnEntity convertColumnEntity2 = ConvertColumnEntity.valueof(dataSrcId, tableName, columnName, JSON.toJSONString(convertColumnDTOS), converName);
            convertColumnRepository.saveAndFlush(convertColumnEntity2);
        }
        // 总条数
        int size = convertColumnDTOS.size();

        List<ConvertColumnDTO> finalConvertColumnDTOS = Lists.newArrayList(convertColumnDTOS);
        convertColumnDTOS = null; // help gc
        executorManager.addTask(AsyncTask.valueOf("convert", new Runnable() {
            @Override
            public void run() {

                convert(finalConvertColumnDTOS, pyfileName, size, tableName, columnName, dbLinkBO, pk);
            }

        }));
        return size;

    }

    /**
     * 执行转换的函数
     */
    public void convert(List<ConvertColumnDTO> finalObj, String pyfileName, int size, String tableName, String columnName, DbLinkBO dbLinkBO, String pk) {
        final ReentrantLock lock = this.lock;
        countSize += size;
        // 线程安全问题
        lock.lock();
        int currentOverSize = 0;
        JSONObject parsingObject = new JSONObject();
        try {
            for (ConvertColumnDTO map : finalObj) {
                if (cancelConvert) {
                    return;
                }
                currentOverSize++;
                overSize++;
                String key = map.getKey();
                String value = map.getValue();
                parsingObject.put(key, value);
                if (currentOverSize % 300 == 0 || currentOverSize == size) {
                    // 解析
                    String result = convertColumnData(parsingObject, pyfileName);
                    if (Objects.equals(result, "error")) {
                        throw new BusinessException("转化规则不适用");
                    }
                    System.out.println(result);
                    JSONObject newObj = new JSONObject();
                    try {
                        newObj.putAll(JSONObject.parseObject(result));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    //移除以及解析的key 重置
                    parsingObject = new JSONObject();
                    //批量更新转换后结果
//                        List<TableColsBO> tableColsBoList = JSONArray.parseArray(JSON.toJSONString(tableFields), TableColsBO.class);
//                        List<TableColsBO> tableColsBos = tableColsBoList.stream().filter(item -> Objects.equals(item.getColCode(), columnName)).map(item -> {
//                            item.setEditColCodeOld(item.getColCode());
//                            item.setColCode(columnName);
//                            item.setColType("VARCHAR");
//                            item.setColLen(50);
//                            item.setEditType(2);
//                            return item;
//                        }).collect(Collectors.toList());
                    //更新表中字段类型
//        dmOperationService.editTableCols(tableName, tableColsBos, dbLinkBO);
                    //更新表中字段数据
                    MysqlOperationServiceImpl bean = BeanUtils.getBean(MysqlOperationServiceImpl.class);
                    bean.updateBatch(tableName, columnName, newObj, pk, dbLinkBO);
//                    dmOperationService.updateBatch();
                    // 消息推送 30
                    StompMessagePusher.pushStompMessage(WebSocketConstant.DATA_CONVERT_MESSAGE, overSize + "-" + size);
                    if (overSize == countSize) {
                        countSize = 0;
                        overSize = 0;
                    }
                }
            }
        } catch (Exception e) {
            LOG.error(e.getMessage());
        } finally {
            lock.unlock();
        }

    }

    /**
     * 转换之后导入操作
     */
    @Override
    public void convertColumnAfterImport(String tableName, String dataSrcId) {
        List<ConvertColumnEntity> convertColumnEntities = convertColumnRepository
                .findAll(Example.of(ConvertColumnEntity.builder().tableName(tableName).dataSrcId(dataSrcId).build()));
        convertColumnRepository.deleteAll(convertColumnEntities);
        if (CollUtil.isNotEmpty(convertColumnEntities)) {
            for (ConvertColumnEntity entity : convertColumnEntities) {
                ColumnConvertDTO columnConvertDTO = ColumnConvertDTO.valueOf(entity);
                convertColumn(columnConvertDTO);
            }
        }
    }

    /**
     * 获取数据表
     */
    @Override
    public TableInfoVO getSourceColumn(ColumnConvertPageDTO convertDTO) {
        String tableName = convertDTO.getTableName();
        String dataSrcId = convertDTO.getDataSrcId();
        Integer pageNum = convertDTO.getPageNum();
        Integer pageSize = convertDTO.getPageSize();
        TableInfoVO tableInfoVO = this.tableNameDefineField(ExerciseInfoDTO.valueOf(tableName, dataSrcId, pageSize, pageNum));
        List<ConvertColumnEntity> convertColumnEntities = convertColumnRepository
                .findAll(Example.of(ConvertColumnEntity.builder().tableName(tableName).dataSrcId(dataSrcId).build()));
        if (CollUtil.isNotEmpty(convertColumnEntities)) {
            //主键字段
            List<TableColsDTO> tableFields = tableInfoVO.getTableFields();
            String pk = tableFields.stream().filter(item -> Objects.equals(item.getPk(), 1))
                    .map(TableColsDTO::getColCode).findFirst().get();
            for (ConvertColumnEntity entity : convertColumnEntities) {
                String columnName = entity.getColumnName();
                String convertData = entity.getConvertData();
                List<ConvertColumnDTO> dtos = JSON.parseArray(convertData, ConvertColumnDTO.class);
                //获取该列的原始数据map <主键值，该列值>
                Map<String, String> map = new HashMap<>();
                for (ConvertColumnDTO dto : dtos) {
                    map.put(dto.key, dto.value);
                }
                //获取主键
                List<Map<String, Object>> list = tableInfoVO.getList();
                for (Map<String, Object> entry : list) {
                    String pkValue = (String) entry.get(pk);
                    String columnValue = map.get(pkValue);
                    for (Map.Entry<String, Object> e : entry.entrySet()) {
                        String key = e.getKey();
                        if (Objects.equals(key, columnName)) {
                            e.setValue(columnValue);
                        }
                    }
                }
            }
        }
        return tableInfoVO;
    }

    /**
     * 获取转换后的名称数据
     */
    @Override
    public Map<String, String> getColumnNameAndCovertNameMap(ColumnConvertMapDTO convertDTO) {
        String tableName = convertDTO.getTableName();
        List<ConvertColumnEntity> list = convertColumnRepository
                .findAll(Example.of(ConvertColumnEntity.builder().tableName(tableName).dataSrcId(convertDTO.getDataSrcId()).build()));
        Map<String, String> map = list.stream().collect(Collectors.toMap(ConvertColumnEntity::getColumnName, ConvertColumnEntity::getConvertName));
        return map;
    }

    /**
     * 删除转换的表
     */
    @Override
    public void delSourceColumn(List<String> tableNames) {
        for (String tableName : tableNames) {
            List<ConvertColumnEntity> all = convertColumnRepository.findAll(Example.of(ConvertColumnEntity.builder().tableName(tableName).build()));
            if (CollUtil.isNotEmpty(all)) {
                convertColumnRepository.deleteAll(all);
            }
        }
    }


    /**
     * 表名称以及数据源确定字段
     *
     * @return com.yw.domain.vo.TableInfoVO
     * @Author lj
     * @Description 表名称以及数据源确定字段
     * @Date 2021/12/21
     * @Param [dto]
     **/
    @Override
    public TableInfoVO tableNameDefineField(ExerciseInfoDTO dto) {
        //根据类型获取数据
        String dataSrcId = dto.getDataSrcId();

        //根据数据源类型获取对应的链接信息
        Optional<DatasrcEntity> entityOptional = iDatasrcRepository.findById(dataSrcId);
        if (!entityOptional.isPresent()) {
            LOG.error("暂未配置该数据解析类型");
            return new TableInfoVO();
        }
        DatasrcEntity entity = entityOptional.get();
        try {
            //DbLinkBO
            DbLinkBO dbLinkBO = entity.createDblinkDto().createDbLinkBo();
            //获取表展示信息
            TableInfoVO tableInfoVO = getTableInfoVO(dbLinkBO, dto.getDbName(), dto.getOffSet(), dto.getLimit(), dataSrcId, dto.getRoundFilterList());

            return tableInfoVO;
        } catch (Exception e) {
            // 表或者视图不存在
            throw new BusinessException("表或视图不存在");
        }

    }

    /**
     * 获取本地带解析的数据源
     *
     * @param host
     * @param analysisId
     * @return java.util.List<com.yw.domain.entity.dataSource.DataAnalysisEntity>
     * @Author lj
     * @Description 获取本地带解析的数据源
     * @Date 2021/12/21
     * @Param [host]
     */
    @Override
    public List<DataAnalysisEntity> showDataSrc(String host, String analysisId) {
        List<DataAnalysisEntity> result = Lists.newArrayList();
        if (!StringUtils.isEmpty(analysisId)) {
            Optional<DataAnalysisEntity> dataAnalysisEntity = dataSrcManagerRepository.findById(analysisId);
            if (dataAnalysisEntity.isPresent()) {
                result.add(dataAnalysisEntity.get());
                return result;
            }
        }
        if (StringUtils.isEmpty(host)) {
            result = dataSrcManagerRepository.findAll();
        } else {
            result = dataSrcManagerRepository.findByHostContaining(host);
        }
        return result;
    }

    /**
     * 获取仿真任务或者演习任务信息
     *
     * @return java.util.List<com.yw.domain.vo.TaskInfoVO>
     * @Author lj
     * @Description 获取仿真任务或者演习任务信息
     * @Date 2021/12/21
     * @Param [type]
     */
    @Override
    public List<TaskInfoVO> showTaskInfo(String dataSrcId) {
        //存储适配类型
        Optional<DatasrcEntity> entityOptional = iDatasrcRepository.findById(dataSrcId);
        if (!entityOptional.isPresent()) {
            LOG.error("暂未配置该数据解析类型");
        }
        DatasrcEntity entity = entityOptional.get();
        try {
            //DbLinkBO
            DbLinkBO dbLinkBO = entity.createDblinkDto().createDbLinkBo();
            //获取表数据
            List<Map<String, Object>> dataList = dataBaseHandler.findDataList(entity.getTaskName(), dbLinkBO);
            List<TaskInfoVO> vo = Lists.newArrayList();
            for (Map<String, Object> map : dataList) {
                //设置任务信息
                String fieldName = "TASK_ID";
                String dbType = entity.getType();
                if (dbType.equals("mysql")) {
                    fieldName = "task_id";
                }
                Object task_name = map.get("TASK_NAME");
                String name = task_name != null ? task_name.toString() : null;
                String id = map.get("ID").toString();
                vo.add(TaskInfoVO.valueOf(id, name, fieldName));
            }
            return vo;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Lists.newArrayList();
    }

    /**
     * 展示任务信息
     */
    @Override
    public List<TaskInfoVO> showTaskInfoV2(String dataSrcId) {
        List<TaskInfoVO> result = Lists.newArrayList();
        List<GatherRoundRecord> gatherRoundRecords = iGatherRoundRecordService.queryList(dataSrcId);
        for (GatherRoundRecord roundRecord : gatherRoundRecords) {
            String defaultFiledName = StringUtils.isEmpty(roundRecord.getRoundField()) ? "TASK_ID" : roundRecord.getRoundField();
            result.add(TaskInfoVO.valueOf(roundRecord.getTaskId(), roundRecord.getName(), defaultFiledName));
        }
        return result;
    }

    /**
     * 根据类型获取数据源 1.演习数据 2.仿真数据
     *
     * @return com.yw.domain.entity.dataSource.DataAnalysisEntity
     * @Author lj
     * @Description 根据类型获取数据源 1.演习数据 2.仿真数据
     * @Date 2021/12/21
     * @Param [type]
     **/
    @Override
    public DataAnalysisEntity dataSource(String dataSrcId) {
        Optional<DataAnalysisEntity> one = dataSrcManagerRepository.findById(dataSrcId);
        if (one.isPresent()) {
            DataAnalysisEntity dataAnalysisEntity = one.get();
            return dataAnalysisEntity;
        } else {
            return new DataAnalysisEntity();
        }
    }

    /**
     * 导出为指定文件 可以导出多表
     */
    @Override
    public void exportDataTable(DataTableExportDTO dto, HttpServletResponse response, HttpServletRequest request) throws
            IOException {
        String dataSrcId = dto.getDataSrcId();
        String type = dto.getFileType();
        List<String> tableName = dto.getTableName();
        if (!FileUtils.checkFileType(type)) {
            LOG.error("The current file type does not support export, File Type is :{}", type);
            throw new BusinessException("当前文件不支持导出");
        }
        //获取数据源信息
        DatasrcEntity entity = iDatasrcRepository.findById(dataSrcId).get();
        DbLinkBO bo = entity.createDblinkDto().createDbLinkBo();
        switch (type) {
            case "excel":
                exportByExcel(bo, tableName, response);
                break;
            case "json":
                exportByJson(bo, tableName, response, request, ".json");
                break;
            case "xml":
                exportByXml(bo, tableName, response, request);
                break;
            case "csv":
                exportByCsv(bo, tableName, response, request);
                break;
            case "txt":
                exportByJson(bo, tableName, response, request, ".txt");
                break;
            case "binary":
                exportBinary(bo, tableName, response);
                break;
            default:
                break;
        }
    }

    /**
     * txt 导出
     */
    private void exportBytxt(DbLinkBO dbLinkBO, List<String> tableNames, HttpServletResponse
            response, HttpServletRequest request) {
        List<List<Map<String, Object>>> data = new ArrayList<>();
        for (int i = 0; i < tableNames.size(); i++) {
            String tableName = tableNames.get(i);
            List<Map<String, Object>> dataList = dataBaseHandler.findDataList(tableName, dbLinkBO);
            data.add(dataList);
        }
        ExportTxtFileUtil.tablesExport(tableNames, data, response);
    }


    /**
     * 二进制文件导出
     */
    private void exportBinary(DbLinkBO bo, List<String> tableName, HttpServletResponse response) {
        BufferedReader br = null;
        ServletOutputStream outputStream = null;
        StringBuffer dataTable = new StringBuffer();
        InputStream input = null;
        try {
            //获取对应数据
            for (String table : tableName) {
                List<Map<String, Object>> dataList = dataBaseHandler.findDataList(table, bo);
                if (CollUtil.isNotEmpty(dataList)) {
                    dataTable.append(table + "\n");
                    Map<String, Object> map = dataList.get(0);
                    int i = 0;
                    for (Map.Entry<String, Object> item : map.entrySet()) {
                        String key = item.getKey();
                        if (i == map.size() - 1) {
                            dataTable.append((key + "\n"));
                        } else {
                            dataTable.append((key + " "));
                            i++;
                        }
                    }
                }
                for (Map<String, Object> map : dataList) {
                    int j = 0;
                    for (Map.Entry<String, Object> entry : map.entrySet()) {
                        Object value = entry.getValue();
                        if (j == map.size() - 1) {
                            dataTable.append((value + "\n"));
                        } else {
                            dataTable.append((value + " "));
                        }
                        j++;
                    }
                }
                dataTable.append("\n\n\n\n");
            }
            input = new ByteArrayInputStream(dataTable.toString().getBytes(StandardCharsets.UTF_8));
            response.setHeader("content-disposition", "attachment;filename=" + tableName.get(0) + ".dat");
            outputStream = response.getOutputStream();
            byte[] bytes = new byte[1024];
            int len;
            while ((len = input.read(bytes)) != -1) {
                outputStream.write(bytes, 0, len);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (input != null) {
                try {
                    input.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 导出JSON格式
     *
     * @return void
     * @Author hww
     * @Description 导出JSON格式
     * @Date 14:21 2021/11/15
     * @Param [dbLinkBO, tableName, response]
     **/
    public void exportByJson(DbLinkBO dbLinkBO, List<String> tableNames, HttpServletResponse
            response, HttpServletRequest request, String fileType) {
        JSONArray jsonArray = new JSONArray();
        tableNames.forEach(tableName -> {
            List<Map<String, Object>> dataList = dataBaseHandler.findDataList(tableName, dbLinkBO);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("tableName", tableName);
            jsonObject.put("data", dataList);
            jsonArray.add(jsonObject);
        });
        JsonFileUtil.createJsonFile(request, response, JSON.toJSONString(jsonArray), UUIDGenerator.getUUID(), fileType);
    }


    /**
     * 导出Csv表
     *
     * @return void
     * @Author hww
     * @Description 导出Csv表
     * @Date 10:46 2021/11/16
     * @Param [dbLinkBO, tableNames, response, request]
     **/
    public void exportByCsv(DbLinkBO dbLinkBO, List<String> tableNames, HttpServletResponse
            response, HttpServletRequest request) throws IOException {
        List<String> urls = new ArrayList<>();
        String path = System.getProperty("user.dir") + File.separator + "mycsv" + File.separator;
        //创建目录，将生成的csv文件放到该目录下
        File fileRoot = new File(path);
        if (!fileRoot.exists()) {
            fileRoot.mkdirs();
        }
        try {
            for (int i = 0; i < tableNames.size(); i++) {
                String tableName = tableNames.get(i);
                List<Map<String, Object>> dataList = dataBaseHandler.findDataList(tableName, dbLinkBO);
                List<Object> tableHeaders = new ArrayList<>();
                List<List<Object>> tableData = new ArrayList<>();
                if (CollUtil.isNotEmpty(dataList)) {
                    Map<String, Object> map = dataList.get(0);
                    map.entrySet().stream().forEach(item -> {
                        String key = item.getKey();
                        tableHeaders.add(key);
                    });
                }
                for (Map<String, Object> map : dataList) {
                    List<Object> objects = new ArrayList<>();
                    for (Map.Entry<String, Object> entry : map.entrySet()) {
                        Object value = entry.getValue();
                        if (value instanceof DmdbNClob) {
                            objects.add(((DmdbNClob) value).data);
                            continue;
                        }
                        objects.add(value);
                    }
                    tableData.add(objects);
                }
                CsvUtil.generateCsv(path, tableName, tableHeaders, tableData);
            }
            String zipName = "tableData.zip";
            String zipPath = System.getProperty("user.dir") + File.separator + zipName;
            FileUtils.zipFile(path, zipPath, zipName, response);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            CsvUtil.deleteFiles(urls);
        }
    }


    /**
     * 导出xml格式
     *
     * @return void
     * @Author xm
     * @Description 导出xml格式
     * @Date 15:13 2021/11/15
     * @Param [dbLinkBO, tableNames, response, request]
     **/
    public void exportByXml(DbLinkBO dbLinkBO, List<String> tableNames, HttpServletResponse
            response, HttpServletRequest request) {
        try {
            List<ExportXmlDTO> list = Lists.newArrayList();
            for (String tableName : tableNames) {
                ExportXmlDTO exportXmlDTO = new ExportXmlDTO();
                List<Map<String, Object>> dataList = dataBaseHandler.findDataList(tableName, dbLinkBO);
                exportXmlDTO.setTableName(tableName);
                exportXmlDTO.setData(dataList);
                list.add(exportXmlDTO);
            }
            XmlJsonConvertUtil.exportXmlToFile(request, response, UUIDGenerator.getUUID(), XmlJsonConvertUtil.listToXml(list));
            LOG.info("成功导出XML文件格式数据");
        } catch (IOException e) {
            throw new BusinessException("导出xml异常！");
        }
    }


    /**
     * excel文件导出
     *
     * @return void
     * @Author xm
     * @Description excel文件导出
     * @Date 18:20 2021/11/15
     * @Param [dbLinkBO, tableName, response, request]
     **/
    private void exportByExcel(DbLinkBO dbLinkBO, List<String> tableNames, HttpServletResponse response) {
        String exportName = IdUtil.simpleUUID();
        ExcelWriter excelWriter = null;
        try {
            excelWriter = new ExcelWriter(getOutputStream(exportName, response), ExcelTypeEnum.XLSX);
            for (int i = 0; i < tableNames.size(); i++) {
                String tableName = tableNames.get(i);
                List<Map<String, Object>> dataList = dataBaseHandler.findDataList(tableName, dbLinkBO);
                List<List<String>> tableHeaders = new ArrayList<>();
                List<List<Object>> tableData = new ArrayList<>();
                if (CollUtil.isNotEmpty(dataList)) {
                    Map<String, Object> map = dataList.get(0);
                    map.entrySet().stream().forEach(item -> {
                        String key = item.getKey();
                        List<String> keys = new ArrayList<>();
                        keys.add(key);
                        tableHeaders.add(keys);
                    });
                }
                for (Map<String, Object> map : dataList) {
                    List<Object> objects = new ArrayList<>();
                    for (Map.Entry<String, Object> entry : map.entrySet()) {
                        Object value = entry.getValue();
                        if (value instanceof DmdbNClob) {
                            objects.add(((DmdbNClob) value).data);
                            continue;
                        }
                        objects.add(value);
                    }
                    tableData.add(objects);
                }
                WriteSheet writeSheet = buildSheetByHead(i, tableName, tableHeaders);
                excelWriter.write(tableData, writeSheet);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // 千万别忘记finish 会帮忙关闭流
            if (excelWriter != null) {
                excelWriter.finish();
            }
        }
    }

    /**
     * 构造excel头数据
     */
    private WriteSheet buildSheetByHead(Integer index, String sheetName, List<List<String>> head) {
        WriteSheet writeSheet = EasyExcel.writerSheet(index, sheetName).head(head).build();
        return writeSheet;
    }

    /**
     * 导出文件时为Writer生成OutputStream
     *
     * @param fileName
     * @param response
     * @return
     */
    private OutputStream getOutputStream(String fileName, HttpServletResponse response) throws Exception {
        try {
            response.setContentType("application/vnd.ms-excel");
            response.setCharacterEncoding("utf8");
            response.setHeader("Content-Disposition", "attachment; filename=" + fileName + ".xlsx");
            response.setHeader("Pragma", "public");
            response.setHeader("Cache-Control", "no-store");
            response.addHeader("Cache-Control", "max-age=0");

            return response.getOutputStream();
        } catch (IOException e) {
            throw new Exception("导出excel表格失败!", e);
        }
    }

    /**
     * 获取转换数据
     */
    private String convertColumnData(JSONObject obj, String pyfileName) {
        //TODO 执行python脚本转化
        try {
            File classPath = new File(URLDecoder.decode(ResourceUtils.getURL("classpath:").getFile(),
                    "utf-8")).getParentFile();
            String classPathStr = classPath.getPath();
            if (classPathStr.contains("file:")) {
                classPath = classPath.getParentFile().getParentFile();
                classPathStr = classPath.getPath().replace("file:", "");
            }
            String pythonPath = "\\" + pyfileName;
            File file = new File(classPathStr, pythonPath);
            //需要系统安装Python配置好环境变量，不然会报错
            String[] arguments = new String[3];
            arguments[0] = "python";
            arguments[1] = file.getPath();
            arguments[2] = obj.toJSONString().replace('\"', '\'');
            String ret = "";
            System.out.println(Arrays.toString(arguments));
            Process process = Runtime.getRuntime().exec(arguments);
            BufferedReader in = new BufferedReader(new InputStreamReader(process.getInputStream(), "GBK"));
            String line = null;
            while ((line = in.readLine()) != null) {
                ret += line;
            }
            in.close();
            int re = process.waitFor();
            InputStream errorStream = process.getErrorStream();
            String str = new String(ByteStreams.toByteArray(errorStream));
            System.out.println(str);
            if (re == 0) {
                return ret;
            } else {
                return "error";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "error";
    }

    /**
     * 构建列名对象
     *
     * @return java.util.List<com.yw.framework.backMgr.dbTableGenerator.domain.bo.TableColsBO>
     * @Author xm
     * @Description 构建列名对象
     * @Date 11:54 2021/12/9
     * @Param [colName：列名]
     **/
    private List<TableColsDTO> buildColName(Map<String, String> colNames) {
        List<TableColsDTO> colsEntities = Lists.newArrayList();
        Set<Map.Entry<String, String>> sets = colNames.entrySet();
        for (Map.Entry<String, String> entry : sets) {
            TableColsDTO colsDTO = new TableColsDTO();
            colsDTO.setDescribes(entry.getValue());
            colsDTO.setColCode(entry.getKey().toUpperCase());
            if (entry.getValue().toUpperCase().trim().contains("LOCATION")
                    || entry.getValue().toUpperCase().trim().contains("FIND")) {
                colsDTO.setColType("TEXT");
            } else {
                colsDTO.setColType("VARCHAR2");
                colsDTO.setColLen(3500);
            }
            if ("ID".equals(entry.getKey().toUpperCase()) || "id".equals(entry.getKey().toUpperCase()) || "TASK_ID".equals(entry.getKey().toUpperCase())) {
                colsDTO.setPk(1);
                colsDTO.setNullAble(0);
                colsDTO.setColType("VARCHAR");
                colsDTO.setColLen(50);
            } else {
                colsDTO.setNullAble(1);
                colsDTO.setPk(0);
            }
            colsEntities.add(colsDTO);
        }
        return colsEntities;
    }

    /**
     * 获取mongodb的表
     */
    public List<String> getMongoTable(String host, Integer port, String username, String database, String pwd) {

        MongoClient mongoClient = getMongoClient(host, port, username, database, pwd);
        //连接到数据库
        MongoDatabase mongoDatabase = mongoClient.getDatabase(database);
        MongoIterable<String> strings = mongoDatabase.listCollectionNames();
        MongoCursor<String> iterator = null;
        try {
            iterator = strings.iterator();
        } catch (Exception e) {
            LOG.error("query mongodb tables fail, exception message: {}", e.getMessage());
            mongoClient.close();
            throw new BusinessException("数据库不存在, 请检查数据源连接信息");
        }
        List<String> tableNameList = new ArrayList<>();
        while (iterator.hasNext()) {
            String next = iterator.next();
            tableNameList.add(next);
        }
        mongoClient.close();
        return tableNameList;
    }

    /**
     * 获取mongodb链接
     */
    private MongoClient getMongoClient(String host, Integer port, String username, String database, String pwd) {
        MongoCredential credential = MongoCredential.createCredential(username, database, pwd.toCharArray());
        MongoClientSettings setting = MongoClientSettings.builder()
                .credential(credential)
                .applyToClusterSettings(builder ->
                        builder.hosts(Arrays.asList(new ServerAddress(host, port)))
                                .mode(ClusterConnectionMode.SINGLE)
                                .requiredClusterType(ClusterType.STANDALONE).serverSelectionTimeout(3, TimeUnit.SECONDS)
                ).build();
        return MongoClients.create(setting);
    }

    /**
     * 检查任务表数据
     */
    private boolean verificationTaskNameContain(String host, Integer port, String username, String databaseName, String taskName, String pwd) {

//        try {
        MongoClient mongoClient = getMongoClient(host, port, username, databaseName, pwd);
        //连接到数据库
        MongoDatabase mongoDatabase = mongoClient.getDatabase(databaseName);

        MongoCollection<Document> collection = mongoDatabase.getCollection(taskName);

        FindIterable<Document> limit = collection.find().limit(1);
        for (Document document : limit) {
            Set<String> tableKeys = document.keySet();
            if ((tableKeys.contains("_id") || tableKeys.contains("ID")) && (tableKeys.contains("task_name") || tableKeys.contains("TASK_NAME"))) {
                mongoClient.close();
                return true;
            }
            break;
        }
        mongoClient.close();
        return false;
    }

}

