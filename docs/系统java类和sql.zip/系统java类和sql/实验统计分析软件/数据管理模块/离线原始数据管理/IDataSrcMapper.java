package com.yw.source.datagather.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yw.source.datagather.entity.DatasrcEntity;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.*;
import java.util.List;

/**
 * @Author: 刘乐法
 * @Description: 数据源mapper
 * @Date: 2021/1/8 14:02
 */
@Mapper
public interface IDataSrcMapper extends BaseMapper<DatasrcEntity> {

    /**
     * @Author 刘乐法
     * @Description 通过主键集合查询名称集合
      * @param ids id集合
     * @Return List<String>
     * @Date 2021/1/21 16:13
     */
    @Select("<script>" +
            "SELECT t.name FROM yw_toses_datasrc t\n" +
            "        WHERE t.id IN\n" +
            "        <foreach collection=\"ids\" index=\"index\" item=\"item\" open=\"(\"\n" +
            "                 separator=\",\" close=\")\">\n" +
            "            #{item}\n" +
            "        </foreach>\n" +
            "        ORDER BY t.name" +
            "</script>")
    List<String> findNameByIds(@Param("ids") List<String> ids);

    /**
     * @Author 刘乐法
     * @Description 通过id集合查询所有信息
      * @param ids id集合
     * @Return
     * @Date 2021/1/21 16:14
     */
    @Select("<script>" +
            "SELECT * FROM yw_toses_datasrc t\n" +
            "        WHERE t.id IN\n" +
            "        <foreach collection=\"ids\" index=\"index\" item=\"item\" open=\"(\"\n" +
            "                 separator=\",\" close=\")\">\n" +
            "            #{item}\n" +
            "        </foreach>" +
            "</script>")
    List<DatasrcEntity> findAllByIds(@Param("ids") List<String> ids);

    /**
     * 根据任务类型修改本地数据源的任务表名称
     * @param type
     * @param taskName
     */
    @Update("<script>" +
            "update yw_toses_datasrc set TASK_NAME = #{taskName} where TASK_TYPE= #{type}" +
            "</script>")
    void updateTaskNameForTaskType(@Param("type") Integer type, @Param("taskName") String taskName);

}
