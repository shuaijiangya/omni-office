package com.yw.source.datagather.mapper;

import com.yw.domain.entity.dataSource.DataTableManagerEntity;
import com.yw.domain.reqeust.dataSource.TableManagerListParam;
import com.yw.domain.vo.dataSource.TableManagerListVO;
import org.apache.ibatis.annotations.*;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * @author zhangkun
 * @date 2022年4月19日10:44:11
 */
@Mapper
public interface DataTableManagerMapper {

    /**
     * 分页查询管理表
     */
    @Select("<script>" +
            "SELECT ID, TABLE_NAME, DATA_SRC_ID, TABLE_CLASSIFY_ID, CREATE_DATE FROM YW_TOSES_DATA_TABLE_MANAGER " +
            "<where>" +
            "<if test='id != null'>AND ID = #{id}</if>" +
            "<if test='tableName != null'><bind name='tableNameLike' value=\"tableName+'%'\"/>AND TABLE_NAME LIKE #{tableNameLike}</if>" +
            "<if test='dataSrcId != null'>AND DATA_SRC_ID = #{dataSrcId}</if>" +
            "<if test='tableClassifyId != null'>AND TABLE_CLASSIFY_ID = #{tableClassifyId}</if>" +
            "</where>" +
            "</script>")
    @Results({
            @Result(column = "ID", property = "id"),
            @Result(column = "TABLE_NAME", property = "tableName"),
            @Result(column = "DATA_SRC_ID", property = "dataSrcId"),
            @Result(column = "TABLE_CLASSIFY_ID", property = "tableClassifyId"),
            @Result(column = "CREATE_DATE", property = "createDate"),
    })
    List<TableManagerListVO> list(TableManagerListParam param);

    /**
     * 查询所有表
     *
     * @param tableClassifyId
     * @param tableName
     * @return
     */
    @Select("<script>" +
            "SELECT ID, TABLE_NAME, DATA_SRC_ID, TABLE_CLASSIFY_ID, CREATE_DATE FROM YW_TOSES_DATA_TABLE_MANAGER  " +
            "<where>" +
            "<if test='tableClassifyId != null'>AND TABLE_CLASSIFY_ID = #{tableClassifyId}</if>" +
            "<if test='tableName != null ' >AND TABLE_NAME like concat('%',#{tableName},'%')</if>" +
            "</where>" +
            "</script>")
    @Results({
            @Result(column = "ID", property = "id"),
            @Result(column = "TABLE_NAME", property = "tableName"),
            @Result(column = "DATA_SRC_ID", property = "dataSrcId"),
            @Result(column = "TABLE_CLASSIFY_ID", property = "tableClassifyId"),
            @Result(column = "CREATE_DATE", property = "createDate"),
    })
    List<TableManagerListVO> showCollect(@Param("tableClassifyId") String tableClassifyId,
                                         @RequestParam("tableName") String tableName);

    /**
     * 根据表名和数据源查询所有表
     *
     * @param tableName
     * @param dataSrcId
     * @return
     */
    @Select("<script>" +
            "SELECT ID, TABLE_NAME, DATA_SRC_ID, TABLE_CLASSIFY_ID, CREATE_DATE FROM YW_TOSES_DATA_TABLE_MANAGER  " +
            "<where>" +
            "<if test='tableName != null'>AND TABLE_NAME = #{tableName}</if>" +
            "<if test='dataSrcId != null'>AND DATA_SRC_ID = #{dataSrcId}</if>" +
            "</where>" +
            "</script>")
    @Results({
            @Result(column = "ID", property = "id"),
            @Result(column = "TABLE_NAME", property = "tableName"),
            @Result(column = "DATA_SRC_ID", property = "dataSrcId"),
            @Result(column = "TABLE_CLASSIFY_ID", property = "tableClassifyId"),
            @Result(column = "CREATE_DATE", property = "createDate"),
    })
    TableManagerListVO selectByTableName(@Param("tableName") String tableName, @Param("dataSrcId") String dataSrcId);

    /**
     * 根据表名和数据源删除表
     *
     * @param tableNames
     * @param dataSrcId
     */
    @Delete(value = "<script>delete from YW_TOSES_DATA_TABLE_MANAGER where TABLE_NAME in " +
            "<foreach item='item' collection='tableNames' index='index' open='( ' separator = ',' close = ' )'>#{item}</foreach>" +
            "<if test='dataSrcId != null'>AND DATA_SRC_ID = #{dataSrcId}</if>" +
            "</script>")
    void deleteByTableNams(@Param("tableNames") List<String> tableNames, @Param("dataSrcId") String dataSrcId);

    /**
     * 获取分类下面所有表
     *
     * @param ClassifyId
     * @return
     */
    @Select(value = "SELECT dtm.ID, dtm.TABLE_NAME, dtm.TABLE_CLASSIFY_ID, tc.CH_NAME " +
            "FROM YW_TOSES_DATA_TABLE_MANAGER dtm LEFT JOIN YW_TOSES_TABLE_CHNAME tc " +
            "ON dtm.DATA_SRC_ID = tc.DATA_SRC_ID AND tc.FLAG = 1 AND dtm.TABLE_NAME = tc.TABLE_NAME " +
            "WHERE TABLE_CLASSIFY_ID = #{ClassifyId}")
    List<DataTableManagerEntity> findByTableClassifyId(String ClassifyId);

    /**
     * 根据数据源删除表
     *
     * @param dataSrcId
     */
    @Delete("<script>" +
            "delete from YW_TOSES_DATA_TABLE_MANAGER where DATA_SRC_ID = #{dataSrcId}" +
            "</script>")
    void deleteByDataSrcId(@Param("dataSrcId") String dataSrcId);
}
