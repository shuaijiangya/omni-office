CREATE TABLE `cd_data_directory` (
  `ID` varchar(255) COLLATE utf8_bin NOT NULL,
  `NAME` varchar(255) COLLATE utf8_bin DEFAULT NULL COMMENT '目录名称',
  `PARENT_ID` varchar(255) COLLATE utf8_bin DEFAULT NULL COMMENT '父目录id',
  `LEAF_NODE_FLAG` tinyint(4) DEFAULT NULL COMMENT '叶子节点标识',
  `MARK` varchar(512) COLLATE utf8_bin DEFAULT NULL COMMENT '扩展',
  `MARK_TYPE` int(11) DEFAULT NULL COMMENT '扩展类型',
  `BUSINESS_KEY` varchar(128) COLLATE utf8_bin DEFAULT NULL COMMENT '业务标识',
  `DIRECTORY_TYPE` varchar(255) COLLATE utf8_bin DEFAULT NULL COMMENT '目录数据类型，用于标识当前目录节点存储的是什么类型的数据，例如当前节点存储的word数据，标识为word；当前节点存储的是视频数据，标识为video',
  `USER_ID` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '用户ID',
  `ROUTING_PATH` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '路由地址',
  `COMPONENT` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `SORT` int(11) DEFAULT NULL COMMENT '排序字段',
  `CREATE_TIME` timestamp NULL DEFAULT NULL,
  `UPDATE_TIME` timestamp NULL DEFAULT NULL,
  `OPERATION_FLAG` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '是否可操作标识 1可以 0不可以',
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=DYNAMIC;