package com.yw.source.importDataDirectory.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.yw.exception.BusinessException;
import com.yw.source.datagather.localInfo.service.IDatasrcService;
import com.yw.source.datagather.req.DirectoryInfo;
import com.yw.source.gatherSchedule.domain.entity.GatherSchemeEntity;
import com.yw.source.gatherSchedule.service.GatherSchemeService;
import com.yw.source.importDataDirectory.entity.DataDirectory;
import com.yw.source.importDataDirectory.entity.ImportTableRecord;
import com.yw.source.importDataDirectory.mapper.DataDirectoryMapper;
import com.yw.source.importDataDirectory.service.IDataDirectoryService;
import com.yw.source.importDataDirectory.service.IImportTableRecordService;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 数据目录service
 *
 * @author xiangyichen
 * @date 2023/7/20 14:12
 */
@Service
public class DataDirectoryServiceImpl implements IDataDirectoryService {

    @Resource
    private DataDirectoryMapper dataDirectoryMapper;

    @Resource
    private IDatasrcService datasrcService;

    @Resource
    private IImportTableRecordService importTableRecordService;
    @Resource
    private GatherSchemeService gatherSchemeService;

    /**
     * 获取树形结构目录
     *
     * @return
     */
    @Override
    public List<Map<String, Object>> getDirectory(String directoryType, String userId, String businessKey) {
        return buildDirectoryTreeV2(new Callback() {
            @Override
            public void call(Map directory, Map<String, List<Map>> childrenMap, List<Map<String, Object>> rootDirectories) {
                String parentId = (String) directory.get("parentId");
                if (parentId.equals("0")) {
                    rootDirectories.add(directory);
                } else {
                    List<Map> children = childrenMap.getOrDefault(parentId, new ArrayList<>());
                    children.add(directory);
                    childrenMap.put(parentId, children);
                }
            }
        }, directoryType, userId, businessKey);
    }

    @Override
    public List<DataDirectory> getDirectoryV2(String directoryType, String userId, String businessKey) {
        Map<String, DataDirectory> nodeMap = new HashMap<>();
        List<DataDirectory> nodes = dataDirectoryMapper.selectList(new QueryWrapper<DataDirectory>()
                .eq(StringUtils.isNotBlank(directoryType), "DIRECTORY_TYPE", directoryType)
                .eq(StringUtils.isNotBlank(businessKey), "BUSINESS_KEY", businessKey)
                .eq(StringUtils.isNotBlank(userId), "USER_ID", userId));
        for (DataDirectory node : nodes) {
            nodeMap.put(node.getId(), node);
        }
        List<DataDirectory> roots = new ArrayList<>();
        for (DataDirectory node : nodes) {
            String parentId = node.getParentId();
            if ("0".equals(parentId)) {
                roots.add(node);
            } else {
                DataDirectory parent = nodeMap.get(parentId);
                if (!Objects.isNull(parent)) {
                    parent.addChild(node);
                }
            }
        }
        return roots;
    }


    @Override
    public List<DataDirectory> listDirectoryLeafNode(String directoryType, String userId, String businessKey) {
        return dataDirectoryMapper.selectList(new QueryWrapper<DataDirectory>()
                .eq("LEAF_NODE_FLAG", true)
                .eq(StringUtils.isNotBlank(directoryType), "DIRECTORY_TYPE", directoryType)
                .eq(StringUtils.isNotBlank(businessKey), "BUSINESS_KEY", businessKey)
                .eq(StringUtils.isNotBlank(userId), "USER_ID", userId));
    }

    @Override
    public List<DataDirectory> listDirectoryRoot(String directoryType, String userId, String businessKey) {
        return dataDirectoryMapper.selectList(new QueryWrapper<DataDirectory>().eq("PARENT_ID", "0")
                .eq(StringUtils.isNotBlank(directoryType), "DIRECTORY_TYPE", directoryType)
                .eq(StringUtils.isNotBlank(businessKey), "BUSINESS_KEY", businessKey)
                .eq(StringUtils.isNotBlank(userId), "USER_ID", userId));
    }

    @Override
    public List<DataDirectory> listAllDirectory(String directoryType, String userId, String businessKey) {
        return dataDirectoryMapper.selectList(new QueryWrapper<DataDirectory>()
                .eq(StringUtils.isNotBlank(directoryType), "DIRECTORY_TYPE", directoryType)
                .eq(StringUtils.isNotBlank(businessKey), "BUSINESS_KEY", businessKey)
                .eq(StringUtils.isNotBlank(userId), "USER_ID", userId));
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public String addDirectory(DataDirectory dataDirectory) throws Exception {

        dataDirectory.setId(UUID.randomUUID().toString());
        dataDirectory.setLeafNodeFlag(true);
        String parentId;

        // 判断是否为根节点
        if (!(parentId = dataDirectory.getParentId()).equals("0")) {
            DataDirectory parentDirectory = dataDirectoryMapper.getById(parentId);

            if (ObjectUtils.isEmpty(parentDirectory)) {
                throw new Exception("新增目录失败, 父目录不存在");
            }

            // 设置父目录的leafNodeFlag为false
            if (parentDirectory.getLeafNodeFlag()) {
                parentDirectory.setLeafNodeFlag(false);
                dataDirectoryMapper.updateById(parentDirectory);
            }
        }

        // 判断目录名是否重复
        boolean isDuplicate = listChildrenNode(parentId).stream().anyMatch(d -> d.getName().equals(dataDirectory.getName()));
        if (isDuplicate) {
            throw new Exception("新增目录失败, 重复节点");
        } else {
            dataDirectoryMapper.insert(dataDirectory);
            return dataDirectory.getId();
        }
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public Integer deleteDirectoryById(String id) throws Exception {

        DataDirectory currentNode = getCurrentNode(id);

        if (ObjectUtils.isEmpty(currentNode)) {
            throw new Exception("目录节点不存在");
        }
        //校验是否有绑定的采集方案和评估方案
        LambdaQueryWrapper<GatherSchemeEntity> lqw = new LambdaQueryWrapper<>();
        lqw.eq(GatherSchemeEntity::getDataSrcId, id);
        List<GatherSchemeEntity> list = gatherSchemeService.list(lqw);
        if (!list.isEmpty()) {
            throw new BusinessException("存在关联的方案无法删除目录");
        }

        List<DataDirectory> children = listAllChildrenNode(id);

        children.add(currentNode);

        dataDirectoryMapper.deleteBatchIds(children.stream().map(DataDirectory::getId).collect(Collectors.toList()));

        // 非根节点更新上级节点的叶子标识
        if (!currentNode.getParentId().equals("0")) {
            DataDirectory parent = dataDirectoryMapper.getById(currentNode.getParentId());
            parent.setLeafNodeFlag(true);
            dataDirectoryMapper.updateById(parent);
        } else {
            // 根节点需要删除绑定的数据库
            JSONObject jsonObject = JSONUtil.parseObj(currentNode.getMark());
            String dataSrcId = jsonObject.getStr("dataSrcId");
            if (StringUtils.isNotEmpty(dataSrcId)) {
                datasrcService.delete(dataSrcId);
            }
        }

        // 找出根节点删除关联的导入记录
        List<DataDirectory> leaves = children.stream().filter(DataDirectory::getLeafNodeFlag).collect(Collectors.toList());
        List<ImportTableRecord> needDeleteRecords = new ArrayList<>();
        for (DataDirectory d : leaves) {
            List<ImportTableRecord> records = importTableRecordService.listRecordBy(d.getId());
            if (CollUtil.isEmpty(records)) {
                continue;
            }
            needDeleteRecords.addAll(records);
        }
        if (CollUtil.isNotEmpty(needDeleteRecords))
            importTableRecordService.deleteRecords(needDeleteRecords);
        return 1;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public Integer deleteAllChildrenDirectory(String currentNodeId) throws Exception {

        DataDirectory currentNode = getCurrentNode(currentNodeId);

        if (ObjectUtils.isEmpty(currentNode)) {
            throw new Exception("目录节点不存在");
        }

        List<DataDirectory> children = listAllChildrenNode(currentNodeId);

        if (!ObjectUtils.isEmpty(children)) {
            dataDirectoryMapper.deleteBatchIds(children.stream().map(DataDirectory::getId).collect(Collectors.toList()));
        }

        // 非根节点更新上级节点的叶子标识
        if (!currentNode.getParentId().equals("0")) {
            DataDirectory parent = dataDirectoryMapper.getById(currentNode.getParentId());
            parent.setLeafNodeFlag(true);
            dataDirectoryMapper.updateById(parent);
        } else {
            // 根节点需要删除绑定的数据库
            JSONObject jsonObject = JSONUtil.parseObj(currentNode.getMark());
            String dataSrcId = jsonObject.getStr("dataSrcId");
            if (StringUtils.isNotEmpty(dataSrcId)) {
                datasrcService.delete(dataSrcId);
            }
        }

        // 找出根节点删除关联的导入记录
        List<DataDirectory> leaves = children.stream().filter(DataDirectory::getLeafNodeFlag).collect(Collectors.toList());
        List<ImportTableRecord> needDeleteRecords = new ArrayList<>();
        for (DataDirectory d : leaves) {
            needDeleteRecords.addAll(importTableRecordService.listRecordByDataDirectoryId(d.getId()));
        }
        importTableRecordService.deleteRecords(needDeleteRecords);
        return 1;
    }

    @Override
    public DataDirectory getById(String id) {
        return dataDirectoryMapper.getById(id);
    }

    @Override
    public Integer updateDirectory(DataDirectory dataDirectory) {
        // 不允许手动更新leafNodeFlag
        DataDirectory directory = dataDirectoryMapper.getById(dataDirectory.getId());
        dataDirectory.setLeafNodeFlag(directory.getLeafNodeFlag());
        return dataDirectoryMapper.updateById(dataDirectory);
    }

    private void setChildren(Map dataDirectory, Map<String, List<Map>> childrenMap) {
        String directoryId = (String) dataDirectory.get("id");
        if (childrenMap.containsKey(directoryId)) {
            List list = (List) JSON.toJSON(dataDirectory.get("children"));
            list.addAll(childrenMap.get(directoryId));
            dataDirectory.put("children", list);
            for (Map child : (List<Map<String, Object>>) dataDirectory.get("children")) {
                setChildren(child, childrenMap);
            }
        }
    }

    @Override
    public List<Map<String, Object>> getDirectoryWithRecordsV2(String directoryType, String userId, String businessKey) {
        return buildDirectoryTreeV2(new Callback() {
            @Override
            public void call(Map directory, Map<String, List<Map>> childrenMap, List<Map<String, Object>> rootDirectories) {
//                String parentId = (String) directory.get("parentId");
//                if ((Byte) directory.get("leafNodeFlag") == 1 ? true : false) {
//                    directory.put("children", importTableRecordService.listRecordByDataDirectoryId((String) directory.get("id"))
//                            .stream()
//                            .map(record -> {
//                                        record.setName(record.getTableName());
//                                        return record;
//                                    }
//                            ).collect(Collectors.toList()));
//                }
//                if (parentId.equals("0")) {
//                    rootDirectories.add(directory);
//                } else {
//                    List<Map> children = childrenMap.getOrDefault(parentId, new ArrayList<>());
//                    children.add(directory);
//                    childrenMap.put(parentId, children);
//                }
                String parentId = (String) directory.get("parentId");
                directory.put("children", importTableRecordService.listRecordByDataDirectoryId((String) directory.get("id"))
                        .stream()
                        .map(record -> {
                                    record.setName(record.getTableName());
                                    return record;
                                }
                        ).collect(Collectors.toList()));
                if (parentId.equals("0")) {
                    rootDirectories.add(directory);
                } else {
                    List<Map> children = childrenMap.getOrDefault(parentId, new ArrayList<>());
                    children.add(directory);
                    childrenMap.put(parentId, children);
                }
            }
        }, directoryType, userId, businessKey);
    }

    @Override
    public List<Map<String, Object>> getDirectoryWithRecords() {
        return buildDirectoryTree(new Callback() {
            @Override
            public void call(Map directory, Map<String, List<Map>> childrenMap, List<Map<String, Object>> rootDirectories) {
//                String parentId = (String) directory.get("parentId");
//                if ((Byte) directory.get("leafNodeFlag") == 1 ? true : false) {
//                    directory.put("children", importTableRecordService.listRecordByDataDirectoryId((String) directory.get("id"))
//                            .stream()
//                            .map(record -> {
//                                        record.setName(record.getTableName());
//                                        return record;
//                                    }
//                            ).collect(Collectors.toList()));
//                }
//                if (parentId.equals("0")) {
//                    rootDirectories.add(directory);
//                } else {
//                    List<Map> children = childrenMap.getOrDefault(parentId, new ArrayList<>());
//                    children.add(directory);
//                    childrenMap.put(parentId, children);
//                }
                String parentId = (String) directory.get("parentId");
                directory.put("children", importTableRecordService.listRecordByDataDirectoryId((String) directory.get("id"))
                        .stream()
                        .map(record -> {
                                    record.setName(record.getTableName());
                                    return record;
                                }
                        ).collect(Collectors.toList()));
                if (parentId.equals("0")) {
                    rootDirectories.add(directory);
                } else {
                    List<Map> children = childrenMap.getOrDefault(parentId, new ArrayList<>());
                    children.add(directory);
                    childrenMap.put(parentId, children);
                }
            }
        });
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void addDirectoryTree(List<DirectoryInfo> directoryInfos) throws Exception {

        Date date = DateUtil.date();
        try {
            for (DirectoryInfo info : directoryInfos) {

                List<String> nodeNames = Arrays.asList(info.getDir().split("/"));
                List<String> markType = Arrays.asList(info.getDirType().split("/"));

                String currentNodeId = nodeNames.get(0);

                // 修改传入根节点
                DataDirectory directory = new DataDirectory();
                directory.setLeafNodeFlag(false);
                directory.setId(currentNodeId);
                directory.setMarkType(Integer.parseInt(markType.get(0)));
                dataDirectoryMapper.updateById(directory);

                List<DataDirectory> needInsertDir = new ArrayList<>();

                for (int i = 1; i < nodeNames.size(); i++) {

                    DataDirectory newDir = new DataDirectory();
                    newDir.setParentId(currentNodeId);
                    newDir.setId(currentNodeId = UUID.randomUUID().toString());
                    newDir.setName(nodeNames.get(i));
                    newDir.setMarkType(Integer.parseInt(markType.get(i)));
                    if (nodeNames.size() - i > 1) {
                        newDir.setLeafNodeFlag(false);
                    } else {
                        newDir.setLeafNodeFlag(true);
                        newDir.setMark(info.getMark());
                    }
                    needInsertDir.add(newDir);
                }
                //已存在的目录不需要进行新增
                ArrayList<DataDirectory> deleteList = new ArrayList<>();
                for (DataDirectory dataDirectory : needInsertDir) {
                    List<DataDirectory> parentDataDirectory = dataDirectoryMapper.selectList(new QueryWrapper<DataDirectory>()
                            .eq("PARENT_ID", dataDirectory.getParentId()));
                    if (!parentDataDirectory.isEmpty()) {
                        for (DataDirectory parentIdDataDirectory : parentDataDirectory) {
                            if (parentIdDataDirectory.getName().equalsIgnoreCase(dataDirectory.getName())) {
                                deleteList.add(dataDirectory);
                            }
                        }
                    }
                }
                for (DataDirectory dataDirectory : deleteList) {
                    needInsertDir.remove(dataDirectory);
                }
                dataDirectoryMapper.insertBatch(needInsertDir);

                List<ImportTableRecord> needInsertRecord = new ArrayList<>();
                List<DirectoryInfo.TableInfo> tableInfos = info.getTableNames();
                for (DirectoryInfo.TableInfo table : tableInfos) {
                    ImportTableRecord importTableRecord = new ImportTableRecord();
                    importTableRecord.setFromId(table.getDataSrcId());
                    importTableRecord.setTableName(table.getTableName());
                    importTableRecord.setFromType(table.getFromType());
                    importTableRecord.setDirectoryId(currentNodeId);
                    importTableRecord.setCreateTime(date);
                    needInsertRecord.add(importTableRecord);
                }
                importTableRecordService.addRecords(needInsertRecord);

            }
        } catch (Exception e) {
            throw new BusinessException("数据导入失败，请检查是否重复导入相同目录名");
        }

    }

    @Override
    public List<Map<String, Object>> getDirectoryTreeNoRound(String directoryType, String userId, String businessKey) {
//        return buildDirectoryTree(new Callback() {
//            @Override
//            public void call(Map directory, Map<String, List<Map>> childrenMap, List<Map<String, Object>> rootDirectories) {
//
//                String parentId = (String) directory.get("parentId");
//                Integer markType = (Integer) directory.get("markType");
//
//                // 抛弃 markType 为scheme的节点
//                if (markType != null && MarkTypeJudge.isScheme(markType) && !MarkTypeJudge.isFilterRound(markType)) {
//                    return;
//                }
//
//                if (markType != null && MarkTypeJudge.isFilterRound(markType)) {
//
//                    List<ImportTableRecord> importTableRecords = new ArrayList<>();
//
//                    List<String> leafNodeIds = listAllChildrenNode((String)directory.get("id"))
//                            .stream().filter(d -> d.getLeafNodeFlag() == true)
//                            .map(DataDirectory::getId)
//                            .collect(Collectors.toList());
//
//                    // 去重
//                    for (String leadNodeId : leafNodeIds) {
//                        importTableRecords.addAll(importTableRecordService.listRecordByDataDirectoryId(leadNodeId).stream().distinct().collect(Collectors.toList()));
//                    }
//
//                    directory.put("children", importTableRecords.stream().map(record -> {
//                                        record.setName(record.getTableName());
//                                        return record;
//                                    }
//                            ).collect(Collectors.toList()));
//                }
//
//                if (parentId.equals("0")) {
//                    rootDirectories.add(directory);
//                } else {
//                    List<Map> children = childrenMap.getOrDefault(parentId, new ArrayList<>());
//                    children.add(directory);
//                    childrenMap.put(parentId, children);
//                }
//            }
//        });
        List<DataDirectory> root = listDirectoryRoot(directoryType, userId, businessKey);
        List<Map<String, Object>> rootTree = new ArrayList<>();
        for (DataDirectory d : root) {
            HashMap<String, Object> newMap = new HashMap<>();
            newMap.put("mark", d.getMark());
            newMap.put("markType", d.getMarkType());
            newMap.put("id", d.getId());
            newMap.put("name", d.getName());
            newMap.put("parentId", d.getParentId());
            newMap.put("leafNodeFlag", d.getLeafNodeFlag());
            String datasourceId = "";
            if (StringUtils.isNotEmpty(d.getMark()) && d.getMark().contains("{")) {
                datasourceId = JSONUtil.parseObj(d.getMark()).getStr("dataSrcId");
            }
            List<ImportTableRecord> importTableRecords = importTableRecordService.listRecordByFromId(datasourceId);
            for (ImportTableRecord importTableRecord : importTableRecords) {
                importTableRecord.setName(importTableRecord.getTableName());
            }
            List<ImportTableRecord> distinctTableName = importTableRecords.stream()
                    .collect(Collectors
                            .collectingAndThen(Collectors.toCollection(() ->
                                            new TreeSet<>(Comparator.comparing(o -> o.getTableName())))
                                    , ArrayList::new));
            newMap.put("children", distinctTableName);
            rootTree.add(newMap);
        }
        return rootTree;

    }

    private List<Map<String, Object>> buildDirectoryTree(Callback callback) {
        List<Map<String, Object>> allDataDirectories = dataDirectoryMapper.selectMaps(new QueryWrapper<DataDirectory>()).stream().map(oldMap -> {
            HashMap<String, Object> newMap = new HashMap<>();
            newMap.put("mark", oldMap.get("MARK"));
            newMap.put("markType", oldMap.get("MARK_TYPE"));
            newMap.put("id", oldMap.get("ID"));
            newMap.put("name", oldMap.get("NAME"));
            newMap.put("parentId", oldMap.get("PARENT_ID"));
            newMap.put("leafNodeFlag", oldMap.get("LEAF_NODE_FLAG"));
            return newMap;
        }).collect(Collectors.toList());

        if (allDataDirectories.isEmpty()) {
            return new ArrayList<>();
        }

        Map<String, List<Map>> childrenMap = new HashMap<>();
        List<Map<String, Object>> rootDirectories = new ArrayList<>();

        // 初始化childrenMap
        for (Map dir : allDataDirectories) {
            callback.call(dir, childrenMap, rootDirectories);
        }

        for (Map map : rootDirectories) {
            setChildren(map, childrenMap);
        }

        return rootDirectories;
    }

    /**
     * 加入目录类型以及用户ID
     *
     * @param callback
     * @param directoryType
     * @param userId
     * @return
     */
    private List<Map<String, Object>> buildDirectoryTreeV2(Callback callback, String directoryType, String userId, String businessKey) {
        List<Map<String, Object>> allDataDirectories = dataDirectoryMapper.selectMaps(new QueryWrapper<DataDirectory>()
                .eq(StringUtils.isNotBlank(directoryType), "DIRECTORY_TYPE", directoryType)
                .eq(StringUtils.isNotBlank(businessKey), "BUSINESS_KEY", businessKey)
                .eq(StringUtils.isNotBlank(userId), "USER_ID", userId)).stream().map(oldMap -> {
            HashMap<String, Object> newMap = new HashMap<>();
            newMap.put("mark", oldMap.get("MARK"));
            newMap.put("markType", oldMap.get("MARK_TYPE"));
            newMap.put("id", oldMap.get("ID"));
            newMap.put("name", oldMap.get("NAME"));
            newMap.put("parentId", oldMap.get("PARENT_ID"));
            newMap.put("leafNodeFlag", oldMap.get("LEAF_NODE_FLAG"));
            return newMap;
        }).collect(Collectors.toList());

        if (allDataDirectories.isEmpty()) {
            return new ArrayList<>();
        }

        Map<String, List<Map>> childrenMap = new HashMap<>();
        List<Map<String, Object>> rootDirectories = new ArrayList<>();

        // 初始化childrenMap
        for (Map dir : allDataDirectories) {
            callback.call(dir, childrenMap, rootDirectories);
        }

        for (Map map : rootDirectories) {
            setChildren(map, childrenMap);
        }

        return rootDirectories;
    }


    interface Callback {
        void call(Map directory, Map<String, List<Map>> childrenMap, List<Map<String, Object>> rootDirectories);
    }

    /**
     * find by id
     *
     * @param dir dir id
     */
    @Override
    public DataDirectory findById(String dir) {
        return dataDirectoryMapper.getById(dir);
    }

    private List<DataDirectory> listAllChildrenNode(String id) {

        List<DataDirectory> children = new ArrayList<>();
        List<String> nodeIds = new ArrayList<>();
        List<String> childNodeIds = new ArrayList<>();
        nodeIds.add(id);
        boolean flag = true;

        while (flag) {
            flag = false;
            for (String nodeId : nodeIds) {
                List<DataDirectory> tmp = listChildrenNode(nodeId);
                if (!ObjectUtils.isEmpty(tmp)) {
                    children.addAll(tmp);
                    childNodeIds.addAll(tmp.stream().map(DataDirectory::getId).collect(Collectors.toList()));
                    flag = true;
                }
            }
            nodeIds.clear();
            nodeIds.addAll(childNodeIds);
            childNodeIds.clear();
        }

        return children;
    }

    private List<DataDirectory> listChildrenNode(String currentDirectoryId) {
        return dataDirectoryMapper.selectList(new QueryWrapper<DataDirectory>().eq("PARENT_ID", currentDirectoryId));
    }

    private DataDirectory getCurrentNode(String currentDirectoryId) {
        return dataDirectoryMapper.getById(currentDirectoryId);
    }
}
