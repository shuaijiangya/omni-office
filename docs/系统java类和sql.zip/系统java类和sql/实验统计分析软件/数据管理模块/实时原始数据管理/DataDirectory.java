package com.yw.source.importDataDirectory.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.Transient;
import java.util.ArrayList;
import java.util.List;

/**
 * 数据目录
 *
 * @author xiangyichen
 * @date 2023/7/20 11:49
 */
@TableName("YW_TOSES_DATA_DIRECTORY")
@ApiModel(value = "数据目录表（构建原始数据管理目录）")
@Data
public class DataDirectory {

    @TableId(value = "ID", type = IdType.ASSIGN_UUID)
    @ApiModelProperty(value = "id", name = "id")
    private String id;

    @TableField(value = "NAME")
    @ApiModelProperty(value = "目录名称", name = "name")
    private String name;

    @TableField(value = "PARENT_ID")
    @ApiModelProperty(value = "父目录id", name = "parentId")
    private String parentId;

    @TableField(value = "LEAF_NODE_FLAG")
    @ApiModelProperty(value = "叶子节点标识", name = "isLeafNode")
    private Boolean leafNodeFlag;

    @TableField(value = "MARK")
    @ApiModelProperty(value = "扩展", name = "mark")
    private String mark;

    @TableField(value = "MARK_TYPE")
    @ApiModelProperty(value = "扩展类型", name = "markType")
    private Integer markType;

    @TableField(value = "BUSINESS_KEY")
    @ApiModelProperty("业务标识")
    private String businessKey;

    @TableField(value = "DIRECTORY_TYPE")
    @ApiModelProperty(value = "目录数据类型，用于标识当前目录节点存储的是什么类型的数据，例如当前节点存储的word数据，标识为word；当前节点存储的是视频数据，标识为video")
    private String directoryType;

    @TableField(value = "USER_ID")
    @ApiModelProperty(value = "用户ID")
    private String userId;

    @TableField(exist = false)
    @ApiModelProperty(value = "子节点", name = "children")
    @Transient
    private List<DataDirectory> children = new ArrayList<>();

    @TableField(exist = false)
    @ApiModelProperty(value = "记录", name = "records")
    @Transient
    private List<ImportTableRecord> records;

    public void addChild(DataDirectory dataDirectory) {
        this.children.add(dataDirectory);
    }

}
