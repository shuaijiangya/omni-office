package com.yw.source.importDataDirectory.mapper;

import com.yw.source.common.mapper.BaseCrudMapper;
import com.yw.source.importDataDirectory.entity.DataDirectory;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * @author xiangyichen
 * @date 2023/7/20 13:48
 */
@Mapper
public interface DataDirectoryMapper extends BaseCrudMapper<DataDirectory> {

    /**
     * 判断是否可以删除
     * @param id
     * @return
     */
    boolean checkById(@Param("id") Integer id);
}
