package com.yw.module.export.handle;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.text.StrBuilder;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.StringPool;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import com.spire.doc.*;
import com.spire.doc.documents.Paragraph;
import com.spire.doc.fields.TextRange;
import com.yw.common.defines.base.FixedColumnVo;
import com.yw.common.defines.base.MergeTablesVo;
import com.yw.common.defines.enums.CalModuleType;
import com.yw.common.defines.enums.SchemaEvaluateType;
import com.yw.common.utils.BuildTree;
import com.yw.common.utils.FileUtil;
import com.yw.common.utils.Node;
import com.yw.common.utils.UUIDGenerator;
import com.yw.framework.backMgr.menu.ISysMenuService;
import com.yw.framework.backMgr.menu.domain.entity.SysMenuEntity;
import com.yw.framework.common.component.word.builder.SectionBuilder;
import com.yw.framework.common.component.word.builder.manager.StyleParagraphEnum;
import com.yw.framework.common.component.word.entity.SingleTable;
import com.yw.framework.common.component.word.helper.DocumentTableHelper;
import com.yw.framework.common.defines.tree.sample.TreeModel;
import com.yw.framework.common.util.spring.SpringUtils;
import com.yw.module.analysis.domain.entity.MiningModelConfigEntity;
import com.yw.module.analysis.domain.entity.MiningResultEntity;
import com.yw.module.analysis.domain.entity.SensitivityAnalysisEntity;
import com.yw.module.analysis.domain.entity.TrendForecastEntity;
import com.yw.module.analysis.domain.request.MiningModelConfigReq;
import com.yw.module.analysis.domain.response.GreyRelationAnalysisResultResp;
import com.yw.module.analysis.domain.response.MiningParamResp;
import com.yw.module.analysis.domain.response.MiningResultResp;
import com.yw.module.analysis.domain.vo.ExploratoryAnalysisVO;
import com.yw.module.analysis.domain.vo.SimpleLinearVO;
import com.yw.module.analysis.mapper.MiningResultMapper;
import com.yw.module.analysis.mapper.SensitivityAnalysisMapper;
import com.yw.module.analysis.service.ITrendForecastService;
import com.yw.module.analysis.service.MiningModelConfigService;
import com.yw.module.analysis.service.SensitivityAnalysisV2Service;
import com.yw.module.analysis.service.StaticsticalAnalysisService;
import com.yw.module.calculation.contributionRate.domain.enums.AttributePropertyEnums;
import com.yw.module.calculation.contributionRate.service.ContributionRateResultService;
import com.yw.module.calculation.contributionRate.service.EffectAndAbilityResultService;
import com.yw.module.calculation.domain.entity.CalcModuleEntity;
import com.yw.module.calculation.domain.enums.PlanSampleMethodType;
import com.yw.module.calculation.domain.vo.EquInvulnerabilityVO;
import com.yw.module.calculation.domain.vo.KeyIndicatorSensitivityResultVO;
import com.yw.module.calculation.service.IEvaluationCalculationService;
import com.yw.module.datasource.domain.enums.CustomizedDataCollectionType;
import com.yw.module.datasource.service.RealTimeCalculateService;
import com.yw.module.equipmentImportance.domain.entity.EquipmentImportanceResult;
import com.yw.module.equipmentImportance.service.EquipmentImportanceResultService;
import com.yw.module.equipmentImportance.service.EquipmentImportanceService;
import com.yw.module.equnode.domain.dto.NetWorkNodeBaseDataDto;
import com.yw.module.equnode.service.AtlasEntityService;
import com.yw.module.export.domain.dto.IndicatorExportNode;
import com.yw.module.indicator.domain.entity.IndicatorEntity;
import com.yw.module.indicator.domain.entity.IndicatorTreeEntity;
import com.yw.module.indicator.service.IIndicatorService;
import com.yw.module.indicator.service.IIndicatorTreeService;
import com.yw.module.missionScene.domain.dto.CompeteSceneDTO;
import com.yw.module.missionScene.domain.entity.CompeteSceneEntity;
import com.yw.module.missionScene.domain.entity.MissionTaskEntity;
import com.yw.module.missionScene.domain.entity.SceneScenarioEntity;
import com.yw.module.missionScene.domain.entity.SidesDirecEntity;
import com.yw.module.missionScene.service.CompeteSceneService;
import com.yw.module.missionScene.service.IMissionTaskService;
import com.yw.module.missionScene.service.SceneScenarioService;
import com.yw.module.missionScene.service.SidesDirecService;
import com.yw.module.plan.domain.dto.ContributionRateExportDTO;
import com.yw.module.plan.domain.entity.SceneEntity;
import com.yw.module.plan.domain.entity.SchemaEntity;
import com.yw.module.plan.domain.req.DDDExportReq;
import com.yw.module.plan.service.ISceneService;
import com.yw.module.plan.service.ISchemaService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.dom4j.Element;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.util.*;
import java.util.stream.Collectors;

/**
 * ddd-场景导出
 */
@Component
@Slf4j
public class DDDExportTemplate extends AbstractReportExportTemplate {


    @Autowired
    private IMissionTaskService missionTaskService;

    @Autowired
    private CompeteSceneService competeSceneService;

    @Autowired
    private ContributionRateResultService contributionRateResultService;

    @Autowired
    private EffectAndAbilityResultService effectAndAbilityResultService;

    @Autowired
    private ISysMenuService sysMenuService;
    @Autowired
    private ITrendForecastService trendForecastService;

    @Autowired
    private SensitivityAnalysisMapper sensitivityAnalysisMapper;

    @Autowired
    private EquipmentImportanceResultService equipmentImportanceResultService;

    @Autowired
    private SceneScenarioService sceneScenarioService;

    @Autowired
    private EquipmentImportanceService equipmentImportanceService;

    @Autowired
    private MiningResultMapper miningResultMapper;

    @Autowired
    private StaticsticalAnalysisService staticsticalAnalysisService;


    @Autowired
    private MiningModelConfigService miningModelConfigService;

    @Autowired
    private AtlasEntityService atlasEntityService;

    @Autowired
    private IEvaluationCalculationService evaluationCalculationService;

    @Autowired
    private SensitivityAnalysisV2Service sensitivityAnalysisV2Service;

    @Autowired
    private IIndicatorTreeService indicatorTreeService;

    @Autowired
    private IIndicatorService indicatorService;

    @Autowired
    private ISceneService sceneService;

    @Autowired
    private RealTimeCalculateService realTimeCalculateService;

    @Autowired
    private ISchemaService schemaService;


    @Value("${pg-general.module.indicator-calculation.basic-file-path}")
    private String basicFilePath;


    private final static String DEFAULT_STR = "暂无";


    public void doExport(Document document, HttpServletResponse response, SectionBuilder sectionBuilder, SchemaEntity entity, DDDExportReq req, List<SceneScenarioEntity> list, CompeteSceneEntity competeSceneEntity) {
        //设置文档内容
        setDocument(document, sectionBuilder, entity, req, list, competeSceneEntity);
        if (ObjectUtil.isNull(req.getIsPreview()) || req.getIsPreview() == 0) {
            // 导出
            abstractDoExportV2(response, document, req, competeSceneEntity);
        } else {
            //预览
            documentPreview(document, response);
        }

    }

    private void setDocument(Document document, SectionBuilder sectionBuilder, SchemaEntity entity, DDDExportReq req, List<SceneScenarioEntity> list, CompeteSceneEntity competeSceneEntity) {
        String optimizationSuggestion = req.getOptimizationSuggestion();
        if (StrUtil.isEmpty(optimizationSuggestion)) {
            log.error("");
            return;
        }
        List<IndicatorEntity> abilityIndicatorLists = Lists.newArrayList();
        List<IndicatorEntity> efficacyIndicatorLists = Lists.newArrayList();

        //菜单
        List<TreeModel> menus = sysMenuService.list(new SysMenuEntity());
        List<Map<String, Object>> optimizationSuggestionList = JSONObject.parseObject(optimizationSuggestion, new TypeReference<List<Map<String, Object>>>() {
        });
        if (CollUtil.isEmpty(optimizationSuggestionList)) {
            return;
        }
        //获取所有导出模块
        List<String> names = optimizationSuggestionList.stream().map(item -> String.valueOf(item.get("name"))).collect(Collectors.toList());
        int num = 1;
        for (int i = 0; i < menus.size(); i++) {
            if (!names.contains(menus.get(i).getName())) {
                continue;
            }
            // 一级标题设置
            wordChapterTitle(num, menus.get(i).getName(), sectionBuilder);
            switch (i) {
                case 0:
                    // 1：作战场景构建
                    builderCompeteSceneAndMissTask(document, sectionBuilder, entity.getId(), req, list);
                    // 2：评估报告
                    // 标题
                    wordTitle(sectionBuilder);
                    // 方案
                    // 指标
                    indicatorExport(sectionBuilder, 1, entity.getId(), "1.2.1", abilityIndicatorLists, efficacyIndicatorLists);
                    // 评估样本结构
                    sceneStructureExport(sectionBuilder, 1, entity.getId(), abilityIndicatorLists, efficacyIndicatorLists, "1.2.2");
                    // 评估结果与结论  子类方法
                    resultAndConclusionComplexExport(document, sectionBuilder, 1, entity, "1.3", competeSceneEntity,
                            list, abilityIndicatorLists, efficacyIndicatorLists);
                    break;
                case 1:
                    //趋势预测
                    builderTrendForecast(req.getSid(), num, sectionBuilder);
                    break;
                case 2:
                    //灵敏度
                    builderSensitivityResult(req.getSid(), num, sectionBuilder);
                    break;
                case 3:
                    //边界探索
                    builderBoundExploreResult(req.getSid(), num, sectionBuilder);
                    break;
                case 4:
                    //重要度
                    builderImportanceDegreeResult(req.getSid(), num, sectionBuilder);
                    break;
                case 5:
                    //关联关系挖掘
                    builderAssociationMiningResult(req.getSid(), num, sectionBuilder);
                    break;
                case 6:
                    //抗毁性
                    builderSurvivability(req.getSid(), num, sectionBuilder);
                    break;
                case 7:
                    //优化建议
                    optimizationSuggestion(sectionBuilder, 1, entity.getId(), abilityIndicatorLists, efficacyIndicatorLists, optimizationSuggestionList, num);

            }
            num++;
        }
    }

    private void builderBoundExploreResult(String sid, int num, SectionBuilder sectionBuilder) {
        //二级标题
        sectionBuilder.addParagraph(num + ".1 边界条件与指标异常", StyleParagraphEnum.HEADING_2.getCode());


        List<ExploratoryAnalysisVO> exploratoryAnalysisVOS = staticsticalAnalysisService.exportAnalysisResultV2(sid);
        sectionBuilder.addText("探索与分析结论：");
        if (CollectionUtil.isEmpty(exploratoryAnalysisVOS)) {
            sectionBuilder.addText("无");
        } else {
            for (ExploratoryAnalysisVO exploratoryAnalysisVO : exploratoryAnalysisVOS) {
                List<SimpleLinearVO> simpleLinearVOList = exploratoryAnalysisVO.getSimpleLinearVOList();
                for (SimpleLinearVO simpleLinearVO : simpleLinearVOList) {
                    sectionBuilder.addText(simpleLinearVO.getOverallConclusion());
                }
            }
        }

        sectionBuilder.addParagraph(num + ".2 关键因素统计与数据分布探索", StyleParagraphEnum.HEADING_2.getCode());
        sectionBuilder.addText("数据分布分析结论：");
        if (CollectionUtil.isEmpty(exploratoryAnalysisVOS)) {
            sectionBuilder.addText("无");
        } else {
            for (ExploratoryAnalysisVO exploratoryAnalysisVO : exploratoryAnalysisVOS) {
                List<SimpleLinearVO> simpleLinearVOList = exploratoryAnalysisVO.getSimpleLinearVOList();
                for (SimpleLinearVO simpleLinearVO : simpleLinearVOList) {
                    sectionBuilder.addText(simpleLinearVO.getDataConclusion());
                }
            }
        }

        //sectionBuilder.addParagraph(num+".3 最优取值区间探索", StyleParagraphEnum.HEADING_2.getCode());
        //staticsticalAnalysisService.e
        //文本描述

    }

    /**
     * 文件预览
     */
    private void documentPreview(Document document, HttpServletResponse response) {
        //将Document保存到内存流，格式为PDF

        //设置响应头
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "inline; filename=preview.pdf");
        //写入输出流
        try {
            document.saveToStream(response.getOutputStream(), FileFormat.PDF);
            document.dispose();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    /**
     * 导出体系抗毁性
     *
     * @param sid 方案id
     * @param num 标题num
     */
    private void builderSurvivability(String sid, int num, SectionBuilder sectionBuilder) {
        //二级标题7.1
        sectionBuilder.addParagraph(num + ".1 装备节点复杂网络", StyleParagraphEnum.HEADING_2.getCode());
        //文本描述
        NetWorkNodeBaseDataDto netWorkNodeBaseData = atlasEntityService.netWorkNodeBaseData(sid);
        sectionBuilder.addText("装备节点复杂网络包括侦察类装备数量" + netWorkNodeBaseData.getUnmannedNum() + "件、指控类装备数量" + netWorkNodeBaseData.getEffectNum() + "件、打击类装备数量" + netWorkNodeBaseData.getSenseNum() + "件，共计形成杀伤链数" + netWorkNodeBaseData.getSslNum() + "条。这些装备形成的复杂网络如下图所示：");
        File file = new File(basicFilePath + FileUtil.INDICATOR_IMAGE + sid + "-装备节点复杂网络.jpg");
        if (file.exists()) {
            sectionBuilder.addImage(basicFilePath + FileUtil.INDICATOR_IMAGE + sid + "-装备节点复杂网络.jpg", 300, 400);
        }
        //二级标题7.2
        sectionBuilder.addParagraph(num + ".2 抗毁性评估指标体系", StyleParagraphEnum.HEADING_2.getCode());
        List<IndicatorEntity> invulnerabilityIndicatorLists = Lists.newArrayList();
        List<IndicatorExportNode> efficacyIndicatorExportNode = getIndicatorExportNode(sid, invulnerabilityIndicatorLists, CustomizedDataCollectionType.INVULNERABILITY.id);
        // 表格数据
        setMergeTable(sectionBuilder, efficacyIndicatorExportNode);

        //二级标题7.3
        sectionBuilder.addParagraph(num + ".3 体系抗毁性评估结果", StyleParagraphEnum.HEADING_2.getCode());
        setPGResultTable(sid, null, sectionBuilder, CustomizedDataCollectionType.INVULNERABILITY.id);


        //二级标题7.4
        sectionBuilder.addParagraph(num + ".4 装备损毁后对体系抗毁性影响分析", StyleParagraphEnum.HEADING_2.getCode());
        try {
            EquInvulnerabilityVO equInvulnerabilityVO = evaluationCalculationService.calculateEquInvulnerabilityRandom(sid, null);
            if (CollUtil.isNotEmpty(equInvulnerabilityVO.getEquNameList()) && CollUtil.isNotEmpty(equInvulnerabilityVO.getSslNumberList()) && CollUtil.isNotEmpty(equInvulnerabilityVO.getEquInvulnerabilityList())) {
                SingleTable singleTable = new SingleTable();
                //获取表列数
                singleTable.col = 3;
                //获取表行数
                singleTable.row = equInvulnerabilityVO.getEquNameList().size() + 1;
                //表头
                List<String> tableCol = Lists.newArrayList();
                tableCol.add("损毁ZB");
                tableCol.add("SSL数量");
                tableCol.add("体系抗毁性评估值");
                //表数据
                List<List<String>> data = Lists.newArrayList();
                for (int i = 0; i < equInvulnerabilityVO.getEquNameList().size(); i++) {
                    List<String> row = Lists.newArrayList();
                    row.add(equInvulnerabilityVO.getEquNameList().get(i));
                    row.add(String.valueOf(equInvulnerabilityVO.getSslNumberList().get(i)));
                    row.add(equInvulnerabilityVO.getEquInvulnerabilityList().get(i));
                    data.add(row);
                }
                singleTable.firstTableCol = tableCol;
                singleTable.rowData = data;
                sectionBuilder.addTableAndNotMerge(singleTable);
            }
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }

    /**
     * 添加评估结果表格
     */
    private void setPGResultTable(String sid, String sceneId, SectionBuilder sectionBuilder, int type) {
        try {
            MergeTablesVo mergeTablesVo = evaluationCalculationService.getTable(sid, sceneId, type);
            //获取表头
            List<FixedColumnVo> fixedColumn = mergeTablesVo.getFixedColumn();
            //获取表数据
            List<Map<String, Object>> listData = mergeTablesVo.getListData();
            if (CollUtil.isNotEmpty(fixedColumn) && CollUtil.isNotEmpty(listData)) {
                SingleTable singleTable = new SingleTable();
                //获取表列数
                singleTable.col = fixedColumn.size();
                //获取表行数
                singleTable.row = listData.size() + 1;
                //表头
                List<String> tableCol = Lists.newArrayList();
                for (FixedColumnVo fixedColumnVo : fixedColumn) {
                    tableCol.add(fixedColumnVo.getLabel());
                }
                //表数据
                List<List<String>> data = Lists.newArrayList();
                for (Map<String, Object> listDatum : listData) {
                    List<String> row = Lists.newArrayList();
                    for (FixedColumnVo fixedColumnVo : fixedColumn) {
                        row.add(String.valueOf(listDatum.get(fixedColumnVo.getProp())));
                    }
                    data.add(row);
                }
                singleTable.firstTableCol = tableCol;
                singleTable.rowData = data;
                sectionBuilder.addTable(singleTable);
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
        }
    }

    /**
     * 关联关系挖掘导出
     *
     * @param sid
     * @param num
     * @param sectionBuilder
     */
    private void builderAssociationMiningResult(String sid, int num, SectionBuilder sectionBuilder) {
        sectionBuilder.addParagraph(num + ".1 关联关系挖掘数据如下所示", StyleParagraphEnum.HEADING_2.getCode());
        MiningModelConfigEntity miningModelConfig = miningModelConfigService.getOne(new LambdaQueryWrapper<MiningModelConfigEntity>().eq(MiningModelConfigEntity::getSid, sid));
        if (miningModelConfig == null) {
            sectionBuilder.addText("无");
        } else {
            MiningModelConfigReq req = new MiningModelConfigReq();
            req.setSid(sid);
            req.setMiningModel(miningModelConfig.getMiningModel());
            req.setIndicatorIntervalConfig(JSON.parseArray(miningModelConfig.getIndicatorInterval(), MiningModelConfigReq.IntervalConfig.class));
            req.setIndicatorParamIntervalConfig(JSON.parseArray(miningModelConfig.getIndicatorParamInterval(), MiningModelConfigReq.IntervalConfig.class));
            JSONObject sampleData = staticsticalAnalysisService.getSampleData(req);
            JSONArray tableHeader = sampleData.getJSONArray("tableHeader");
            JSONArray tableData = sampleData.getJSONArray("tableData");

            SingleTable singleTable = new SingleTable();
            singleTable.firstTableCol = new ArrayList<>();
            singleTable.row = tableData.size();
            singleTable.col = 5;
            for (int i = 0; i < tableHeader.size(); i++) {
                singleTable.firstTableCol.add(tableHeader.getJSONObject(i).getString("label"));
            }
            List<List<String>> datas = new ArrayList<>();
            for (int i = 0; i < tableData.size(); i++) {
                List<String> data = new ArrayList<>();
                for (int j = 0; j < tableHeader.size(); j++) {
                    data.add(String.valueOf(tableData.getJSONObject(i).get(tableHeader.getJSONObject(j).getString("prop"))));
                }
                datas.add(data);
            }
            singleTable.rowData = datas;
            sectionBuilder.addTableAndNotMerge(singleTable);
        }


        MiningParamResp miningThresholdConfig = staticsticalAnalysisService.getMiningThresholdConfig();
        sectionBuilder.addText("当支持度、置信度和提升度分别设置为" + miningThresholdConfig.getSupportThreshold() + "、" + miningThresholdConfig.getConfidenceThreshold() + "和" + miningThresholdConfig.getImproveThreshold() + "时，二项集和三项集结果如下所示：");

        List<MiningResultResp.ItemSet> threeItemSets = null;
        sectionBuilder.addParagraph(num + ".2 二项集关联关系数据表", StyleParagraphEnum.HEADING_2.getCode());
        MiningResultEntity miningResultEntity = miningResultMapper.selectOne(new LambdaQueryWrapper<MiningResultEntity>().eq(MiningResultEntity::getSid, sid).last("limit 1"));
        if (miningResultEntity != null && com.yw.framework.common.util.StringUtils.isNotEmpty(miningResultEntity.getResult())) {
            MiningResultResp miningResultResp = JSON.parseObject(miningResultEntity.getResult(), MiningResultResp.class);
            List<MiningResultResp.ItemSet> twoItemSets = miningResultResp.getTwoItemSets();
            threeItemSets = miningResultResp.getThreeItemSets();

            if (CollectionUtil.isNotEmpty(twoItemSets)) {
                //只导出前20条
                twoItemSets = twoItemSets.subList(0, Math.min(twoItemSets.size(), 20));
                List<List<String>> datas = new ArrayList<>();
                for (MiningResultResp.ItemSet itemSet : twoItemSets) {
                    List<String> data = new ArrayList<>();
                    data.add(itemSet.getRelationship());
                    data.add(String.valueOf(itemSet.getSupport()));
                    data.add(String.valueOf(itemSet.getConfidence()));
                    data.add(String.valueOf(itemSet.getImprove()));
                    data.add(String.valueOf(itemSet.getExplain()));
                    datas.add(data);
                }
                SingleTable singleTable = new SingleTable();
                singleTable.firstTableCol = Arrays.asList("关联关系", "支持度", "置信度", "提升度", "说明");
                singleTable.row = twoItemSets.size();
                singleTable.col = 5;
                singleTable.rowData = datas;
                sectionBuilder.addTableAndNotMerge(singleTable);
            } else {
                sectionBuilder.addText("无");
            }
        } else {
            sectionBuilder.addText("无");
        }
        sectionBuilder.addParagraph(num + ".3 三项集关联关系数据表", StyleParagraphEnum.HEADING_2.getCode());
        if (CollectionUtil.isNotEmpty(threeItemSets)) {
            threeItemSets = threeItemSets.subList(0, Math.min(threeItemSets.size(), 20));
            List<List<String>> datas = new ArrayList<>();
            for (MiningResultResp.ItemSet itemSet : threeItemSets) {
                List<String> data = new ArrayList<>();
                data.add(itemSet.getRelationship());
                data.add(String.valueOf(itemSet.getSupport()));
                data.add(String.valueOf(itemSet.getConfidence()));
                data.add(String.valueOf(itemSet.getImprove()));
                data.add(String.valueOf(itemSet.getExplain()));
                datas.add(data);
            }
            SingleTable singleTable = new SingleTable();
            singleTable.firstTableCol = Arrays.asList("关联关系", "支持度", "置信度", "提升度", "说明");
            singleTable.row = threeItemSets.size();
            singleTable.col = 5;
            singleTable.rowData = datas;
            sectionBuilder.addTableAndNotMerge(singleTable);
        } else {
            sectionBuilder.addText("无");
        }
        sectionBuilder.addText("指标间的关系强弱程度如下表所示：");

        GreyRelationAnalysisResultResp greyRelationAnalysisResultResp = staticsticalAnalysisService.greyCorrelationAnalysis(sid);
        if (greyRelationAnalysisResultResp != null && greyRelationAnalysisResultResp.getHeaders() != null && greyRelationAnalysisResultResp.getData() != null) {
            List<GreyRelationAnalysisResultResp.Header> headers = greyRelationAnalysisResultResp.getHeaders();
            List<Map<String, Object>> tableData = greyRelationAnalysisResultResp.getData();
            SingleTable singleTable = new SingleTable();
            singleTable.firstTableCol = new ArrayList<>();
            singleTable.row = tableData.size();
            singleTable.col = 5;
            for (int i = 0; i < headers.size(); i++) {
                singleTable.firstTableCol.add(headers.get(i).getLabel());
            }
            List<List<String>> datas = new ArrayList<>();
            for (int i = 0; i < tableData.size(); i++) {
                List<String> data = new ArrayList<>();
                for (int j = 0; j < headers.size(); j++) {
                    data.add(String.valueOf(tableData.get(i).get(headers.get(j).getProp())));
                }
                datas.add(data);
            }
            singleTable.rowData = datas;
            sectionBuilder.addTable(singleTable);
        } else {
            sectionBuilder.addText("无");
        }
    }

    /**
     * 装备重要性导出
     *
     * @param sid
     * @param num
     * @param sectionBuilder
     */
    private void builderImportanceDegreeResult(String sid, int num, SectionBuilder sectionBuilder) {

        SceneScenarioEntity sceneScenarioEntity = sceneScenarioService.getOne(new LambdaQueryWrapper<SceneScenarioEntity>().eq(SceneScenarioEntity::getSid, sid).last("limit 1"));


        List<EquipmentImportanceResult> list = equipmentImportanceResultService.list(new LambdaQueryWrapper<EquipmentImportanceResult>()
                .eq(EquipmentImportanceResult::getScenarioId, sceneScenarioEntity.getId()));
        sectionBuilder.addText("装备节点网络图");
        File file = new File(basicFilePath + FileUtil.INDICATOR_IMAGE + sid + "-装备节点网络图.jpg");
        if (file.exists()) {
            sectionBuilder.addImage(basicFilePath + FileUtil.INDICATOR_IMAGE + sid + "-装备节点网络图.jpg", 300, 400);
        }
        sectionBuilder.addText("装备节点重要度评估计算结果");

        List<List<String>> datas = new ArrayList<>();
        for (EquipmentImportanceResult equipmentImportanceResult : list) {
            List<String> data = new ArrayList<>();
            data.add(equipmentImportanceResult.getNodeName());
            data.add(String.valueOf(equipmentImportanceResult.getImportance()));
            data.add(String.valueOf(equipmentImportanceResult.getDcValue()));
            data.add(String.valueOf(equipmentImportanceResult.getBcValue()));
            data.add(String.valueOf(equipmentImportanceResult.getCcValue()));
            datas.add(data);
        }
        SingleTable singleTable = new SingleTable();
        singleTable.firstTableCol = Arrays.asList("节点", "重要度", "度中心性", "介数中心性", "接近中心性");
        singleTable.row = list.size();
        singleTable.col = 5;
        singleTable.rowData = datas;
        if (CollectionUtil.isEmpty(list)) {
            sectionBuilder.addText("无");
        } else {
            sectionBuilder.addTableAndNotMerge(singleTable);
        }

        sectionBuilder.addText("重要度分析结论");
        if (CollectionUtil.isEmpty(list)) {
            sectionBuilder.addText("无");
        } else {
            List<String> conclusion = equipmentImportanceService.getConclusion(sceneScenarioEntity.getId());
            for (String s : conclusion) {
                sectionBuilder.addText(s);
            }
        }

    }

    private void builderSensitivityResult(String sid, int num, SectionBuilder sectionBuilder) {
        sectionBuilder.addParagraph(num + ".1 装备数量灵敏度分析", StyleParagraphEnum.HEADING_2.getCode());
        SensitivityAnalysisEntity result = sensitivityAnalysisV2Service.getSensitivityAnalysis(sid, 2);
        if (result != null && ObjectUtil.isNotNull(result.getResultVO()) && CollUtil.isNotEmpty(result.getResultVO().getResultVOS())) {
            List<KeyIndicatorSensitivityResultVO> resultVOS = result.getResultVO().getResultVOS();
            SingleTable singleTable = new SingleTable();
            //获取表列数
            singleTable.col = 2;
            //获取表行数
            singleTable.row = resultVOS.size() + 1;
            //表头
            List<String> tableCol = Lists.newArrayList();
            tableCol.add("装备名称");
            tableCol.add("装备数量");
            //表数据
            List<List<String>> data = Lists.newArrayList();
            for (KeyIndicatorSensitivityResultVO resultVO : resultVOS) {
                List<String> row = Lists.newArrayList();
                row.add(resultVO.getColumn());
                row.add(String.valueOf(resultVO.getResultVOS().get(resultVO.getLightIndex()).getKeyValue()));
                data.add(row);
            }
            singleTable.firstTableCol = tableCol;
            singleTable.rowData = data;
            sectionBuilder.addTable(singleTable);

            String analysisResult = result.getAnalysisResult();
            if (com.yw.framework.common.util.StringUtils.isNotEmpty(analysisResult)) {
                JSONObject analysisResultJsonobject = JSON.parseObject(analysisResult);
                String conclusion = analysisResultJsonobject.getString("conclusion");
                if (com.yw.framework.common.util.StringUtils.isNotEmpty(conclusion)) {
                    sectionBuilder.addText("结论：");
                    sectionBuilder.addText(conclusion);
                }

            }
        }
        sectionBuilder.addParagraph(num + ".2 关键指标灵敏度分析", StyleParagraphEnum.HEADING_2.getCode());
        SensitivityAnalysisEntity sensitivityAnalysisEntity = sensitivityAnalysisMapper.selectOne(new LambdaQueryWrapper<SensitivityAnalysisEntity>()
                .eq(SensitivityAnalysisEntity::getSid, sid).orderByDesc(SensitivityAnalysisEntity::getCreateTime)
                .last("limit 1"));
        if (sensitivityAnalysisEntity != null) {
            String analysisResult = sensitivityAnalysisEntity.getAnalysisResult();
            JSONObject jsonObject = JSON.parseObject(analysisResult);
            String conclusion = jsonObject.getString("conclusion");
            sectionBuilder.addText(conclusion);
        } else {
            sectionBuilder.addText("无");
        }
    }

    private void builderTrendForecast(String sid, int num, SectionBuilder sectionBuilder) {

        List<TrendForecastEntity> list = trendForecastService.list(new LambdaQueryWrapper<TrendForecastEntity>()
                .eq(TrendForecastEntity::getSid, sid)
                .orderByDesc(TrendForecastEntity::getCreateTime)
        );
        sectionBuilder.addParagraph(num + ".1 自回归", StyleParagraphEnum.HEADING_2.getCode());
        Optional<TrendForecastEntity> autoregression = list.stream().filter(t -> t.getSampleMethodType().equals(PlanSampleMethodType.AUTOREGRESSION.getName())).findFirst();
        if (autoregression.isPresent()) {
            JSONObject jsonObject = JSON.parseObject(autoregression.get().getResult());
            String regressionEquation = jsonObject.getJSONObject("resultJsonStr").getString("regressionEquation");
            String desc = jsonObject.getJSONArray("params").getJSONObject(0).getString("desc");
            sectionBuilder.addText(desc + "为关键指标名称。回归方程如下所示：");
            sectionBuilder.addText(regressionEquation.trim());

            JSONArray conclusions = jsonObject.getJSONObject("resultAll").getJSONArray("conclusionLists");
            if (conclusions != null) {
                SingleTable singleTable = new SingleTable();
                sectionBuilder.addText("结论：");
                for (int i = 0; i < conclusions.size(); i++) {
                    Object o = conclusions.get(i);

                    if (i == 0) {
                        sectionBuilder.addText(o.toString());
                        continue;
                    }
                    String str = o.toString();

                    if (i == 2) {
                        // 组装成一个表格
                        str = str.substring(str.indexOf("【") + 1, str.indexOf("】"));
                        String[] split = str.split(",");
                        // 预测数据
                        // 表格数据
                        singleTable.firstTableCol = Lists.newArrayList("序号", "预测值");
                        singleTable.col = 2;
                        singleTable.row = split.length + 1;
                        singleTable.rowData = new ArrayList<>();
                        for (int i1 = 0; i1 < split.length; i1++) {
                            singleTable.rowData.add(Lists.newArrayList((i1 + 1) + "", split[i1]));
                        }
                        continue;
                    }
                    str = str.substring(1);
                    sectionBuilder.addText((i == 1 ? i : i - 1) + str.trim());

                }
                sectionBuilder.addText("对未来"+desc+"的预测值如下表格所示：");
                sectionBuilder.addTable(singleTable);

            }
        } else {
            sectionBuilder.addText("无");
        }

        sectionBuilder.addText("");
        //sectionBuilder.addText("X为关键指标名称，y为效能指标名称。回归方程如下所示：");
        sectionBuilder.addParagraph(num + ".2 一元线性回归", StyleParagraphEnum.HEADING_2.getCode());
        setRegressionResultDocx(PlanSampleMethodType.SIMPLE_LINEAR.getName(), list, sectionBuilder);
        sectionBuilder.addText("");
        sectionBuilder.addParagraph(num + ".3 多元线性回归", StyleParagraphEnum.HEADING_2.getCode());
        setRegressionResultDocx(PlanSampleMethodType.MULTIPLE_LINEAR.getName(), list, sectionBuilder);
        sectionBuilder.addText("");
        sectionBuilder.addParagraph(num + ".4 二元逻辑回归", StyleParagraphEnum.HEADING_2.getCode());
        setRegressionResultDocx(PlanSampleMethodType.BINARY_LOGISTIC.getName(), list, sectionBuilder);
        sectionBuilder.addText("");
        sectionBuilder.addParagraph(num + ".5 多元逻辑回归", StyleParagraphEnum.HEADING_2.getCode());
        setRegressionResultDocx(PlanSampleMethodType.MULTIVARIATE_LOGISTIC.getName(), list, sectionBuilder);
        sectionBuilder.addText("");
        sectionBuilder.addParagraph(num + ".6 BP神经网络", StyleParagraphEnum.HEADING_2.getCode());
        setRegressionResultDocx(PlanSampleMethodType.APSO_BPLearn.getName(), list, sectionBuilder);
        sectionBuilder.addText("");
    }

    private void setRegressionResultDocx(String name, List<TrendForecastEntity> list, SectionBuilder sectionBuilder) {
        Optional<TrendForecastEntity> regression = list.stream().filter(t -> t.getSampleMethodType().equals(name)).findFirst();
        if (regression.isPresent()) {
            JSONObject jsonObject = JSON.parseObject(regression.get().getResult());
            String regressionEquation = jsonObject.getJSONObject("resultJsonStr").getString("regressionEquation");
            if (com.yw.framework.common.util.StringUtils.isEmpty(regressionEquation)) {
                regressionEquation = jsonObject.getJSONObject("resultJsonStr").getString("equation");
            }
            JSONArray params = jsonObject.getJSONArray("params");
            String param = "";
            String indicator = "";
            for (int i = 0; i < params.size(); i++) {
                String type = params.getJSONObject(i).getString("type");
                String desc = params.getJSONObject(i).getString("desc");
                if ("DEPENDENT".equals(type)) {
                    if (com.yw.framework.common.util.StringUtils.isEmpty(indicator)) {
                        indicator = desc;
                    } else {
                        indicator = indicator + "," + desc;
                    }
                } else {
                    if (com.yw.framework.common.util.StringUtils.isEmpty(param)) {
                        param = desc;
                    } else {
                        param = param + "," + desc;
                    }
                }
            }

            if (!PlanSampleMethodType.MULTIVARIATE_LOGISTIC.getName().equals(name)) {
                sectionBuilder.addText(param + "为关键指标名称，" + indicator + "为效能指标名称。回归方程如下所示：");
                sectionBuilder.addText(regressionEquation.trim());
            } else {
                sectionBuilder.addText(param + "为关键指标名称，" + indicator + "为效能指标名称。");
            }

            JSONArray conclusions = jsonObject.getJSONObject("resultAll").getJSONArray("conclusions");
            if (conclusions != null) {
                sectionBuilder.addText("结论：");
                for (Object conclusion : conclusions) {
                    sectionBuilder.addText(conclusion.toString().trim());
                }
            }

        } else {
            sectionBuilder.addText("无");
        }
    }

    /**
     * 章节大标题设置
     *
     * @param num            章节编号
     * @param name           章节名称
     * @param sectionBuilder
     */
    private void wordChapterTitle(int num, String name, SectionBuilder sectionBuilder) {
        sectionBuilder.addParagraph(num + " " + name, StyleParagraphEnum.HEADING_1.getCode());
    }


    /**
     * 优化建议
     */
    private void optimizationSuggestion(SectionBuilder sectionBuilder, int isShow, String id, List<IndicatorEntity> abilityIndicatorLists, List<IndicatorEntity> efficacyIndicatorLists, List<Map<String, Object>> optimizationSuggestionList, int number) {
        if (isShow == 1) {
            //优化建议
            //sectionBuilder.addParagraph(number + " 优化建议", StyleParagraphEnum.HEADING_2.getCode());
            //导出表格
//            List<Map<String, Object>> optimizationSuggestionList = JSONObject.parseObject(optimizationSuggestion, new TypeReference<List<Map<String, Object>>>() {
//            });
            SingleTable singleTable = new SingleTable();
            //列数
            singleTable.col = 3;
            //行数
            singleTable.row = optimizationSuggestionList.size() + 1;
            //表头
            List<String> tableCol = Lists.newArrayList();
            tableCol.add("序号");
            tableCol.add("分析内容");
            tableCol.add("优化建议");
            // 获取表数据 每一行
            List<List<String>> data = Lists.newArrayList();
            for (int i = 0; i < optimizationSuggestionList.size(); i++) {
                List<String> row = Lists.newArrayList();
                Map<String, Object> stringObjectMap = optimizationSuggestionList.get(i);
                row.add(String.valueOf(i + 1));
                row.add(stringObjectMap.get("name").toString());
                if (stringObjectMap.get("suggestion") != null) {
                    JSONArray jsonArray = ((JSONArray) stringObjectMap.get("suggestion"));
                    StrBuilder strBuilder = new StrBuilder();
                    for (Object value : jsonArray) {
                        strBuilder.append(value).append(StringPool.CRLF);
                    }
                    row.add(strBuilder.toString());
                }
                data.add(row);
            }
            singleTable.firstTableCol = tableCol;
            singleTable.rowData = data;
            sectionBuilder.addTable(singleTable);
        }
    }

    public void resultAndConclusionComplexExport(Document document, SectionBuilder sectionBuilder, int isShow, SchemaEntity schema, String number,
                                                 CompeteSceneEntity competeSceneEntity, List<SceneScenarioEntity> sceneScenarioEntities,
                                                 List<IndicatorEntity> abilityIndicatorLists,
                                                 List<IndicatorEntity> efficacyIndicatorLists) {
        //1.3 评估结果与结论
        if (isShow == 1) {
            //1.3 评估结果与结论
            sectionBuilder.addParagraph(number + " 评估结果与结论", StyleParagraphEnum.HEADING_2.getCode());
//            sectionBuilder.addParagraph("         以下展示的体系贡献率评估结果值，其重点包括当前场景下的实际情况效能值以及能力值。最终存在体系贡献率的效能值和能力值。", StyleParagraphEnum.TEXT.getCode());
            sectionBuilder.addParagraph("         以下展示当前场景下的实际情况效能值", StyleParagraphEnum.TEXT.getCode());


            //1.3.1 体系贡献率评估结果
//            sectionBuilder.addParagraph(number + ".1 体系贡献率评估结果", StyleParagraphEnum.HEADING_3.getCode());
            sectionBuilder.addParagraph(number + ".1 体系评估结果", StyleParagraphEnum.HEADING_3.getCode());


            //1.3.1.1 评估结果摘要
            sectionBuilder.addParagraph(number + ".1.1 评估结果摘要", StyleParagraphEnum.HEADING_4.getCode());


            Section section = document.getSections().get(0);
            Table table = section.addTable(true);
            table.resetCells(1, 1);
            TableCell cell = table.getRows().get(0).getCells().get(0);
            //Paragraph para1 = cell.addParagraph();
            //TextRange text1 = para1.appendText("评估方案名称：" + schema.getName());
            //text1.getCharacterFormat().setFontSize(12);
            Paragraph para2 = cell.addParagraph();
            TextRange text2 = para2.appendText("评估场景：" + competeSceneEntity.getName());
            text2.getCharacterFormat().setFontSize(12);
            String nameList = "";
            for (SceneScenarioEntity sceneScenarioEntity : sceneScenarioEntities) {
                String scenarioName = sceneScenarioEntity.getScenarioName();
                nameList += scenarioName + "、";
            }
            int i = nameList.lastIndexOf("、");
            String substring = nameList.substring(0, i);
            Paragraph para3 = cell.addParagraph();
            TextRange text3 = para3.appendText("评估想定：" + substring);
            text3.getCharacterFormat().setFontSize(12);
            //String Summary = StringUtils.isEmpty(schema.getSummary()) ? "未设置评估结论" : schema.getSummary();
            //Paragraph para4 = cell.addParagraph();
            //TextRange text4 = para4.appendText("评估结论：" + Summary);
            //text4.getCharacterFormat().setFontSize(12);

            //2.4.1.2 评估结果详情
            sectionBuilder.addParagraph(number + ".1.2 评估结果详情", StyleParagraphEnum.HEADING_4.getCode());
            //根据sid查询指标树
            List<IndicatorTreeEntity> indicatorTreeEntities = indicatorTreeService.list(new LambdaQueryWrapper<IndicatorTreeEntity>().eq(IndicatorTreeEntity::getSid, schema.getId()));
            //根据sid查询样本
            List<SceneEntity> sceneEntities = sceneService.list(new LambdaQueryWrapper<SceneEntity>()
                    .eq(SceneEntity::getSid, schema.getId())
                    .eq(SceneEntity::getSceneType, CustomizedDataCollectionType.AFTERWARDS.id));
            if (CollUtil.isNotEmpty(indicatorTreeEntities) && CollUtil.isNotEmpty(sceneEntities)) {
                //根据指标类型分类
                Map<Integer, List<IndicatorTreeEntity>> indicatorTreeMap = indicatorTreeEntities.stream().filter(f -> CustomizedDataCollectionType.AFTERWARDS.id == f.getIndicatorTreeCategory()).collect(Collectors.groupingBy(IndicatorTreeEntity::getIndicatorTreeType));
                //根据指标树id分类
                Map<String, List<SceneEntity>> sceneEntitieMap = sceneEntities.stream().collect(Collectors.groupingBy(SceneEntity::getTreeId));
                sectionBuilder.addParagraph(number + ".1.2.1 效能评估计算结果值", StyleParagraphEnum.HEADING_5.getCode());
                //获取效能样本
                List<IndicatorTreeEntity> indicatorTreeEfficacy = indicatorTreeMap.get(2);
                if (CollUtil.isNotEmpty(indicatorTreeEfficacy)) {
                    List<SceneEntity> sceneEntityListEfficacy = sceneEntitieMap.get(indicatorTreeEfficacy.get(0).getId());
                    sceneEntityListEfficacy.sort((o1, o2) -> Integer.parseInt(o1.getName().split("/")[1].split("-")[1]) - Integer.parseInt(o2.getName().split("/")[1].split("-")[1]));
                    if (CollUtil.isNotEmpty(sceneEntityListEfficacy)) {
                        for (SceneEntity sceneEntity : sceneEntityListEfficacy) {
                            //导出结果表格
                            String s = sceneEntity.getName().split("/")[1].split("-")[1];
                            sectionBuilder.addText("仿真样本：" + s);
                            setPGResultTable(schema.getId(), sceneEntity.getId(), sectionBuilder, SchemaEvaluateType.EFFICACY_EVALUATE.getId());
                        }
                    }
                }
            }

            //1.3.2 评估结论
            sectionBuilder.addParagraph(number + ".2 评估结论", StyleParagraphEnum.HEADING_3.getCode());
            //战况多维--获取根指标优化建议
            List<String> list = realTimeCalculateService.efficiencyTrendConclusion(competeSceneEntity.getSid());
            String afterConclusion = schemaService.afterConclusion(competeSceneEntity.getSid());
            if (com.yw.framework.common.util.StringUtils.isNotEmpty(afterConclusion)) {
                if (list.size() == 1) {
                    list.clear();
                    afterConclusion = "1. " + afterConclusion;
                } else {
                    afterConclusion = "4. " + afterConclusion;
                }
                list.add(afterConclusion);
            }
            for (String s : list) {
                sectionBuilder.addText("    " + s);
            }
//            List<String> taskIdLists = competeSceneEntity.getTaskIdLists();
//            Map<String, String> taskIdAndNameMap = competeSceneEntity.getTaskIdAndNameMap();
//
//            for (SceneScenarioEntity sceneScenarioEntity : sceneScenarioEntities) {
//                List<ContributionRateResultEntity> contributionRateResult = contributionRateResultService.getContributionRateResult(competeSceneEntity.getId(), sceneScenarioEntity.getTaskId(), sceneScenarioEntity.getId());
//
//                Map<String /*indicatorId*/ , List<ContributionRateResultEntity> /*value*/> obtainContributionIndicatorResult =
//                        contributionRateResult.stream().collect(Collectors.groupingBy(ContributionRateResultEntity::getIndicatorId));
//
//                if (CollUtil.isEmpty(obtainContributionIndicatorResult)) {
//                    continue;
//                }
//                DocumentParagraphHelper.createParagraphAndAppendText(document, sceneScenarioEntity.getScenarioName() + "效能评估计算结果值");
//                Map<String, Map<String, String>> indicatorValueMaps = Maps.newHashMap();
//                obtainContributionIndicatorResult.forEach((k, v) -> {
//                    Map<String, String> paramMap = new HashMap<String, String>();
//                    for (ContributionRateResultEntity entity : v) {
//                        String label = entity.getStandardLabelName();
//                        paramMap.put(entity.getMissionTaskId(), entity.getIndicatorResult() + "(" + label + ")");
//                    }
//                    indicatorValueMaps.put(k, paramMap);
//                });
//                // todo
//                createContributionRateResultTableV2(sectionBuilder,document, indicatorValueMaps, taskIdAndNameMap, efficacyIndicatorLists, Lists.newArrayList(sceneScenarioEntity.getTaskId()));
//                DocumentParagraphHelper.createParagraphAndAppendText(document, "\n\n");
//                DocumentParagraphHelper.createParagraphAndAppendText(document, sceneScenarioEntity.getScenarioName() + "能力评估计算结果值");
//                // todo
//                createContributionRateResultTableV2(sectionBuilder, document, indicatorValueMaps, taskIdAndNameMap, abilityIndicatorLists, Lists.newArrayList(sceneScenarioEntity.getTaskId()));
//                DocumentParagraphHelper.createParagraphAndAppendText(document, "\n\n");
//            }
//            List<TaskResultEntity> abilityResultServiceList = effectAndAbilityResultService.getList(schema.getId());
//            Map<String, Map<String, String>> indicatorContributionRateValueMaps = Maps.newHashMap();
//            for (TaskResultEntity entity : abilityResultServiceList) {
//                Map<String, String> stringStringMap = indicatorContributionRateValueMaps.get(entity.getIndicatorId());
//                if (CollUtil.isEmpty(stringStringMap)) {
//                    stringStringMap = Maps.newHashMap();
//                    indicatorContributionRateValueMaps.put(entity.getIndicatorId(), stringStringMap);
//                }
//                stringStringMap.put(entity.getTaskId(), entity.getValue() + "");
//            }
//            DocumentParagraphHelper.createParagraphAndAppendText(document, "\n\n");
//            DocumentParagraphHelper.createParagraphAndAppendText(document, "         ");
//            DocumentParagraphHelper.createParagraphAndAppendText(document, "效能贡献率结果值");
//            // todo
//            createContributionRateResultTableV2(sectionBuilder, document, indicatorContributionRateValueMaps, taskIdAndNameMap, efficacyIndicatorLists, taskIdLists);
//
//            DocumentParagraphHelper.createParagraphAndAppendText(document, "能力贡献率结果值");
//            // todo
//            createContributionRateResultTableV2(sectionBuilder, document, indicatorContributionRateValueMaps, taskIdAndNameMap, abilityIndicatorLists, taskIdLists);
        }
    }


    public void createContributionRateResultTableV2(SectionBuilder sectionBuilder, Document document, Map<String, Map<String, String>> indicatorValueMaps,
                                                    Map<String, String> missionTaskNameMap, List<IndicatorEntity> indicatorEntities, List<String> taskIdLists) {
        List<String> tableHead = Lists.newArrayList();

        Map<String, List<IndicatorEntity>> map = indicatorEntities.stream().collect(Collectors.groupingBy(IndicatorEntity::getPid));

        List<IndicatorExportNode> efficacyIndicatorValueList = Lists.newArrayList();
        List<IndicatorExportNode> mideValue = Lists.newArrayList();
        for (IndicatorEntity eff : indicatorEntities) {
            IndicatorExportNode indicatorExportNode = new IndicatorExportNode(eff.getId(), eff.getName(), eff.getPid(), -1.0);
            efficacyIndicatorValueList.add(indicatorExportNode);
            mideValue.add(new IndicatorExportNode(eff.getId(), eff.getName(), eff.getPid(), -1.0));
        }
        List<Node> nodes = BuildTree.buildTree(mideValue);
        BuildTree.setLevel(nodes);
        //表的行列数
        int columnSize = BuildTree.maxLevel(nodes, 0);
        for (int i = 0; i < columnSize; i++) {
            tableHead.add((i + 1) + "级指标");
        }
        /*for (String taskId : taskIdLists) {
            String s = missionTaskNameMap.get(taskId);
            tableHead.add(s);
        }*/
        for (IndicatorEntity eff : indicatorEntities) {
            if (!map.containsKey(eff.getId()) && indicatorValueMaps.containsKey(eff.getId())) {
                Map<String, String> value = indicatorValueMaps.get(eff.getId());
                String preId = null;
                for (String task : taskIdLists) {
                    if (StringUtils.isEmpty(preId)) {
                        preId = UUIDGenerator.getUUID();
                        IndicatorExportNode indicatorExportNode = new IndicatorExportNode(preId, StringUtils.isEmpty(value.get(task)) ? "" : value.get(task), eff.getId(), -1.0);
                        efficacyIndicatorValueList.add(indicatorExportNode);
                        continue;
                    }
                    String currentId = UUIDGenerator.getUUID();
                    IndicatorExportNode indicatorExportNode = new IndicatorExportNode(currentId, StringUtils.isEmpty(value.get(task)) ? "" : value.get(task), preId, -1.0);
                    preId = currentId;
                    efficacyIndicatorValueList.add(indicatorExportNode);
                }
            }
        }
        flag = true;
        this.abstractCreateDocumentTable(efficacyIndicatorValueList, tableHead, sectionBuilder);
        flag = false;
    }

    public void builderCompeteSceneAndMissTask(Document document, SectionBuilder sectionBuilder, String sid, DDDExportReq req, List<SceneScenarioEntity> list) {
        //1 作战场景构建
        sectionBuilder.addParagraph("1.1 作战场景构建", StyleParagraphEnum.HEADING_2.getCode());

        // 是否显示武器系使命任务
        //weaponsSystemShow(sectionBuilder, sid);

        // 是否显示对抗场景设置
        CompeteSceneShow(sectionBuilder, sid);


        //  对抗场景多种情况分析是是否显示
        manyCompeteSceneShow(document, sectionBuilder, list);


    }


    private void CompeteSceneShow(SectionBuilder sectionBuilder, String sid) {
        //1.2 对抗场景设置
        sectionBuilder.addParagraph("1.1.1 对抗场景设置", StyleParagraphEnum.HEADING_3.getCode());

        //场景表格构建
        setCompeteSceneTable(sectionBuilder, sid);
    }

    private void weaponsSystemShow(SectionBuilder sectionBuilder, String sid) {
        //1.1 武器系统使命任务
        sectionBuilder.addParagraph("1.1.1 武器系统使命任务", StyleParagraphEnum.HEADING_3.getCode());


        // 获取所有任务
        setMissionTasksTableInfo(sectionBuilder, sid);
    }

    private void setMissionTasksTableInfo(SectionBuilder sectionBuilder, String sid) {
        List<MissionTaskEntity> missionTaskEntities = missionTaskService.find(MissionTaskEntity.builder().sid(sid).build());
        if (CollUtil.isEmpty(missionTaskEntities)) {
            return;
        }
        List<IndicatorExportNode> missionTasksTableInfo = Lists.newArrayList();
        for (MissionTaskEntity missionTaskEntity : missionTaskEntities) {
            if (missionTaskEntity.getFlag() == 2) {
                String pid = UUIDGenerator.getUUID();
                missionTasksTableInfo.add(new IndicatorExportNode(pid, missionTaskEntity.getName(), "0", -1.0));
                String descPid = UUIDGenerator.getUUID();
                missionTasksTableInfo.add(new IndicatorExportNode(descPid, missionTaskEntity.getDescs(), pid, -1.0));
                missionTasksTableInfo.add(new IndicatorExportNode(UUIDGenerator.getUUID(), missionTaskEntity.getBackGround(), descPid, -1.0));
            }
        }
        if (missionTasksTableInfo.size() > 0) {
            this.createDocumentTable(missionTasksTableInfo, Lists.newArrayList("使命任务", "描述信息", "使命任务背景"), sectionBuilder);
        }
    }

    private void createDocumentTable(List<IndicatorExportNode> indicatorExportNodes, ArrayList<String> tableHead, SectionBuilder sectionBuilder) {
        List<com.yw.common.utils.Node> nodes = com.yw.common.utils.BuildTree.buildTree(indicatorExportNodes);
        com.yw.common.utils.BuildTree.setLevel(nodes);
        List<com.yw.common.utils.Node> leafNode = com.yw.common.utils.BuildTree.getLeafNode(nodes, new ArrayList<>());
        //表的行列数
        int rowSize = leafNode.size();
        int columnSize = tableHead.size();

        SingleTable singleTable = new SingleTable();
        singleTable.col = columnSize;
        singleTable.row = rowSize + 1;

        //表头
        List<String> tableCol = Lists.newArrayList();
        for (int i = 0; i < columnSize; i++) {
            tableCol.add(tableHead.get(i));
        }


        // 表数据
        setTableRowNum(indicatorExportNodes, nodes);

        // 获取表数据 每一行
        List<List<String>> data = Lists.newArrayList();
        for (Node node : nodes) {
            if (node.getParentId().equals("0")) {
                data = treePaths((IndicatorExportNode) node);
            }
        }
        singleTable.firstTableCol = tableCol;
        singleTable.rowData = data;

        sectionBuilder.addTable(singleTable);

    }


    private void manyCompeteSceneShow(Document document, SectionBuilder sectionBuilder, List<SceneScenarioEntity> list) {
        //1.3 对抗场景多种情况分析
        sectionBuilder.addParagraph("1.1.2 对抗场景多种情况分析", StyleParagraphEnum.HEADING_3.getCode());

        //想定数据
        int count = 1;
        for (SceneScenarioEntity sceneScenarioEntity : list) {
            //1.3.1 想定1
            sectionBuilder.addParagraph("1.1.2." + count + " " + sceneScenarioEntity.getScenarioName(), StyleParagraphEnum.HEADING_4.getCode());


            //1.3.1.1 原型基础信息
            sectionBuilder.addParagraph("1.1.2." + count + ".1 原型基础信息", StyleParagraphEnum.HEADING_5.getCode());


            // 单元格添加多个段落实现换行
            List<String> cells = Lists.newArrayList();
            cells.add("想定名称：" + StringUtils.defaultIfEmpty(sceneScenarioEntity.getScenarioName(), DEFAULT_STR));
            //数据转换
            Integer attributeProperty = sceneScenarioEntity.getAttributeProperty();
            if (attributeProperty == null) {
                attributeProperty = 1;
            }
            AttributePropertyEnums attributePropertyEnums = AttributePropertyEnums.getAttributePropertyEnums(attributeProperty);
//            String name = attributePropertyEnums.getName();
//            cells.add("情况属性：" + StringUtils.defaultIfEmpty(name, DEFAULT_STR));
            // 装备
            cells.add("想定描述:" + StringUtils.defaultIfEmpty(sceneScenarioEntity.getDescs(), DEFAULT_STR));
            // 数量
//            int equipmentNum = sceneScenarioEntity.getEquipmentNum() == null ? 0 : sceneScenarioEntity.getEquipmentNum();
//            cells.add("数量:" + equipmentNum);
            DocumentTableHelper.createOneRowMutiCellTable(document, cells);
            StringBuilder redDeployment = new StringBuilder();
            StringBuilder blueDeployment = new StringBuilder();
            getTroops(redDeployment, blueDeployment, sceneScenarioEntity.getId());

            //1.3.1.2 我方兵力编成与部署
            sectionBuilder.addParagraph("1.1.2." + count + ".2 我方兵力编成与部署", StyleParagraphEnum.HEADING_5.getCode());


            String ourTroopDeployment = StringUtils.isEmpty(redDeployment.toString()) ? "暂无我方兵力编程与部署信息" : redDeployment.substring(0, redDeployment.length() - 1);
            sectionBuilder.addParagraph("   " + ourTroopDeployment, StyleParagraphEnum.TEXT.getCode());

            //1.3.1.3 敌方兵力编成与部署
            sectionBuilder.addParagraph("1.1.2." + count + ".3 敌方兵力编成与部署", StyleParagraphEnum.HEADING_5.getCode());

            //敌方兵力部署
            String otherTroopDeployment = StringUtils.isEmpty(blueDeployment.toString()) ? "暂无敌方兵力编程与部署信息 " : blueDeployment.substring(0, blueDeployment.length() - 1);
            sectionBuilder.addParagraph("   " + otherTroopDeployment, StyleParagraphEnum.TEXT.getCode());
            count++;
        }
    }

    /**
     * 获取想定装备信息
     *
     * @param redDeployment
     * @param blueDeployment
     * @param sceneScenarioId
     */
    private void getTroops(StringBuilder redDeployment, StringBuilder blueDeployment, String sceneScenarioId) {
        SidesDirecService sidesDirecService = SpringUtils.getBean(SidesDirecService.class);
        List<SidesDirecEntity> tree = sidesDirecService.getOneTree(sceneScenarioId);
        for (SidesDirecEntity sidesDirecEntity : tree) {
            List<SidesDirecEntity> child = sidesDirecEntity.getChild();
            if ("1".equals(sidesDirecEntity.getType())) {
                redDeployment.append(sidesDirecEntity.getSideName());
                if (CollectionUtil.isNotEmpty(child)) {
                    redDeployment.append("(").append("数量:").append(child.get(0).getSideName()).append(")");
                }
                redDeployment.append(",");
            } else {
                blueDeployment.append(sidesDirecEntity.getSideName());
                if (CollectionUtil.isNotEmpty(child)) {
                    blueDeployment.append("(").append("数量:").append(child.get(0).getSideName()).append(")");
                }
                blueDeployment.append(",");
            }
        }
    }

    private void setCompeteSceneTable(SectionBuilder sectionBuilder, String sid) {
        PageInfo<CompeteSceneDTO> showCompeteScene = competeSceneService.showCompeteScene(null, sid, 0, 10, null);
        List<CompeteSceneDTO> showCompeteSceneList = showCompeteScene.getList();
        if (CollUtil.isEmpty(showCompeteSceneList)) {
            return;
        }
        //创建表格
        //创建表格
        int rowSize = showCompeteSceneList.size() + 1;//表行
        int colSize = 1;
        SingleTable singleTable = new SingleTable();
        singleTable.col = colSize;
        singleTable.row = rowSize;
        //表头
//        List<String> tableCol = Lists.newArrayList("场景名称", "军事背景", "装备体系", "关联任务");
        List<String> tableCol = Lists.newArrayList("场景名称");


        // 表数据
        List<List<String>> tableData = Lists.newArrayList();
        // 表数据填充
        for (int i = 0; i < showCompeteSceneList.size(); i++) {
            List<String> tableCols = Lists.newArrayList();
            CompeteSceneDTO sceneDTO = showCompeteSceneList.get(i);

            //名称
            tableCols.add(sceneDTO.getName());
//            //军事背景
//            FighterEntityVO fighterEntityVO = sceneDTO.getVoList();
//            String stringBuilder = "\n 作战时间：" +
//                    (Objects.isNull(fighterEntityVO.getFighterTime()) ? "" : fighterEntityVO.getFighterTime()) +
//                    "\n 作战对手：" +
//                    (Objects.isNull(fighterEntityVO.getEnemy()) ? "" : fighterEntityVO.getEnemy()) +
//                    "\n 作战区域：" +
//                    (Objects.isNull(fighterEntityVO.getFighterArea()) ? "" : fighterEntityVO.getFighterArea()) +
//                    "\n 作战样式：" +
//                    (Objects.isNull(fighterEntityVO.getTaskModel()) ? "" : fighterEntityVO.getTaskModel());
//            tableCols.add(stringBuilder);
//            //装备体系
//            List<EquipmentVo> equipmentVoList = sceneDTO.getEquipmentVoList();
//            if (!CollUtil.isEmpty(equipmentVoList)) {
//                StringBuilder equStr = new StringBuilder();
//                for (EquipmentVo equipmentVo : equipmentVoList) {
//                    equStr.append("装备种类：").append(equipmentVo.getEquipmentName()).append("   ").append("数量：1 \n ");
//                }
//                tableCols.add(equStr.toString());
//            } else {
//                tableCols.add("");
//            }
//
//            //关联任务
//            List<Pair<String, String>> missionTasks = sceneDTO.getMissionTasks();
//            if (CollUtil.isNotEmpty(missionTasks)) {
//                StringBuilder missTaskStr = new StringBuilder();
//                for (Pair<String, String> missionTask : missionTasks) {
//                    String value = missionTask.getValue();
//                    missTaskStr.append(value);
//                }
//                tableCols.add(missTaskStr.toString());
//            }else {
//                tableCols.add("");
//            }
            tableData.add(tableCols);
        }
        singleTable.firstTableCol = tableCol;
        singleTable.rowData = tableData;


        sectionBuilder.addTable(singleTable);
    }

    private void createContributionRateResultTable(XWPFDocument word, Map<String, Map<String, String>> indicatorValueMaps,
                                                   List<IndicatorEntity> indicatorEntities) {
        List<String> tableHead = Lists.newArrayList();

        Map<String, List<IndicatorEntity>> map = indicatorEntities.stream().collect(Collectors.groupingBy(IndicatorEntity::getPid));

        List<IndicatorExportNode> efficacyIndicatorValueList = Lists.newArrayList();
        List<IndicatorExportNode> mideValue = Lists.newArrayList();
        for (IndicatorEntity eff : indicatorEntities) {
            IndicatorExportNode indicatorExportNode = new IndicatorExportNode(eff.getId(), eff.getName(), eff.getPid(), -1.0);
            efficacyIndicatorValueList.add(indicatorExportNode);
            mideValue.add(new IndicatorExportNode(eff.getId(), eff.getName(), eff.getPid(), -1.0));
        }
        List<Node> nodes = BuildTree.buildTree(mideValue);
        BuildTree.setLevel(nodes);
        //表的行列数
        int columnSize = BuildTree.maxLevel(nodes, 0);
        for (int i = 0; i < columnSize; i++) {
            tableHead.add((i + 1) + "级指标");
        }

        for (IndicatorEntity eff : indicatorEntities) {
            if (!map.containsKey(eff.getId()) && indicatorValueMaps.containsKey(eff.getId())) {
                Map<String, String> value = indicatorValueMaps.get(eff.getId());
                String preId = null;
               /* for (String task : taskIdLists) {
                    if (StringUtils.isEmpty(preId)) {
                        preId = UUIDGenerator.getUUID();
                        IndicatorExportNode indicatorExportNode = new IndicatorExportNode(preId, StringUtils.isEmpty(value.get(task)) ? "" : value.get(task), eff.getId(), -1.0);
                        efficacyIndicatorValueList.add(indicatorExportNode);
                        continue;
                    }
                    String currentId = UUIDGenerator.getUUID();
                    IndicatorExportNode indicatorExportNode = new IndicatorExportNode(currentId, StringUtils.isEmpty(value.get(task)) ? "" : value.get(task), preId, -1.0);
                    preId = currentId;
                    efficacyIndicatorValueList.add(indicatorExportNode);
                }*/
            }
        }
        evaluationReportService.createDocumentTable(efficacyIndicatorValueList, tableHead, word);
    }


    @Override
    public void builderCompeteSceneAndMissTask(XWPFDocument word, String sid, ContributionRateExportDTO dto, List<SceneScenarioEntity> list) {

    }

    public void doExportXml(SchemaEntity schemaEntity, DDDExportReq req, List<SceneScenarioEntity> scenarioList, CompeteSceneEntity competeSceneEntity, Element element) {
        String optimizationSuggestion = req.getOptimizationSuggestion();
        if (StrUtil.isEmpty(optimizationSuggestion)) {
            log.error("");
            return;
        }

        //菜单
        List<TreeModel> menus = sysMenuService.list(new SysMenuEntity());
        List<Map<String, Object>> optimizationSuggestionList = JSONObject.parseObject(optimizationSuggestion, new TypeReference<List<Map<String, Object>>>() {
        });
        if (CollUtil.isEmpty(optimizationSuggestionList)) {
            return;
        }
        //获取所有导出模块
        List<String> names = optimizationSuggestionList.stream().map(item -> String.valueOf(item.get("name"))).collect(Collectors.toList());
        int num = 1;
        for (int i = 0; i < menus.size(); i++) {
            if (!names.contains(menus.get(i).getName())) {
                continue;
            }
            // 一级标题设置
            Element firstElement = element.addElement(menus.get(i).getName());
            switch (i) {
                case 0:
                    // 1：评估分析
                    builderPgAnalysisXml(firstElement, req, scenarioList, competeSceneEntity);
                    break;
                case 1:
                    //趋势预测
                    builderTrendForecastXml(req.getSid(), firstElement);
                    break;
                case 2:
                    //灵敏度
                    builderSensitivityResultXml(req.getSid(), num, firstElement);
                    break;
                case 3:
                    //边界探索
                    builderBoundExploreResultXml(req.getSid(), firstElement);
                    break;
                case 4:
                    //重要度
                    builderImportanceDegreeResultXml(req.getSid(), firstElement);
                    break;
                case 5:
                    //关联关系挖掘
                    builderAssociationMiningResultXml(req.getSid(), num, firstElement);
                    break;
                case 6:
                    //抗毁性
                    builderSurvivabilityXml(req.getSid(), num, firstElement);
                    break;
                case 7:
                    //优化建议
                    optimizationSuggestionXml(firstElement, optimizationSuggestionList);
            }
            num++;
        }
    }

    /**
     * 优化建议xml构建
     *
     * @param firstElement
     * @param optimizationSuggestionList
     */
    private void optimizationSuggestionXml(Element firstElement, List<Map<String, Object>> optimizationSuggestionList) {
        Element optimizationSuggestionElement = firstElement.addElement("结论生成");
        List<String> tableCol = Lists.newArrayList();
        tableCol.add("序号");
        tableCol.add("分析内容");
        tableCol.add("优化建议");
        // 获取表数据 每一行
        List<List<String>> data = Lists.newArrayList();
        Element listElement = optimizationSuggestionElement.addElement("list");
        for (int i = 0; i < optimizationSuggestionList.size(); i++) {
            Element element1 = listElement.addElement("序号");
            Element element2 = listElement.addElement("分析内容");
            Element element3 = listElement.addElement("优化建议");
            Map<String, Object> stringObjectMap = optimizationSuggestionList.get(i);
            element1.addText(String.valueOf(i + 1));
            element2.addText(stringObjectMap.get("name").toString());
            if (stringObjectMap.get("suggestion") != null) {
                element3.addText(stringObjectMap.get("suggestion").toString());
            }
        }
    }

    /**
     * 抗毁性xml构建
     *
     * @param sid
     * @param num
     * @param firstElement
     */
    private void builderSurvivabilityXml(String sid, int num, Element firstElement) {
        Element survivabilityElement1 = firstElement.addElement("装备节点复杂网络");
        Element survivabilityElement2 = firstElement.addElement("抗毁性评估指标体系");
        Element survivabilityElement3 = firstElement.addElement("体系抗毁性评估结果");
        Element survivabilityElement4 = firstElement.addElement("装备损毁后对体系抗毁性影响分析");
        //文本描述
        NetWorkNodeBaseDataDto netWorkNodeBaseData = atlasEntityService.netWorkNodeBaseData(sid);
        survivabilityElement1.addText("装备节点复杂网络包括侦察类装备数量" + netWorkNodeBaseData.getUnmannedNum() + "件、指控类装备数量" + netWorkNodeBaseData.getEffectNum() + "件、打击类装备数量" + netWorkNodeBaseData.getSenseNum() + "件，共计形成杀伤链数" + netWorkNodeBaseData.getSslNum() + "条。这些装备形成的复杂网络如下图所示：");

        //二级标题7.2
        List<IndicatorEntity> invulnerabilityIndicatorLists = Lists.newArrayList();
        List<IndicatorExportNode> efficacyIndicatorExportNode = getIndicatorExportNode(sid, invulnerabilityIndicatorLists, CustomizedDataCollectionType.INVULNERABILITY.id);
        // 表格数据
        builderIndicatorSystemXml(survivabilityElement2, BuildTree.buildTree(efficacyIndicatorExportNode));

        //二级标题7.3
        try {
            MergeTablesVo mergeTablesVo = evaluationCalculationService.getTable(sid, null, CustomizedDataCollectionType.INVULNERABILITY.id);
            Element listElement = survivabilityElement3.addElement("list");
            for (Map<String, Object> listDatum : mergeTablesVo.getListData()) {
                for (FixedColumnVo fixedColumnVo : mergeTablesVo.getFixedColumn()) {
                    Element propElement = listElement.addElement(fixedColumnVo.getLabel());
                    if (listDatum.get(fixedColumnVo.getProp()) != null) {
                        propElement.addText(listDatum.get(fixedColumnVo.getProp()).toString());
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
        }

        //二级标题7.4
        try {
            Element listsElement = survivabilityElement4.addElement("lists");
            EquInvulnerabilityVO equInvulnerabilityVO = evaluationCalculationService.calculateEquInvulnerabilityRandom(sid, null);
            if (CollUtil.isNotEmpty(equInvulnerabilityVO.getEquNameList()) && CollUtil.isNotEmpty(equInvulnerabilityVO.getSslNumberList()) && CollUtil.isNotEmpty(equInvulnerabilityVO.getEquInvulnerabilityList())) {
                for (int i = 0; i < equInvulnerabilityVO.getEquNameList().size(); i++) {
                    Element listElement = listsElement.addElement("list");
                    Element equName = listElement.addElement("损毁ZB");
                    Element sslNumberElement = listElement.addElement("SSL数量");
                    Element equInvulnerabilityElement = listElement.addElement("体系抗毁性评估值");

                    equName.addText(equInvulnerabilityVO.getEquNameList().get(i));
                    sslNumberElement.addText(String.valueOf(equInvulnerabilityVO.getSslNumberList().get(i)));
                    equInvulnerabilityElement.addText(equInvulnerabilityVO.getEquInvulnerabilityList().get(i));
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }

    /**
     * 关联关系挖掘xml构建
     *
     * @param sid
     * @param num
     * @param firstElement
     */
    private void builderAssociationMiningResultXml(String sid, int num, Element firstElement) {
        Element miningAnalysisElement1 = firstElement.addElement("关联关系挖掘数据如下所示");
        Element miningAnalysisElement2 = firstElement.addElement("二项集关联关系数据表");
        Element miningAnalysisElement3 = firstElement.addElement("三项集关联关系数据表");
        Element miningAnalysisElement4 = firstElement.addElement("指标间的关系强弱程度");
        Element listsElement = miningAnalysisElement1.addText("lists");

        MiningModelConfigEntity miningModelConfig = miningModelConfigService.getOne(new LambdaQueryWrapper<MiningModelConfigEntity>().eq(MiningModelConfigEntity::getSid, sid));
        if (miningModelConfig == null) {
            miningAnalysisElement1.addText("无");
        } else {
            MiningModelConfigReq req = new MiningModelConfigReq();
            req.setSid(sid);
            req.setMiningModel(miningModelConfig.getMiningModel());
            req.setIndicatorIntervalConfig(JSON.parseArray(miningModelConfig.getIndicatorInterval(), MiningModelConfigReq.IntervalConfig.class));
            req.setIndicatorParamIntervalConfig(JSON.parseArray(miningModelConfig.getIndicatorParamInterval(), MiningModelConfigReq.IntervalConfig.class));
            JSONObject sampleData = staticsticalAnalysisService.getSampleData(req);
            JSONArray tableHeader = sampleData.getJSONArray("tableHeader");
            JSONArray tableData = sampleData.getJSONArray("tableData");

            for (int i = 0; i < tableData.size(); i++) {
                Element listElement = listsElement.addElement("list");
                for (int j = 0; j < tableHeader.size(); j++) {
                    Element label = listElement.addElement(tableHeader.getJSONObject(j).getString("label"));
                    label.addText(String.valueOf(tableData.getJSONObject(i).get(tableHeader.getJSONObject(j).getString("prop"))));
                }
            }

        }


        //MiningParamResp miningThresholdConfig = staticsticalAnalysisService.getMiningThresholdConfig();
        //sectionBuilder.addText("当支持度、置信度和提升度分别设置为" + miningThresholdConfig.getSupportThreshold() + "、" + miningThresholdConfig.getConfidenceThreshold() + "和" + miningThresholdConfig.getImproveThreshold() + "时，二项集和三项集结果如下所示：");

        Element listsElement2 = miningAnalysisElement2.addElement("lists");
        List<MiningResultResp.ItemSet> threeItemSets = null;
        MiningResultEntity miningResultEntity = miningResultMapper.selectOne(new LambdaQueryWrapper<MiningResultEntity>().eq(MiningResultEntity::getSid, sid).last("limit 1"));
        if (miningResultEntity != null && com.yw.framework.common.util.StringUtils.isNotEmpty(miningResultEntity.getResult())) {
            MiningResultResp miningResultResp = JSON.parseObject(miningResultEntity.getResult(), MiningResultResp.class);
            List<MiningResultResp.ItemSet> twoItemSets = miningResultResp.getTwoItemSets();
            threeItemSets = miningResultResp.getThreeItemSets();

            if (CollectionUtil.isNotEmpty(twoItemSets)) {
                //只导出前20条
                twoItemSets = twoItemSets.subList(0, Math.min(twoItemSets.size(), 20));
                for (MiningResultResp.ItemSet itemSet : twoItemSets) {
                    Element listElement = listsElement2.addElement("list");
                    Element relationshipElement = listElement.addElement("说明");
                    Element supportElement = listElement.addElement("关联关系");
                    Element confidenceElement = listElement.addElement("支持度");
                    Element improveElement = listElement.addElement("置信度");
                    Element explainElement = listElement.addElement("提升度");

                    relationshipElement.addText(itemSet.getRelationship());
                    supportElement.addText(String.valueOf(itemSet.getSupport()));
                    confidenceElement.addText(String.valueOf(itemSet.getConfidence()));
                    improveElement.addText(String.valueOf(itemSet.getImprove()));
                    explainElement.addText(String.valueOf(itemSet.getExplain()));
                }
            } else {
                listsElement2.addText("无");
            }
        } else {
            listsElement2.addText("无");
        }

        Element listsElement3 = miningAnalysisElement3.addElement("lists");
        if (CollectionUtil.isNotEmpty(threeItemSets)) {
            threeItemSets = threeItemSets.subList(0, Math.min(threeItemSets.size(), 20));
            for (MiningResultResp.ItemSet itemSet : threeItemSets) {
                Element listElement = listsElement3.addElement("list");
                Element relationshipElement = listElement.addElement("说明");
                Element supportElement = listElement.addElement("关联关系");
                Element confidenceElement = listElement.addElement("支持度");
                Element improveElement = listElement.addElement("置信度");
                Element explainElement = listElement.addElement("提升度");

                relationshipElement.addText(itemSet.getRelationship());
                supportElement.addText(String.valueOf(itemSet.getSupport()));
                confidenceElement.addText(String.valueOf(itemSet.getConfidence()));
                improveElement.addText(String.valueOf(itemSet.getImprove()));
                explainElement.addText(String.valueOf(itemSet.getExplain()));
            }
        } else {
            listsElement3.addText("无");
        }

        Element listsElement4 = miningAnalysisElement4.addElement("lists");
        GreyRelationAnalysisResultResp greyRelationAnalysisResultResp = staticsticalAnalysisService.greyCorrelationAnalysis(sid);
        if (greyRelationAnalysisResultResp != null && greyRelationAnalysisResultResp.getHeaders() != null && greyRelationAnalysisResultResp.getData() != null) {
            List<GreyRelationAnalysisResultResp.Header> headers = greyRelationAnalysisResultResp.getHeaders();
            List<Map<String, Object>> tableData = greyRelationAnalysisResultResp.getData();

            for (int i = 0; i < tableData.size(); i++) {
                for (int j = 0; j < headers.size(); j++) {
                    Element listElement = listsElement4.addElement("list");
                    Element lableElement = listElement.addElement(headers.get(i).getLabel());
                    lableElement.addText(String.valueOf(tableData.get(i).get(headers.get(j).getProp())));
                }
            }
        } else {
            listsElement4.addText("无");
        }
    }

    /**
     * 重要度xml构建
     *
     * @param sid
     * @param firstElement
     */
    private void builderImportanceDegreeResultXml(String sid, Element firstElement) {
        Element equipmentImportanceResultElement1 = firstElement.addElement("装备节点重要度评估计算结果");
        Element equipmentImportanceResultElement2 = firstElement.addElement("重要度分析结论");

        SceneScenarioEntity sceneScenarioEntity = sceneScenarioService.getOne(new LambdaQueryWrapper<SceneScenarioEntity>().eq(SceneScenarioEntity::getSid, sid).last("limit 1"));

        List<EquipmentImportanceResult> list = equipmentImportanceResultService.list(new LambdaQueryWrapper<EquipmentImportanceResult>()
                .eq(EquipmentImportanceResult::getScenarioId, sceneScenarioEntity.getId()));

        Element listsElement = equipmentImportanceResultElement1.addElement("list");
        for (EquipmentImportanceResult equipmentImportanceResult : list) {
            Element listElement = listsElement.addElement("list");
            Element nodeNameElement = listElement.addElement("节点名称");
            Element importanceElement = listElement.addElement("重要度");
            Element dcElement = listElement.addElement("度中心性");
            Element dvElement = listElement.addElement("介数中心性");
            Element ccElement = listElement.addElement("接近中心性");

            nodeNameElement.addText(equipmentImportanceResult.getNodeName());
            importanceElement.addText(String.valueOf(equipmentImportanceResult.getImportance()));
            dcElement.addText(String.valueOf(equipmentImportanceResult.getDcValue()));
            dvElement.addText(String.valueOf(equipmentImportanceResult.getBcValue()));
            ccElement.addText(String.valueOf(equipmentImportanceResult.getCcValue()));
        }
        if (CollectionUtil.isEmpty(list)) {
            listsElement.addText("无");
        }

        if (CollectionUtil.isEmpty(list)) {
            equipmentImportanceResultElement2.addText("无");
        } else {
            List<String> conclusion = equipmentImportanceService.getConclusion(sceneScenarioEntity.getId());
            for (String s : conclusion) {
                equipmentImportanceResultElement2.addText(s);
            }
        }
    }

    /**
     * 边界探索xml构建
     *
     * @param sid
     * @param firstElement
     */
    private void builderBoundExploreResultXml(String sid, Element firstElement) {
        Element exploratoryAnalysisElement1 = firstElement.addElement("边界条件与指标异常");
        Element exploratoryAnalysisElement2 = firstElement.addElement("关键因素统计与数据分布探索");

        List<ExploratoryAnalysisVO> exploratoryAnalysisVOS = staticsticalAnalysisService.exportAnalysisResultV2(sid);
        exploratoryAnalysisElement1.addText("探索与分析结论：");
        if (CollectionUtil.isEmpty(exploratoryAnalysisVOS)) {
            exploratoryAnalysisElement1.addText("无");
        } else {
            for (ExploratoryAnalysisVO exploratoryAnalysisVO : exploratoryAnalysisVOS) {
                List<SimpleLinearVO> simpleLinearVOList = exploratoryAnalysisVO.getSimpleLinearVOList();
                for (SimpleLinearVO simpleLinearVO : simpleLinearVOList) {
                    exploratoryAnalysisElement1.addText(simpleLinearVO.getOverallConclusion());
                }
            }
        }

        exploratoryAnalysisElement2.addText("数据分布分析结论：");
        if (CollectionUtil.isEmpty(exploratoryAnalysisVOS)) {
            exploratoryAnalysisElement2.addText("无");
        } else {
            for (ExploratoryAnalysisVO exploratoryAnalysisVO : exploratoryAnalysisVOS) {
                List<SimpleLinearVO> simpleLinearVOList = exploratoryAnalysisVO.getSimpleLinearVOList();
                for (SimpleLinearVO simpleLinearVO : simpleLinearVOList) {
                    exploratoryAnalysisElement2.addText(simpleLinearVO.getDataConclusion());
                }
            }
        }
    }

    /**
     * 灵敏度xml构建
     *
     * @param sid
     * @param num
     * @param firstElement
     */
    private void builderSensitivityResultXml(String sid, int num, Element firstElement) {
        Element sensitivityResultElement1 = firstElement.addElement("装备数量灵敏度分析");
        Element sensitivityResultElement2 = firstElement.addElement("关键指标灵敏度分析");

        SensitivityAnalysisEntity result = sensitivityAnalysisV2Service.getSensitivityAnalysis(sid, 2);
        if (result != null && ObjectUtil.isNotNull(result.getResultVO()) && CollUtil.isNotEmpty(result.getResultVO().getResultVOS())) {
            List<KeyIndicatorSensitivityResultVO> resultVOS = result.getResultVO().getResultVOS();

            Element listElement = sensitivityResultElement1.addElement("list");
            for (KeyIndicatorSensitivityResultVO resultVO : resultVOS) {
                Element equipmentNameElement = listElement.addElement("装备名称");
                equipmentNameElement.addText(resultVO.getColumn());
                Element equipmentSizeElement = listElement.addElement("装备数量");
                equipmentSizeElement.addText(String.valueOf(resultVO.getResultVOS().get(resultVO.getLightIndex()).getKeyValue()));
            }


            String analysisResult = result.getAnalysisResult();
            if (com.yw.framework.common.util.StringUtils.isNotEmpty(analysisResult)) {
                JSONObject analysisResultJsonobject = JSON.parseObject(analysisResult);
                String conclusion = analysisResultJsonobject.getString("conclusion");
                if (com.yw.framework.common.util.StringUtils.isNotEmpty(conclusion)) {
                    Element conclusionElement = sensitivityResultElement1.addElement("结论");
                    conclusionElement.addText(conclusion);
                }

            }
        }

        SensitivityAnalysisEntity sensitivityAnalysisEntity = sensitivityAnalysisMapper.selectOne(new LambdaQueryWrapper<SensitivityAnalysisEntity>()
                .eq(SensitivityAnalysisEntity::getSid, sid).orderByDesc(SensitivityAnalysisEntity::getCreateTime)
                .last("limit 1"));
        if (sensitivityAnalysisEntity != null) {
            String analysisResult = sensitivityAnalysisEntity.getAnalysisResult();
            JSONObject jsonObject = JSON.parseObject(analysisResult);
            String conclusion = jsonObject.getString("conclusion");
            sensitivityResultElement2.addText(conclusion);
        } else {
            sensitivityResultElement2.addText("无");
        }
    }

    /**
     * 趋势预测xml构建
     *
     * @param sid
     * @param firstElement
     */
    private void builderTrendForecastXml(String sid, Element firstElement) {
        Element trendForecastElement = firstElement.addElement("趋势分析");
        List<TrendForecastEntity> list = trendForecastService.list(new LambdaQueryWrapper<TrendForecastEntity>()
                .eq(TrendForecastEntity::getSid, sid)
                .orderByDesc(TrendForecastEntity::getCreateTime)
        );
        Element autoregressionElement = trendForecastElement.addElement("自回归");
        Optional<TrendForecastEntity> autoregression = list.stream().filter(t -> t.getSampleMethodType().equals(PlanSampleMethodType.AUTOREGRESSION.getName())).findFirst();
        if (autoregression.isPresent()) {
            JSONObject jsonObject = JSON.parseObject(autoregression.get().getResult());
            String regressionEquation = jsonObject.getJSONObject("resultJsonStr").getString("regressionEquation");
            String desc = jsonObject.getJSONArray("params").getJSONObject(0).getString("desc");
            autoregressionElement.addText(desc + "为关键指标名称。回归方程如下所示：");
            autoregressionElement.addText(regressionEquation);

            JSONArray conclusions = jsonObject.getJSONObject("resultAll").getJSONArray("conclusionLists");
            if (conclusions != null) {
                autoregressionElement.addText("结论：");
                for (Object conclusion : conclusions) {
                    autoregressionElement.addText(conclusion.toString());
                }
            }
        } else {
            autoregressionElement.addText("无");
        }


        //sectionBuilder.addText("X为关键指标名称，y为效能指标名称。回归方程如下所示：");
        setRegressionResultXml(PlanSampleMethodType.SIMPLE_LINEAR, list, trendForecastElement);
        setRegressionResultXml(PlanSampleMethodType.MULTIPLE_LINEAR, list, trendForecastElement);
        setRegressionResultXml(PlanSampleMethodType.BINARY_LOGISTIC, list, trendForecastElement);
        setRegressionResultXml(PlanSampleMethodType.MULTIVARIATE_LOGISTIC, list, trendForecastElement);
        setRegressionResultXml(PlanSampleMethodType.APSO_BPLearn, list, trendForecastElement);
    }

    private void setRegressionResultXml(PlanSampleMethodType planSampleMethodType, List<TrendForecastEntity> list, Element trendForecastElement) {
        Element regressionElement = trendForecastElement.addElement(planSampleMethodType.getDesc());
        Optional<TrendForecastEntity> regression = list.stream().filter(t -> t.getSampleMethodType().equals(planSampleMethodType.name())).findFirst();
        if (regression.isPresent()) {
            JSONObject jsonObject = JSON.parseObject(regression.get().getResult());
            String regressionEquation = jsonObject.getJSONObject("resultJsonStr").getString("regressionEquation");
            if (com.yw.framework.common.util.StringUtils.isEmpty(regressionEquation)) {
                regressionEquation = jsonObject.getJSONObject("resultJsonStr").getString("equation");
            }
            JSONArray params = jsonObject.getJSONArray("params");
            String param = "";
            String indicator = "";
            for (int i = 0; i < params.size(); i++) {
                String type = params.getJSONObject(i).getString("type");
                String desc = params.getJSONObject(i).getString("desc");
                if ("DEPENDENT".equals(type)) {
                    if (com.yw.framework.common.util.StringUtils.isEmpty(indicator)) {
                        indicator = desc;
                    } else {
                        indicator = indicator + "," + desc;
                    }
                } else {
                    if (com.yw.framework.common.util.StringUtils.isEmpty(param)) {
                        param = desc;
                    } else {
                        param = param + "," + desc;
                    }
                }
            }

            if (!PlanSampleMethodType.MULTIVARIATE_LOGISTIC.getName().equals(planSampleMethodType.name())) {
                regressionElement.addText(param + "为关键指标名称，" + indicator + "为效能指标名称。回归方程如下所示：");
                regressionElement.addText(regressionEquation);
            } else {
                regressionElement.addText(param + "为关键指标名称，" + indicator + "为效能指标名称。");
            }

            JSONArray conclusions = jsonObject.getJSONObject("resultAll").getJSONArray("conclusions");
            if (conclusions != null) {
                regressionElement.addText("结论：");
                for (Object conclusion : conclusions) {
                    regressionElement.addText(conclusion.toString());
                }
            }

        } else {
            regressionElement.addText("无");
        }
    }

    /**
     * 评估分析构建xml
     *
     * @param firstElement
     * @param req
     * @param scenarioList
     * @param competeSceneEntity
     */
    private void builderPgAnalysisXml(Element firstElement, DDDExportReq req, List<SceneScenarioEntity> scenarioList, CompeteSceneEntity competeSceneEntity) {
        Element nodeElement = firstElement.addElement("作战场景构建");
        Element sceneNameElement = nodeElement.addElement("场景名称");
        sceneNameElement.addText(competeSceneEntity.getName());
        Element scenario = nodeElement.addElement("战法想定");
        scenario.addText(scenarioList.get(0).getScenarioName());
        Element myTroops = nodeElement.addElement("我方兵力编成与部署");
        Element enemyTroops = nodeElement.addElement("敌方兵力编成与部署");
        StringBuilder redDeployment = new StringBuilder();
        StringBuilder blueDeployment = new StringBuilder();
        getTroops(redDeployment, blueDeployment, scenarioList.get(0).getId());


        //我方兵力部署
        String ourTroopDeployment = StringUtils.isEmpty(redDeployment.toString()) ? "暂无我方兵力编程与部署信息" : redDeployment.substring(0, redDeployment.length() - 1);
        myTroops.addText(ourTroopDeployment);
        //敌方兵力部署
        String otherTroopDeployment = StringUtils.isEmpty(blueDeployment.toString()) ? "暂无敌方兵力编程与部署信息 " : blueDeployment.substring(0, blueDeployment.length() - 1);
        enemyTroops.addText(otherTroopDeployment);

        // 指标
        Element indicatorSystem = nodeElement.addElement("评估指标体系");
        IndicatorTreeEntity indicatorTreeEntity = indicatorTreeService.getOne(new LambdaQueryWrapper<IndicatorTreeEntity>().eq(IndicatorTreeEntity::getSid, req.getSid())
                .eq(IndicatorTreeEntity::getIndicatorTreeCategory, CustomizedDataCollectionType.AFTERWARDS.getId()));
        List<IndicatorEntity> indicatorEntityList = indicatorService.findByTreeId(indicatorTreeEntity.getId());
        List<IndicatorExportNode> result = Lists.newArrayList();
        indicatorEntityList.forEach(e -> {
            result.add(new IndicatorExportNode(e.getId(), e.getName(), e.getPid(), -1.0));
        });
        List<Node> nodes = BuildTree.buildTree(result);
        builderIndicatorSystemXml(indicatorSystem, nodes);

        // 2：评估报告

        // 评估样本结构
        Element sceneStruct = nodeElement.addElement("评估样本结构");
        List<CalcModuleEntity> calcModuleEntities = iCalcModuleService.find(CalcModuleEntity.builder().sid(req.getSid()).defaultCalModule(CalModuleType.DEFAULT_MODEL.id).build());
        List<String> calModeAlgIds = Lists.newArrayList();
        if (CollUtil.isNotEmpty(calcModuleEntities)) {
            calModeAlgIds.addAll(calcModuleEntities.stream().map(CalcModuleEntity::getId).collect(Collectors.toList()));
        }
        List<IndicatorExportNode> efficacyIndicatorCalcorExportNodes = Lists.newArrayList();
        evaluationReportService.setIndicatorCalcorValueAndNumber(indicatorService.getLeafIndicator(indicatorTreeEntity.getId()), calModeAlgIds, req.getSid(), efficacyIndicatorCalcorExportNodes, 0);
        List<Node> indicatorSceneStructNodes = BuildTree.buildTree(efficacyIndicatorCalcorExportNodes);
        for (Node indicatorSceneStructNode : indicatorSceneStructNodes) {
            Element indicatorElement = sceneStruct.addElement(indicatorSceneStructNode.getName());
            List<Node> children = indicatorSceneStructNode.getChildren();
            if (CollectionUtil.isNotEmpty(children)) {
                Element indicatorParamElement = indicatorElement.addElement("指标计算需要的数据字段（采集项）");
                for (Node child : children) {
                    try {
                        indicatorParamElement.addElement(child.getName());
                    } catch (Exception e) {
                        log.error("导出时计算参数采集项出现异常，异常信息：{}", e.getMessage());
                    }
                }
            }
        }

        // 评估结果与结论
        Element resultAndConclusionElement = nodeElement.addElement("评估结果与结论");
        List<SceneEntity> sceneEntities = sceneService.list(new LambdaQueryWrapper<SceneEntity>()
                .eq(SceneEntity::getSid, req.getSid())
                .eq(SceneEntity::getSceneType, CustomizedDataCollectionType.AFTERWARDS.id));
        Map<String, List<SceneEntity>> sceneEntitieMap = sceneEntities.stream().collect(Collectors.groupingBy(SceneEntity::getTreeId));
        List<SceneEntity> sceneEntityListEfficacy = sceneEntitieMap.get(indicatorTreeEntity.getId());
        sceneEntityListEfficacy.sort((o1, o2) -> Integer.parseInt(o1.getName().split("/")[1].split("-")[1]) - Integer.parseInt(o2.getName().split("/")[1].split("-")[1]));
        Element pgResultElement = resultAndConclusionElement.addElement("评估结果详情");
        if (CollUtil.isNotEmpty(sceneEntityListEfficacy)) {
            for (SceneEntity sceneEntity : sceneEntityListEfficacy) {
                //导出结果表格
                String s = sceneEntity.getName().split("/")[1].split("-")[1];
                Element sceneElement = pgResultElement.addElement("仿真样本：" + s);
                try {
                    MergeTablesVo mergeTablesVo = evaluationCalculationService.getTable(req.getSid(), sceneEntity.getId(), CustomizedDataCollectionType.AFTERWARDS.id);
                    Element listElement = sceneElement.addElement("list");
                    for (Map<String, Object> listDatum : mergeTablesVo.getListData()) {
                        for (FixedColumnVo fixedColumnVo : mergeTablesVo.getFixedColumn()) {
                            Element propElement = listElement.addElement(fixedColumnVo.getLabel());
                            propElement.addText(listDatum.get(fixedColumnVo.getProp()).toString());
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    log.error(e.getMessage());
                }
            }
        }
        Element pgConlusionElement = resultAndConclusionElement.addElement("评估结论");
        //战况多维--获取根指标优化建议
        List<String> list = realTimeCalculateService.efficiencyTrendConclusion(competeSceneEntity.getSid());
        String afterConclusion = schemaService.afterConclusion(competeSceneEntity.getSid());
        if (com.yw.framework.common.util.StringUtils.isNotEmpty(afterConclusion)) {
            if (list.size() == 1) {
                list.clear();
                afterConclusion = "1. " + afterConclusion;
            } else {
                afterConclusion = "4. " + afterConclusion;
            }
            list.add(afterConclusion);
        }
        for (String s : list) {
            pgConlusionElement.addText(s);
        }
    }

    private void builderIndicatorSystemXml(Element element, List<Node> nodes) {
        for (Node node : nodes) {
            //节点name去除空格--xml节点不允许有空格
            String name = node.getName().trim();
            Element nodeElement = element.addElement(name);
            if (node.getChildren() != null && !node.getChildren().isEmpty()) {
                Element children = nodeElement.addElement("children");
                builderIndicatorSystemXml(children, node.getChildren());
            }
        }
    }

}
