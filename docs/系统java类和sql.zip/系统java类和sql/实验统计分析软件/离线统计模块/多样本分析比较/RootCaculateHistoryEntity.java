package com.yw.module.indicator.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.yw.framework.common.base.support.BaseEntity;
import com.yw.framework.common.module.login.util.DateUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

/**
 * TODO
 *
 * @author longyuming
 * @date 2025/1/7 19:18
 */
@Data
@ApiModel(value = "根指标计算结果历史记录表实体")
@TableName("yw_toses_root_calculate_history")
public class RootCaculateHistoryEntity {

    @ApiModelProperty(value = "id", name = "id")
    @TableId(value = "id",type = IdType.ASSIGN_UUID)
    private String id;

    @ApiModelProperty(value = "方案ID", name = "sid")
    @TableField("SID")
    private String sid;

    @ApiModelProperty(value = "根指标ID(能力指标或效能指标)", name = "indicatorId")
    @TableField("INDICATOR_ID")
    private String indicatorId;

    @ApiModelProperty(value = "样本ID", name = "sceneId")
    @TableField("SCENE_ID")
    private String sceneId;

    @ApiModelProperty(value = "指标值", name = "normalizedValue")
    @TableField("NORMALIZED_VALUE")
    private String normalizedValue;

    @ApiModelProperty(value = "指标树类型 1能力 2效能", name = "indicatorTreeType")
    @TableField(value = "INDICATOR_TREE_TYPE")
    private Integer indicatorTreeType;

    @ApiModelProperty(value = "指标评价值", name = "standardLabelValue")
    @TableField("STANDARD_LABEL_VALUE")
    private String standardLabelValue;

    @ApiModelProperty(value = "指标评价名称", name = "standardLabelName")
    @TableField("STANDARD_LABEL_NAME")
    private String standardLabelName;


    @ApiModelProperty(value = "评估次数", name = "pgNum")
    @TableField("PG_NUM")
    private Integer pgNum;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @JsonFormat(pattern = DateUtils.FMT_LONG_DATE)
    @DateTimeFormat(pattern = DateUtils.FMT_LONG_DATE)
    @ApiModelProperty("创建时间")
    private LocalDateTime createTime;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @JsonFormat(pattern = DateUtils.FMT_LONG_DATE)
    @DateTimeFormat(pattern = DateUtils.FMT_LONG_DATE)
    @ApiModelProperty("修改时间")
    private LocalDateTime updateTime;

}
