package com.yw.module.indicator.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yw.module.indicator.domain.entity.RootCaculateHistoryEntity;

public interface RootCaculateHistoryMapper extends BaseMapper<RootCaculateHistoryEntity> {
}
