package com.yw.module.indicator.controller;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.github.pagehelper.PageInfo;
import com.yw.common.defines.base.FixedColumnVo;
import com.yw.common.defines.base.Query;
import com.yw.common.utils.BuildTree;
import com.yw.common.utils.Node;
import com.yw.framework.common.base.api.R;
import com.yw.framework.common.base.support.BaseController;
import com.yw.framework.common.defines.exception.custom.BusinessException;
import com.yw.module.calculation.indicatorCalculation.point.DecimalPointRetention;
import com.yw.module.datasource.service.RealTimeCalculateService;
import com.yw.module.indicator.domain.dto.IndicatorNode;
import com.yw.module.indicator.domain.entity.IndicatorEntity;
import com.yw.module.indicator.domain.entity.IndicatorTreeEntity;
import com.yw.module.indicator.domain.entity.IndicatorValuesEntity;
import com.yw.module.indicator.domain.entity.RootCaculateHistoryEntity;
import com.yw.module.indicator.domain.req.RootCaculateHistoryReq;
import com.yw.module.indicator.domain.vo.IndicatorResultTrendConclusionVO;
import com.yw.module.indicator.domain.vo.RootCaculateHistoryVO;
import com.yw.module.indicator.domain.wrapper.RootCaculateHistoryWrapper;
import com.yw.module.indicator.service.IIndicatorService;
import com.yw.module.indicator.service.IIndicatorTreeService;
import com.yw.module.indicator.service.IRootCaculateHistoryService;
import com.yw.module.indicator.service.ITIndicatorValueService;
import com.yw.module.missionScene.domain.entity.SceneScenarioEntity;
import com.yw.module.missionScene.service.ContributionRateAlgorithmService;
import com.yw.module.missionScene.service.SceneScenarioService;
import com.yw.module.plan.domain.entity.SceneEntity;
import com.yw.module.plan.domain.entity.SchemaEntity;
import com.yw.module.plan.service.ISceneService;
import com.yw.module.plan.service.ISchemaService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiOperationSupport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

/**
 * TODO
 *
 * @author longyuming
 * @date 2025/1/7 19:16
 */
@RestController
@RequestMapping("rootCalculateHistory")
@Api(value = "根指标计算结果历史控制器", tags = "根指标计算结果历史控制器")
public class RootCaculateHistoryController extends BaseController {

    protected final static Logger log = LoggerFactory.getLogger(RootCaculateHistoryController.class);

    @Autowired
    private IRootCaculateHistoryService rootCaculateHistoryService;

    @Autowired
    private IIndicatorTreeService indicatorTreeService;

    @Autowired
    private IIndicatorService indicatorService;

    @Autowired
    private ITIndicatorValueService indicatorValueService;

    @Autowired
    private SceneScenarioService sceneScenarioService;

    @Autowired
    private ContributionRateAlgorithmService contributionRateAlgorithmService;

    @Autowired
    private ISceneService sceneService;

    @Autowired
    private DecimalPointRetention decimalPointRetention;

    @Autowired
    private ISchemaService schemaService;
    @Autowired
    private RealTimeCalculateService realTimeCalculateService;


    /**
     * 实时评估结果统计表
     *
     * @param req
     * @return
     */
    @PostMapping("/pageList")
    @ApiOperationSupport(order = 2)
    @ApiOperation(value = "分页", notes = "传入ExampleReq")
    public R<PageInfo<RootCaculateHistoryVO>> list(@RequestBody RootCaculateHistoryReq req) {
        RootCaculateHistoryVO params = req.getParams();
        Query query = req.getQuery();
        PageInfo<RootCaculateHistoryEntity> pages = rootCaculateHistoryService.selectPage(query, params);
        return R.data(RootCaculateHistoryWrapper.build().pageVO(pages));
    }

    /**
     * 实时评估 实时评估结果统计分析结论
     */
    @GetMapping("getCountResult")
    @ApiOperation(value = "实时评估 实时评估结果统计分析结论", notes = "传入方案id")
    public R<List<String>> getCountResult(String sid) {
        //TODO 如果后续这里的数据量过大，比如100万，需要优化效率，可以采用迭代式的统计方式，将最后一次的查询到的次数，最大值，最小值，累加值，数据数量，指标id入库，在这个基础上查询增量数据并重新统计
        List<RootCaculateHistoryEntity> list = rootCaculateHistoryService.list(new LambdaQueryWrapper<RootCaculateHistoryEntity>().eq(RootCaculateHistoryEntity::getSid, sid).eq(RootCaculateHistoryEntity::getIndicatorTreeType, 1).orderByAsc(RootCaculateHistoryEntity::getPgNum));
        if (CollectionUtils.isEmpty(list)) {
            return R.data(null);
        }
        List<Double> data = list.stream().map(obj -> Double.parseDouble(obj.getNormalizedValue())).collect(Collectors.toList());
        //计算平均值
        double avg = data.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
        //第m次为最大值,第n次为最小值
        double max = Double.MIN_VALUE, min = Double.MAX_VALUE;
        int m = 0, n = 1;
        for (RootCaculateHistoryEntity rootCaculateHistoryEntity : list) {
            double v = Double.parseDouble(rootCaculateHistoryEntity.getNormalizedValue());
            if (v > max) {
                max = v;
                m = rootCaculateHistoryEntity.getPgNum();
            }
            if (v < min) {
                min = v;
                n = rootCaculateHistoryEntity.getPgNum();
            }

        }

        String s1 = "通过对" + list.size() + "次能力评估结果的趋势分析可知:";
        String s2 = "1.第" + n + "次能力评估结果最差，第" + m + "次能力评估结果最优";
        String s3 = "2.以上" + list.size() + "次能力评估结果的均值为" + avg + "，能力整体趋于良好";

        List<String> result = new ArrayList<>();
        result.add(s1);
        result.add(s2);
        result.add(s3);

        return R.data(result);
    }


    /**
     * 统计分析效能统计 选择指标下拉选项
     */
    @GetMapping("getAllIndicator")
    @ApiOperation(value = "统计分析效能统计 选择指标下拉选项", notes = "传入方案id")
    public R<List<IndicatorEntity>> getAllIndicator(String sid) {
        List<IndicatorTreeEntity> treeEntityList = indicatorTreeService.list(new LambdaQueryWrapper<IndicatorTreeEntity>()
                .eq(IndicatorTreeEntity::getIndicatorTreeType, 2)
                .eq(IndicatorTreeEntity::getIndicatorTreeCategory, 2)
                .eq(IndicatorTreeEntity::getSid, sid));
        if (CollectionUtils.isEmpty(treeEntityList)) {
            return null;
        } else {
            List<IndicatorEntity> indicatorEntityList = indicatorService.list(new LambdaQueryWrapper<IndicatorEntity>().eq(IndicatorEntity::getTreeId, treeEntityList.get(0).getId()));
            return R.data(indicatorEntityList);
        }
    }

    /**
     * 统计分析效能统计 选择指标下拉选项
     */
    @GetMapping("getAllScenario")
    @ApiOperation(value = "统计分析效能统计 选择想定下拉选项", notes = "传入方案id")
    public R<List<SceneScenarioEntity>> getAllScenario(String sid) {
        List<SceneScenarioEntity> sceneScenarioEntityList = sceneScenarioService.list(new LambdaQueryWrapper<SceneScenarioEntity>().eq(SceneScenarioEntity::getSid, sid));
        return R.data(sceneScenarioEntityList);
    }

    /**
     * 统计分析效能统计 统计表格
     */
    @PostMapping("efficiencyCount")
    @ApiOperation(value = "统计分析效能统计 统计表格")
    public R<Map<String, Object>> efficiencyCount(String sid) {
        Optional<SchemaEntity> schemaEntity = schemaService.findById(sid);
        if (!schemaEntity.isPresent()) {
            throw new BusinessException("当前方案不存在");
        }
        IndicatorTreeEntity indicatorTreeEntity = indicatorTreeService.getOne(new LambdaQueryWrapper<IndicatorTreeEntity>()
                .eq(IndicatorTreeEntity::getSid, sid)
                .eq(IndicatorTreeEntity::getIndicatorTreeCategory, 1));
        List<IndicatorEntity> indicatorEntityList = indicatorService.list(new LambdaQueryWrapper<IndicatorEntity>().in(IndicatorEntity::getTreeId, indicatorTreeEntity.getId()));

        List<IndicatorNode> indicatorNodes = new ArrayList<>();
        for (IndicatorEntity indicatorEntity : indicatorEntityList) {
            IndicatorNode indicatorNode = new IndicatorNode();
            indicatorNode.setName(indicatorEntity.getName());
            indicatorNode.setId(indicatorEntity.getId());
            indicatorNode.setParentId(indicatorEntity.getPid());
            indicatorNodes.add(indicatorNode);
        }
        List<Node> treeNodes = BuildTree.buildTree(indicatorNodes);
        List<Node> leafNode = new ArrayList<>();
        BuildTree.getLeafNode(treeNodes, leafNode);
        List<String> ids = leafNode.stream().map(t -> t.getId()).collect(Collectors.toList());

        Map<String, List<Node>> indicatorChildrenMap = leafNode.stream().collect(Collectors.groupingBy(Node::getParentId));
        List<FixedColumnVo> fixedColumnList = new ArrayList<>();
        for (Map.Entry<String, List<Node>> entry : indicatorChildrenMap.entrySet()) {
            IndicatorEntity parent = indicatorService.getById(entry.getKey());
            if (parent != null) {
                FixedColumnVo fixedColumn = new FixedColumnVo();
                fixedColumn.setProp(entry.getKey());
                fixedColumn.setLabel(parent.getName());
                fixedColumnList.add(fixedColumn);

                List<Node> value = entry.getValue();
                List<FixedColumnVo> childrenFixedColumnList = new ArrayList<>();
                for (Node node : value) {
                    FixedColumnVo child = new FixedColumnVo();
                    child.setProp(node.getId());
                    child.setLabel(node.getName());
                    childrenFixedColumnList.add(child);
                }
                fixedColumn.setPropsChildren(childrenFixedColumnList);
            }

        }
        FixedColumnVo fixedColumn = new FixedColumnVo();
        fixedColumn.setProp("name");
        fixedColumn.setLabel("统计量名称");
        fixedColumnList.add(fixedColumn);


        //查询想定样本关联表
//        List<ContributionRateAlgorithmEntity> contributionRateAlgorithmEntityList = contributionRateAlgorithmService.list(new LambdaQueryWrapper<ContributionRateAlgorithmEntity>().eq(ContributionRateAlgorithmEntity::getSceneScenarioId,vo.getScenarioId()));
//        if(CollectionUtils.isEmpty(contributionRateAlgorithmEntityList)){
//            return R.data(null);
//        }
//        List<String> sceneIds = contributionRateAlgorithmEntityList.stream().map(obj->obj.getSceneId()).collect(Collectors.toList());
        //二次过滤
        List<SceneEntity> sceneEntityList = sceneService.list(new LambdaQueryWrapper<SceneEntity>().eq(SceneEntity::getSid, indicatorEntityList.get(0).getSid()).eq(SceneEntity::getTreeId, indicatorTreeEntity.getId()));

        if (CollectionUtils.isEmpty(sceneEntityList)) {
            return R.data(null);
        }
        Set<String> sceneIds = sceneEntityList.stream().map(SceneEntity::getId).collect(Collectors.toSet());
        List<IndicatorValuesEntity> indicatorValuesEntityList = indicatorValueService.list(new LambdaQueryWrapper<IndicatorValuesEntity>()
                .in(IndicatorValuesEntity::getIndicatorId, ids)
                .in(IndicatorValuesEntity::getSceneId, sceneIds));
        Map<String, List<IndicatorValuesEntity>> indicatorValueMap = indicatorValuesEntityList.stream().collect(Collectors.groupingBy(IndicatorValuesEntity::getIndicatorId));

        List<Map<String, String>> list = new ArrayList<>();
        Map<String, String> avgMap = new TreeMap<>();
        avgMap.put("name", "均值");
        Map<String, String> minMap = new TreeMap<>();
        minMap.put("name", "最小值");
        Map<String, String> maxMap = new TreeMap<>();
        maxMap.put("name", "最大值");
        Map<String, String> sumOfsquareMap = new TreeMap<>();
        sumOfsquareMap.put("name", "方差");
        Map<String, String> standardMap = new TreeMap<>();
        standardMap.put("name", "标准差");
        Map<String, String> midMap = new TreeMap<>();
        midMap.put("name", "中位数");
        Map<String, String> modeMap = new TreeMap<>();
        modeMap.put("name", "众数");

        list.add(avgMap);
        list.add(minMap);
        list.add(maxMap);
        list.add(sumOfsquareMap);
        list.add(standardMap);
        list.add(midMap);
        list.add(modeMap);

        for (Node node : leafNode) {
            String id = node.getId();
            List<IndicatorValuesEntity> valueList = indicatorValueMap.get(id);
            if (CollectionUtils.isEmpty(valueList)) {
                continue;
            }
            List<Double> data = valueList.stream().map(obj -> Double.parseDouble(obj.getNormalizedValue())).collect(Collectors.toList());

            //计算平均值
            double avg = decimalPointRetention.setScale(BigDecimal.valueOf(data.stream().mapToDouble(Double::doubleValue).average().orElse(0.0)), 0.0);
            avgMap.put(id, avg + "");
            //计算最大值
            OptionalDouble maxOp = data.stream().mapToDouble(Double::doubleValue).max();
            double max = maxOp.isPresent() ? maxOp.getAsDouble() : 0.0;
            maxMap.put(id, max + "");
            //计算最小值
            OptionalDouble minOp = data.stream().mapToDouble(Double::doubleValue).min();
            double min = minOp.isPresent() ? minOp.getAsDouble() : 0.0;
            minMap.put(id, min + "");
            //计算方差
            double sumOfsquareDiff = decimalPointRetention.setScale(BigDecimal.valueOf(data.stream().mapToDouble(Double::doubleValue).map(x -> Math.pow(x - avg, 2)).sum() / (data.size())), 0.0);
            sumOfsquareMap.put(id, sumOfsquareDiff + "");
            //计算标准差
            double standard = decimalPointRetention.setScale(BigDecimal.valueOf(Math.sqrt(sumOfsquareDiff)), 0.0);
            standardMap.put(id, standard + "");
            //计算中位数
            double mid = 0.0;
            List<Double> sortedList = data.stream().sorted().collect(Collectors.toList());
            if (data.size() == 1) {
                mid = data.get(0);
            } else if (data.size() % 2 == 0) {
                mid = (sortedList.get(data.size() / 2 - 1) + sortedList.get(data.size() / 2)) / 2;
            } else {
                mid = sortedList.get(data.size() / 2);
            }
            midMap.put(id, decimalPointRetention.setScale(BigDecimal.valueOf(mid), ""));
            //计算众数
            Map<Double, Long> frequencyMap = data.stream().collect(Collectors.groupingBy(x -> x, Collectors.counting()));
            long maxFrequency = frequencyMap.values().stream().max(Long::compareTo).orElse(0L);
            List<Double> mode = frequencyMap.entrySet().stream().filter(entry -> entry.getValue() == maxFrequency).map(Map.Entry::getKey).collect(Collectors.toList());
            modeMap.put(id, mode.get(0) + "");
        }
        Map<String, Object> data = new HashMap<>();
        data.put("data", list);
        data.put("herder", fixedColumnList);
        data.put("conclusions", realTimeCalculateService.efficiencyTrendConclusion(sid));
        return R.data(data);
    }


    /**
     * 统计分析效能结果变化趋势
     */
    @PostMapping("/efficiencyTrend")
    @ApiOperation(value = "统计分析效能结果变化趋势")
    public R<IndicatorResultTrendConclusionVO> efficiencyTrend(String indicatorId) {

        IndicatorResultTrendConclusionVO vo = rootCaculateHistoryService.efficiencyTrendSuggestion(indicatorId);


        return R.data(vo);
    }
}
