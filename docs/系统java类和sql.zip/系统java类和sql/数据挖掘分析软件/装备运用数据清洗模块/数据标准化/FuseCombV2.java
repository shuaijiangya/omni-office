package com.yw.fusionanaly.database.collection;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.yw.fusionanaly.common.annotation.Muster;
import com.yw.fusionanaly.database.Entity;
import com.yw.fusionanaly.database.entity.FieldEntity;
import com.yw.fusionanaly.module.disposeFuse.type.FuseMoldType;
import com.yw.fusionanaly.module.disposeFuse.type.FuseSourceTypeV2;
import com.yw.fusionanaly.module.plan.type.PlanMethodsType;
import com.yw.fusionanaly.module.plan.type.PlanSampleMethodType;
import com.yw.fusionanaly.module.plan.type.TopicTypeMethod;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 组合数据
 */
@Data
@Muster(name = "fuse_comb_v2", pk = "_id")
@Document("fuse_comb_v2")
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FuseCombV2 extends Entity {
    /**
     * 组合Id
     */
    @ApiModelProperty("组合id")
    @Id
    private Integer _id;
    /**
     * 主题名称
     */
    @ApiModelProperty("主题名称")
    private String topicName;
    /**
     * 主题类别
     */
    @ApiModelProperty("主题类别")
    private TopicTypeMethod topicType;
    /**
     * 主题描述
     */
    @ApiModelProperty("主题描述")
    private String topicDescription;
    /**
     * 方案id
     */
    @ApiModelProperty("方案id")
    private String planId;
    /**
     * 分析方法
     */
    @ApiModelProperty(name = "分析方法", notes = "com.yw.fusionanaly.module.plan.type.PlanRegressionType", required = true)
    private List<PlanMethodsType> method;
    /**
     * 选取的字段
     * {key:FuseSourceType, value:{key:fieldName, value:FieldEntity}}
     */
    @ApiModelProperty("选取字段")
    private Map<Integer, Map<String, FieldEntity>> chooseMap;
    /**
     * 选取参数
     */
    @ApiModelProperty("选取参数")
    private List<Integer> trunkList;
    /**
     * 类型
     * 4: 装备
     * 2: 装备体系
     * 5: 指标体系
     */
    @ApiModelProperty("类型（ 4: 装备 2: 装备体系 5: 指标体系）")
    private int type;
    /**
     * 融合数据集合名字
     */
    @ApiModelProperty("融合数据集合名字")
    private String collectionName;
    /**
     * 状态
     */
    @ApiModelProperty("状态 1.组合完成 2.采集数据 3.采集失败 4.采集成功")
    private int status;
    /**
     * 是否预处理
     */
    @ApiModelProperty("是否预处理 0未预处理，1相同列预处理，2固定值与处理，4数据填充预处理，1+2 1+4....代表多项预处理")
    private int pretreatment;
    /**
     * 创建时间
     */
    @ApiModelProperty("创建时间")
    private String createTime;

    @ApiModelProperty("参数数量")
    private long paramCount;


    private String identicalDate;
    private String lossDate;
    private String fixedDate;

    /**
     * 方案下样本列表
     */
    @ApiModelProperty(name = "方案下样本列表", required = true)
    @Transient
    private List<PlanSample> planSampleList;

    public static FuseCombV2 valueOf(int type, Map<Integer, Map<String, FieldEntity>> chooseMap, int status,
                                     String topicName, TopicTypeMethod topicType, String topicDescription, List<PlanMethodsType> methods, String planId) {
        FuseCombV2 comb = new FuseCombV2();
        comb.type = type;
        if (type == FuseMoldType.INDEX_SYSTEM_EXCAVATE.getId() || type == FuseMoldType.EVALUATION_TASK_EXCAVATE.getId()) {
            comb.pretreatment = 7;
        } else {
            comb.pretreatment = 0;
        }
        comb.chooseMap = chooseMap;
        comb.createTime = DateUtil.formatDateTime(new Date());
        comb.status = status;
        comb.paramCount = comb.getCount(chooseMap);
        comb.topicName = topicName;
        comb.topicType = topicType;
        comb.topicDescription = topicDescription;
        comb.method = methods;
        comb.planId = planId;
        return comb;
    }

    private long getCount(Map<Integer, Map<String, FieldEntity>> chooseMap) {
        long count = 0;
        Set<Integer> integers = chooseMap.keySet();
        for (Integer i : integers) {
            Map<String, FieldEntity> map = chooseMap.get(i);
            FieldEntity root = map.get("ROOT");
            FieldEntity middle = map.get("MIDDLE");
            FieldEntity leaf = map.get("LEAF");
            if (root != null || middle != null || leaf != null) {
                if (root != null) {
                    count += root.getChildField().size();
                }
                if (middle != null) {
                    count += middle.getChildField().size();
                }
                if (leaf != null) {
                    count += leaf.getChildField().size();
                }
            } else {
                count += map.size();
            }
        }
        return count;
    }

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        FuseCombV2 fuseComb = (FuseCombV2) o;
        return _id.equals(fuseComb._id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(_id);
    }

    @ApiModelProperty("主题-方法")
    public List<Map<String, Object>> getMethodList() {
        return method.stream().map(item -> {
            Map<String, Object> map = Maps.newHashMap();
            map.put("id", item.name());
            map.put("name", item.getName());

            if (CollUtil.isNotEmpty(this.planSampleList)) {
                List<PlanSample> planSampleList = this.planSampleList.stream().filter(
                        planSample -> PlanMethodsType.toPlanSampleRegressionType(PlanMethodsType.valueOf(item.name()))
                                .contains(PlanSampleMethodType.valueOf(planSample.getType().getName()))).collect(Collectors.toList());
                map.put("planSampleList", planSampleList);
            } else {
                map.put("planSampleList", Collections.emptyList());
            }
            return map;
        }).collect(Collectors.toList());
    }

    @ApiModelProperty("指标/变量")
    public List<Map<String, Object>> getVariableList() {
        List<Map<String, Object>> objects = Lists.newArrayList();
//        if (type == 4 || type == 2) {
        // 装备和装备体系
        chooseMap.forEach((key, value) -> {
            FuseSourceTypeV2 type = FuseSourceTypeV2.getType(key);
            if (type.getId() == 3) {
                value.values().forEach(item2 -> {
                    item2.getChildField().forEach(item -> {
                        Map<String, Object> map = Maps.newHashMap();
                        map.put("id", item.getField());
                        map.put("name", item.getName());
                        map.put("sourceTypeId", type.getId());
                        map.put("sourceTypeName", type.getName());
                        objects.add(map);
                    });
                });
            } else {
                value.values().forEach(item2 -> {
                    Map<String, Object> map = Maps.newHashMap();
                    map.put("id", item2.getField());
                    map.put("name", item2.getName());
                    map.put("sourceTypeId", type.getId());
                    map.put("sourceTypeName", type.getName());
                    objects.add(map);
                });
            }
        });
        return objects;
    }

    public List<Map<String, Object>> getSelectVariableList() {
        List<Map<String, Object>> objects = Lists.newArrayList();
        // 装备和装备体系
        chooseMap.forEach((key, value) -> {
            FuseSourceTypeV2 type = FuseSourceTypeV2.getType(key);
            if (type.getId() == 3) {
                value.values().forEach(item2 -> {
                    item2.getChildField().forEach(item -> {
                        Map<String, Object> map = Maps.newHashMap();
                        map.put("id", item.getField());
                        map.put("name", item.getName());
                        map.put("sourceTypeId", type.getId());
                        map.put("sourceTypeName", type.getName());
                        objects.add(map);
                    });
                });
            } else {
                // 字段名去重
                Set<String> fieldNameSet = Sets.newHashSet();

                value.values().forEach(item2 -> {
                    if (fieldNameSet.add(item2.getFieldName())) {
                        Map<String, Object> map = Maps.newHashMap();
                        map.put("id", item2.getField());
                        map.put("name", item2.getFieldName());
                        map.put("sourceTypeId", type.getId());
                        map.put("sourceTypeName", type.getName());
                        objects.add(map);
                    }
                });
            }
        });
        return objects;
    }

    @ApiModelProperty(value = "主题类别名称")
    public String getTopicTypeName() {
        return topicType.getTopicName();
    }

}
