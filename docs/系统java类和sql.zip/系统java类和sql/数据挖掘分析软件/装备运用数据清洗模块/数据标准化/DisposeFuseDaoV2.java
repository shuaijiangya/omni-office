package com.yw.fusionanaly.module.disposeFuse.dao;

import com.yw.fusionanaly.common.result.PageResult;
import com.yw.fusionanaly.common.result.YwResult;
import com.yw.fusionanaly.database.collection.FuseCombV2;
import com.yw.fusionanaly.database.collection.FuseSpecimen;
import com.yw.fusionanaly.database.entity.FieldEntity;
import com.yw.fusionanaly.module.disposeFuse.request.FuseDataPageReq;
import com.yw.fusionanaly.module.disposeFuse.response.FuseCheckResponse;
import com.yw.fusionanaly.module.disposeFuse.response.FuseCombResponseV2;
import com.yw.fusionanaly.module.disposeFuse.response.FuseDataResp;
import com.yw.fusionanaly.module.disposeFuse.type.FuseMoldType;
import com.yw.fusionanaly.module.disposeFuse.type.FuseSourceType;
import com.yw.fusionanaly.module.disposeFuse.type.FuseStatusType;
import com.yw.fusionanaly.module.plan.type.PlanMethodsType;
import com.yw.fusionanaly.module.plan.type.TopicTypeMethod;

import java.util.Collection;
import java.util.List;
import java.util.Map;

public interface DisposeFuseDaoV2 {

    /**
     * 创建组合
     *
     * @param type
     * @param chooseMap
     * @param methods
     * @param planId
     * @param trunkList
     * @return
     */
    FuseCombV2 createFuseComb(Integer id, FuseMoldType type, String topicName, TopicTypeMethod topicType, String topicDescription, Map<Integer, Map<String, FieldEntity>> chooseMap, List<PlanMethodsType> methods, String planId, List<Integer> trunkList);

    /**
     * 获取表字段
     *
     * @param sourceType
     * @param type
     * @param tableName
     * @param trunkList
     * @return
     */
    Map<String, FieldEntity> getFields(FuseSourceType sourceType, FuseMoldType type, String tableName, Collection<Integer> trunkList);

    /**
     * 保存融合数据
     *
     * @param values
     */
    void saveFuseSpecimen(int fuseId, Collection<FuseSpecimen> values, int status);


    /**
     * 获取装备列表信息
     *
     * @param type
     * @return
     */
    Map<Object, Object> getTrunkParam(FuseSourceType type);


    /**
     * 获取组合字段
     *
     * @param fuseId
     * @return
     */
    public Map<String, String> getFuseFields(int fuseId);

    /**
     * 选取字段返回目标字段数据
     *
     * @param type
     * @param tableName
     * @param trunkList
     * @param chooseList
     * @param pageNum
     * @param limit
     * @return
     */
    Map<Integer, Map<String, Object>> getTableResource(FuseMoldType type, String tableName, List<Integer> trunkList, List<String> chooseList, int pageNum, int limit);


    //修改融合采集状态
    void updateFuseCombStatus(int id, FuseStatusType collectData);


    /**
     * 根据方案id查询
     *
     * @param id 方案id
     * @return 当前方案下所有主题
     */
    List<FuseCombV2> queryFuseByPlanId(String id);

    /**
     * 根据方案id删除fuse_comb
     *
     * @param planId 方案id
     */
    void deleteByPlanId(String planId);

    /**
     * 获取装备字段信息
     *
     * @param sourceType
     * @param moldType
     * @param tableName
     * @param trunkList
     * @return
     */
    Map<String, FieldEntity> getEquipmentFields(FuseSourceType sourceType, FuseMoldType moldType, String tableName, Collection<Integer> trunkList);

    /**
     * 删除列数据
     *
     * @param fuseId
     * @param fieldName
     * @return
     */
    Long deleteField(int fuseId, List<String> fieldName, String type);

    /**
     * 融合数据分页
     *
     * @param fuseDataPageReq
     * @return
     */
    YwResult<FuseDataResp> dataPageList(FuseDataPageReq fuseDataPageReq);

    /**
     * 手动数据填充（修改）
     *
     * @param fuseId
     * @return
     */
    YwResult handFillData(Integer fuseId, List<FuseSpecimen> fuseSpecimenList);

    /**
     * 固定值检查
     *
     * @param fuseId
     * @return
     */
    FuseCheckResponse fixedCheck2(int fuseId);

    /**
     * 缺失项检查
     *
     * @param fuseId
     * @return
     */
    FuseCheckResponse defect(int fuseId);

    /**
     * 相同列检查
     *
     * @param fuseId
     * @return
     */
    FuseCheckResponse uniformityCheck2(int fuseId);

    /**
     * 自动--数据填充
     *
     * @param fuseId
     * @param value
     * @return
     */
    Long autoFillData(int fuseId, Object value);

    /**
     * 获取组合数据
     *
     * @param id
     * @return
     */
    FuseCombResponseV2 getFuseCombData(int id);

    /**
     * 获取所有组合
     *
     * @param pageNum
     * @param limit
     * @param name
     */
    PageResult getAllFuseComb(int pageNum, int limit, String name,
                              String pretreatment);

    List<FuseCombV2> listByPlanId(String planId);

    void deleteById(Integer topicId);
}
