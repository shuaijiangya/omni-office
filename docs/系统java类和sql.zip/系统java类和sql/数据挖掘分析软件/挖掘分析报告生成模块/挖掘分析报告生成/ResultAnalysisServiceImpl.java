package com.yw.fusionanaly.module.analysis.service.impl;

import com.yw.fusionanaly.common.exception.ApiException;
import com.yw.fusionanaly.common.parser.AbstractParser;
import com.yw.fusionanaly.database.collection.PlanSample;
import com.yw.fusionanaly.module.analysis.model.request.ExportBySampleParam;
import com.yw.fusionanaly.module.analysis.model.response.AbstractResultAnalysisVO;
import com.yw.fusionanaly.module.analysis.service.ResultAnalysisService;
import com.yw.fusionanaly.module.analysis.strategy.ResultAnalysisStrategy;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;

/**
 * 结果分析
 *
 * @author zhangkun
 * @date 2022/10/9 10:30
 */
@Service
@RequiredArgsConstructor
public class ResultAnalysisServiceImpl implements ResultAnalysisService {

    private final ResultAnalysisStrategy strategy;
    private final MongoTemplate mongoTemplate;

    /**
     * 获取样本的result;
     * 解析result;八种类型
     * 分析并生成结论;八种类型
     * 拼装返回;
     *
     * @param sampleId 样本id
     */
    @Override
    public AbstractResultAnalysisVO getResultBySampleId(String sampleId) {
        // 获取样本
        PlanSample planSample = validAndGetSample(sampleId);
        // 获取解析实体
        AbstractParser parser = strategy.getParser(planSample);
        // 分析并组装数据
        return strategy.analysis(parser, planSample);
    }

    @Override
    public void export(HttpServletResponse response, ExportBySampleParam param) {
        // 获取样本
        PlanSample planSample = validAndGetSample(param.getSampleId());
        // 获取解析实体
        AbstractParser parser = strategy.getParser(planSample);
        // 导出数据
        strategy.export(response, param, parser, planSample);
    }

    protected PlanSample validAndGetSample(String sampleId) {
        if (StringUtils.isBlank(sampleId)) {
            throw new ApiException("样本id为空");
        }

        PlanSample planSample = mongoTemplate.findById(sampleId, PlanSample.class);
        if (planSample == null) {
            throw new ApiException("样本id不存在");
        }

        String result = (String) planSample.getResult();
        if (StringUtils.isBlank(result)) {
            throw new ApiException("样本结果集为空");
        }

        return planSample;
    }

}
