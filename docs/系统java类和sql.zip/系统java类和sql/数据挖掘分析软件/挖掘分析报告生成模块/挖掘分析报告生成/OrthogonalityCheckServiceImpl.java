package com.yw.fusionanaly.module.analysis.service.impl;

import com.yw.fusionanaly.module.analysis.model.request.ExportBySampleParam;
import com.yw.fusionanaly.module.analysis.service.OrthogonalityCheckService;
import com.yw.fusionanaly.module.analysis.strategy.OrthogonalityCheckStrategy;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;

/**
 * 正态性校验
 *
 * @author zhangkun
 * @date 2022/9/2 15:26
 */
@Service
@RequiredArgsConstructor
public class OrthogonalityCheckServiceImpl implements OrthogonalityCheckService {

    private final OrthogonalityCheckStrategy strategy;

    @Override
    public Object analysis(String sampleId) {
        return strategy.execute(sampleId);
    }

    @Override
    public void exportByTopic(HttpServletResponse response, ExportBySampleParam param) {
        strategy.export(response, param);
    }
}
