package com.yw.fusionanaly.module.analysis.service.impl;

import cn.hutool.core.collection.CollUtil;
import com.yw.fusionanaly.database.collection.PlanSample;
import com.yw.fusionanaly.module.analysis.model.request.ComparativeByTopicParam;
import com.yw.fusionanaly.module.analysis.model.request.ExportByTopicParam;
import com.yw.fusionanaly.module.analysis.service.ComparativeService;
import com.yw.fusionanaly.module.analysis.strategy.ComparativeSameTopicStrategy;
import com.yw.fusionanaly.module.plan.type.PlanSampleMethodType;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * 对比分析
 *
 * @author zhangkun
 * @date 2022/9/1 9:41
 */
@Service
@RequiredArgsConstructor
public class ComparativeServiceImpl implements ComparativeService {

    /**
     * 对比分析 - 相同主题不同主题类别的比较方式
     */
    private final ComparativeSameTopicStrategy strategy;

    private final MongoTemplate mongoTemplate;

    @Override
    public Object sameTopic(ComparativeByTopicParam comparativeByTopicParam) {
        return strategy.execute(comparativeByTopicParam);
    }

    @Override
    public void exportByTopic(HttpServletResponse response, ExportByTopicParam param) {
        strategy.export(response, param);
    }

    @Override
    public List<PlanSample> listSameTopicSelect(String topicId, String sampleId) {
        List<PlanSample> planSampleList = mongoTemplate.find(Query.query(Criteria.where("basesetId").is(topicId)), PlanSample.class);
        planSampleList = planSampleList.stream().filter(item -> item.getResult() != null && StringUtils.isNotBlank((String) item.getResult())).collect(Collectors.toList());

        if (CollUtil.isEmpty(planSampleList)) {
            return Collections.emptyList();
//            throw new ApiException("没有可选样本");
        }

        Optional<PlanSample> optionalPlanSample = planSampleList.stream().filter(item -> item.getId().equals(sampleId)).findFirst();
        if (!optionalPlanSample.isPresent()) {
//            throw new ApiException("所选样本没结果数据");
            return Collections.emptyList();
        }
        PlanSample selectPlanSample = optionalPlanSample.get();
        PlanSampleMethodType methodType = selectPlanSample.getType();

        planSampleList.removeIf(planSample -> methodType.equals(planSample.getType()));

        if (CollUtil.isEmpty(planSampleList)) {
//            throw new ApiException("没有可选样本");
            return Collections.emptyList();
        }

        return planSampleList;
    }
}
