package com.yw.module.rules.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yw.module.rules.domain.entity.RuleEntity;
import com.yw.module.rules.mapper.RuleMapper;
import com.yw.module.rules.service.RuleService;
import org.springframework.stereotype.Service;


/**
 * 规则代码信息存储服务
 * @author lei
 * @date 2025/7/16 14:16
 */
@Service
public class RuleServiceImpl extends ServiceImpl<RuleMapper, RuleEntity> implements RuleService {


}