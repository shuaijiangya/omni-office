package com.yw.module.rules.domain.entity;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.yw.framework.common.base.support.BaseEntity;
import com.yw.framework.common.module.login.util.DateUtils;
import com.yw.framework.common.util.StringUtils;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * @author lei
 * @date 2025/7/16 14:16
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("wa_jue_rule")
public class RuleEntity extends BaseEntity {

    @TableId(value = "ID", type = IdType.ASSIGN_UUID)
    @ApiModelProperty("id，新增时不传")
    private String id;

    /**
     * 规则名称（唯一）
     */
    private String name;

    /**
     * 规则描述
     */
    private String description;

    /**
     * 规则条件
     */
    @TableField("`condition`")
    private String condition = "return true;";

    /**
     * 规则执行代码
     */
    @ApiModelProperty("规则脚本")
    private String action;

    /**
     * 优先级
     */
    private int priority = 1;

    /**
     * 方案id
     */
    @ApiModelProperty("方案id")
    private String sid;

    /**
     * 指标id
     */
    @ApiModelProperty("指标id")
    private String indicatorId;

    /**
     * 指标计算模型id
     */
    @ApiModelProperty("指标计算模型id")
    private String calcModuleId;

    /**
     * 数据源id
     */
    @ApiModelProperty("数据源id")
    private String dataSrcId;

    private String tableFields;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @JsonFormat(pattern = DateUtils.FMT_LONG_DATE)
    @DateTimeFormat(pattern = DateUtils.FMT_LONG_DATE)
    @ApiModelProperty("创建时间")
    private LocalDateTime createTime;

    /**
     * 拖拉表对应字段
     */
    @TableField(exist = false)
    @ApiModelProperty("表对应字段")
    private Map<String, List<String>> tableFieldsMap;

    public void setTableFields(String tableFields) {
        //System.out.println("tableFields");
        if (StringUtils.isNotEmpty(tableFields)){
            this.tableFieldsMap = JSON.parseObject(tableFields, Map.class);
            this.tableFields = tableFields;
        }
    }

//    public void setTableFieldsMap(Map<String, List<String>> tableFieldsMap) {
//        if (tableFieldsMap!=null){
//            this.tableFieldsMap = tableFieldsMap;
//            this.tableFields = JSON.toJSONString(tableFieldsMap);
//        }
//        System.out.println("tableFieldsMap");
//    }


}
