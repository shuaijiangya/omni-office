package com.yw.module.rules.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yw.module.rules.domain.entity.RuleEntity;

public interface RuleMapper extends BaseMapper<RuleEntity> {
}
