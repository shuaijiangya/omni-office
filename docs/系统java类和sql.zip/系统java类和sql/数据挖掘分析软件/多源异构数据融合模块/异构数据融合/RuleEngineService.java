package com.yw.module.rules.service;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.IdUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.yw.common.defines.listener.AutoGeneratorSceneApplication;
import com.yw.common.utils.DataGatherUtils;
import com.yw.common.utils.EquTypeUtils;
import com.yw.framework.common.util.StringUtils;
import com.yw.framework.common.util.db.DbUtil;
import com.yw.framework.common.util.db.MySqlStatementUtil;
import com.yw.framework.common.util.pool2.DbConn;
import com.yw.module.analysis.domain.entity.FzEquipmentNum;
import com.yw.module.analysis.service.IFzEquipmentService;
import com.yw.module.analysis.service.SensitivityAnalysisV2Service;
import com.yw.module.datasource.domain.enums.CustomizedDataCollectionType;
import com.yw.module.indicator.domain.entity.IndicatorTreeEntity;
import com.yw.module.plan.domain.entity.SceneEntity;
import com.yw.module.plan.domain.entity.SceneTableEntity;
import com.yw.module.plan.service.ISceneTableService;
import com.yw.module.tcpconnect.script.CircleUnionArea;
import com.yw.framework.backMgr.dbTableGenerator.domain.bo.DbLinkBO;
import com.yw.framework.backMgr.dbTableGenerator.domain.dto.TableColsDTO;
import com.yw.framework.backMgr.dbTableGenerator.service.impl.DataBaseHandler;
import com.yw.framework.common.component.stomp.message.StompMessagePusher;
import com.yw.framework.common.component.taskschedule.TaskSchedulerManager;
import com.yw.framework.common.defines.exception.custom.BusinessException;
import com.yw.framework.common.util.UUIDGenerator;
import com.yw.gather.dbinfomgr.IDatasrcService;
import com.yw.gather.dbinfomgr.entity.DatasrcEntity;
import com.yw.gather.gatherscheme.schemeMgr.entity.GatherRoundRecord;
import com.yw.gather.gatherscheme.schemeMgr.service.IGatherRoundRecordService;
import com.yw.gather.gathertask.defines.CopyDataFromFileToDB;
import com.yw.gather.gathertask.defines.DataSourceExeclParam;
import com.yw.module.indicator.service.IIndicatorTreeService;
import com.yw.module.missionScene.domain.entity.SceneScenarioEntity;
import com.yw.module.missionScene.service.SceneScenarioService;
import com.yw.module.plan.service.ISceneService;
import com.yw.module.rules.domain.Result;
import com.yw.module.rules.domain.entity.RuleEntity;
import com.yw.module.tcpconnect.script.*;
import com.yw.source.common.enums.SceneTypeEnum;
import com.yw.source.dataManagement.handler.DataBasesOperationHandler;
import com.yw.source.dataManagement.handler.method.SimpleFrameworkController;
import com.yw.source.importDataDirectory.entity.DataDirectory;
import com.yw.source.importDataDirectory.entity.ImportTableRecord;
import com.yw.source.importDataDirectory.service.IDataDirectoryService;
import com.yw.source.importDataDirectory.service.IImportTableRecordService;
import com.yw.sys.websocket.WebSocketConstant;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.api.Facts;
import org.jeasy.rules.api.Rules;
import org.jeasy.rules.api.RulesEngine;
import org.jeasy.rules.mvel.MVELRule;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * 规则引擎
 *
 * @author lei
 * @date 2025/7/16 14:17
 */
@Slf4j
@Service
public class RuleEngineService implements ApplicationContextAware {
    @Autowired
    private RulesEngine rulesEngine;
    private final Rules rules = new Rules();
    @Autowired
    private RuleService ruleService;

    @Autowired
    private IDataDirectoryService dataDirectoryService;

    @Autowired
    private IDatasrcService datasrcService;
    @Autowired
    private SimpleFrameworkController simpleFrameworkController;

    @Autowired
    private ISceneService sceneService;

    @Autowired
    private ISceneTableService sceneTableService;
    @Autowired
    private IIndicatorTreeService indicatorTreeService;

    @Autowired
    private IGatherRoundRecordService roundRecordService;
    /**
     * 数据写入
     */
    @Autowired
    private CopyDataFromFileToDB copyDataFromFileToDB;
    /**
     * 数据库操作
     */
    @Autowired
    private DataBaseHandler dataBaseHandler;

    @Autowired
    private DataBasesOperationHandler dataBasesOperationHandler;

    @Resource
    private IImportTableRecordService importTableRecordService;

    @Autowired
    private SceneScenarioService sceneScenarioService;

    @Autowired
    private TaskSchedulerManager taskSchedulerManager;
    @Autowired
    private SensitivityAnalysisV2Service sensitivityAnalysisV2Service;

    @Autowired
    private IFzEquipmentService fzEquipmentService;

    private ApplicationContext applicationContext;

    /**
     * 执行规则引擎前，缓存的所有表数据
     */
    @Getter
    @Setter
    private Map<String, List<Map<String, Object>>> tableData;

    final ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(6, 12, 10000, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<>(), Executors.defaultThreadFactory());


    /**
     * 重新加载所有规则
     */
    public void reloadAllRules() {
        //rules.unregisterAll();
        //rules.unregister();
        rules.clear();
        ruleService.list().forEach(ruleDef -> {
            try {
                MVELRule rule = new MVELRule()
                        .name(ruleDef.getName())
                        .description(ruleDef.getDescription())
                        .priority(ruleDef.getPriority())
                        .when(ruleDef.getCondition())
                        .then(ruleDef.getAction());
                rules.register(rule);
            } catch (Exception e) {
                System.err.println("加载规则失败: " + ruleDef.getName());
                e.printStackTrace();
            }
        });
    }

    /**
     * 重新加载计算方案所有规则
     */
    public void reloadAllRulesBySid(String sid) {
        //rules.unregisterAll();
        //rules.unregister();
        rules.clear();
        ruleService.list(new LambdaQueryWrapper<RuleEntity>().eq(RuleEntity::getSid, sid))
                .forEach(ruleDef -> {
                    try {
                        MVELRule rule = new MVELRule()
                                .name(ruleDef.getIndicatorId())
                                .description(ruleDef.getDescription())
                                .priority(ruleDef.getPriority())
                                .when(ruleDef.getCondition())
                                .then(ruleDef.getAction());
                        rules.register(rule);
                    } catch (Exception e) {
                        System.err.println("加载规则失败: " + ruleDef.getName());
                        e.printStackTrace();
                    }
                });
    }

    /**
     * 将规则从规则引擎中删除
     *
     * @param ruleDef
     */
    public void deleteRuls(RuleEntity ruleDef) {
        rules.unregister(ruleDef);
    }


    /**
     * 加载规则到规则引擎
     */
    public void reloadRule(RuleEntity ruleDef) {
        try {
            MVELRule rule = new MVELRule()
                    .name(ruleDef.getIndicatorId())
                    .description(ruleDef.getDescription())
                    .priority(ruleDef.getPriority())
                    .when(ruleDef.getCondition())
                    .then(ruleDef.getAction());
            rules.register(rule);
        } catch (Exception e) {
            System.err.println("加载规则失败: " + ruleDef.getName());
            e.printStackTrace();
        }
    }


    /**
     * 执行规则引擎中的规则
     */
    public Map<String, Object> applyRules(String id, String k) {

        RuleEntity ruleEntity = ruleService.getById(id);

        DatasrcEntity datasrcEntity = datasrcService.getById(ruleEntity.getDataSrcId());

        Map<String, List<String>> tableFieldsMap = ruleEntity.getTableFieldsMap();

        String taskId = k;
        if (k==null){
            SceneScenarioEntity sceneScenarioEntity = sceneScenarioService.getOne(new LambdaQueryWrapper<SceneScenarioEntity>()
                    .eq(SceneScenarioEntity::getSid, ruleEntity.getSid()).last("limit 1"));
            GatherRoundRecord gatherRoundRecord = roundRecordService.getOne(new LambdaQueryWrapper<GatherRoundRecord>()
                    //.like(GatherRoundRecord::getTaskId, "3b63b84dd48b4edb9b07ac169f2078a9")
                    .like(GatherRoundRecord::getTaskId, sceneScenarioEntity.getSourceId())
                    .eq(GatherRoundRecord::getDataSrcId, datasrcEntity.getId()).orderByDesc(GatherRoundRecord::getTaskId).last("limit 1"));
            if (gatherRoundRecord==null){
                throw new BusinessException("场景仿真数据不存在，请先接收仿真数据后重试！");
            }
            taskId = gatherRoundRecord.getTaskId();
        }

        List<String> tobeQueried = Lists.newArrayList();
        String[] split = taskId.split("/");
        tobeQueried.add("SCENESCENARIOID-" + split[0] + ";"+ "FZID-" + split[1]);

        for (String tableName2 : tableFieldsMap.keySet()) {
            List<String> fields = tableFieldsMap.get(tableName2);
            simpleFrameworkController.initObjectPool(tobeQueried, datasrcEntity, new ArrayList<>(fields), tableName2);
        }

        //规则引擎计算需要数据
        Map<String, Map<String, Object>> tableData = new HashMap<>();
        try {
            for (String key : tableFieldsMap.keySet()) {
                if (!tableData.containsKey(key)) {
                    tableData.put(key, new HashMap<>());
                }
                List<String> fields = tableFieldsMap.get(key);
                for (String field : fields) {
                    Object singleResult = simpleFrameworkController.obtainData(field, key, datasrcEntity.getDatabaseName(), taskId, datasrcEntity, SceneTypeEnum.DEFAULT);
                    tableData.get(key).put(field, singleResult);
                }
            }
        } catch (Exception e) {
            throw new BusinessException(e.getMessage());
        }

        if (ruleEntity.getName().equals("我方各装备通信中断时间")) {
            return ConncectInterruptTime.conncectInterruptTime(tableData);
        }else {
            //规则引擎传参
            Result result = new Result();
            Facts facts = new Facts();
            facts.put("tableData", tableData);
            facts.put("result", result);
            facts.put("HashSet", HashSet.class);
            facts.put("HashMap", HashMap.class);
            facts.put("CircleUnionArea", CircleUnionArea.class);
            //构造MVEL语法规则
            Rules rules = new Rules();
            try {
                MVELRule rule = new MVELRule()
                        .name(ruleEntity.getId())
                        .description(ruleEntity.getId())
                        .priority(ruleEntity.getPriority())
                        .when(ruleEntity.getCondition())
                        .then(ruleEntity.getAction());
                rules.register(rule);
            } catch (Exception e) {
                System.err.println("加载规则失败: " + ruleEntity.getName());
                e.printStackTrace();
            }
            //执行规则
            this.applyRules(rules, facts);
            //获取规则执行结果
            return result.getData();
        }
    }

    public void applyRules(Rules rules, Facts facts) {
        rulesEngine.fire(rules, facts);
    }


    /**
     * 执行方案所有规则，融合数据为参数表数据
     *
     * @param sid
     */
    public void applyRulesBySid(String sid, String directoryId, String saveTableName, String dataSrcId) {
        List<RuleEntity> ruleEntityList = ruleService.list(new LambdaQueryWrapper<RuleEntity>().eq(RuleEntity::getSid, sid));

        DatasrcEntity datasrcEntity = datasrcService.getById(dataSrcId);
        SceneScenarioEntity sceneScenarioEntity = sceneScenarioService.getOne(new LambdaQueryWrapper<SceneScenarioEntity>().eq(SceneScenarioEntity::getSid, sid).last("limit 1"));

        List<GatherRoundRecord> gatherRoundRecordList = roundRecordService
                .list(new LambdaQueryWrapper<GatherRoundRecord>()
                        //.like(GatherRoundRecord::getTaskId, "3b63b84dd48b4edb9b07ac169f2078a9")
                        .like(GatherRoundRecord::getTaskId, sceneScenarioEntity.getSourceId())
                        .eq(GatherRoundRecord::getDataSrcId, datasrcEntity.getId()));
        Set<String> taskIds = gatherRoundRecordList.stream().map(t -> t.getTaskId()).collect(Collectors.toSet());

        //过滤掉已经计算融合的轮次数据
        try {
            DatasrcEntity datasrcEntity1 = getDatasrcEntity(directoryId);
            List<Map<String, Object>> oldDataList = dataBaseHandler.findDataList(saveTableName, datasrcEntity1.createDblinkDto().createDbLinkBo());
            for (Map<String, Object> map : oldDataList) {
                if (map.containsKey("SCENESCENARIOID") && map.get("SCENESCENARIOID") != null){
                    taskIds.remove(map.get("SCENESCENARIOID")+"/"+map.get("FZID"));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (CollectionUtil.isEmpty(taskIds)){
            StompMessagePusher.pushStompMessage(WebSocketConstant.RULE_COMPLETION_RATE + "/" + sid, 100);
            return;
        }

        //通过所有轮次所有脚本的乘积计算融合进度
        int total = taskIds.size() * ruleEntityList.size();
        if (total == 0) {
            throw new BusinessException("暂无仿真数据或未设置脚本，请检查后重试");
        }
        AtomicInteger successRate = new AtomicInteger(0);
        StompMessagePusher.pushStompMessage(WebSocketConstant.RULE_COMPLETION_RATE + "/" + sid, successRate.get());

        List<String> dataCacheKey = Lists.newArrayList();
        //提前构建待计算的数据,进行缓存
        cacheData(ruleEntityList, taskIds, datasrcEntity,dataCacheKey);

        List<Map<String, Object>> dataList = new ArrayList<>();
        //for (SceneEntity sceneEntity : sceneEntityList) {
        String scenescenarioid = "";
        for (String taskId : taskIds) {
            //先计算装备数量
            calcFzEquipmentSize(taskId,sid,datasrcEntity);

            //样本轮次标识
            //Map<String, String> taskIdMap = sceneEntity.getSampleTaskMap();
            //一行参数数据downLatch等待，计算完后统一记录
            Map<String, Object> data = new ConcurrentHashMap<>();
            CountDownLatch downLatch = new CountDownLatch(ruleEntityList.size());
            for (RuleEntity ruleEntity : ruleEntityList) {
                CompletableFuture.supplyAsync(() -> doCalculateRules(data,sid,taskId,ruleEntity,datasrcEntity,successRate,total,downLatch), threadPoolExecutor)
                        .thenAccept(result -> {
                            data.putAll(result);
                        })
                        .exceptionally((e) -> {
                            e.printStackTrace();
                            return null;
                        });
            }
            try {
                downLatch.await();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            String[] split = taskId.split("/");
            scenescenarioid = split[0];
            data.put("SCENESCENARIOID", split[0]);
            data.put("FZID", split[1]);
            dataList.add(data);
        }
        saveDB(dataList, saveTableName, directoryId, scenescenarioid, sid);

        //清空缓存
        //simpleFrameworkController.invalidateCache(dataCacheKey);
    }


    /**
     * 轮次样本单脚本计算
     * @param data 存储脚本计算结果
     * @param sid 方案id
     * @param taskId 轮次标识
     * @param ruleEntity 脚本
     * @param datasrcEntity 数据源
     * @param successRate 计算进度
     * @param total 轮次脚本总量
     * @param downLatch2 阀门
     * @return
     */
    private Map<String, Object> doCalculateRules(Map<String, Object> data,String sid, String taskId, RuleEntity ruleEntity,
                                                 DatasrcEntity datasrcEntity, AtomicInteger successRate, int total,CountDownLatch downLatch2){
        try {
            //脚本规则计算需要的列
            Map<String, List<String>> tableFieldsMap = ruleEntity.getTableFieldsMap();
            //规则引擎计算需要数据
            Map<String, Map<String, Object>> tableData = new HashMap<>();
            try {
                for (String tableName : tableFieldsMap.keySet()) {
                    if (!tableData.containsKey(tableName)) {
                        tableData.put(tableName, new HashMap<>());
                    }
                    List<String> fields = tableFieldsMap.get(tableName);
                    //按列查询当前样本数据
                    for (String field : fields) {
                        Object singleResult = simpleFrameworkController.obtainData(field, tableName, datasrcEntity.getDatabaseName(), taskId, datasrcEntity, SceneTypeEnum.DEFAULT);
                        tableData.get(tableName).put(field, singleResult);
                    }
                }
            } catch (Exception e) {
                throw new BusinessException(e.getMessage());
            }

            if (ruleEntity.getName().equals("我方各装备通信中断时间")) {
                return ConncectInterruptTime.conncectInterruptTime(tableData);
            } else {
                //规则引擎传参
                Result result = new Result();
                Facts facts = new Facts();
                facts.put("tableData", tableData);
                facts.put("result", result);
                facts.put("HashSet", HashSet.class);
                facts.put("HashMap", HashMap.class);
                //构造MVEL语法规则
                Rules rules = new Rules();
                try {
                    MVELRule rule = new MVELRule()
                            .name(ruleEntity.getName())
                            .description(ruleEntity.getName())
                            .priority(ruleEntity.getPriority())
                            .when(ruleEntity.getCondition())
                            .then(ruleEntity.getAction());
                    rules.register(rule);
                } catch (Exception e) {
                    System.err.println("加载规则失败: " + ruleEntity.getName());
                    e.printStackTrace();
                }
                //执行规则
                applyRules(rules, facts);

                //获取规则执行结果
                Map<String, Object> resultData = result.getData();

                if (resultData!=null)
                data.putAll(resultData);
            }

            //推送任务完成率
            StompMessagePusher.pushStompMessage(WebSocketConstant.RULE_COMPLETION_RATE + "/" + sid, (int) (100.0 * successRate.incrementAndGet() / total));
        } catch (BusinessException e) {
            e.printStackTrace();
            throw new BusinessException(e.getMessage());
        } finally {
            downLatch2.countDown();
        }

        return data;
    }

    /**
     * 计算每次仿真不同类型装备使用数量，存储
     *
     * @return
     */
    private synchronized void calcFzEquipmentSize(String taskId, String sid, DatasrcEntity datasrcEntity) {
        //融合数据--数据源
        //String equipmentCode = EquTypeUtils.getEquipmentCode(equType, taskId.split("/")[0]);

        try {
            Object objectname = simpleFrameworkController.obtainData("OBJECTNAME", "msgtype_cdkobjectinit", datasrcEntity.getDatabaseName(), taskId, datasrcEntity, SceneTypeEnum.DEFAULT);
            Object objectcamp = simpleFrameworkController.obtainData("OBJECTCAMP", "msgtype_cdkobjectinit", datasrcEntity.getDatabaseName(), taskId, datasrcEntity, SceneTypeEnum.DEFAULT);
            Object objecttype = simpleFrameworkController.obtainData("OBJECTTYPE", "msgtype_cdkobjectinit", datasrcEntity.getDatabaseName(), taskId, datasrcEntity, SceneTypeEnum.DEFAULT);

            List objectnameList = (List) objectname;
            List objecttypeList = (List)objecttype;
            List objectcampList = (List) objectcamp;

            List<Map<String, String>> equMapList = sensitivityAnalysisV2Service.obtainEquType(sid);

            for (Map<String, String> stringStringMap : equMapList) {
                //装备类型标识，如：rc_chn_uav_dr400_x
                String type = stringStringMap.get("code");
                String equipmentCode = EquTypeUtils.getEquipmentCode2(type);

                Set<String> nameTotalSet = new HashSet<>();
                for(int i=0; i<objectcampList.size(); i++){
                    //实体阵营 0红方 1蓝方
                    if("0".equals(objectcampList.get(i)) && equipmentCode.equals(objecttypeList.get(i))){
                        nameTotalSet.add(objectnameList.get(i).toString());
                    }
                }

                String fzid = taskId.split("/")[1];
                FzEquipmentNum fzEquipmentNum = fzEquipmentService.getOne(new LambdaQueryWrapper<FzEquipmentNum>()
                        .eq(FzEquipmentNum::getSid, sid).eq(FzEquipmentNum::getFzid, fzid).eq(FzEquipmentNum::getEquipmentType, type));

                if (fzEquipmentNum == null) {
                    fzEquipmentNum = new FzEquipmentNum();
                }
                fzEquipmentNum.setSid(sid);
                fzEquipmentNum.setFzid(fzid);
                fzEquipmentNum.setEquipmentType(type);
                fzEquipmentNum.setEquipmentNum(nameTotalSet.size());
                fzEquipmentNum.setCreateTime(LocalDateTime.now());
                fzEquipmentService.saveOrUpdate(fzEquipmentNum);

            }
        } catch (Exception e) {
            //throw new RuntimeException(e);
            e.printStackTrace();
        }
    }

    /**
     * 先缓存整个方案计算数据
     * @param ruleEntityList
     * @param taskIds
     * @param datasrcEntity
     */
    private void cacheData(List<RuleEntity> ruleEntityList, Set<String> taskIds, DatasrcEntity datasrcEntity,List<String> dataCacheKey) {
        List<String> tobeQueried = Lists.newArrayList();
        for (String taskId : taskIds) {
            String[] split = taskId.split("/");
            tobeQueried.add("SCENESCENARIOID-" + split[0] + ";"+ "FZID-" + split[1]);
        }

        //表字段列合并后的
        Map<String, Set<String>> tableFieldSetMap = new HashMap<>();
        for (RuleEntity ruleEntity : ruleEntityList) {
            //脚本规则计算需要的列
            Map<String, List<String>> tableFieldsMap = ruleEntity.getTableFieldsMap();
            try {
                for (String tableName2 : tableFieldsMap.keySet()) {
                    if (tableFieldSetMap.containsKey(tableName2)) {
                        tableFieldSetMap.get(tableName2).addAll(tableFieldsMap.get(tableName2));
                    }else {
                        tableFieldSetMap.put(tableName2, new HashSet<>(tableFieldsMap.get(tableName2)));
                    }
                }
            } catch (Exception e) {
                throw new BusinessException(e.getMessage());
            }
        }
        for (String tableName2 : tableFieldSetMap.keySet()) {
            dataCacheKey.add(tableName2);
            Set<String> fields = tableFieldSetMap.get(tableName2);
            simpleFrameworkController.initObjectPool(tobeQueried, datasrcEntity, new ArrayList<>(fields), tableName2);
        }
    }

    private DatasrcEntity getDatasrcEntity(String directoryId){
        if (StringUtils.isEmpty(directoryId)) {
            return null;
        }

        //根据目录id获取当前数据目录
        DataDirectory dataDirectory = dataDirectoryService.findById(directoryId);
        JSONObject jsonObject = (JSONObject) JSON.parse(dataDirectory.getMark());
        //通过目录对象中的扩展树形获取到数据源ID
        String dsid = jsonObject.get("dataSrcId").toString();
        DatasrcEntity datasrcEntity = datasrcService.getById(dsid);
        return datasrcEntity;
    }

    private void saveDB(List<Map<String, Object>> data, String tableName, String directoryId, String scenescenarioid, String sid) {

        DatasrcEntity datasrcEntity = getDatasrcEntity(directoryId);
        //获取数据源链接对象
        DbLinkBO dbLinkBo = datasrcEntity.createDblinkDto().createDbLinkBo();

        List<TableColsDTO> oldTableCols = null;
        try {
            oldTableCols = dataBaseHandler.findTableCols(tableName, dbLinkBo);
        } catch (Exception e) {
            //throw new RuntimeException(e);
        }

        List<Map<String, Object>> dataInsert = Lists.newArrayList();
        for (Map<String, Object> datum : data) {
            if (datum == null) {
                continue;
            }

            //补充ID列
            if (!datum.containsKey("ID") && !datum.containsKey("id")) {
                datum.put("ID", IdUtil.fastSimpleUUID());
            }
            Map<String, Object> map = Maps.newHashMap();
            for (Map.Entry<String, Object> entry : datum.entrySet()) {
                map.put(entry.getKey().toUpperCase(), entry.getValue());
            }

            if (CollectionUtil.isNotEmpty(oldTableCols)){
                Set<String> keys = datum.keySet();
                for (TableColsDTO oldTableCol : oldTableCols) {
                    if (!keys.contains(oldTableCol.getColCode())){
                        datum.put(oldTableCol.getColCode(),"0");
                    } else if (datum.get(oldTableCol.getColCode())==null) {
                        datum.put(oldTableCol.getColCode(),"0");
                    }
                }
            }

            dataInsert.add(map);
        }


        //获取表列
        List<TableColsDTO> columnList = Lists.newArrayList();
        List<String> tableColumns = Lists.newArrayList();
        for (Map<String, Object> datum : dataInsert) {
            for (Map.Entry<String, Object> entry : datum.entrySet()) {
                String col = entry.getKey();
                if (!tableColumns.contains(col)) {
                    TableColsDTO colsDTO = new TableColsDTO();
                    colsDTO.setColCode(col);
                    colsDTO.setColType("VARCHAR");
                    colsDTO.setColLen(50);

                    if ("ID".equalsIgnoreCase(col)){
                        colsDTO.setNullAble(0);
                    }
                    columnList.add(colsDTO);
                    tableColumns.add(col);
                }
            }
        }
        //创建轮次
        DataGatherUtils.roundDataParser(dataInsert, "SCENESCENARIOID/FZID",datasrcEntity.getId(), Collections.singletonList(tableName), roundRecordService);
        //roundHandler(tableName, "SCENESCENARIOID/FZID", tableColumns, dataInsert, datasrcEntity.getId(), datasrcEntity.getDatabaseName());

        //dataBaseHandler.deleteTable(Collections.singletonList(tableName), dbLinkBo);

        //获取事后指标树
        IndicatorTreeEntity indicatorTreeEntity = indicatorTreeService.getOne(new LambdaQueryWrapper<IndicatorTreeEntity>()
                .eq(IndicatorTreeEntity::getSid, sid)
                .eq(IndicatorTreeEntity::getIndicatorTreeCategory, CustomizedDataCollectionType.AFTERWARDS.id));

        SceneTableEntity sceneTableEntity = sceneTableService.getOne(new LambdaQueryWrapper<SceneTableEntity>()
                .eq(SceneTableEntity::getIndicatorTreeId, indicatorTreeEntity.getId())
                .eq(SceneTableEntity::getSid, sid)
                .eq(SceneTableEntity::getTableName, tableName)
                .eq(SceneTableEntity::getDsid, datasrcEntity.getId())
                .last("limit 1"));

        //如果指标树已经关联仿真数据，则更新样本
        if (sceneTableEntity!=null){
            //构建样本
            applicationContext.publishEvent(new AutoGeneratorSceneApplication("autoGenerator", datasrcEntity.getId(), tableName, sceneTableEntity.getSid(), sceneTableEntity.getIndicatorTreeId()));
        }

        //累加数据
        dataBasesOperationHandler.saveV2("ID", dbLinkBo, 0, tableName, columnList, dataInsert, 2, 1);


        long count = importTableRecordService.count(new LambdaQueryWrapper<ImportTableRecord>()
                .eq(ImportTableRecord::getFromId, datasrcEntity.getId())
                .eq(ImportTableRecord::getTableName, tableName).last("limit 1"));
        if (count==0){
            ImportTableRecord importTableRecord = new ImportTableRecord();
            importTableRecord.setId(UUIDGenerator.getUUID());
            importTableRecord.setTableName(tableName);
            importTableRecord.setFromId(datasrcEntity.getId());
            importTableRecord.setFromType(3);
            importTableRecord.setDirectoryId(directoryId);
            importTableRecordService.save(importTableRecord);
        }

    }

    /**
     * 处理轮次数据
     *
     * @param roundKey     轮次标识
     * @param tableColumns 列名称
     * @param saveData     存储的数据
     */
    private void roundHandler(String tableName, String roundKey, List<String> tableColumns, List<Map<String, Object>> saveData, String dataSrcId, String databaseName) {
        DataSourceExeclParam sourceExeclParam = new DataSourceExeclParam();
        sourceExeclParam.setData(saveData);
        sourceExeclParam.setTableStructure(tableColumns);
        sourceExeclParam.setTableName(tableName);
        sourceExeclParam.setRoundKeys(roundKey);
        sourceExeclParam.setDataSrcId(dataSrcId);
        sourceExeclParam.setDataBasesName(databaseName);
        copyDataFromFileToDB.parsingFileRoundData(sourceExeclParam);
    }


    public List<Map<String, Object>> findDataList(List<String> columnNameList, String tableName, DbLinkBO dbLink) {//筛选字段（时间），条数
        PreparedStatement preparedStatement = null;
        ResultSet resultSetData;
        DatabaseMetaData meta;
        List<Map<String, Object>> dataList = new ArrayList<>();
        List<String> cols = new ArrayList<>();
        StringBuilder sqlBuilder = new StringBuilder();
        DbConn dbConn = null;
        try {
            dbConn = DbUtil.createConnFromPool(dbLink);
            Connection connection = dbConn.getConn();
            sqlBuilder.append("SELECT ");
            for (int i = 0; i < columnNameList.size(); i++) {
                if (i != 0) {
                    sqlBuilder.append(",").append(MySqlStatementUtil.addPoint(columnNameList.get(i)));
                } else {
                    sqlBuilder.append(MySqlStatementUtil.addPoint(columnNameList.get(i)));
                }
            }
            sqlBuilder.append(" FROM " + MySqlStatementUtil.addPoint(tableName) + "");

            preparedStatement = connection.prepareStatement(sqlBuilder.toString());
            meta = connection.getMetaData();
            resultSetData = preparedStatement.executeQuery();
            //获取列名
            ResultSet resultSetMeta = meta.getColumns(connection.getCatalog(), connection.getSchema(), tableName, "%");
            while (resultSetMeta.next()) {
                String columnName = resultSetMeta.getString("COLUMN_NAME");
                if (columnNameList.contains(columnName)) {
                    cols.add(resultSetMeta.getString("COLUMN_NAME"));
                }
            }
            //获取数据
            while (resultSetData.next()) {
                Map<String, Object> data = new HashMap<>();
                for (String col : cols) {
                    Object object = null;
                    if (col.contains("TIME") || col.contains("DATE")) {
                        object = LocalDateTime.now();
                    } else {
                        object = resultSetData.getObject(col);
                    }
                    data.put(col, object);
                }
                dataList.add(data);
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e.getMessage());
        } finally {
            DbUtil.returnPool(dbConn);
            DbUtil.closeConn(null, preparedStatement, null, null);
        }
        return dataList;
    }


    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    public void calcEquipmentNum(String sid, String directoryId) {

//        for (int i = 20; i <= 25; i++) {
//            String name = "场景4方案"+i;
//            DataDirectory dataDirectory = dataDirectoryService.getOne(new LambdaQueryWrapper<DataDirectory>().eq(DataDirectory::getName, name));
            DataDirectory dataDirectory = dataDirectoryService.getById(directoryId);
            DatasrcEntity datasrcEntity1 = getDatasrcEntity(dataDirectory.getId());
            //融合数据源
            //DatasrcEntity datasrcEntity = datasrcService.getById("321974b48c384dde9a38263157de2259");
            SceneScenarioEntity sceneScenarioEntity = sceneScenarioService.getOne(new LambdaQueryWrapper<SceneScenarioEntity>().eq(SceneScenarioEntity::getSid, sid).last("limit 1"));

            List<GatherRoundRecord> gatherRoundRecordList = roundRecordService
                    .list(new LambdaQueryWrapper<GatherRoundRecord>()
                            //.like(GatherRoundRecord::getTaskId, "3b63b84dd48b4edb9b07ac169f2078a9")
                            .like(GatherRoundRecord::getTaskId, sceneScenarioEntity.getSourceId())
                            .eq(GatherRoundRecord::getDataSrcId, datasrcEntity1.getId()));
            Set<String> taskIds = gatherRoundRecordList.stream().map(t -> t.getTaskId()).collect(Collectors.toSet());

            List<String> tobeQueried = Lists.newArrayList();
            for (String taskId : taskIds) {
                String[] split = taskId.split("/");
                tobeQueried.add("SCENESCENARIOID-" + split[0] + ";"+ "FZID-" + split[1]);
            }
            List<String> fields = Arrays.asList("OBJECTNAME","OBJECTCAMP","OBJECTTYPE");

            simpleFrameworkController.initObjectPool(tobeQueried, datasrcEntity1, new ArrayList<>(fields), "msgtype_cdkobjectinit");

            for (String taskId : taskIds) {
                calcFzEquipmentSize(taskId,sid,datasrcEntity1);
            }
//        }



    }
}
