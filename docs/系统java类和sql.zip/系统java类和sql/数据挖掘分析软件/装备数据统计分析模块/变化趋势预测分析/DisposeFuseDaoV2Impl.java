package com.yw.fusionanaly.module.disposeFuse.dao.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.map.MapUtil;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;
import com.yw.fusionanaly.common.annotation.Muster;
import com.yw.fusionanaly.common.result.PageResult;
import com.yw.fusionanaly.common.result.ResultUtil;
import com.yw.fusionanaly.common.result.YwResult;
import com.yw.fusionanaly.common.util.SqlStatementUtil;
import com.yw.fusionanaly.database.BaseMongoTemplate;
import com.yw.fusionanaly.database.Entity;
import com.yw.fusionanaly.database.collection.FuseCombV2;
import com.yw.fusionanaly.database.collection.FuseSpecimen;
import com.yw.fusionanaly.database.entity.FieldEntity;
import com.yw.fusionanaly.module.disposeFuse.dao.DisposeFuseDaoV2;
import com.yw.fusionanaly.module.disposeFuse.request.FuseDataPageReq;
import com.yw.fusionanaly.module.disposeFuse.response.FuseCheckResponse;
import com.yw.fusionanaly.module.disposeFuse.response.FuseCombResponseV2;
import com.yw.fusionanaly.module.disposeFuse.response.FuseDataResp;
import com.yw.fusionanaly.module.disposeFuse.type.FuseMoldType;
import com.yw.fusionanaly.module.disposeFuse.type.FuseMoldTypeV2;
import com.yw.fusionanaly.module.disposeFuse.type.FuseSourceType;
import com.yw.fusionanaly.module.disposeFuse.type.FuseStatusType;
import com.yw.fusionanaly.module.plan.type.PlanMethodsType;
import com.yw.fusionanaly.module.plan.type.TopicTypeMethod;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.context.event.SpringApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class DisposeFuseDaoV2Impl implements DisposeFuseDaoV2, ApplicationListener<SpringApplicationEvent> {

    /**
     * 目标数据表主键
     */
    private Map<String, String> TABLE_PRIMARY_KEY_MAP = Maps.newHashMap();

    private AtomicInteger idGenerator = new AtomicInteger();

    public static final String BASE_NAME = "fuse_specimen_v2_%s";
    private String FUSE_COMB_V2 = "fuse_comb_v2";

    private final JdbcTemplate jdbcTemplate;
    private final BaseMongoTemplate baseMongoTemplate;
    private final MongoTemplate mongoTemplate;

    @Override
    public void onApplicationEvent(SpringApplicationEvent event) {
        idGenerator.set(this.initMaxId());
        TABLE_PRIMARY_KEY_MAP.put("WJPG_EQUIPMENT", "ID");
        TABLE_PRIMARY_KEY_MAP.put("WJPG_EQUIPMENT_SYSTEM", "ID");
    }

    private <T extends Entity> int initMaxId() {
        Muster muster = FuseCombV2.class.getAnnotation(Muster.class);
        if (muster == null) {
            return 0;
        }
        String key = muster.pk();
        Integer maxValue = 1;
        FuseCombV2 value = baseMongoTemplate.findMaxValue(key, FuseCombV2.class, muster.name());
        if (value != null) {
            maxValue = value.get_id();
        }
        return maxValue;
    }


    @Override
    public FuseCombV2 createFuseComb(Integer id, FuseMoldType type, String topicName, TopicTypeMethod topicType, String topicDescription,
                                     Map<Integer, Map<String, FieldEntity>> chooseMap, List<PlanMethodsType> methods, String planId, List<Integer> trunkList) {
        FuseCombV2 fuseComb = FuseCombV2.valueOf(type.getId(), chooseMap, FuseStatusType.CREATED.getId(), topicName, topicType, topicDescription, methods, planId);
        if (id != null && id != 0) {
            Query query = new Query();
            query.addCriteria(Criteria.where("_id").is(id));
            Update update = new Update();
            update.set("type", type.getId());
            update.set("chooseMap", chooseMap);
            update.set("paramCount", fuseComb.getParamCount());
            update.set("status", FuseStatusType.CREATED.getId());
            update.set("topicName", topicName);
            update.set("topicType", topicType);
            update.set("topicDescription", topicDescription);
            update.set("method", methods);
            update.set("planId", planId);
            baseMongoTemplate.update(query, update, FUSE_COMB_V2);
            fuseComb.set_id(id);
            return fuseComb;
        }
        int newId = idGenerator.incrementAndGet();
        fuseComb.set_id(newId);
        fuseComb.setCollectionName(getFuseSpecimenName(newId));
        baseMongoTemplate.save(fuseComb);
        return fuseComb;
    }

    private String getFuseSpecimenName(int fuseId) {
        return String.format(BASE_NAME, fuseId);
    }


    @Override
    public Map<String, FieldEntity> getFields(FuseSourceType sourceType, FuseMoldType type, String tableName, Collection<Integer> trunkList) {
        //根据关联主键查询信息
        Map<String, FieldEntity> map = Maps.newLinkedHashMap();
        //装备体系分析 1.获取当前装备体系共有的参数
        if (sourceType == FuseSourceType.EQUIPMENT_SYSTEM) {
            String paramSql = SqlStatementUtil.paramSql(sourceType, tableName, trunkList);
            List<Map<String, Object>> maps = jdbcTemplate.queryForList(paramSql);
            for (Map<String, Object> paramMap : maps) {
                Object en_name = paramMap.get("EN_PARAM");
                String paramChSql = SqlStatementUtil.paramChSql(sourceType, tableName, en_name);
                List<Map<String, Object>> maps1 = jdbcTemplate.queryForList(paramChSql);
                FieldEntity entity = FieldEntity.valueOf(en_name, maps1.get(0));
                map.put(en_name.toString(), entity);
            }
        }
        return map;
    }


    @Override
    public void saveFuseSpecimen(int fuseId, Collection<FuseSpecimen> values, int status) {
        String collectionName = String.format(BASE_NAME, fuseId);
        baseMongoTemplate.delete(new Query(), collectionName);
        baseMongoTemplate.insert(collectionName, values);
        //修改数据采集状态
        updateFuseCombStatus(fuseId, FuseStatusType.getType(status));
    }


    @Override
    public List<FuseCombV2> queryFuseByPlanId(String id) {
        Query query = Query.query(Criteria.where("planId").is(id));
        return baseMongoTemplate.find(query, FuseCombV2.class);
    }

    @Override
    public void deleteByPlanId(String planId) {
        Query query = Query.query(Criteria.where("planId").is(planId));
        mongoTemplate.remove(query, FuseCombV2.class);
    }

    /**
     * 从基础数据表获取装备字段信息
     *
     * @param moldType
     * @param tableName
     * @param trunkList
     * @return
     */
    @Override
    public Map<String, FieldEntity> getEquipmentFields(FuseSourceType sourceType, FuseMoldType moldType, String tableName, Collection<Integer> trunkList) {
        Map<String, FieldEntity> map = Maps.newLinkedHashMap();
        switch (moldType) {
            case EQUIPMENT_SYSTEM_TREND:
            case EQUIPMENT_SYSTEM_CENSUS:
                String queryEquIdSQL = SqlStatementUtil.queryEquIdsql(trunkList, tableName);
                List<Map<String, Object>> maps = jdbcTemplate.queryForList(queryEquIdSQL);
                if (maps.isEmpty()) {
                    return Maps.newLinkedHashMap();
                }
                List<Integer> EquID = Lists.newArrayList();
                maps.stream().forEach(s -> {
                    EquID.add(Integer.parseInt(s.get("EQUID").toString()));
                });
                // 根据装备id获取对应名称
                StringBuffer equNameSql = new StringBuffer("select ID,EQU_NAME from WJPG_EQUIPMENT where ID IN ( ");
                for (int i = 0; i < EquID.size(); i++) {
                    if (i == EquID.size() - 1) {
                        equNameSql.append(EquID.get(i) + " )");
                        continue;
                    }
                    equNameSql.append(EquID.get(i) + ",");
                }
                Map<Integer, String> equNameMap = Maps.newLinkedHashMap();
                List<Map<String, Object>> equNamList = jdbcTemplate.queryForList(equNameSql.toString());
                //获取装备名称
                for (Map<String, Object> objectMap : equNamList) {
                    Integer key = (Integer) objectMap.get("ID");
                    String value = (String) objectMap.get("EQU_NAME");
                    equNameMap.put(key, value);
                }
                String equSql = SqlStatementUtil.paramSql(sourceType, tableName, EquID);
                List<Map<String, Object>> list = jdbcTemplate.queryForList(equSql);
                for (Map<String, Object> paramMap : list) {
                    Object en_name = paramMap.get("EN_PARAM");
                    String paramChSql = SqlStatementUtil.paramChSql(sourceType, tableName, en_name);
                    List<Map<String, Object>> chNameMap = jdbcTemplate.queryForList(paramChSql);
                    EquID.stream().forEach(s1 -> {
                        FieldEntity entity = FieldEntity.valueOf(en_name, chNameMap.get(0), s1 + "", sourceType, equNameMap.get(s1));
                        map.put(entity.getKey(), entity);
                    });
                }
                return map;
            case EQUIPMENT_TREND:
            case EQUIPMENT_CENSUS:
                //装备
                String sql = SqlStatementUtil.paramSql(sourceType, tableName, trunkList);
                List<Map<String, Object>> mapList = jdbcTemplate.queryForList(sql);
                for (Map<String, Object> paramMap : mapList) {
                    Object en_name = paramMap.get("EN_PARAM");
                    String paramChSql = SqlStatementUtil.paramChSql(sourceType, tableName, en_name);
                    List<Map<String, Object>> maps1 = jdbcTemplate.queryForList(paramChSql);
                    FieldEntity entity = FieldEntity.valueOf(en_name, maps1.get(0));
                    map.put(en_name.toString(), entity);
                }
                return map;
        }
        return map;
    }

    /**
     * 获取组合字段
     *
     * @param fuseId
     * @return
     */
    @Override
    public Map<String, String> getFuseFields(int fuseId) {
        FuseCombV2 fuseComb = baseMongoTemplate.find(fuseId, FuseCombV2.class);
        if (fuseComb == null) {
            return new HashMap<>();
        }
        Map<Integer, Map<String, FieldEntity>> chooseMap = fuseComb.getChooseMap();
        Map<String, String> fields = new HashMap<>();
        chooseMap.forEach((key, value) ->
                value.forEach((key1, value1) -> {
                    if (value1.getChildField() != null && !value1.getChildField().isEmpty()) {
                        value1.getChildField().forEach(c -> fields.put(c.getField(), c.getName()));
                    } else {
                        fields.put(key1, value1.getName());
                    }
                }));

        return fields;
    }


    @Override
    public Map<Object, Object> getTrunkParam(FuseSourceType type) {
        Map<Object, Object> equ_Map = Maps.newLinkedHashMap();
        StringBuffer sql;
        switch (type) {
            case EQUIPMENT:
                sql = new StringBuffer("select ID,EQU_NAME from FLOWCHART_BKY.WJPG_EQUIPMENT");
                List<Map<String, Object>> maps = jdbcTemplate.queryForList(sql.toString());
                for (Map<String, Object> map : maps) {
                    Object id = map.get("ID");
                    Object name = map.get("EQU_NAME");
                    equ_Map.put(id, name);
                }
                return equ_Map;
            case EQUIPMENT_SYSTEM:
                sql = new StringBuffer("select ID,EQU_NAME from FLOWCHART_BKY.WJPG_EQUIPMENT_SYSTEM");
                List<Map<String, Object>> equSys = jdbcTemplate.queryForList(sql.toString());
                for (Map<String, Object> map : equSys) {
                    Object id = map.get("ID");
                    Object name = map.get("EQU_NAME");
                    equ_Map.put(id, name);
                }
                return equ_Map;
            default:
                return Maps.newLinkedHashMap();
        }
    }

    /**
     * 从基础数据表获取装备战技指标
     *
     * @param type       组合类别
     * @param tableName  表名称
     * @param trunkList  组合分析对象
     * @param chooseList 选择的参数
     * @param pageNum    当前页
     * @param limit      页大小
     * @return
     */
    @Override
    public Map<Integer, Map<String, Object>> getTableResource(FuseMoldType type, String tableName, List<Integer> trunkList, List<String> chooseList, int pageNum, int limit) {

        Map<Integer, Map<String, Object>> resultMap = Maps.newLinkedHashMap();
        String param = "EQU_SYS_ID";
        List<Integer> sameEquIDs = Lists.newArrayList();//共同装备id
        /**
         * WJPG_EQU_PARAM: 表示获取装备参数数据 否则获取装备体系参数数据
         * 当为获取装备参数数据时，如果是装备体系趋势或者统计分析时，只需要对他们的共同装备进行处理分析
         */
        if (tableName.equals("WJPG_EQU_PARAM")) {
            param = "EQU_ID";
            switch (type) {
                case EQUIPMENT_SYSTEM_TREND:
                case EQUIPMENT_SYSTEM_CENSUS:
                    String queryEquIdSQL = SqlStatementUtil.queryEquIdsql(trunkList, tableName);
                    List<Map<String, Object>> maps = jdbcTemplate.queryForList(queryEquIdSQL);
                    if (maps.isEmpty()) {
                        return Maps.newLinkedHashMap();
                    }
                    maps.stream().forEach(s -> {
                        sameEquIDs.add(Integer.parseInt(s.get("EQUID").toString()));
                    });
            }
        }
        //共同装备的共同参数的数据值
        String sql = SqlStatementUtil.paramAndValue(param, chooseList, tableName, sameEquIDs);
        List<Map<String, Object>> maps = jdbcTemplate.queryForList(sql);//所有chooseList字段的装备或体系数据
        for (int i = 0; i < trunkList.size(); i++) {
            Map<String, Object> hashMap = Maps.newHashMap();
            Integer trunkId = trunkList.get(i);
            for (Map<String, Object> map : maps) {
                Integer equId = (Integer) map.get(param);
                //当组合类型为装备体系并且矩阵列为装备战技指标
                if (!CollUtil.isEmpty(sameEquIDs)) {
                    String eqParaName = (String) map.get("EN_PARAM");//装备参数名称
                    String eqName = (String) map.get("EQU_NAME");
                    hashMap.put(2 + "_" + equId + "_" + eqParaName, map.get("PARAM_VALUE"));
                } else {
                    if (trunkId.equals(equId)) {
                        String en_param = (String) map.get("EN_PARAM");
                        hashMap.put(en_param, map.get("PARAM_VALUE"));
                    }
                }
            }
            resultMap.put(trunkId, hashMap);
        }
        return resultMap;
    }


    @Override
    public void updateFuseCombStatus(int id, FuseStatusType collectData) {
        Query query = new Query();
        query.addCriteria(Criteria.where("_id").is(id));
        Update update = new Update();
        update.set("status", collectData.getId());
        baseMongoTemplate.update(query, update, FUSE_COMB_V2);
    }

    /**
     * 删除行/列数据
     *
     * @param fuseId    主题id
     * @param fieldName 字段名称
     * @param type      行/列
     * @return
     */
    @Override
    public Long deleteField(int fuseId, List<String> fieldName, String type) {
        if (CollUtil.isEmpty(fieldName)) {
            return 0L;
        }
        long count;
        Query query = new Query();
        if ("line".equals(type)) {
            query.addCriteria(Criteria.where("_id").in(fieldName));
            DeleteResult delete = baseMongoTemplate.delete(query, String.format(BASE_NAME, fuseId));
            count = delete.getDeletedCount();
        } else {
            Update update = new Update();
            for (int i = 0; i < fieldName.size(); i++) {
                update.unset("fuseData." + fieldName.get(i));
            }
            //删除数据列
            UpdateResult updateResult = baseMongoTemplate.updateMulti(query, update, String.format(BASE_NAME, fuseId));
            count = updateResult.getModifiedCount();
            FuseCombV2 fuseComb = baseMongoTemplate.find(fuseId, FuseCombV2.class);
            if (fuseComb != null) {
                for (Map.Entry<Integer, Map<String, FieldEntity>> entry : fuseComb.getChooseMap().entrySet()) {
                    Iterator<Map.Entry<String, FieldEntity>> iterator = entry.getValue().entrySet().iterator();
                    while (iterator.hasNext()) {
                        Map.Entry<String, FieldEntity> subEntry = iterator.next();
                        if (fieldName.contains(subEntry.getKey())) {
                            iterator.remove();
                            //break;
                            continue;
                        }
                        Collection<FieldEntity> childField = subEntry.getValue().getChildField();
                        if (CollUtil.isEmpty(childField)) {
                            continue;
                        }
                        Iterator<FieldEntity> subIterator = subEntry.getValue().getChildField().iterator();
                        while (subIterator.hasNext()) {
                            if (fieldName.contains(subIterator.next().getField())) {
                                subIterator.remove();
                            }
                        }
                    }
                }
            }
            //设置参数个数
            Map<Integer, Map<String, FieldEntity>> chooseMap = fuseComb.getChooseMap();
            int fieldCount = 0;
            for (Map.Entry<Integer, Map<String, FieldEntity>> map : chooseMap.entrySet()) {
                Map<String, FieldEntity> value = map.getValue();
                if (map.getKey().equals(FuseSourceType.EVALUATION.getId())) {
                    for (Map.Entry<String, FieldEntity> childMap : value.entrySet()) {
                        FieldEntity mapValue = childMap.getValue();
                        Collection<FieldEntity> childField = mapValue.getChildField();
                        if (!CollUtil.isEmpty(childField)) {
                            fieldCount += childField.size();
                        }
                    }
                } else {
                    if (!MapUtil.isEmpty(value)) {
                        fieldCount += value.size();
                    }
                }
            }
            fuseComb.setParamCount(fieldCount);
            baseMongoTemplate.save(fuseComb);
        }
        //再次预处理检查，更新预处理状态
        //uniformityCheck(fuseId);
        //fixedCheck(fuseId);
        return count;
    }

    @Override
    public YwResult<FuseDataResp> dataPageList(FuseDataPageReq fuseDataPageReq) {
        if (fuseDataPageReq.getFuseId() == null) {
            return ResultUtil.fail("主题id不能为空");
        }

        //分页查询FuseSpecimen转Map<String, Object>
        Function<FuseSpecimen, Map<String, Object>> function = fun -> {
            Map<String, Object> map;
            map = fun.getFuseData();
            if (map != null) {

                map.put("id", fun.getId());
                return map;
            } else {
                return new HashMap<>();
            }

        };
        //根据Function分页查询融合数据
        PageResult<Map<String, Object>> page = baseMongoTemplate.findPage(new Query(), FuseSpecimen.class, fuseDataPageReq.getPageNum(), fuseDataPageReq.getPageSize(), function,
                String.format(BASE_NAME, fuseDataPageReq.getFuseId()));
        FuseDataResp fuseDataResp = new FuseDataResp();
        fuseDataResp.setFuseData(page);

        //查询组合
        FuseCombV2 fuseComb = baseMongoTemplate.find(fuseDataPageReq.getFuseId(), FuseCombV2.class);
        switch (fuseComb.getStatus()) {
            case 1:
                break;
            case 2:
                ResultUtil.fail("当前组合正在采集数据，请稍后");
                break;
            case 3:
                ResultUtil.fail("当前组合采集数据失败，请重试");
                break;
            default:
                ;
        }
        Map<Integer, Map<String, FieldEntity>> chooseMap = fuseComb.getChooseMap();
        Map<String, Object> fieldsName = new HashMap<>();
        //字段--名称映射封装
        chooseMap.forEach((key, value) -> {
            value.forEach((key1, value1) -> {
                if (value1.getChildField() != null && !value1.getChildField().isEmpty()) {
                    value1.getChildField().forEach(c -> fieldsName.put(c.getField(), c.getName()));
                } else {
                    fieldsName.put(key1, value1.getName());
                }
            });
        });
        fuseDataResp.setName(fuseComb.getTopicName());
        fuseDataResp.setModelName(FuseMoldTypeV2.getType(fuseComb.getType()).getName());
        fuseDataResp.setFieldsName(fieldsName);
        fuseDataResp.setType(fuseComb.getType());
        return ResultUtil.success(fuseDataResp);
    }

    @Override
    public YwResult handFillData(Integer fuseId, List<FuseSpecimen> fuseSpecimenList) {
        if (fuseId == null) {
            return ResultUtil.fail("主题id不能为空");
        }

        if (CollUtil.isEmpty(fuseSpecimenList)) {
            return ResultUtil.fail("没有传要修改的数据");
        }

        Map<String, String> map = getFuseFields(fuseId);
        Set<String> fuseFields = map.keySet();
        for (int i = 0; i < fuseSpecimenList.size(); i++) {
            Query query = new Query();
            query.addCriteria(Criteria.where("_id").is(fuseSpecimenList.get(i).getId()));
            Update update = new Update();
            int finalI = i;
            fuseFields.forEach(e -> {
                update.set("fuseData." + e, fuseSpecimenList.get(finalI).getFuseData().get(e));
            });
            baseMongoTemplate.update(query, update, String.format(BASE_NAME, fuseId));
        }

        //再次缺失项检查，更新预处理检查状态
        //defect(fuseId);
        return ResultUtil.success();
    }

    @Override
    public FuseCheckResponse fixedCheck2(int fuseId) {
        //当前组合表使用数据字段
        Map<String, String> map = getFuseFields(fuseId);

        //组合数据
        List<FuseSpecimen> fuseData = baseMongoTemplate.findFuseData(new Query(), FuseSpecimen.class, String.format(BASE_NAME, fuseId));

        FuseCheckResponse fuseCheckResponse = new FuseCheckResponse();
        //固定值字段存储
        Map<String, String> fixedFields = new HashMap<>();

        Set<Map.Entry<String, String>> fuseFields = map.entrySet();
        //循环遍历每一个字段
        fuseFields.forEach(e -> {
            boolean isEquals = true;
            //循环遍历每一个字段数据，判断是否相同
            for (int i = 1; i < fuseData.size(); i++) {
                Object o1 = fuseData.get(i - 1).getFuseData().get(e.getKey());
                Object o2 = fuseData.get(i).getFuseData().get(e.getKey());

                if (o1 == null || o2 == null) {
                    continue;
                }

                String s1 = String.valueOf(o1);
                String s2 = String.valueOf(o2);
                //特殊处理
                if ("".equals(s1) || s1 == null) {
                    s1 = "0.000";
                }
                if ("".equals(s2) || s2 == null) {
                    s2 = "0.000";
                }

                double value1 = Double.parseDouble(s1);
                double value2 = Double.parseDouble(s2);
                if (Double.compare(value1, value2) != 0) {
                    isEquals = false;
                    break;
                }
            }

            //如果分组查询集合只一个，说明此列数据值都相同
            if (isEquals && fuseData.size() > 1) {
                fixedFields.put(e.getKey(), e.getValue());
            }
        });

        fuseCheckResponse.setFixedFields(fixedFields);

        //如果不存在固定值列，更新预处理检查状态
        if (fixedFields.isEmpty()) {
            FuseCombV2 fuseComb = baseMongoTemplate.find(fuseId, FuseCombV2.class);
            if ((fuseComb.getPretreatment() & 2) == 0) {
                baseMongoTemplate.update(Query.query(Criteria.where("_id").is(fuseId)), Update.update("pretreatment", fuseComb.getPretreatment() + 2), FUSE_COMB_V2);
            }
        } else {
            FuseCombV2 fuseComb = baseMongoTemplate.find(fuseId, FuseCombV2.class);
            if ((fuseComb.getPretreatment() & 2) == 2) {
                baseMongoTemplate.update(Query.query(Criteria.where("_id").is(fuseId)), Update.update("pretreatment", fuseComb.getPretreatment() - 2), FUSE_COMB_V2);
            }
        }

        //设置检查时间
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String checkTime = f.format(new Date());
        fuseCheckResponse.setCheckTime(checkTime);
        baseMongoTemplate.update(Query.query(Criteria.where("_id").is(fuseId)), Update.update("fixedDate", checkTime), FUSE_COMB_V2);

        return fuseCheckResponse;
    }

    /**
     * 缺失项检查
     *
     * @param fuseId 主题id
     * @return
     */
    @Override
    public FuseCheckResponse defect(int fuseId) {
        //当前组合表使用数据字段
        Map<String, String> map = getFuseFields(fuseId);
        FuseCheckResponse fuseCheckResponse = new FuseCheckResponse();

        //缺失项存储
        Map<String, String> lossField = new HashMap<>();
        Set<String> lossIds = new HashSet<>();
        FuseCheckResponse.LossCheck lossCheck = new FuseCheckResponse.LossCheck();

        Set<String> fields = map.keySet();
        map.forEach((field, value) -> {
            Query query = new Query();
            //当前组合表使用数据字段
            query.addCriteria(new Criteria().orOperator(Criteria.where("fuseData." + field).is(""),
                    Criteria.where("fuseData." + field).is(null)));

            List<FuseSpecimen> fuseSpecimen = baseMongoTemplate.findFuseData(query, FuseSpecimen.class, String.format(BASE_NAME, fuseId));
            if (!fuseSpecimen.isEmpty()) {
                List<String> ids = fuseSpecimen.stream().map(e -> {
                    if (!e.getFuseData().isEmpty()) {
                        return e.getId();
                    }
                    return null;
                }).filter(e -> e != null).collect(Collectors.toList());
                if (!ids.isEmpty()) {
                    lossField.put(field, value);
                    lossIds.addAll(ids);
                }
            }
        });

        lossCheck.setFields(lossField);
        lossCheck.setIds(lossIds);
        fuseCheckResponse.setLossItem(lossCheck);

        //如果没有缺失项，更新预处理检查状态
        if (lossField.isEmpty()) {
            FuseCombV2 fuseComb = baseMongoTemplate.find(fuseId, FuseCombV2.class);
            if ((fuseComb.getPretreatment() & 4) == 0) {
                baseMongoTemplate.update(Query.query(Criteria.where("_id").is(fuseId)), Update.update("pretreatment", fuseComb.getPretreatment() + 4), FUSE_COMB_V2);
            }
        } else {
            FuseCombV2 fuseComb = baseMongoTemplate.find(fuseId, FuseCombV2.class);
            if ((fuseComb.getPretreatment() & 4) == 4) {
                baseMongoTemplate.update(Query.query(Criteria.where("_id").is(fuseId)), Update.update("pretreatment", fuseComb.getPretreatment() - 4), FUSE_COMB_V2);
            }
        }

        //设置检查时间
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String checkTime = f.format(new Date());
        fuseCheckResponse.setCheckTime(checkTime);
        baseMongoTemplate.update(Query.query(Criteria.where("_id").is(fuseId)), Update.update("lossDate", checkTime), FUSE_COMB_V2);
        return fuseCheckResponse;
    }

    @Override
    public FuseCheckResponse uniformityCheck2(int fuseId) {
        //当前组合表使用数据字段
        Map<String, String> map = getFuseFields(fuseId);
        FuseCheckResponse fuseCheckResponse = new FuseCheckResponse();
        //相同列存储集合
        Collection<Map<String, String>> identicalFields = new ArrayList<>();

        List<FuseSpecimen> fuseData = baseMongoTemplate.findFuseData(new Query(), FuseSpecimen.class, String.format(BASE_NAME, fuseId));

        //标记字段是否已经检查过，防止重复检查
        Map<String, Boolean> flag = new HashMap<>();
        Set<Map.Entry<String, String>> fuseFields = map.entrySet();
        //循环遍历，对比两列数据是否相同
        fuseFields.forEach(e -> {
            if (flag.get(e.getKey()) == null) {
                Map<String, String> sameFields = new HashMap<>();
                fuseFields.forEach(f -> {
                    if (!e.getKey().equals(f.getKey()) && flag.get(f.getKey()) == null) {

                        boolean isEquals = true;
                        for (int i = 0; i < fuseData.size(); i++) {
                            Object o1 = fuseData.get(i).getFuseData().get(e.getKey());
                            Object o2 = fuseData.get(i).getFuseData().get(f.getKey());

                            if (o1 == null || o2 == null) {
                                continue;
                            }

                            String s1 = String.valueOf(o1);
                            String s2 = String.valueOf(o2);

                            if ("".equals(s1) || s1 == null) {
                                s1 = "0.000";
                            }
                            if ("".equals(s2) || s2 == null) {
                                s2 = "0.000";
                            }

                            double eValue = Double.parseDouble(s1);
                            double fValue = Double.parseDouble(s2);
                            if (Double.compare(eValue, fValue) != 0) {
                                isEquals = false;
                                break;
                            }
                        }
                        if (isEquals) {
                            if (sameFields.size() == 0) {
                                sameFields.put(e.getKey(), e.getValue());
                                flag.put(e.getKey(), true);
                            }
                            sameFields.put(f.getKey(), f.getValue());
                            flag.put(f.getKey(), true);
                        }
                    }
                });
                if (!sameFields.isEmpty()) {
                    identicalFields.add(sameFields);
                }
            }
        });
        fuseCheckResponse.setIdenticalFields(identicalFields);

        //如果不存在相同列，更新预处理检查状态
        if (identicalFields.isEmpty()) {
            FuseCombV2 fuseComb = baseMongoTemplate.find(fuseId, FuseCombV2.class);
            if ((fuseComb.getPretreatment() & 1) == 0) {
                baseMongoTemplate.update(Query.query(Criteria.where("_id").is(fuseId)), Update.update("pretreatment", fuseComb.getPretreatment() + 1), FUSE_COMB_V2);
            }
        } else {
            FuseCombV2 fuseComb = baseMongoTemplate.find(fuseId, FuseCombV2.class);
            if ((fuseComb.getPretreatment() & 1) == 1) {
                baseMongoTemplate.update(Query.query(Criteria.where("_id").is(fuseId)), Update.update("pretreatment", fuseComb.getPretreatment() - 1), FUSE_COMB_V2);
            }
        }

        //设置检查时间
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String checkTime = f.format(new Date());
        fuseCheckResponse.setCheckTime(checkTime);
        baseMongoTemplate.update(Query.query(Criteria.where("_id").is(fuseId)), Update.update("identicalDate", checkTime), FUSE_COMB_V2);

        return fuseCheckResponse;
    }

    @Override
    public Long autoFillData(int fuseId, Object value) {
        Map<String, String> map = getFuseFields(fuseId);
        Set<String> fuseFields = map.keySet();
        fuseFields.forEach(e -> {
            Query query = new Query();
            query.addCriteria(new Criteria().orOperator(Criteria.where("fuseData." + e).is(null),
                    Criteria.where("fuseData." + e).is("")));
            Update update = new Update();
            update.set("fuseData." + e, value);
            baseMongoTemplate.updateMulti(query, update, String.format(BASE_NAME, fuseId));
        });

        //再次缺失项检查，更新预处理检查状态
        //defect(fuseId);

        return 0L;
    }

    @Override
    public FuseCombResponseV2 getFuseCombData(int id) {
        //分页查询FuseSpecimen转Map<String, Object>
        Function<FuseSpecimen, Map<String, Object>> function = fun -> {
            Map<String, Object> map = new HashMap<>();
            map = fun.getFuseData();
            map.put("id", fun.getId());
            return map;
        };
        //查询组合
        FuseCombV2 fuseComb = baseMongoTemplate.find(id, FuseCombV2.class);
        Map<Integer, Map<String, FieldEntity>> chooseMap = fuseComb.getChooseMap();
        Map<Integer, Map<String, Object>> fieldsName = Maps.newHashMap();
        Map<String, Object> resultMap = Maps.newHashMap();
        //字段--名称映射封装
        chooseMap.forEach((key, value) -> {
            value.forEach((key1, value1) -> {
                resultMap.put(key1, value1.getName());
            });
            if (key.equals(3)) {
                Map<String, Object> filedMap = Maps.newHashMap();
                value.forEach((key2, value2) -> {
                    filedMap.put(key2, value2.getName());
                    Collection<FieldEntity> childField = value2.getChildField();
                    childField.stream().forEach(s -> {
                        filedMap.put(s.getField(), s.getName());
                    });
                });
                fieldsName.put(key, filedMap);
            } else {
                fieldsName.put(key, Maps.newHashMap(resultMap));
            }
            resultMap.clear();
        });
        FuseCombResponseV2 response = FuseCombResponseV2.valueOf(fuseComb, fieldsName);
        return response;
    }

    @Override
    public PageResult getAllFuseComb(int pageNum, int limit, String name,
                                     String pretreatment) {
        PageResult fuseCombs = baseMongoTemplate.findAll(FuseCombV2.class, pageNum, limit, name, pretreatment);
        return fuseCombs;
    }

    @Override
    public List<FuseCombV2> listByPlanId(String planId) {
        return mongoTemplate.find(Query.query(Criteria.where("planId").is(planId)), FuseCombV2.class);
    }

    @Override
    public void deleteById(Integer topicId) {
        mongoTemplate.remove(Query.query(Criteria.where("_id").is(topicId)), FuseCombV2.class);
    }
}
