package com.yw.fusionanaly.module.disposeFuse.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.map.MapUtil;
import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.yw.fusionanaly.common.exception.ApiException;
import com.yw.fusionanaly.common.result.PageResult;
import com.yw.fusionanaly.common.result.ResultUtil;
import com.yw.fusionanaly.common.result.YwResult;
import com.yw.fusionanaly.common.util.MongodbStringUtil;
import com.yw.fusionanaly.database.collection.FuseComb;
import com.yw.fusionanaly.database.collection.FuseCombV2;
import com.yw.fusionanaly.database.collection.FuseSpecimen;
import com.yw.fusionanaly.database.entity.FieldEntity;
import com.yw.fusionanaly.module.disposeFuse.dao.DisposeFuseDao;
import com.yw.fusionanaly.module.disposeFuse.dao.DisposeFuseDaoV2;
import com.yw.fusionanaly.module.disposeFuse.helper.DisposeFuseActuator;
import com.yw.fusionanaly.module.disposeFuse.parser.FuseContext;
import com.yw.fusionanaly.module.disposeFuse.parser.FuseMoldParser;
import com.yw.fusionanaly.module.disposeFuse.parser.FuseSourceParser;
import com.yw.fusionanaly.module.disposeFuse.parser.lineinfo.BaseLineData;
import com.yw.fusionanaly.module.disposeFuse.parser.lineinfo.ComposeLineData;
import com.yw.fusionanaly.module.disposeFuse.parser.lineinfo.QuotaTaskConditionLineData;
import com.yw.fusionanaly.module.disposeFuse.request.AutoFillDataReq;
import com.yw.fusionanaly.module.disposeFuse.request.FuseChooseRequestV2;
import com.yw.fusionanaly.module.disposeFuse.request.FuseColumnClearingReq;
import com.yw.fusionanaly.module.disposeFuse.request.FuseDataPageReq;
import com.yw.fusionanaly.module.disposeFuse.response.*;
import com.yw.fusionanaly.module.disposeFuse.service.DisposeFuseServiceV2;
import com.yw.fusionanaly.module.disposeFuse.type.*;
import com.yw.fusionanaly.module.plan.service.PlanSampleServiceV2;
import com.yw.fusionanaly.module.plan.type.TopicTypeMethod;
import lombok.RequiredArgsConstructor;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DisposeFuseServiceImplV2 implements DisposeFuseServiceV2 {

    private final DisposeFuseDao disposeFuseDao;
    private final DisposeFuseDaoV2 disposeFuseDaoV2;
    private final FuseContext fuseContext;
    private final MongoTemplate mongoTemplate;
    private final PlanSampleServiceV2 planSampleServiceV2;

    @Override
    public YwResult<PageResult> queryFuseList(int pageNum, int limit, String name,
                                              String pretreatment) {
        String converedName = MongodbStringUtil.escapeQueryChars(name);
        PageResult allFuseComb = disposeFuseDaoV2.getAllFuseComb(pageNum, limit, converedName, pretreatment);
        if (allFuseComb == null) {
            return ResultUtil.fail("组合信息不存在");
        }
        return ResultUtil.success(allFuseComb);
    }

    @Override
    public YwResult deleteFuse(int fuseId) {
        int i = disposeFuseDao.deleteFuseId(fuseId);
        return i == 0 ? ResultUtil.fail("当前组合与方案关联无法被删除") : ResultUtil.success();
    }

    @Override
    public YwResult<FuseTrunkKeyResponse> queryTrunkKey(FuseMoldType type) {
        FuseMoldParser parser = fuseContext.getMoldParser(type);
        if (parser == null) {
            return ResultUtil.fail();
        }
        Map<Object, Object> map = parser.getTrunkParam();
        FuseTrunkKeyResponse response = FuseTrunkKeyResponse.valueOf(map);
        return ResultUtil.success(response);
    }

    /**
     * 获取主题变量
     * param 参数
     *
     * @return
     */
    @Override
    public YwResult<List<Map<String, Object>>> queryFieldParam(FuseChooseRequestV2 param) {
        List<Map<String, Object>> resultList = Lists.newArrayList();

        int typeId = param.getTypeId();
        Collection<Integer> trunkId = param.getTrunkId();

        FuseMoldTypeV2 typeV2 = FuseMoldTypeV2.getType(typeId);
        Collection<FuseSourceTypeV2> sourceTypeV2s = typeV2.getSourceTypes();
        for (FuseSourceTypeV2 sourceTypeV2 : sourceTypeV2s) {
            Map<String, Object> map = Maps.newHashMap();
            map.put("sourceTypeId", sourceTypeV2.getId());
            map.put("name", sourceTypeV2.getName());

            FuseMoldType type = FuseMoldType.getType(typeId);
            FuseSourceType sourceType = FuseSourceType.getType(sourceTypeV2.getId());

            FuseMoldParser parser = fuseContext.getMoldParser(type);
            FuseSourceParser sourceParser = fuseContext.getSourceParser(sourceType);

            if (sourceParser == null || parser == null) {
                return ResultUtil.fail();
            }

            Map<String, FieldEntity> fieldEntities = sourceParser.getFieldParam(type, trunkId);
            //当组合类型为装备体系分析 并且局阵列类型为装备则需要过滤掉相同的数据
            if (sourceType == FuseSourceType.EQUIPMENT) {
                Map<String, FieldEntity> resultMap = Maps.newHashMap();
                Set<String> names = Sets.newHashSet();
                //丢弃重复的名称
                fieldEntities.entrySet().forEach(e -> {
                    String name = e.getValue().getName();
                    if (!names.contains(name)) {
                        resultMap.put(e.getKey(), e.getValue());
                    }
//                    names.add(name);
                });

//                FuseFieldQueryResponse fuseFieldQueryResponse = FuseFieldQueryResponse.valueOf(resultMap.values());
                map.put("list", resultMap.values());
            } else {
                map.put("list", fieldEntities.values());
            }

            resultList.add(map);
        }

        return ResultUtil.success(resultList);
    }

    /**
     * 根据选择的分析对象 选取字段(返回目标字段数据)
     *
     * @param type
     * @param trunkList 分析对象
     * @param allParam  字段key列表
     * @param pageNum
     * @param limit
     * @return
     */
    @Override
    public YwResult<FuseDataResp> chooseFieldData(FuseMoldType type, List<Integer> trunkList, Map<Integer, List<String>> allParam, int pageNum, int limit) {
        if (MapUtil.isEmpty(allParam)) {
            return ResultUtil.success(new FuseDataResp());
        }
        Map<String, FieldEntity> fieldMap = Maps.newHashMap();//字段的详细信息
        //按分析对象类型，以此查询数据
        List<QuotaTaskConditionLineData> quotaLineData = new ArrayList<>();
        List<BaseLineData> equLineData = new ArrayList<>();
        List<BaseLineData> equSysLineData = new ArrayList<>();
        List<BaseLineData> evlTaskLineData = new ArrayList<>();
        List<BaseLineData> quotaSysLineData = new ArrayList<>();

        gainData(type, trunkList, allParam, pageNum, limit, fieldMap, quotaLineData, equLineData, equSysLineData, evlTaskLineData, quotaSysLineData);
        List<ComposeLineData> composeLineData = combineLine(quotaLineData, equLineData, equSysLineData, evlTaskLineData, quotaSysLineData);

        /**
         *  1 改数据库的行id，不能用trunkId
         *  2 List:可以是重复装备---多样本---多指标
         *    如何存数据库：必须有唯一key，由分析对象id+评估任务id+样本id，或者直接自增。在保存的时候通过方法生成即可。一个组合的所有数据都在一个表。
         *    一行数据包括：id，fuseData行数据，分析对象id和中文名，评估任务id和中文名，样本id，演戏id，仿真id，演戏和仿真中文名
         */
        FuseMoldParser moldParser = fuseContext.getMoldParser(type);
        if (moldParser == null) {
            return ResultUtil.fail();
        }
        Map<String, Object> fieldNameMap = parseChName(composeLineData, trunkList, fieldMap, moldParser, allParam.containsKey(FuseSourceType.EVALUATION.getId()));

        PageResult pageResult = new PageResult<Map<String, Object>>();
        List<Map<String, Object>> results = Lists.newArrayList();
        pageResult.setTotal((long) composeLineData.size());
        for (ComposeLineData line : composeLineData) {
            results.add(line.getFuseData());
        }
        pageResult.setList(results);
        FuseDataResp response = FuseDataResp.valueOf(pageResult, fieldNameMap);
        return ResultUtil.success(response);
    }

    /**
     * 将六个类型返回行数据进行合并
     *
     * @param quotaLineData
     * @param equLineData
     * @param equSysLineData
     * @param evlTaskLineData
     * @param quotaSysLineData
     * @return
     */
    private List<ComposeLineData> combineLine(List<QuotaTaskConditionLineData> quotaLineData,
                                              List<BaseLineData> equLineData, List<BaseLineData> equSysLineData, List<BaseLineData> evlTaskLineData, List<BaseLineData> quotaSysLineData) {
        List<ComposeLineData> totalLine = Lists.newArrayList();
        if (CollUtil.isNotEmpty(quotaLineData)) {
            for (QuotaTaskConditionLineData data : quotaLineData) {
                ComposeLineData cline = new ComposeLineData();
                cline.copyFrom(data);
                BaseLineData equLin = findOneLineFieldDataFrom(data.analysisTargetId, equLineData);
                if (equLin != null) {
                    cline.copyFrom(equLin);
                }
                BaseLineData equSysLin = findOneLineFieldDataFrom(data.analysisTargetId, equSysLineData);
                if (equSysLin != null) {
                    cline.copyFrom(equSysLin);
                }
                totalLine.add(cline);
            }
        } else if (CollUtil.isNotEmpty(equLineData)) {
            for (BaseLineData data : equLineData) {
                ComposeLineData cline = new ComposeLineData();
                cline.copyFrom(data);
                BaseLineData equSysLin = findOneLineFieldDataFrom(data.analysisTargetId, equSysLineData);
                if (equSysLin != null) {
                    cline.copyFrom(equSysLin);
                }
                totalLine.add(cline);
            }
        } else if (CollUtil.isNotEmpty(equSysLineData)) {
            for (BaseLineData data : equSysLineData) {
                ComposeLineData cline = new ComposeLineData();
                cline.copyFrom(data);
                totalLine.add(cline);
            }
        } else {
            for (BaseLineData data : evlTaskLineData) {
                ComposeLineData cline = new ComposeLineData();
                cline.copyFrom(data);
                totalLine.add(cline);
            }
            for (BaseLineData data : quotaSysLineData) {
                ComposeLineData cline = new ComposeLineData();
                cline.copyFrom(data);
                totalLine.add(cline);
            }
        }
        return totalLine;
    }

    private <T extends BaseLineData> BaseLineData findOneLineFieldDataFrom(Integer analysisTargetId, List<T> lineData) {
        for (BaseLineData data : lineData) {
            if (analysisTargetId.equals(data.analysisTargetId)) {
                return data;
            }
        }
        return null;
    }

    /**
     * @param type
     * @param trunkList
     * @param allParam
     * @param pageNum
     * @param limit
     * @param fieldMap
     * @param quotaLineData
     * @param equLineData
     * @param equSysLineData
     * @param evlTaskLineData
     * @param quotaSysLineData
     */
    private void gainData(FuseMoldType type, List<Integer> trunkList, Map<Integer, List<String>> allParam, int pageNum, int limit,
                          Map<String, FieldEntity> fieldMap, List<QuotaTaskConditionLineData> quotaLineData,
                          List<BaseLineData> equLineData, List<BaseLineData> equSysLineData, List<BaseLineData> evlTaskLineData, List<BaseLineData> quotaSysLineData) {
        for (Map.Entry<Integer, List<String>> entry : allParam.entrySet()) {
            FuseSourceType sourceType = FuseSourceType.getType(entry.getKey());
            FuseSourceParser sourceParser = fuseContext.getSourceParser(sourceType);
            if (sourceParser == null) {
                continue;
            }
            fieldMap.putAll(sourceParser.getFieldParam(type, trunkList));
            switch (sourceType) {
                case EVALUATION: {
                    quotaLineData.addAll(sourceParser.getTableResource(type, trunkList, entry.getValue(), allParam.get(4), pageNum, limit));
                    break;
                }
                case EQUIPMENT: {
                    equLineData.addAll(sourceParser.getTableResource(type, trunkList, entry.getValue(), Lists.newArrayList(), pageNum, limit));
                    break;
                }
                case TASK_CONDITION: {
                    break;
                }
                case EQUIPMENT_SYSTEM: {
                    equSysLineData.addAll(sourceParser.getTableResource(type, trunkList, entry.getValue(), Lists.newArrayList(), pageNum, limit));
                    break;
                }
                case EVALUATION_TASK: {
                    evlTaskLineData.addAll(sourceParser.getTableResource(type, trunkList, entry.getValue(), Lists.newArrayList(), pageNum, limit));
                    break;
                }
                case INDEX_SYSTEM: {
                    quotaSysLineData.addAll(sourceParser.getTableResource(type, trunkList, entry.getValue(), Lists.newArrayList(), pageNum, limit));
                    break;
                }
            }
        }
    }

    private Map<String, Object> parseChName(List<ComposeLineData> totalData, List<Integer> trunkList, Map<String, FieldEntity> fieldMap, FuseMoldParser moldParser, boolean isEvaluateQuota) {
        List<String> str = Lists.newArrayList();
        if (isEvaluateQuota) {
            str.add("ROOT");
            str.add("MIDDLE");
            str.add("LEAF");
        }

        Map<Integer, String> paramMap = moldParser.getTrunkParam(trunkList);//获取分析对象中文名称<ID,名称>
        Map<String, Object> fieldNameMap = Maps.newLinkedHashMap();//临时存储表头中文名<字段key,中文名称>
        for (ComposeLineData line : totalData) {
            line.setAnalysisTargetName(paramMap.get(line.getAnalysisTargetId()));
            Map<String, Object> fuseData = line.getFuseData();
            fuseData.put("trunk_name", line.getLineName());
        }
        //获取表头名称并保存到fieldNameMap
        ComposeLineData composeLineData = totalData.get(0);
        Map<String, Object> fuseData = composeLineData.getFuseData();
        fuseData.entrySet().forEach(v -> {
            for (String s : str) {
                FieldEntity entity1 = fieldMap.get(s);
                if (entity1 == null) {
                    continue;
                }
                for (FieldEntity en : entity1.getChildField()) {
                    if (en.getField().equals(v.getKey())) {
                        fieldNameMap.put(v.getKey(), en.getName());
                    }
                }
            }
            FieldEntity entity = fieldMap.get(v.getKey());
            if (entity != null) {
                //设置展示名称
                String showName = entity.getName();
                String belongToName = entity.getBelongToName();
                if (!StringUtils.isEmpty(belongToName)) {
                    showName = belongToName + "_" + showName;
                }
//                fieldNameMap.put(v.getKey(), showName);
                fieldNameMap.put(v.getKey(), showName + "(" + FuseSourceTypeV2.getType(Integer.valueOf(entity.getBelongToType())).getName() + ")");
            }
        });
        return fieldNameMap;
    }

    @Override
    public Map<String, FieldEntity> getFields(FuseSourceType sourceType, FuseMoldType type, String tableName, Collection<Integer> trunkList) {
        switch (sourceType) {
            case EQUIPMENT_SYSTEM:
                return disposeFuseDaoV2.getFields(sourceType, type, tableName, trunkList);
            case EQUIPMENT:
                return disposeFuseDaoV2.getEquipmentFields(sourceType, type, tableName, trunkList);
            default:
                return Maps.newLinkedHashMap();
        }
    }

    @Override
    public YwResult<FuseCreateResponse> createFuseComb(Integer _id, String fuseName, FuseMoldType type, List<Integer> trunkList, Map<Integer, List<String>> chooseMap) {
        if (!combCheck(fuseName, type, trunkList, chooseMap.keySet())) {
            return ResultUtil.fail();
        }
        FuseMoldParser parser = fuseContext.getMoldParser(type);
        if (parser == null) {
            return ResultUtil.fail();
        }
        Map<Object, Object> trunkMap = parser.getTrunkParam();
        if (trunkMap != null && trunkMap.isEmpty() && !trunkMap.keySet().containsAll(trunkList)) {
            return ResultUtil.fail();
        }
        List<FuseComb> targetCombs = disposeFuseDao.getFuseComb(fuseName);
        if (!targetCombs.isEmpty() && !targetCombs.stream().filter(t -> t.getId() != _id).collect(Collectors.toList()).isEmpty()) {
            // 存在名字相同的组合
            return ResultUtil.fail("组合名称重复");
        }
        //根据选择类型获取对应chooseMaps
        Map<Integer, Map<String, FieldEntity>> chooseMaps = getChooseMaps(type);
        for (Map.Entry<Integer, List<String>> entry : chooseMap.entrySet()) {
            int sourceType = entry.getKey();
            if (!type.getSourceTypes().contains(FuseSourceType.getType(sourceType))) {
                return ResultUtil.fail();
            }
            Collection<String> fields = entry.getValue();
            FuseSourceParser sourceParser = fuseContext.getSourceParser(FuseSourceType.getType(sourceType));
            if (sourceParser == null) {
                continue;
            }
            Map<String, FieldEntity> tableFields = sourceParser.getFieldParam(type, trunkList);
            Map<String, FieldEntity> chooseFieldMap = Maps.newLinkedHashMap();
            // 当组合类型为体系分析时使用
            if (sourceType == FuseSourceType.EQUIPMENT.getId() && (type == FuseMoldType.EQUIPMENT_SYSTEM_CENSUS || type == FuseMoldType.EQUIPMENT_SYSTEM_TREND)) {
                for (String field : fields) {
                    if (chooseFieldMap.get(field) != null) {
                        continue;
                    }
                    //选择的参数
                    FieldEntity entity = tableFields.get(field);
                    if (entity != null) {
                        String name = entity.getName(); // 装备参数名称
                        String belongToName = entity.getBelongToName();
                        if (!StringUtils.isEmpty(belongToName)) {
                            belongToName = belongToName + "_" + name;
                            entity.setName(belongToName);
                        }
                        chooseFieldMap.put(field, entity);
                        for (Map.Entry<String, FieldEntity> fieldMap : tableFields.entrySet()) {
                            String key = fieldMap.getKey();
                            if (!key.equals(field)) {
                                FieldEntity value = fieldMap.getValue();
                                String valueName = value.getName();
                                if (name.equals(valueName)) {
                                    if (chooseFieldMap.get(value.getField()) != null) {
                                        continue;
                                    }
                                    String fieldBelongToName = value.getBelongToName();
                                    if (!StringUtils.isEmpty(fieldBelongToName)) {
                                        valueName = fieldBelongToName + "_" + valueName;
                                        value.setName(valueName);
                                    }
                                    chooseFieldMap.put(key, value);
                                }
                            }
                        }
                    }
                }
                chooseMaps.put(sourceType, chooseFieldMap);
                continue;
            }
            for (Map.Entry<String, FieldEntity> entity : tableFields.entrySet()) {
                if (fields.contains(entity.getKey())) {
                    chooseFieldMap.put(entity.getKey(), entity.getValue());
                    continue;
                }
                if (sourceType == FuseSourceType.EVALUATION.getId()) {
                    Collection<FieldEntity> childList = entity.getValue().getChildField();
                    for (Iterator<FieldEntity> iterable = childList.iterator(); iterable.hasNext(); ) {
                        FieldEntity childEntity = iterable.next();
                        Collection<FieldEntity> childField = childEntity.getChildField();
                        if (childField != null) {
                            for (Iterator<FieldEntity> childFields = childField.iterator(); childFields.hasNext(); ) {
                                FieldEntity next = childFields.next();
                                if (fields.contains(next.getField())) {
                                    String name = next.getName();
                                    next.setName(childEntity.getName() + "-" + name);
                                    chooseFieldMap.put(next.getField(), next);
                                }
                            }
                        }
                    }
                }
                Collection<FieldEntity> childList = entity.getValue().getChildField();
                if (CollUtil.isNotEmpty(childList)) {
                    for (Iterator<FieldEntity> iterable = childList.iterator(); iterable.hasNext(); ) {
                        FieldEntity childEntity = iterable.next();
                        if (!fields.contains(childEntity.getField())) {
                            iterable.remove();
                        }
                    }
                }
                if (CollUtil.isNotEmpty(childList)) {
                    chooseFieldMap.put(entity.getKey(), entity.getValue());
                }

            }
            chooseMaps.put(sourceType, chooseFieldMap);
        }
        FuseComb fuseComb = disposeFuseDao.createFuseComb(_id, type, fuseName, trunkList, chooseMaps);
        //执行融合
        DisposeFuseActuator.dispose(fuseComb);
        FuseCreateResponse response = FuseCreateResponse.valueOf(fuseComb.getId());
        return ResultUtil.success(response);
    }

    private Map<Integer, Map<String, FieldEntity>> getChooseMaps(FuseMoldType type) {
        Map<Integer, Map<String, FieldEntity>> chooseMaps = Maps.newLinkedHashMap();
        Collection<FuseSourceType> sourceTypes = type.getSourceTypes();
        sourceTypes.forEach(s -> {
            chooseMaps.put(s.getId(), Maps.newLinkedHashMap());
        });
        return chooseMaps;
    }

    private boolean combCheck(String fuseName, FuseMoldType type, List<Integer> trunkList, Collection<Integer> chooseMapKeys) {
        if (fuseName == null || fuseName.isEmpty()) {
            return false;
        }
        if (type == null || type == FuseMoldType.NONE) {
            return false;
        }
        if (FuseMoldType.INDEX_SYSTEM_EXCAVATE == type) {
            return true;
        }
        if (FuseMoldType.EVALUATION_TASK_EXCAVATE == type) {
            return true;
        }
        if (trunkList == null || trunkList.isEmpty()) {
            return false;
        }
        return true;
    }

    @Override
    public YwResult<FuseCheckResponse> preFuseCheck(int fuseId, FuseCheckType type) {
        FuseCombV2 fuseCombV2 = mongoTemplate.findById(fuseId, FuseCombV2.class);
        if (fuseCombV2.getTopicType().equals(TopicTypeMethod.TOPIC_6)) {
            return ResultUtil.fail(TopicTypeMethod.TOPIC_1.getTopicName() + "不需要预处理数据");
        }
        switch (type) {
            case FIXED:
                return fixedCheck(fuseId);
            case DEFECT:
                return defect(fuseId);
            case UNIFORMITY:
                return uniformityCheck(fuseId);
            default:
                return ResultUtil.fail();
        }
    }

    /**
     * 缺失项检查
     *
     * @param fuseId
     * @return
     */
    private YwResult<FuseCheckResponse> defect(int fuseId) {
        FuseCheckResponse fuseCheckResponse = disposeFuseDaoV2.defect(fuseId);
        return ResultUtil.success(fuseCheckResponse);
    }

    /**
     * 固定值检查
     *
     * @param fuseId
     * @return
     */
    private YwResult<FuseCheckResponse> fixedCheck(int fuseId) {
        FuseCheckResponse fuseCheckResponse = disposeFuseDaoV2.fixedCheck2(fuseId);
        return ResultUtil.success(fuseCheckResponse);
    }

    /**
     * 相同列检查
     *
     * @param fuseId 组合id
     */
    private YwResult<FuseCheckResponse> uniformityCheck(int fuseId) {
        FuseCheckResponse fuseCheckResponse = disposeFuseDaoV2.uniformityCheck2(fuseId);
        return ResultUtil.success(fuseCheckResponse);
    }

    @Override
    public YwResult deleteField(int fuseId, List<String> fieldName, String type) {
        disposeFuseDaoV2.deleteField(fuseId, fieldName, type);
        // 修改样本数据
        planSampleServiceV2.updateAfterFuseDataChange(fuseId);
        return ResultUtil.success();
    }

    @Override
    public YwResult autoFillData(AutoFillDataReq autoFillDataReq) {
        Long count = disposeFuseDaoV2.autoFillData(autoFillDataReq.getFuseId(), autoFillDataReq.getValue());
        return ResultUtil.success(count);
    }

    /**
     * 预处理 -保存
     *
     * @param fuseId           主题id
     * @param fuseSpecimenList 数据列表
     * @return
     */
    @Override
    public YwResult handFillData(Integer fuseId, List<FuseSpecimen> fuseSpecimenList) {
        return disposeFuseDaoV2.handFillData(fuseId, fuseSpecimenList);
    }

    @Override
    public Map<Object, Object> getTrunkParam(FuseSourceType type) {
        return disposeFuseDao.getTrunkParam(type);
    }

    @Override
    public YwResult<FuseComb> queryFuse(int id) {
        FuseComb fuseComb = disposeFuseDao.queryFuse(id);
        return ResultUtil.success(fuseComb);
    }

    @Override
    public YwResult<Collection<FuseChooseEnumResponse>> getFuse() {
        List<FuseChooseEnumResponse> responses = Lists.newArrayList();
        for (FuseMoldType type : FuseMoldType.values()) {
            if (type == FuseMoldType.NONE) {
                continue;
            }
            FuseChooseEnumResponse response = FuseChooseEnumResponse.valueOf(type);
            responses.add(response);
        }
        return ResultUtil.success(responses);
    }

    @Override
    public YwResult<FuseDataResp> dataPageList(FuseDataPageReq fuseDataPageReq) {
        return disposeFuseDaoV2.dataPageList(fuseDataPageReq);
    }

    @Override
    public Map<Integer, Map<String, Object>> getTableResource(FuseMoldType type, String tableName, List<Integer> trunkList, List<String> chooseList, int pageNum, int limit) {
        return disposeFuseDao.getTableResource(type, tableName, trunkList, chooseList, pageNum, limit);
    }

    @Override
    public YwResult getFuseComb(int id) {
        FuseCombResponseV2 data = disposeFuseDaoV2.getFuseCombData(id);
        return ResultUtil.success(data);
    }

    @Override
    public YwResult oneClickClearing(FuseColumnClearingReq req) {
        List<List<String>> fieldName = req.getFieldName();
        List<String> deleteFields = new ArrayList<>();
        for (int i = 0; i < fieldName.size(); i++) {
            fieldName.get(i).remove(0);
            deleteFields.addAll(fieldName.get(i));
        }
        return deleteField(req.getFuseId(), deleteFields, "column");
    }

    @Override
    public List<Map<String, Object>> getVariableListByTopicId(Integer topicId) {
        FuseCombV2 fuseCombV2 = mongoTemplate.findById(topicId, FuseCombV2.class);
        if (fuseCombV2 == null) {
            throw new ApiException("主题不存在");
        }

        return fuseCombV2.getVariableList();
    }

    public static void main(String[] args) {
        String mapStr = "{'1':'1'}";
        Map<Integer, String> map = JSON.parseObject(mapStr, Map.class);
        System.err.println(map.get(1));
    }
}
