package com.yw.fusionanaly.database.collection;


import com.google.common.collect.Maps;
import com.yw.fusionanaly.database.Entity;

import java.util.Map;

/**
 * 融合标本数据
 */
public class FuseSpecimen extends Entity {
    /**
     * 主键
     * 装备Id
     */
    private String _id;
    /**
     * 融合数据体
     */
    private Map<String, Object> fuseData;

    public static FuseSpecimen valueOf(String id, Map<String, Object> fuseData) {
        FuseSpecimen specimen = new FuseSpecimen();
        specimen._id = id;
        specimen.fuseData = fuseData;
        return specimen;
    }

    public String getId() {
        return _id;
    }

    public void setId(String id) {
        this._id = id;
    }

    public Map<String, Object> getFuseData() {
        return fuseData;
    }

    public void setFuseData(Map<String, Object> fuseData) {
        this.fuseData = fuseData;
    }
}
