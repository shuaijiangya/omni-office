package com.yw.fusionanaly.module.plan.dao;


import com.yw.fusionanaly.common.result.PageResult;
import com.yw.fusionanaly.database.BaseMongoTemplate;
import com.yw.fusionanaly.database.MongoDbDao;
import com.yw.fusionanaly.database.collection.FuseSpecimen;
import com.yw.fusionanaly.database.collection.PlanSample;
import com.yw.fusionanaly.module.plan.request.FieldDataReq;
import com.yw.fusionanaly.module.plan.response.FieldDataResp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import java.util.function.Function;

/**
 * 方案样本dao
 *
 * @author hww
 * @date 2021/08/30 11:00
 **/
@Repository
public class PlanSampleMongoDbDaoV2 extends MongoDbDao<PlanSample> {

    @Autowired
    private BaseMongoTemplate baseMongoTemplate;
    @Autowired
    private MongoTemplate mongoTemplate;

    private final String FUSE_SPECIMEN_V2 = "fuse_specimen_v2_";

    @Override
    protected Class<PlanSample> getEntityClass() {
        return PlanSample.class;
    }

    public PageResult<FieldDataResp> getFieldPageData(FieldDataReq fieldDataReq) {
        //分页查询FuseSpecimen转Map<String, Object>
        Function<FuseSpecimen, FieldDataResp> function = fun -> {
            FieldDataResp fieldDataResp = new FieldDataResp();
            fieldDataResp.setData(fun.getFuseData().get(fieldDataReq.getField()));
            fieldDataResp.setId(fun.getId());
            return fieldDataResp;
        };
        //根据Function分页查询融合数据
        PageResult<FieldDataResp> page = baseMongoTemplate.findPage(new Query(), FuseSpecimen.class, fieldDataReq.getPageNum(), fieldDataReq.getPageSize(), function,
                FUSE_SPECIMEN_V2 + fieldDataReq.getFuseId());

        return page;
    }

    /**
     * 删除方案下所有样本
     *
     * @param planId 方案id
     */
    public void deleteByPlanId(String planId) {
        Query query = Query.query(Criteria.where("planId").is(planId));
        mongoTemplate.remove(query, PlanSample.class);
    }
}
