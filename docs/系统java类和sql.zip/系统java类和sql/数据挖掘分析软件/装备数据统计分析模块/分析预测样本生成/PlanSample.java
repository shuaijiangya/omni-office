package com.yw.fusionanaly.database.collection;

import com.yw.fusionanaly.common.util.LocalDateTimeTool;
import com.yw.fusionanaly.module.analysis.model.response.AbstractResultAnalysisVO;
import com.yw.fusionanaly.module.plan.request.PlanSampleExecuteRequest;
import com.yw.fusionanaly.module.plan.type.PlanExecuteStatusType;
import com.yw.fusionanaly.module.plan.type.PlanSampleMethodType;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;

/**
 * 方案样本
 *
 * @author hww
 * @date 2021/08/27 17:29
 **/
@Data
@Accessors(chain = true)
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "planSample")
public class PlanSample {
    @Id
    @ApiModelProperty(value = "方案样本id", required = true)
    private String id;

    @ApiModelProperty(value = "方案样本名称", required = true)
    private String name;

    @ApiModelProperty(value = "主题id", required = true)
    private String basesetId;

    /**
     * 主题名称
     */
    @ApiModelProperty(value = "主题名称", required = true)
    private String basesetName;

    @ApiModelProperty(value = "所属方案id", required = true)
    private String planId;

    @ApiModelProperty(value = "所属方案名称", required = true)
    private String planName;

    @ApiModelProperty(name = "所属分析方法", notes = "com.yw.fusionanaly.module.plan.type.PlanSampleMethodType", required = true)
    @NotNull(message = "所属分析方法不能为空")
    private PlanSampleMethodType type;

    @ApiModelProperty(value = "变量集合", required = true)
    private List<PlanSampleExecuteRequest> params;

    @ApiModelProperty(name = "因变量起始范围", required = true)
    private Integer start;

    @ApiModelProperty(name = "因变量结束范围", required = true)
    private Integer end;

    @ApiModelProperty(name = "样本阈值", required = true)
    private String threshold;

    @ApiModelProperty(value = "样本返回结果", required = true)
    private Object result;

    @ApiModelProperty(value = "创建时间", required = true)
    private String createTime;

    @ApiModelProperty(value = "更新时间", required = true)
    private String updateTime;

    @ApiModelProperty(value = "样本执行状态")
    @Transient
    private PlanExecuteStatusType status;
    @ApiModelProperty(value = "样本执行返回信息")
    @Transient
    private String msg;

    @ApiModelProperty(value = "结论和推论数据")
    @Transient
    private AbstractResultAnalysisVO resultAll;

    public static PlanSample valueOf(String planId, String fuseId, String name, PlanSampleMethodType type, List<PlanSampleExecuteRequest> params, String planName, String basesetName, String threshold, String id) {
        //校验都通过后，创建样本，并流转到后续节点中处理
        PlanSample newSample = new PlanSample();
        Integer depentdentVaraibleStart = 0;
        Integer depentdentVaraibleEnd = 0;
        newSample.setPlanId(planId);
        newSample.setBasesetId(fuseId);
        newSample.setName(name);
        newSample.setType(type);
        newSample.setParams(params);
        newSample.setStart(depentdentVaraibleStart);
        newSample.setEnd(depentdentVaraibleEnd);
        newSample.setCreateTime(LocalDateTimeTool.dateToDateTimeStr(new Date()));
        newSample.setUpdateTime(LocalDateTimeTool.dateToDateTimeStr(new Date()));
        //设置初始结果为空
        newSample.setResult("");
        newSample.setPlanName(planName);
        newSample.setBasesetName(basesetName);
        newSample.setThreshold(threshold);
        newSample.setId(id);
        return newSample;
    }

    @Transient
    public String getTypeName() {
        return type.getDesc();
    }

//    public Object getResult() {
//        if (PlanSampleMethodType.EXPLORATORY_ANALYSIS.equals(type)) {
//            if (result != null) {
//                String resultStr = (String) result;
//                JSONObject jsonObject = JSON.parseObject(resultStr);
//                JSONArray list = jsonObject.getJSONArray("list");
//
//                for (int i = 0; i < list.size(); ++i) {
//                    JSONObject itemJson = list.getJSONObject(i);
//                    if (!itemJson.containsKey("rang")) {
//
//                    }
//
//                }
//            }
//        }
//        return result;
//    }
}
