package com.yw.fusionanaly.module.plan.service.impl;


import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mongodb.client.result.UpdateResult;
import com.yw.fusionanaly.common.exception.ApiException;
import com.yw.fusionanaly.common.result.PageResult;
import com.yw.fusionanaly.database.collection.PlanSample;
import com.yw.fusionanaly.module.disposeFuse.dao.DisposeFuseDao;
import com.yw.fusionanaly.module.disposeFuse.dao.DisposeFuseDaoV2;
import com.yw.fusionanaly.module.disposeFuse.helper.DisposeFuseHelper;
import com.yw.fusionanaly.module.disposeFuse.parser.moldImpl.IndexSystemParser;
import com.yw.fusionanaly.module.disposeFuse.service.DisposeFuseService;
import com.yw.fusionanaly.module.plan.cache.PlanExecuteStatusCacheService;
import com.yw.fusionanaly.module.plan.chain.SpringContentUtils;
import com.yw.fusionanaly.module.plan.chain.core.Bootstrap;
import com.yw.fusionanaly.module.plan.chain.core.HandlerInitializer;
import com.yw.fusionanaly.module.plan.chain.core.Pipeline;
import com.yw.fusionanaly.module.plan.chain.handler.*;
import com.yw.fusionanaly.module.plan.chain.param.SamplePipeRequest;
import com.yw.fusionanaly.module.plan.chain.response.PlanExecuteResultResponse;
import com.yw.fusionanaly.module.plan.dao.PlanSampleMongoDbDao;
import com.yw.fusionanaly.module.plan.dao.PlanSampleMongoDbDaoV2;
import com.yw.fusionanaly.module.plan.observer.eventbus.EventBusCenter;
import com.yw.fusionanaly.module.plan.request.*;
import com.yw.fusionanaly.module.plan.response.FieldDataResp;
import com.yw.fusionanaly.module.plan.service.PlanSampleServiceV2;
import com.yw.fusionanaly.module.plan.type.PlanMethodsType;
import com.yw.fusionanaly.module.plan.type.PlanSampleMethodType;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 方案数据子集实现类
 *
 * @author hww
 * @date 2021/08/27 17:42
 **/
@Service
@Slf4j
@RequiredArgsConstructor
public class PlanSampleServiceImplV2 implements PlanSampleServiceV2 {

    private final PlanSampleMongoDbDao planSampleDao;
    private final PlanSampleMongoDbDaoV2 planSampleMongoDbDaoV2;
    private final DisposeFuseDao disposeFuseDao;
    private final PlanExecuteStatusCacheService cacheService;
    private final DisposeFuseService disposeFuseService;
    private final IndexSystemParser indexSystemParser;
    private final EventBusCenter eventBusCenter;
    private final SpringContentUtils springContentUtils;
    private final DisposeFuseDaoV2 disposeFuseDaoV2;
    private final MongoTemplate mongoTemplate;
    private final DisposeFuseHelper disposeFuseHelper;

    @Override
    public void setAlgParams(SetAlgParamsRequest params) {
        PlanSampleMethodType type = params.getType();
        String id = params.getId();

        if (StringUtils.isNotBlank(id)) {
            deleteBySampleId(id);
        }
        PlanExecuteResultResponse response = new PlanExecuteResultResponse();
        SamplePipeRequest request = new SamplePipeRequest();
        BeanUtils.copyProperties(params, request);
        request.setType(type);
        Bootstrap bootstrap = new Bootstrap();
        bootstrap.childHandler(new HandlerInitializer(request, response) {
            @Override
            protected void initChannel(Pipeline pipeline) {
                //1.校验样本参数是否合法
                pipeline.addLast(springContentUtils.getHandler(CheckSampleDataHandler.class));
                //2.校验样本是否已经存在
                pipeline.addLast(springContentUtils.getHandler(CheckSampleIsExistedHandler.class));
                //3.对关联挖掘分析和聚类分析的样本特殊处理
                //如果是关联挖掘分析，则根据组合id生成关联挖掘分析的样本数据
                //如果是聚类分析，则根据选择的参数进行阈值的设定
                pipeline.addLast(springContentUtils.getHandler(SetAssiationAndClusterMingSampleV2.class));
                //4.设置样本的默认验证集（默认使用自变量作为验证集，不存在自变量的使用普通变量做验证集,否则使用传入的验证集）
                pipeline.addLast(springContentUtils.getHandler(SetSampleValidateSetHandlerV2.class));
                //5.配置因变量范围
                pipeline.addLast(springContentUtils.getHandler(ConfigDependentRangeHandler.class));
                //6.保存样本到mongodb中
                pipeline.addLast(springContentUtils.getHandler(SaveSampleHandler.class));
                //7.计算
                pipeline.addLast(springContentUtils.getHandler(RunPlanSampleHandlerV2.class));
            }
        });
        PlanExecuteResultResponse response1 = (PlanExecuteResultResponse) bootstrap.execute();
        try {
            JSON.parseObject(response1.getResult());
        } catch (Exception e) {
            e.printStackTrace();
            throw new ApiException(response1.getResult());
        }
    }

    @Override
    public void edit(SetAlgParamsRequest params) {
        disposeFuseHelper.checkFuseDataStatusHandler(Integer.parseInt(params.getBasesetId()));

        SamplePipeRequest request = new SamplePipeRequest();
        BeanUtils.copyProperties(params, request);
        Bootstrap bootstrap = new Bootstrap();
        bootstrap.childHandler(new HandlerInitializer(request, null) {
            @Override
            protected void initChannel(Pipeline pipeline) {
                //1.校验样本参数是否合法
                pipeline.addLast(springContentUtils.getHandler(CheckSampleDataHandler.class));
                //2.校验样本是否已经存在
                pipeline.addLast(springContentUtils.getHandler(CheckSampleIsExistedHandler.class));
                //3.对关联挖掘分析和聚类分析的样本特殊处理
                //如果是关联挖掘分析，则根据组合id生成关联挖掘分析的样本数据
                //如果是聚类分析，则根据选择的参数进行阈值的设定
                pipeline.addLast(springContentUtils.getHandler(SetAssiationAndClusterMingSampleV2.class));
                //4.设置样本的默认验证集（默认使用自变量作为验证集，不存在自变量的使用普通变量做验证集,否则使用传入的验证集）
                pipeline.addLast(springContentUtils.getHandler(SetSampleValidateSetHandlerV2.class));
                //5.配置因变量范围
                pipeline.addLast(springContentUtils.getHandler(ConfigDependentRangeHandler.class));
                //6.保存样本到mongodb中
                pipeline.addLast(springContentUtils.getHandler(SaveSampleHandler.class));
            }
        });
        bootstrap.execute();
    }

    @Override
    public void deleteById(String id) {
        mongoTemplate.remove(Query.query(Criteria.where("id").is(id)), PlanSample.class);
    }

    @Override
    public PlanSample getById(String id) {
        return mongoTemplate.findById(id, PlanSample.class);
    }

    @Override
    public void execute(String id) {
        PlanSample planSample = mongoTemplate.findById(id, PlanSample.class);

        PlanExecuteResultResponse response = new PlanExecuteResultResponse();
        SamplePipeRequest request = new SamplePipeRequest();
        request.setNewSample(planSample);
        Bootstrap bootstrap = new Bootstrap();
        bootstrap.childHandler(new HandlerInitializer(request, response) {
            @Override
            protected void initChannel(Pipeline pipeline) {
                //7.计算
                pipeline.addLast(springContentUtils.getHandler(RunPlanSampleHandlerV2.class));
            }
        });
//        PlanExecuteResultResponse response1 = (PlanExecuteResultResponse) bootstrap.execute();
//        try {
//            JSON.parseObject(response1.getResult());
//        } catch (Exception e) {
//            e.printStackTrace();
//            throw new ApiException(response1.getResult());
//        }
    }

    @Override
    public void createPlanSample(PlanSampleCreateRequest sample) {
        SamplePipeRequest request = new SamplePipeRequest();
        BeanUtils.copyProperties(sample, request);
        Bootstrap bootstrap = new Bootstrap();
        bootstrap.childHandler(new HandlerInitializer(request, null) {
            @Override
            protected void initChannel(Pipeline pipeline) {
                //1.校验样本参数是否合法
                pipeline.addLast(springContentUtils.getHandler(CheckSampleDataHandler.class));
                //2.校验样本是否已经存在
                pipeline.addLast(springContentUtils.getHandler(CheckSampleIsExistedHandler.class));
                //3.对关联挖掘分析和聚类分析的样本特殊处理
                //如果是关联挖掘分析，则根据组合id生成关联挖掘分析的样本数据
                //如果是聚类分析，则根据选择的参数进行阈值的设定
                pipeline.addLast(springContentUtils.getHandler(SetAssiationAndClusterMingSample.class));
                //4.设置样本的默认验证集（默认使用自变量作为验证集，不存在自变量的使用普通变量做验证集）
                pipeline.addLast(springContentUtils.getHandler(SetSampleValidateSetHandler.class));
                //5.保存样本到mongodb中
                pipeline.addLast(springContentUtils.getHandler(SaveSampleHandler.class));
                //6.执行样本数据
                pipeline.addLast(springContentUtils.getHandler(RunPlanSampleHandler.class));
            }
        });
        bootstrap.execute();
    }

    @Override
    public List<PlanSample> getAllPlanSample() {
        return planSampleDao.queryList(new PlanSample());
    }

    @Override
    public PageResult<PlanSample> getPlanSampleByPage(String name, Integer pageNum, Integer pageSize) {
        PlanSample sample = new PlanSample();
        if (StrUtil.isNotEmpty(name)) {
            sample.setName(name);
            return planSampleDao.getPage(sample, pageNum, pageSize);
        }
        return planSampleDao.getPage(sample, pageNum, pageSize);
    }

    @Override
    public List<PlanSample> getPlanSampleByPlanId(String planId) {
        PlanSample sample = new PlanSample().setPlanId(planId);
        List<PlanSample> sampleList = planSampleDao.queryList(sample);
        return sampleList;
    }

    @Override
    public List<PlanSample> getPlanSampleByFuseId(String fuseId) {
        PlanSample sample = new PlanSample().setBasesetId(fuseId);
        List<PlanSample> sampleList = planSampleDao.queryList(sample);
        return sampleList;
    }

    @Override
    public PlanSample getPlanSampleByPlanIdAndId(String planId, String id) {
        PlanSample sample = new PlanSample().setId(id).setPlanId(planId);
        return planSampleDao.queryOne(sample);
    }

    @Override
    public PlanSample getPlanSampleByPlanIdAndMethodType(String planId, PlanSampleMethodType type) {
        PlanSample sample = new PlanSample().setType(type).setPlanId(planId);
        return planSampleDao.queryOne(sample);
    }

    @Override
    public List<PlanSample> getPlanSampleByPlanIdAndType(String planId, PlanMethodsType type) {
        List<PlanSampleMethodType> planSampleRegressionTypes = PlanMethodsType.toPlanSampleRegressionType(type);
        //TODO
        List<PlanSample> sampleList = new ArrayList<>();
        for (PlanSampleMethodType planSampleRegressionType : planSampleRegressionTypes) {
            PlanSample sample = new PlanSample().setPlanId(planId).setType(planSampleRegressionType);
            List<PlanSample> samples = planSampleDao.queryList(sample);
            sampleList.addAll(samples);
        }
        return sampleList;
    }

    @Override
    public List<PlanSample> getPlanSampleByMethodType(PlanSampleMethodType type) {
        PlanSample sample = new PlanSample().setType(type);
        return planSampleDao.queryList(sample);
    }

    @Override
    public long updateOne(PlanSample srcSample, PlanSample targetSample) {
        UpdateResult result = planSampleDao.updateFirst(srcSample, targetSample);
        long matchedCount = result.getMatchedCount();
        return matchedCount;
    }

    @Override
    public long updateMany(PlanSample srcSample, PlanSample targetSample) {
        UpdateResult result = planSampleDao.updateMulti(srcSample, targetSample);
        long matchedCount = result.getMatchedCount();
        return matchedCount;
    }

    @Override
    public void updateAfterFuseDataChange(Integer fuseId) {
        Map<String, String> fuseFields = getFuseFields(fuseId);
        Set<String> fields = fuseFields.keySet();
        List<PlanSample> sampleList = getPlanSampleByFuseId(String.valueOf(fuseId));
        for (PlanSample sample : sampleList) {
            String listStr = JSONObject.toJSONString(sample);
            PlanSample srcSample = JSONObject.parseObject(listStr, PlanSample.class);
            List<PlanSampleExecuteRequest> params = sample.getParams();
            Iterator<PlanSampleExecuteRequest> iterator = params.iterator();
            while (iterator.hasNext()) {
                PlanSampleExecuteRequest item = iterator.next();
                String field = item.getName();
                if (fields.contains(field)) {
                    //修改数据、删除行
                    List<Object> fieldDataArray = getFieldDataArray(FieldDataReq.builder().field(field)
                            .pageNum(0).pageSize(0)
                            .fuseId(fuseId).build());
                    List<Double> newList = fieldDataArray.stream().map(item2 -> Double.parseDouble((String) item2)).collect(Collectors.toList());
                    List<Double> list = new ArrayList<>();
                    for (int i = 0; i < newList.size(); i++) {
                        Double aDouble = newList.get(i);
                        list.add(aDouble);
                    }
                    item.setData(list);
                } else {
                    //说明该列已被删除
                    iterator.remove();
                }
            }
            long l = updateOne(srcSample, sample);
            if (l > 0) {
                String name = sample.getName();
                log.info("{}样本数据更新成功", name);
            }
        }
    }

    @Override
    public void updateOneBySample(PlanSampleUpdateRequest sample) {
        SamplePipeRequest request = new SamplePipeRequest();
        BeanUtils.copyProperties(sample, request);
        Bootstrap bootstrap = new Bootstrap();
        bootstrap.childHandler(new HandlerInitializer(request, null) {
            @Override
            protected void initChannel(Pipeline pipeline) {
                //1.校验样本参数是否合法
                pipeline.addLast(springContentUtils.getHandler(CheckSampleDataHandler.class));
                //2.保存样本到mongodb中
                pipeline.addLast(springContentUtils.getHandler(SaveSampleHandler.class));
            }
        });
        bootstrap.execute();

//        PlanSampleMethodType type = sample.getType();
//        List<PlanSampleExecuteRequest> params = sample.getParams();
//        if (type == MULTIVARIATE_LOGISTIC || type == BINARY_LOGISTIC || type == BAYESIAN_DISCRIMINANT) {
//            checkIndepent(type, params);
//            checkCharacteristic(type, params);
//        }
//        if (type == MULTIPLE_LINEAR) {
//            checkCharacteristic(type, params);
//        }
//        if (type == AUTOREGRESSION) {
//            checkARModel(params);
//        }
//        PlanSample targetSample = new PlanSample();
//        BeanUtils.copyProperties(sample, targetSample);
//        targetSample.setUpdateTime(LocalDateTimeTool.dateToDateTimeStr(new Date()));
//        PlanSample srcSample = getPlanSampleByPlanIdAndId(targetSample.getPlanId(), targetSample.getId());
//        planSampleDao.updateFirst(srcSample, targetSample);

    }

    @Override
    public void deletePlanSample(String planId) {
        PlanSample planSample = new PlanSample().setPlanId(planId);
        planSampleDao.delete(planSample);
    }

    @Override
    public void deletePlanSampleBySampleType(PlanSampleMethodType type, String planId) {
        PlanSample planSample = new PlanSample().setType(type).setPlanId(planId);
        planSampleDao.delete(planSample);
    }

    @Override
    public void deleteAllPlanSample(String planId, String id) {
        //findAll
        PlanSample sample = getPlanSampleByPlanIdAndId(planId, id);
        //delete
        planSampleDao.delete(sample);
    }

    @Override
    public Map<String, String> getFuseFields(int fuseId) {
        return disposeFuseDaoV2.getFuseFields(fuseId);
    }

    @Override
    public PageResult<FieldDataResp> getFieldData(FieldDataReq fieldDataReq) {
        return planSampleMongoDbDaoV2.getFieldPageData(fieldDataReq);
    }

    @Override
    public List<Object> getFieldDataArray(FieldDataReq fieldDataReq) {
        PageResult<FieldDataResp> fieldData = getFieldData(fieldDataReq);
        List<FieldDataResp> list = fieldData.getList();
        List<Object> collect = list.stream().map(FieldDataResp::getData).filter(data -> data != null).collect(Collectors.toList());
        return collect;
    }

    @Override
    public List<PlanSample> getPlanSampleByPlanIdAndTopicId(String planId, String topicId) {
        PlanSample sample = new PlanSample().setBasesetId(topicId).setPlanId(planId);
        return planSampleDao.queryList(sample);
    }

    @Override
    public void deleteByTopicId(String topicId) {
        Query query = Query.query(Criteria.where("basesetId").is(topicId));
        mongoTemplate.remove(query, PlanSample.class);
//        planSampleDao.delete(planSample);
    }

    private void deleteByTopicIdAndMethod(String basesetId, PlanSampleMethodType type) {
        Query query = Query.query(Criteria.where("basesetId").is(basesetId).and("type").is(type));
        mongoTemplate.remove(query, PlanSample.class);
    }

    private void deleteBySampleId(String sampleId) {
        Query query = Query.query(Criteria.where("_id").is(sampleId));
        mongoTemplate.remove(query, PlanSample.class);
    }

}
