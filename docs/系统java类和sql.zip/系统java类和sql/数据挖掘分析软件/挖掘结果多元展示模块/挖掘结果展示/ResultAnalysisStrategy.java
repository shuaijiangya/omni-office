package com.yw.fusionanaly.module.analysis.strategy;

import com.yw.fusionanaly.common.exception.ApiException;
import com.yw.fusionanaly.common.parser.AbstractParser;
import com.yw.fusionanaly.database.collection.PlanSample;
import com.yw.fusionanaly.module.analysis.model.request.ExportBySampleParam;
import com.yw.fusionanaly.module.analysis.model.response.AbstractResultAnalysisVO;
import com.yw.fusionanaly.module.plan.type.PlanSampleMethodType;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletResponse;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 结果分析执行策略类
 *
 * @author zhangkun
 * @date 2022/9/2 15:30
 */
@Component
public class ResultAnalysisStrategy {
    private final Map<PlanSampleMethodType, AbstractResultAnalysis> strategy = new ConcurrentHashMap<>();

    /**
     * 执行方法
     *
     * @param parser     结果解析器
     * @param planSample 样本
     * @return 结果集
     */
    public AbstractResultAnalysisVO analysis(AbstractParser parser, PlanSample planSample) {
        return getExecuteBySampleId(planSample).get(parser, planSample);
    }

    /**
     * 导出报告
     *
     * @param response   http响应
     * @param param      导出参数
     * @param parser     结果解析器
     * @param planSample 样本
     */
    public void export(HttpServletResponse response, ExportBySampleParam param, AbstractParser parser, PlanSample planSample) {
        getExecuteBySampleId(planSample).export(response, param, parser, planSample);
    }

    /**
     * 根据样本id获取执行类
     *
     * @param planSample 样本
     * @return 执行类
     */
    private AbstractResultAnalysis getExecuteBySampleId(PlanSample planSample) {
        if (planSample == null) {
            throw new ApiException("样本不存在");
        }

        AbstractResultAnalysis execute = strategy.get(planSample.getType());
        if (execute == null) {
            throw new ApiException(String.format("%s不能进行结果分析", planSample.getTypeName()));
        }
        return execute;
    }

    public void register(PlanSampleMethodType type, AbstractResultAnalysis handler) {
        strategy.put(type, handler);
    }

    /**
     * 获取结果解析器
     *
     * @param planSample 样本
     * @return 结果解析器
     */
    public AbstractParser getParser(PlanSample planSample) {
        return getExecuteBySampleId(planSample).getParser(planSample);
    }
}
