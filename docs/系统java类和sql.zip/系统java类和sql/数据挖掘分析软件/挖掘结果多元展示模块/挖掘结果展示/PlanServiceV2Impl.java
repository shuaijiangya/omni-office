package com.yw.fusionanaly.module.plan.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.bean.copier.CopyOptions;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.yw.fusionanaly.common.exception.ApiException;
import com.yw.fusionanaly.common.result.PageResult;
import com.yw.fusionanaly.common.result.ResultUtil;
import com.yw.fusionanaly.common.result.YwResult;
import com.yw.fusionanaly.common.util.LocalDateTimeTool;
import com.yw.fusionanaly.common.util.MongodbStringUtil;
import com.yw.fusionanaly.database.BaseMongoTemplate;
import com.yw.fusionanaly.database.collection.*;
import com.yw.fusionanaly.database.entity.FieldEntity;
import com.yw.fusionanaly.module.analysis.model.response.AbstractResultAnalysisVO;
import com.yw.fusionanaly.module.analysis.service.ResultAnalysisService;
import com.yw.fusionanaly.module.disposeFuse.dao.DisposeFuseDaoV2;
import com.yw.fusionanaly.module.disposeFuse.dao.impl.DisposeFuseDaoV2Impl;
import com.yw.fusionanaly.module.disposeFuse.helper.DisposeFuseActuatorV2;
import com.yw.fusionanaly.module.disposeFuse.helper.DisposeFuseHelper;
import com.yw.fusionanaly.module.disposeFuse.parser.FuseContext;
import com.yw.fusionanaly.module.disposeFuse.parser.FuseSourceParser;
import com.yw.fusionanaly.module.disposeFuse.response.FuseCombResponseV2;
import com.yw.fusionanaly.module.disposeFuse.type.FuseMoldType;
import com.yw.fusionanaly.module.disposeFuse.type.FuseSourceType;
import com.yw.fusionanaly.module.plan.algorithm.AlgorithmFactory;
import com.yw.fusionanaly.module.plan.algorithm.AlgorithmStrategy;
import com.yw.fusionanaly.module.plan.cache.PlanExecuteStatusCacheService;
import com.yw.fusionanaly.module.plan.chain.response.PlanExecuteResultResponse;
import com.yw.fusionanaly.module.plan.dao.PlanMongoDbDaoV2;
import com.yw.fusionanaly.module.plan.dao.PlanSampleMongoDbDao;
import com.yw.fusionanaly.module.plan.observer.event.ExecutePlanEvent;
import com.yw.fusionanaly.module.plan.observer.eventbus.EventBusCenter;
import com.yw.fusionanaly.module.plan.observer.listener.ExecutePlanListener;
import com.yw.fusionanaly.module.plan.request.*;
import com.yw.fusionanaly.module.plan.response.PlanSampleStatusResponse;
import com.yw.fusionanaly.module.plan.response.PlanStatusResponse;
import com.yw.fusionanaly.module.plan.response.ValidatesetResponse;
import com.yw.fusionanaly.module.plan.service.PlanSampleService;
import com.yw.fusionanaly.module.plan.service.PlanServiceV2;
import com.yw.fusionanaly.module.plan.type.PlanMethodsType;
import com.yw.fusionanaly.module.plan.type.TopicTypeMethod;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.TimeoutException;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.yw.fusionanaly.module.plan.type.PlanExecuteStatusType.*;
import static com.yw.fusionanaly.module.plan.type.PlanSampleMethodType.toPlanMethodsType;
import static com.yw.fusionanaly.module.plan.type.VariableType.*;

/**
 * @author zhangkun
 * @date 2022/8/17 10:30
 */
@Service
@RequiredArgsConstructor
public class PlanServiceV2Impl implements PlanServiceV2 {

    private final PlanMongoDbDaoV2 planDaoV2;
    private final DisposeFuseDaoV2 disposeFuseV2Dao;
    private final BaseMongoTemplate baseMongoTemplate;
    private final FuseContext fuseContext;
    private final MongoTemplate mongoTemplate;
    private final PlanSampleMongoDbDao planSampleMongoDbDao;
    private final PlanSampleService planSampleService;
    private final EventBusCenter eventBusCenter;
    private final ExecutePlanListener executePlanListener;
    private final DisposeFuseActuatorV2 disposeFuseActuatorV2;
    private final PlanExecuteStatusCacheService cacheService;
    private final AlgorithmFactory factory;
    private final DisposeFuseHelper disposeFuseHelper;
    private final ResultAnalysisService resultAnalysisService;

    @Value("${python.runType}")
    private String pythonRunType;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String createPlan(PlanCreateRequestV2 plan) {
        if (StringUtils.isEmpty(plan.get_id())) {
            plan.set_id(null);
        }

        PlanV2 planEntity = null;
        if (plan.get_id() != null) {
            planEntity = planDaoV2.queryById(plan.get_id());
        }

        // 保存方案
        if (planEntity == null) {
            planEntity = new PlanV2();
            planEntity.setCreateTime(LocalDateTimeTool.dateToDateTimeStr(new Date()));

            String name = plan.getName();
            if (CollUtil.isNotEmpty(planDaoV2.queryByQuery(Query.query(Criteria.where("name").is(name))))) {
                throw new ApiException("方案名称已存在!");
            }
        } else {
            planEntity.setUpdateTime(LocalDateTimeTool.dateToDateTimeStr(new Date()));
        }
        BeanUtil.copyProperties(plan, planEntity, CopyOptions.create().ignoreNullValue());
        planDaoV2.save(planEntity);

        String planId = planEntity.get_id();
        FuseMoldType type = FuseMoldType.getType(plan.getType());
        List<Integer> trunkList = plan.getTrunkList();

        // 刪除组合
        List<FuseCombV2> existsTopicList = disposeFuseV2Dao.listByPlanId(planId);
        List<Integer> existsTopicIdList = existsTopicList.stream().map(FuseCombV2::get_id).collect(Collectors.toList());

        List<PlanCreateRequestV2.TopicRequest> topicList = plan.getTopicList();
        List<Integer> paramTopicIdList = topicList.stream().map(PlanCreateRequestV2.TopicRequest::getId)
                .filter(Objects::nonNull).collect(Collectors.toList());

        existsTopicIdList.removeAll(paramTopicIdList);
        for (Integer topicId : existsTopicIdList) {
            deleteByTopicId(topicId);
        }
        ///

        // 保存组合
        for (PlanCreateRequestV2.TopicRequest topic : topicList) {
            TopicTypeMethod topicTypeMethod = topic.getTopicType();
            List<String> propertiesIdList = topic.getPropertiesIdList();

            if (Objects.isNull(topicTypeMethod)) {
                throw new RuntimeException("主题不存在");
            }

            // 前端配置参数
            Map<Integer, List<String>> chooseMap = topic.getChooseMap();
            Map<Integer, Map<String, FieldEntity>> chooseMaps = getChooseMaps(type);

            for (Map.Entry<Integer, List<String>> entry : chooseMap.entrySet()) {
                int sourceType = entry.getKey();
                List<String> fields = entry.getValue();
                FuseSourceParser sourceParser = fuseContext.getSourceParser(FuseSourceType.getType(sourceType));
                if (sourceParser == null) {
                    continue;
                }
                Map<String, FieldEntity> tableFields = sourceParser.getFieldParam(type, trunkList);

                Map<String, FieldEntity> chooseFieldMap = Maps.newLinkedHashMap();
                // 当组合类型为体系分析时使用
                if (sourceType == FuseSourceType.EQUIPMENT.getId() && (type == FuseMoldType.EQUIPMENT_SYSTEM_CENSUS || type == FuseMoldType.EQUIPMENT_SYSTEM_TREND)) {
                    for (String field : fields) {
                        if (chooseFieldMap.get(field) != null) {
                            continue;
                        }
                        //选择的参数
                        FieldEntity entity = tableFields.get(field);
                        if (entity != null) {
                            String name = entity.getName(); // 装备参数名称
                            String belongToName = entity.getBelongToName();
                            if (!StringUtils.isEmpty(belongToName)) {
                                belongToName = belongToName + "_" + name;
                                entity.setName(belongToName);
                                entity.setFieldName(name);
                            }
                            for (Map.Entry<String, FieldEntity> fieldMap : tableFields.entrySet()) {
                                String key = fieldMap.getKey();
                                if (CollUtil.isNotEmpty(propertiesIdList) && !propertiesIdList.contains(key)) {
                                    continue;
                                }

                                if (!key.equals(field)) {
                                    FieldEntity value = fieldMap.getValue();
                                    String valueName = value.getName();
                                    if (name.equals(valueName)) {
                                        if (chooseFieldMap.get(value.getField()) != null) {
                                            continue;
                                        }
                                        String fieldBelongToName = value.getBelongToName();
                                        if (!StringUtils.isEmpty(fieldBelongToName)) {
                                            valueName = fieldBelongToName + "_" + valueName;
                                            value.setName(valueName);
                                            value.setFieldName(name);
                                        }
                                        chooseFieldMap.put(key, value);
                                    }
                                } else {
                                    chooseFieldMap.put(field, entity);
                                }
                            }
                        }
                    }
                    chooseMaps.put(sourceType, chooseFieldMap);
                    continue;
                }
                for (Map.Entry<String, FieldEntity> entity : tableFields.entrySet()) {
                    entity.getValue().setFieldName(entity.getValue().getName());
                    if (fields.contains(entity.getKey())) {
                        chooseFieldMap.put(entity.getKey(), entity.getValue());
                        continue;
                    }
                    if (sourceType == FuseSourceType.EVALUATION.getId()) {
                        Collection<FieldEntity> childList = entity.getValue().getChildField();
                        for (Iterator<FieldEntity> iterable = childList.iterator(); iterable.hasNext(); ) {
                            FieldEntity childEntity = iterable.next();
                            Collection<FieldEntity> childField = childEntity.getChildField();
                            if (childField != null) {
                                for (Iterator<FieldEntity> childFields = childField.iterator(); childFields.hasNext(); ) {
                                    FieldEntity next = childFields.next();
                                    if (fields.contains(next.getField())) {
                                        String name = next.getName();
                                        next.setName(childEntity.getName() + "-" + name);
                                        next.setFieldName(name);
                                        chooseFieldMap.put(next.getField(), next);
                                    }
                                }
                            }
                        }
                    }
                    Collection<FieldEntity> childList = entity.getValue().getChildField();
                    if (CollUtil.isNotEmpty(childList)) {
                        for (Iterator<FieldEntity> iterable = childList.iterator(); iterable.hasNext(); ) {
                            FieldEntity childEntity = iterable.next();
                            if (!fields.contains(childEntity.getField())) {
                                iterable.remove();
                            }
                        }
                    }
                    if (CollUtil.isNotEmpty(childList)) {
                        chooseFieldMap.put(entity.getKey(), entity.getValue());
                    }

                }
                chooseMaps.put(sourceType, chooseFieldMap);

            }
            List<PlanMethodsType> methods = topicTypeMethod.getMethods();
            FuseCombV2 fuseComb = disposeFuseV2Dao.createFuseComb(topic.getId(), type, topic.getTopicName(), topic.getTopicType(), topic.getDescription(), chooseMaps, methods, planId, trunkList);
            // 不是之前的主题类型，删除
            if (!fuseComb.getTopicType().equals(topicTypeMethod)) {
                deleteSampleByTopicId(topic.getId());
            }
            fuseComb.setTrunkList(trunkList);
            fuseComb.setType(type.getId());
            //执行融合
            disposeFuseActuatorV2.doProcess(fuseComb);
        }
        return planId;
    }

    private void deleteByTopicId(Integer topicId) {
        // 删除fuse_comb
        disposeFuseV2Dao.deleteById(topicId);
        // 删除fuse_specimen
        deleteSpecimenByTopicId(topicId);
        // 删除样本
        deleteSampleByTopicId(topicId);
    }

    public void deleteSampleByTopicId(Integer topicId) {
        mongoTemplate.remove(Query.query(Criteria.where("basesetId").is(String.valueOf(topicId))), PlanSample.class);
    }

    private void deleteSpecimenByTopicId(Integer topicId) {
        FuseCombV2 fuseCombV2 = mongoTemplate.findById(topicId, FuseCombV2.class);
        if (fuseCombV2 != null) {
            mongoTemplate.dropCollection(fuseCombV2.getCollectionName());
        }
    }

    /**
     * 删除方案下fuse_comb数据和fuse_specimen表
     *
     * @param planId 方案id
     */
    private void deleteFuseByPlanId(String planId) {
        // 删除fuse_specimen
        deleteSpecimenByPlanId(planId);
        // 删除fuse_comb
        disposeFuseV2Dao.deleteByPlanId(planId);
        // 删除样本
        planSampleMongoDbDao.deleteByPlanId(planId);
    }

    /**
     * 删除方案下fuse_specimen表
     *
     * @param planId 方案id
     */
    private void deleteSpecimenByPlanId(String planId) {
        List<FuseCombV2> fuseCombV2List = disposeFuseV2Dao.queryFuseByPlanId(planId);
        List<String> collectionNameList = fuseCombV2List.stream().map(FuseCombV2::getCollectionName).collect(Collectors.toList());
        collectionNameList.forEach(mongoTemplate::dropCollection);
    }

    private Map<Integer, Map<String, FieldEntity>> getChooseMaps(FuseMoldType type) {
        Map<Integer, Map<String, FieldEntity>> chooseMaps = Maps.newLinkedHashMap();
        Collection<FuseSourceType> sourceTypes = type.getSourceTypes();
        sourceTypes.forEach(s -> {
            chooseMaps.put(s.getId(), Maps.newLinkedHashMap());
        });
        return chooseMaps;
    }

    @Override
    public void deletePlanById(String id) {
        baseMongoTemplate.delete(id, PlanV2.class);
        deleteFuseByPlanId(id);
    }

    /**
     * @param id 方案id
     * @return
     */
    @Override
    public PlanV2 getPlanTree(String id) {
        PlanV2 planV2 = planDaoV2.queryById(id);
        List<FuseCombV2> fuseCombV2List = disposeFuseV2Dao.queryFuseByPlanId(id);
        if (CollUtil.isEmpty(fuseCombV2List)) {
            return planV2;
        }
        List<PlanSample> planSampleList = planSampleService.getPlanSampleByPlanId(id);
        for (FuseCombV2 fuseCombV2 : fuseCombV2List) {
            List<PlanSample> samples = planSampleList.stream().filter(s -> s.getBasesetId().equals(String.valueOf(fuseCombV2.get_id()))).collect(Collectors.toList());
            fuseCombV2.setPlanSampleList(samples);
        }
        planV2.setTopicList(fuseCombV2List);
        return planV2;
    }

    /**
     * 分页获取方案
     *
     * @param name     的名字
     * @param pageSize 页面大小
     * @param pageNum  页面num
     * @return {@link PageResult}<{@link Plan}>
     */
    @Override
    public PageResult<PlanV2> getPlanByPage(String name, Integer pageSize, Integer pageNum) {
        PlanV2 plan = new PlanV2();
        if (pageSize == 0 && pageNum == 0) {
            PageResult<PlanV2> result = new PageResult<>();
            Query query = new Query();
            query.with(Sort.by(
                    Sort.Order.desc("updateTime")
            ));
            List<PlanV2> plans = planDaoV2.queryByQuery(query);
            result.setList(plans);
            result.setTotal((long) plans.size());
            return result;
        }
        if (StrUtil.isNotEmpty(name)) {
            String n = MongodbStringUtil.escapeQueryChars(name);
            plan.setName(n);
            return planDaoV2.getPage(plan, pageNum, pageSize);
        }
        return planDaoV2.getPage(plan, pageNum, pageSize);
    }

    @Override
    public YwResult getValidationset(GetValidationsetRequest request) {
        String planId = request.getPlanId();
        String sampleId = request.getSampleId();
        PlanSample sample = planSampleService.getPlanSampleByPlanIdAndId(planId, sampleId);
        if (!Objects.equals(sample, null)) {
            ValidatesetResponse response = new ValidatesetResponse();
            response.setSampleId(sample.getId());
            response.setSampleName(sample.getName());
            List<PlanSampleExecuteRequest> params = sample.getParams();
            //是否已经配置验证集
            boolean isSetValidate = params.stream().filter(p -> p.getType() == VALIDATESET)
                    .anyMatch(t -> {
                        boolean b = false;
                        if (null != t.getData()) {
                            b = t.getData().size() > 0 ? true : false;
                        }
                        if (null != t.getStrData()) {
                            b = t.getData().size() > 0 ? true : false;
                        }
                        return b;
                    });
            List<PlanSampleExecuteRequest> validateset;
            if (isSetValidate) {
                validateset = params.stream().filter(p -> p.getType() == VALIDATESET).collect(Collectors.toList());
            } else {
                validateset = params.stream().filter(t -> INDEPENDENT == t.getType() || NORMAL == t.getType()).collect(Collectors.toList());
            }
            List<ValidatesetRequest> requests = validateset.stream().map(p -> {
                ValidatesetRequest validatesetRequest = new ValidatesetRequest();
                validatesetRequest.setName(p.getName());
                validatesetRequest.setDesc(p.getDesc());
                validatesetRequest.setData(p.getData());
                validatesetRequest.setStrData(p.getStrData());
                return validatesetRequest;
            }).collect(Collectors.toList());
            response.setValidatesetRequests(requests);
            return ResultUtil.success(response);
        }
        return ResultUtil.fail("该样本不存在！");
    }

    @Override
    public Object preExecute(PreExecuteRequest request) {
        disposeFuseHelper.checkFuseDataStatusHandler(request.getTopicId());

        // 如果是关联挖掘直接用主题的所有数据
        if (PlanMethodsType.ASSOCIATIONMINING_ANALYSIS.name().equals(request.getMethodId())) {
            FuseCombResponseV2 fuseCombData = disposeFuseV2Dao.getFuseCombData(request.getTopicId());

            FuseSpecimen fuseSpecimen = mongoTemplate.findById("1", FuseSpecimen.class, String.format(DisposeFuseDaoV2Impl.BASE_NAME, request.getTopicId()));
            Map<String, Object> fuseData = fuseSpecimen.getFuseData();

            Map<Integer, Map<String, Object>> chooseMap = fuseCombData.getChooseMap();
            Map<String, Object> stringObjectMap = chooseMap.get(5);

            List<PlanSampleExecuteRequest> paramsList = Lists.newArrayList();

            for (Map.Entry<String, Object> map : stringObjectMap.entrySet()) {

                String field = map.getKey();
                String name = map.getValue().toString();

                PlanSampleExecuteRequest planSampleExecuteRequest = new PlanSampleExecuteRequest();
                planSampleExecuteRequest.setType(NORMAL);
                planSampleExecuteRequest.setName(name);
                planSampleExecuteRequest.setDesc(name);

                String data = fuseData.get(field).toString();
                String[] strData = JSON.parseArray(data).toArray(new String[]{});
                planSampleExecuteRequest.setStrData(strData);
                paramsList.add(planSampleExecuteRequest);
            }

            request.getSrcSample().setParams(paramsList);

        }

        ExecutePlanEvent executePlanEvent = ExecutePlanEvent.builder()
                .previewFlag(true)
                .srcSample(request.getSrcSample())
                .planId(request.getPlanId())
                .topicId(request.getTopicId())
                .sampleId(String.valueOf(request.getTopicId()))
                .build();

        PlanExecuteResultResponse response = (PlanExecuteResultResponse) executePlanListener.excute(executePlanEvent);
        try {
            JSONObject obj = JSON.parseObject(response.getResult());
            obj.put("type", response.getType());
            return obj;
        } catch (Exception e) {
            e.printStackTrace();
            throw new ApiException(response.getResult());
        }
    }

    /**
     * 获取主题下面所有的方法执行结果
     *
     * @param topicId 主题id
     */
    @Override
    public YwResult<Object> getPlanResultByTopic(String topicId) {
        List<PlanSample> planSampleList = planSampleService.getPlanSampleByFuseId(topicId);
        return ResultUtil.success(planSampleList);
    }

    @Override
    public void cancelPlan(PlanTaskStopRequest request) throws IOException, InterruptedException, TimeoutException {
        String planId = request.getPlanId();
        List<String> sampleIds = request.getSampleIds();
        for (String sampleId : sampleIds) {
            cacheService.set(sampleId, CANCELING);
            PlanStatusResponse planStatusResponse = new PlanStatusResponse().setPlanId(planId).setSampleId(sampleId).setStatus(CANCELING);
            cacheService.set(planId + sampleId, planStatusResponse);
        }
        for (String sampleId : sampleIds) {
            String cacheId = planId + sampleId;
            PlanStatusResponse status = (PlanStatusResponse) cacheService.get(cacheId);
            //运行状态才可以取消
            if (null != status) {
                if (status.getStatus() == RUNNING) {
                    PlanSample s = planSampleService.getPlanSampleByPlanIdAndId(planId, sampleId);

                    if (s != null) {
                        AlgorithmStrategy algorithm = factory.getAlgorithm(s);
                        if (Objects.equals(pythonRunType, "remote")) {
                            algorithm.cancelRemote(planId, sampleId);
                        } else {
                            algorithm.cancelLocal(planId, sampleId);
                        }
                    }
                }
            }
        }
    }

    @Override
    public YwResult<JSONObject> getPlanStatus(PlanTaskSearchRequest request) {
        //todo 待优化
//        String topicId = request.getTopicId();
//        List<PlanSample> samples = planSampleService.getPlanSampleByFuseId(topicId);

        String planId = request.getPlanId();
        List<PlanSample> samples = planSampleService.getPlanSampleByPlanId(planId);

        List<PlanStatusResponse> statusResponseList = new ArrayList<>();
        for (PlanSample sample : samples) {
            String sampleId = sample.getId();
            PlanMethodsType planMethodsType = toPlanMethodsType(sample.getType());
            String cacheId = sample.getPlanId() + sampleId;
            PlanStatusResponse status = cacheService.get(cacheId);
            if (status == null) {
                PlanStatusResponse planStatusResponse = new PlanStatusResponse().setPlanId(sample.getPlanId()).setSampleId(sampleId).setType(planMethodsType);
                if ((sample.getResult() == null ||
                        org.apache.commons.lang3.StringUtils.isBlank((String) sample.getResult()))) {
                    planStatusResponse.setStatus(NOTSTART);
                } else {
                    planStatusResponse.setStatus(SUCCESS);
                }
                statusResponseList.add(planStatusResponse);
                continue;
            }
            statusResponseList.add(status);
        }
        List<PlanStatusResponse> collect = statusResponseList.stream().filter(item -> !Objects.equals(item.getStatus(), NOTSTART)).collect(Collectors.toList());
        Function<PlanStatusResponse, PlanMethodsType> key = PlanStatusResponse::getType;
        Function<PlanStatusResponse, PlanSampleStatusResponse> value = response -> {
            PlanSampleStatusResponse planSampleStatusResponse = new PlanSampleStatusResponse();
            planSampleStatusResponse.setSampleId(response.getSampleId()).setStatus(response.getStatus())
                    .setMsg(response.getMsg());
            return planSampleStatusResponse;
        };
        JSONObject jsonObject = new JSONObject();
//        Map<PlanMethodsType, Set<PlanSampleStatusResponse>> map = ListToMapUtil.oneToManyMap(collect, key, value);
        jsonObject.put("list", statusResponseList);
        boolean allSamplesFinished = collect.stream().allMatch(item -> Objects.equals(item.getStatus(), SUCCESS) || Objects.equals(item.getStatus(), FAIL)
                || Objects.equals(item.getStatus(), CANCEL) || Objects.equals(item.getStatus(), CANCELING));
        if (statusResponseList.size() > 0 && !allSamplesFinished) {
            jsonObject.put("startTimer", true);
        } else {
            jsonObject.put("startTimer", false);
        }
        return ResultUtil.success(jsonObject);
    }

    @Override
    public void executePlan(PlanTaskStartRequest request) {
        String planId = request.getPlanId();
        List<String> sampleIds = request.getSampleIds();

        if (CollUtil.isEmpty(sampleIds)) {
            List<PlanSample> planSampleByPlanId = planSampleService.getPlanSampleByPlanId(planId);
            sampleIds = planSampleByPlanId.stream().map(PlanSample::getId).collect(Collectors.toList());
        }

        if (CollUtil.isNotEmpty(sampleIds)) {
            for (String sampleId : sampleIds) {
                ExecutePlanEvent executePlanEvent = ExecutePlanEvent.builder().planId(planId).sampleId(sampleId).build();
                eventBusCenter.postAsync(executePlanEvent);
            }
        }
    }

    @Override
    public YwResult<PlanSample> getPlanResultById(String sampleId) {
        PlanSample planSample = mongoTemplate.findById(sampleId, PlanSample.class);
        if (planSample == null) {
            throw new ApiException("样本不存在");
        }
        // 推论和结论数据
        AbstractResultAnalysisVO result = resultAnalysisService.getResultBySampleId(sampleId);
        planSample.setResultAll(result);
        return ResultUtil.success(planSample);
    }
}
